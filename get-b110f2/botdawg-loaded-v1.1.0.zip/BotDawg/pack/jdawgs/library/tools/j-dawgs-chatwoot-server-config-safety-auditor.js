'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Chatwoot Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers are part of the test) ---------- */

      var RISKY_LINES = [
        "# Risky example - a Chatwoot production config with real problems",
        "SECRET_KEY_BASE=supersecret",
        "FRONTEND_URL=http://chat.example.com",
        "REDIS_URL=redis://:redispass123@redis:6379",
        "POSTGRES_HOST=postgres",
        "POSTGRES_USERNAME=postgres",
        "POSTGRES_PASSWORD=postgres",
        "DATABASE_URL=postgres://postgres:dbpass999@postgres:5432/chatwoot",
        "ENABLE_ACCOUNT_SIGNUP=true",
        "SMTP_ADDRESS=smtp.example.net",
        "SMTP_PORT=587",
        "SMTP_USER_NAME=alerts@example.com",
        "SMTP_PASSWORD=short1",
        "ACTIVE_STORAGE_SERVICE=local",
        "this line is not a config line"
      ];
      var RISKY_EXAMPLE = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hardened example - the same config with every problem fixed",
        "RAILS_ENV=production",
        "SECRET_KEY_BASE=7f3a9c1e5b8d2046f7a1c9e3b5d7082946a1c3e5f7b9d20486a3c5e7f9012b4d",
        "FRONTEND_URL=https://chat.example.com",
        "REDIS_URL=redis://redis:6379",
        "POSTGRES_HOST=postgres",
        "POSTGRES_USERNAME=chatwoot",
        "POSTGRES_PASSWORD=${POSTGRES_PASSWORD_FROM_VAULT}",
        "DATABASE_URL=postgres://chatwoot@postgres:5432/chatwoot_production",
        "ENABLE_ACCOUNT_SIGNUP=false",
        "FORCE_SSL=true",
        "SESSION_COOKIE_SECURE=true",
        "SMTP_ADDRESS=smtp.example.net",
        "SMTP_PORT=587",
        "SMTP_USER_NAME=${SMTP_USER_FROM_VAULT}",
        "SMTP_PASSWORD=${SMTP_PASSWORD_FROM_VAULT}",
        "ACTIVE_STORAGE_SERVICE=amazon",
        "S3_BUCKET_NAME=chatwoot-uploads-prod",
        "MAILER_SENDER_EMAIL=Chatwoot <support@example.com>"
      ];
      var HARDENED_EXAMPLE = HARDENED_LINES.join("\n");

      /* Secrets planted in the examples. The self-test proves these strings
         appear 0 times in the generated report and JSON. */
      var PLANTED_SECRETS = ["supersecret", "redispass123", "dbpass999", "short1",
        "7f3a9c1e5b8d2046f7a1c9e3b5d7082946a1c3e5f7b9d20486a3c5e7f9012b4d"];

      /* ---------- Parsing ---------- */

      var KNOWN_KEYS = {};
      ("SECRET_KEY_BASE FRONTEND_URL REDIS_URL REDIS_PASSWORD POSTGRES_HOST POSTGRES_PORT " +
       "POSTGRES_USERNAME POSTGRES_PASSWORD POSTGRES_DATABASE DATABASE_URL SMTP_ADDRESS SMTP_PORT " +
       "SMTP_USER_NAME SMTP_PASSWORD SMTP_DOMAIN SMTP_AUTHENTICATION SMTP_ENABLE_STARTTLS_AUTO " +
       "ENABLE_ACCOUNT_SIGNUP ACTIVE_STORAGE_SERVICE S3_BUCKET_NAME AWS_ACCESS_KEY_ID " +
       "AWS_SECRET_ACCESS_KEY MAILER_SENDER_EMAIL DEFAULT_LOCALE RAILS_ENV INSTALLATION_ENV " +
       "NODE_ENV FORCE_SSL SESSION_COOKIE_SECURE WEB_CONCURRENCY SIDEKIQ_CONCURRENCY " +
       "INSTALLATION_NAME LOG_LEVEL").split(" ").forEach(function (k) { KNOWN_KEYS[k] = true; });

      var COMMON_PASSWORDS = ["password", "postgres", "redis", "admin", "letmein", "changeme",
        "secret", "123456", "12345678", "qwerty", "chatwoot", "default", "root"];

      function stripQuotes(v) {
        v = v.trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }

      function isReference(v) {
        return /\$\{[^}]+\}/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v);
      }

      function parseConfig(text) {
        var entries = [];
        var notParsed = [];
        var rawLines = String(text == null ? "" : text).split(/\r?\n/);
        rawLines.forEach(function (raw, i) {
          var lineNo = i + 1;
          var t = raw.trim();
          if (t === "") return;
          if (t.charAt(0) === "#") return;
          var s = t;
          if (s.indexOf("- ") === 0) s = s.slice(2).trim();
          if (/^export\s+/.test(s)) s = s.replace(/^export\s+/, "");
          var m = s.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
          if (m) {
            entries.push({ line: lineNo, key: m[1].toUpperCase(), value: stripQuotes(m[2]) });
          } else {
            notParsed.push(lineNo);
          }
        });
        return { entries: entries, notParsed: notParsed };
      }

      function urlScheme(v) {
        var m = v.match(/^([A-Za-z][A-Za-z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : null;
      }
      function urlHost(v) {
        var m = v.match(/^[A-Za-z][A-Za-z0-9+.-]*:\/\/(?:[^\/@]*@)?([^\/:?#]+)/);
        return m ? m[1].toLowerCase() : null;
      }
      function urlPassword(v) {
        var m = v.match(/^[A-Za-z][A-Za-z0-9+.-]*:\/\/[^\/:@]*:([^@\/]*)@/);
        return m ? m[1] : null;
      }
      function exampleLike(v) {
        return /(example|change[-_ ]?me|placeholder|insert[-_ ]|replace[-_ ]|your[-_ ]|todo|xxx+)/i.test(v);
      }
      function isCommonPassword(v) {
        return COMMON_PASSWORDS.indexOf(v.toLowerCase()) !== -1;
      }
      function truthy(v) { return /^(true|1|yes|on)$/i.test(v.trim()); }
      function falsy(v) { return /^(false|0|no|off)$/i.test(v.trim()); }

      /* ---------- The audit ---------- */

      function auditConfig(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, line, key, message, fix) {
          findings.push({ severity: severity, line: line, key: key, message: message, fix: fix });
        }

        var byKey = {};
        parsed.entries.forEach(function (e) {
          if (byKey[e.key]) {
            add("WARNING", e.line, e.key,
              e.key + " is set more than once in this config. Which value the server uses depends on load order, so the value you think is live may not be.",
              "Keep exactly one line for " + e.key + " and delete the others.");
          }
          byKey[e.key] = e;
        });

        parsed.notParsed.forEach(function (lineNo) {
          add("INFO", lineNo, "NOT PARSED",
            "Line " + lineNo + " is not a KEY=VALUE line, so it was skipped. If it was meant to be a setting, the server will never see it. (The line's content is not shown here on purpose, in case it holds a secret.)",
            "Rewrite the line as KEY=VALUE, or delete it if it is a stray note.");
        });

        var recognized = 0;
        Object.keys(byKey).forEach(function (k) { if (KNOWN_KEYS[k]) recognized++; });

        var envEntry = byKey["RAILS_ENV"] || byKey["INSTALLATION_ENV"] || byKey["NODE_ENV"];
        var production = true;
        if (envEntry && /^(development|dev|test)$/i.test(envEntry.value.trim())) production = false;

        /* SECRET_KEY_BASE */
        var skb = byKey["SECRET_KEY_BASE"];
        if (!skb) {
          if (recognized >= 3) {
            add("BLOCKER", null, "SECRET_KEY_BASE",
              "SECRET_KEY_BASE is not set anywhere in this config. Chatwoot uses it to sign sessions and tokens; without a strong one the server either refuses to boot or runs with a guessable signing key.",
              "Generate a long random value (64 or more characters, e.g. from a password manager or `openssl rand -hex 64`) and set SECRET_KEY_BASE to it. Never reuse one across servers.");
          }
        } else if (!isReference(skb.value)) {
          if (skb.value.length < 32) {
            add("BLOCKER", skb.line, "SECRET_KEY_BASE",
              "SECRET_KEY_BASE on line " + skb.line + " is only " + skb.value.length + " characters long. A short signing key can be brute-forced, and anyone who guesses it can forge signed session data. (The value itself is never shown in this report.)",
              "Replace it with a random value of at least 64 characters and restart the server. Treat the old value as compromised.");
          } else if (exampleLike(skb.value)) {
            add("BLOCKER", skb.line, "SECRET_KEY_BASE",
              "SECRET_KEY_BASE on line " + skb.line + " looks like a copied example or placeholder value (" + skb.value.length + " characters). Example values are public knowledge — anyone who has seen the sample config knows your signing key.",
              "Replace it with a freshly generated random value of at least 64 characters that appears in no example, doc, or repo.");
          } else if (skb.value.length < 64) {
            add("WARNING", skb.line, "SECRET_KEY_BASE",
              "SECRET_KEY_BASE on line " + skb.line + " is " + skb.value.length + " characters — long enough to pass, but below the 64-character random value Chatwoot deployments are expected to use.",
              "Rotate it to a random value of 64 or more characters at your next maintenance window.");
          }
        }

        /* FRONTEND_URL */
        var fu = byKey["FRONTEND_URL"];
        if (!fu) {
          if (recognized >= 3) {
            add("INFO", null, "FRONTEND_URL",
              "FRONTEND_URL is not set in this config. Chatwoot builds password-reset links, email links, and redirects from it, so a missing or wrong value breaks those quietly.",
              "Set FRONTEND_URL to the exact public https address users open, with no trailing path.");
          }
        } else {
          var scheme = urlScheme(fu.value);
          var host = urlHost(fu.value);
          if (scheme === "http") {
            add(production ? "HIGH" : "INFO", fu.line, "FRONTEND_URL",
              "FRONTEND_URL on line " + fu.line + " uses http, not https" + (production ? ", and this config is graded in production posture" : "") + ". Logins, session cookies, and password-reset links would travel unencrypted, and Chatwoot will build every emailed link on http.",
              "Put the server behind https (a reverse proxy with a real certificate is fine) and set FRONTEND_URL to the https address.");
          } else if (!scheme) {
            add("WARNING", fu.line, "FRONTEND_URL",
              "FRONTEND_URL on line " + fu.line + " has no scheme (http:// or https://), so links Chatwoot builds from it can come out broken or relative.",
              "Write the full address including https://, e.g. FRONTEND_URL=https://chat.example.com.");
          }
          if (host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1") {
            add(production ? "HIGH" : "WARNING", fu.line, "FRONTEND_URL",
              "FRONTEND_URL on line " + fu.line + " points at localhost. That only resolves on the server itself — every link Chatwoot emails to a user (password resets, notifications) would point at the user's own machine and fail.",
              "Set FRONTEND_URL to the public domain name users actually open in their browser.");
          }
        }

        /* Plaintext passwords inside connection URLs */
        ["REDIS_URL", "DATABASE_URL"].forEach(function (key) {
          var e = byKey[key];
          if (!e) return;
          var pw = urlPassword(e.value);
          if (pw !== null && pw !== "" && !isReference(pw)) {
            if (pw.length < 12 || isCommonPassword(pw)) {
              add("HIGH", e.line, key,
                key + " on line " + e.line + " embeds a plaintext password that is weak — " + pw.length + " characters, or a commonly used value. Anyone who can read this config file (a repo, a backup, a screenshot) owns that password. (The password itself is never shown here.)",
                "Give the service a long random password (16+ characters), store it in a secrets manager or vault reference instead of the raw URL, and rotate the old one.");
            } else {
              add("WARNING", e.line, key,
                key + " on line " + e.line + " embeds a plaintext password (" + pw.length + " characters) directly in the URL. The password is reasonably long, but it sits in clear text wherever this file is copied, committed, or backed up. (The password itself is never shown here.)",
                "Move the password into a secrets manager or an environment reference (for example a ${...} vault reference) so the config file alone does not disclose it, and rotate it if the file was ever shared.");
            }
          }
        });

        /* Standalone database password */
        var pgpw = byKey["POSTGRES_PASSWORD"];
        if (pgpw && !isReference(pgpw.value) && pgpw.value !== "") {
          if (isCommonPassword(pgpw.value) || pgpw.value.length < 12) {
            add("HIGH", pgpw.line, "POSTGRES_PASSWORD",
              "POSTGRES_PASSWORD on line " + pgpw.line + " is weak — " + pgpw.value.length + " characters, or a commonly used value like a default. Database defaults are the first thing an attacker tries. (The value itself is never shown here.)",
              "Set a long random database password (16+ characters), update it everywhere the app connects, and restart.");
          } else {
            add("WARNING", pgpw.line, "POSTGRES_PASSWORD",
              "POSTGRES_PASSWORD on line " + pgpw.line + " is stored in plaintext in this file (" + pgpw.value.length + " characters). Anyone who can read the file has the database password. (The value itself is never shown here.)",
              "Pull it from a secrets manager or vault reference instead of the raw file where your setup allows, and rotate it if the file was ever shared.");
          }
        }

        /* Open account signup */
        var signup = byKey["ENABLE_ACCOUNT_SIGNUP"];
        if (signup && truthy(signup.value)) {
          add("HIGH", signup.line, "ENABLE_ACCOUNT_SIGNUP",
            "ENABLE_ACCOUNT_SIGNUP is true on line " + signup.line + ". Anyone on the internet can create an account on your support desk — and on a fresh install, early signups can claim the workspace before your team does. Open signup also invites spam accounts into your help desk.",
            "Set ENABLE_ACCOUNT_SIGNUP=false and invite your agents from the admin panel instead. Only turn it on briefly, on purpose, if you truly run open registration.");
        }

        /* SMTP credentials */
        var smtppw = byKey["SMTP_PASSWORD"];
        if (smtppw && !isReference(smtppw.value) && smtppw.value !== "") {
          if (smtppw.value.length < 12) {
            add("HIGH", smtppw.line, "SMTP_PASSWORD",
              "SMTP_PASSWORD on line " + smtppw.line + " is plaintext and short — " + smtppw.value.length + " characters. A short mail password is easy to brute-force, and a stolen one lets an attacker send mail as your support address. (The value itself is never shown here.)",
              "Use the longest app password / API key your mail provider offers (16+ characters), store it as a secrets reference, and rotate the short one now.");
          } else {
            add("WARNING", smtppw.line, "SMTP_PASSWORD",
              "SMTP_PASSWORD on line " + smtppw.line + " is stored in plaintext in this file (" + smtppw.value.length + " characters). Anyone who can read the file can send mail as your support address. (The value itself is never shown here.)",
              "Store it as a secrets-manager or vault reference instead of the raw value, and rotate it if the file was ever shared.");
          }
        }
        if (byKey["SMTP_USER_NAME"] && !smtppw && recognized >= 3) {
          add("INFO", byKey["SMTP_USER_NAME"].line, "SMTP_PASSWORD",
            "An SMTP user name is set on line " + byKey["SMTP_USER_NAME"].line + " but no SMTP_PASSWORD appears in this config. That is fine if the password is injected at deploy time — just confirm it really is, or outgoing mail will fail authentication.",
            "Confirm the SMTP password is supplied by your deploy system or secrets manager; if it is not, add it as a reference (not a raw value).");
        }

        /* Force-SSL / secure-cookie posture */
        var forceSsl = byKey["FORCE_SSL"];
        var secureCookie = byKey["SESSION_COOKIE_SECURE"];
        if (forceSsl && falsy(forceSsl.value)) {
          add("HIGH", forceSsl.line, "FORCE_SSL",
            "FORCE_SSL is turned off on line " + forceSsl.line + ". The server will happily serve logins over plain http, where session cookies can be read off the wire.",
            "Set FORCE_SSL=true (with https in FRONTEND_URL) so every request is pushed onto an encrypted connection.");
        }
        if (secureCookie && falsy(secureCookie.value)) {
          add("HIGH", secureCookie.line, "SESSION_COOKIE_SECURE",
            "SESSION_COOKIE_SECURE is turned off on line " + secureCookie.line + ". Session cookies can then be sent over unencrypted connections and stolen.",
            "Set SESSION_COOKIE_SECURE=true so session cookies only ever travel over https.");
        }
        if (!forceSsl && !secureCookie && recognized >= 3) {
          add("INFO", null, "FORCE_SSL",
            "Neither FORCE_SSL nor SESSION_COOKIE_SECURE appears in this config, so the secure-cookie / force-SSL posture is not declared here. It may be handled by your reverse proxy — but if it is not handled anywhere, sessions can leak onto plain http.",
            "Confirm https is enforced (proxy or app). If the app is responsible, set FORCE_SSL=true and SESSION_COOKIE_SECURE=true.");
        }

        /* File storage on local disk */
        var storage = byKey["ACTIVE_STORAGE_SERVICE"];
        if (storage && /^(local|disk|filesystem)$/i.test(storage.value.trim())) {
          add("WARNING", storage.line, "ACTIVE_STORAGE_SERVICE",
            "ACTIVE_STORAGE_SERVICE on line " + storage.line + " stores uploaded files on the server's local disk. Attachments your customers send live and die with that one machine — a rebuild, a moved container, or a dead disk takes them with it.",
            "Point ACTIVE_STORAGE_SERVICE at object storage (for example S3) with its own bucket, so uploads survive the server.");
        }

        /* Other plaintext secrets sitting in the file */
        var awsSecret = byKey["AWS_SECRET_ACCESS_KEY"];
        if (awsSecret && !isReference(awsSecret.value) && awsSecret.value !== "") {
          add("WARNING", awsSecret.line, "AWS_SECRET_ACCESS_KEY",
            "AWS_SECRET_ACCESS_KEY on line " + awsSecret.line + " is a live cloud credential stored in plaintext in this file (" + awsSecret.value.length + " characters). A leaked copy can run up real charges. (The value itself is never shown here.)",
            "Move it into a secrets manager or an instance role, and rotate the key if this file was ever committed or shared.");
        }

        /* Verdict */
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (recognized < 3) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0 || counts.HIGH >= 2) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH === 1 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        var sevRank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        return {
          verdict: verdict,
          recognizedKeys: recognized,
          parsedLines: parsed.entries.length,
          notParsedLines: parsed.notParsed.slice(),
          counts: counts,
          findings: findings
        };
      }

      /* ---------- Report + JSON builders (never contain secret values) ---------- */

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Chatwoot Server Config Safety Auditor - audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Parsed KEY=VALUE lines: " + result.parsedLines +
          " | Recognizable Chatwoot keys: " + result.recognizedKeys +
          " | Lines not parsed: " + (result.notParsedLines.length ? result.notParsedLines.join(", ") : "none"));
        out.push("Findings: " + result.findings.length +
          " (BLOCKER " + result.counts.BLOCKER +
          ", HIGH " + result.counts.HIGH +
          ", WARNING " + result.counts.WARNING +
          ", INFO " + result.counts.INFO + ")");
        out.push("Secrets are reported by key name, line, and length only - no secret value appears in this report.");
        out.push("");
        if (!result.findings.length) {
          out.push("No findings. Every check passed on the pasted config.");
        } else {
          result.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.severity + "] " +
              (f.line == null ? "Config-wide" : "Line " + f.line) + " - " + f.key);
            out.push("   " + f.message);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        out.push("Scope: offline text audit of a pasted config. This report does not verify the config will start, and nothing was uploaded or saved.");
        return out.join("\n");
      }

      function buildJson(result) {
        return JSON.stringify({
          tool: "J-Dawgs Chatwoot Server Config Safety Auditor",
          verdict: result.verdict,
          recognizedChatwootKeys: result.recognizedKeys,
          parsedLines: result.parsedLines,
          notParsedLines: result.notParsedLines,
          counts: result.counts,
          findings: result.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, message: f.message, fix: f.fix };
          }),
          note: "Secrets are reported by key name, line, and length only. No secret value is included in this export."
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-chatwoot-server-config-safety-auditor',
  name: 'J-Dawgs Chatwoot Server Config Safety Auditor',
  description: 'Grades a pasted Chatwoot server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
