'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Calibre Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */

      var RISKY_EXAMPLE = [
        "# RISKY worked example — a calibre-web style setup with live problems. Do not deploy this.",
        "calibre-server --port 8080 --listen-on 0.0.0.0 --disable-auth",
        "SECRET_KEY=abc123",
        "SESSION_SECRET=short",
        "DATABASE_PASSWORD=dbpass-rocket-42",
        "SMTP_PASSWORD=Tr0picThunder!99",
        "OAUTH_CLIENT_SECRET=oauth-secret-value-1234",
        "admin_username: admin",
        "admin_password: admin",
        "ALLOW_PUBLIC_REGISTRATION=true",
        "ALLOW_ANONYMOUS_UPLOADS=true",
        "TRUSTED_IPS=0.0.0.0/0",
        "BASE_URL=http://books.example.org",
        "DEBUG=true"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# HARDENED worked example — secrets come from the environment, never from this file.",
        "# Public traffic reaches this server only through a reverse proxy that terminates HTTPS.",
        "calibre-server --port 8083 --listen-on 127.0.0.1 --enable-auth --auth-mode basic",
        "SECRET_KEY=\${CALIBRE_SECRET_KEY}",
        "SESSION_SECRET=\${CALIBRE_SESSION_SECRET}",
        "DATABASE_PASSWORD=\${CALIBRE_DB_PASSWORD}",
        "SMTP_PASSWORD=\${SMTP_PASSWORD}",
        "OAUTH_CLIENT_SECRET=\${OAUTH_CLIENT_SECRET}",
        "admin_username: jdawgs-admin",
        "admin_password: \${CALIBRE_ADMIN_PASSWORD}",
        "ALLOW_PUBLIC_REGISTRATION=false",
        "ALLOW_ANONYMOUS_UPLOADS=false",
        "TRUSTED_IPS=127.0.0.1/32",
        "BASE_URL=https://books.example.org",
        "DEBUG=false"
      ].join("\n");

      var PLANTED_SECRETS = ["Tr0picThunder!99", "dbpass-rocket-42", "oauth-secret-value-1234", "abc123"];

      /* ---------------- Parsing ---------------- */

      function cleanValue(v){
        if (v === null || v === undefined) return "";
        v = String(v).trim();
        if (v.charAt(0) !== '"' && v.charAt(0) !== "'") {
          var hash = v.indexOf(" #");
          if (hash > -1) v = v.slice(0, hash);
        }
        v = v.replace(/[,;]\s*$/, "").trim();
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) v = v.slice(1, -1);
        }
        return v.trim();
      }

      function isTruthy(v){ return /^(true|yes|on|1|enabled?)$/i.test(v || ""); }
      function isFalsy(v){ return /^(false|no|off|0|disabled?|none)$/i.test(v || ""); }

      function isEnvRef(v){
        if (!v) return false;
        return /^\$\{[^}]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v)
          || /^env:/i.test(v) || /^vault:/i.test(v) || /^file:/i.test(v)
          || /^<[^>]*>$/.test(v) || /^\*+$/.test(v) || /^redacted$/i.test(v)
          || /os\.environ|getenv/i.test(v);
      }

      function parseEntries(text){
        var entries = [];
        var lines = String(text || "").split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var t = raw.trim();
          if (!t) continue;
          if (t.charAt(0) === "#" || t.indexOf("//") === 0 || t.charAt(0) === ";") continue;

          /* Command-line flags, e.g. calibre-server --listen-on 0.0.0.0 --disable-auth */
          if (/(^|\s)--[A-Za-z]/.test(t)) {
            var tokens = t.split(/\s+/);
            for (var j = 0; j < tokens.length; j++) {
              var tok = tokens[j];
              if (tok.indexOf("--") !== 0) continue;
              var body = tok.slice(2);
              var eq = body.indexOf("=");
              if (eq > -1) {
                entries.push({ line: lineNo, key: body.slice(0, eq), value: cleanValue(body.slice(eq + 1)), kind: "flag" });
              } else if (j + 1 < tokens.length && tokens[j + 1].indexOf("-") !== 0) {
                entries.push({ line: lineNo, key: body, value: cleanValue(tokens[j + 1]), kind: "flag" });
                j++;
              } else {
                entries.push({ line: lineNo, key: body, value: null, kind: "flag" });
              }
            }
            continue;
          }

          /* key = value / key: value / "key": "value" */
          var work = t.replace(/^export\s+/i, "");
          var m = work.match(/^["']?([A-Za-z_][A-Za-z0-9_.\-]*)["']?\s*[:=]\s*(.*)$/);
          if (m) {
            entries.push({ line: lineNo, key: m[1], value: cleanValue(m[2]), kind: "kv" });
          }
        }
        return entries;
      }

      function normKey(k){ return String(k || "").toLowerCase().replace(/-/g, "_"); }

      /* ---------------- Checks ---------------- */

      var DEFAULT_VALUES = ["admin","password","passwd","changeme","change-me","letmein","calibre","calibre123","password1","123456","1234","secret","example","demo","test","default","books","library","qwerty","root","user"];
      var EXAMPLE_RE = /example|changeme|change_me|placeholder|your[-_ ]|insert[-_ ]|todo|sample|dummy/i;

      function audit(text){
        var rawText = String(text || "");
        var lines = rawText.split(/\r?\n/);
        var entries = parseEntries(rawText);
        var findings = [];

        function add(severity, line, check, title, detail, fix){
          findings.push({ severity: severity, line: line, check: check, title: title, detail: detail, fix: fix });
        }

        if (!rawText.trim()) {
          return { verdict: "NOT ENOUGH TO GRADE", reason: "The paste is empty — there is nothing to grade.", entries: entries, findings: findings, lineCount: 0 };
        }
        if (entries.length === 0) {
          return { verdict: "NOT ENOUGH TO GRADE", reason: "No recognizable config settings were found — this looks like prose, not a Calibre server config. Paste server options, key/value settings, or environment lines.", entries: entries, findings: findings, lineCount: lines.length };
        }

        var byKey = function(re){
          var out = [];
          for (var i = 0; i < entries.length; i++) if (re.test(normKey(entries[i].key))) out.push(entries[i]);
          return out;
        };
        var findEntry = function(re){
          var list = byKey(re);
          return list.length ? list[0] : null;
        };

        /* --- Exposure: bind on all interfaces + auth state --- */
        var bindEntry = null;
        var bindKeys = /^(listen_on|listen|bind|bind_address|host|server_host)$/;
        for (var b = 0; b < entries.length; b++) {
          var bk = normKey(entries[b].key), bv = (entries[b].value || "").trim();
          if (bindKeys.test(bk) && (bv === "0.0.0.0" || bv === "::" || bv === "[::]" || bv === "*" || bv === "0.0.0.0/0")) bindEntry = entries[b];
        }
        var authOffEntry = null;
        for (var a = 0; a < entries.length; a++) {
          var ak = normKey(entries[a].key), av = entries[a].value;
          if (ak === "disable_auth" && entries[a].kind === "flag") authOffEntry = entries[a];
          else if (/^(enable_auth|auth_enabled|authentication|use_auth|require_auth|auth)$/.test(ak) && av !== null && isFalsy(av)) authOffEntry = entries[a];
          else if (ak === "auth_mode" && av !== null && /^(none|off|disabled|anonymous)$/i.test(av)) authOffEntry = entries[a];
        }

        if (bindEntry && authOffEntry) {
          add("critical", authOffEntry.line, "exposure-auth",
            "Listening on all interfaces with authentication disabled",
            "Line " + bindEntry.line + " binds the server to " + (bindEntry.value || "all interfaces") + " (every network interface, not just this machine), and line " + authOffEntry.line + " turns authentication off. Anyone who can reach the port can browse and download the library with no login at all.",
            "Bind to 127.0.0.1 unless remote access is truly needed, and turn authentication on (--enable-auth / enable_auth) with real user accounts.");
        } else if (authOffEntry) {
          add("critical", authOffEntry.line, "exposure-auth",
            "Authentication is disabled",
            "This setting switches off login checks, so anyone who can reach the server can use it without credentials.",
            "Turn authentication on and give every user a real password.");
        } else if (bindEntry) {
          add("high", bindEntry.line, "exposure-auth",
            "Listening on all interfaces",
            "The server binds to " + (bindEntry.value || "all interfaces") + ", exposing it on every network this machine touches. Authentication is on, which limits the damage, but the port is still reachable by the whole network.",
            "Bind to 127.0.0.1 behind a reverse proxy, or firewall the port to the networks that need it.");
        }

        /* --- Sensitive keys: account passwords, secret keys, credentials --- */
        var SECRET_KEY_RE = /(secret_key|session_secret|flask_secret|app_secret|signing_key|^secret$|_secret$)/;
        var CLIENT_SECRET_RE = /(client_secret|oauth)/;
        var CRED_RE = /(password|passwd|pwd|client_secret|api_key|apikey|access_token|auth_token|private_key|smtp|oauth|db_pass|database_pass)/;

        entries.forEach(function(e){
          var k = normKey(e.key);
          var isSecretKey = SECRET_KEY_RE.test(k) && !CLIENT_SECRET_RE.test(k);
          var isCred = CRED_RE.test(k);
          if (!isSecretKey && !isCred) return;
          var v = e.value === null ? "" : e.value;
          var isAccountPw = /(password|passwd|pwd)/.test(k);

          if (v === "") {
            if (isAccountPw) {
              add("critical", e.line, "no-password",
                "User account with no password",
                "Key " + e.key + " on line " + e.line + " sets an account password to an empty value. That account can be used with no password at all.",
                "Set a long, unique password for the account, or remove the account.");
            } else if (isSecretKey) {
              add("critical", e.line, "secret-key",
                "Secret key is empty",
                "Key " + e.key + " on line " + e.line + " is empty. Sessions and signed tokens protected by an empty key can be forged by anyone.",
                "Generate a long random secret and supply it from the environment.");
            }
            return;
          }
          if (isEnvRef(v)) return;

          var lower = v.toLowerCase();
          var isDefault = DEFAULT_VALUES.indexOf(lower) > -1;
          var isExample = EXAMPLE_RE.test(v);

          if (isSecretKey) {
            if (isDefault || isExample) {
              add("high", e.line, "secret-key",
                "Example secret key / session secret",
                "Key " + e.key + " on line " + e.line + " holds a widely known example value (" + v.length + " characters). Anyone who has seen the same example can forge sessions.",
                "Replace it with a long random value supplied from the environment.");
            } else if (v.length < 32) {
              add("high", e.line, "secret-key",
                "Secret key / session secret is too short",
                "Key " + e.key + " on line " + e.line + " is only " + v.length + " characters long. Short secrets can be brute-forced, which puts every session at risk.",
                "Use at least 32 random characters, supplied from the environment rather than written in the config.");
            }
            return;
          }

          if (isDefault || isExample) {
            add(isAccountPw ? "critical" : "high", e.line, "default-password",
              isAccountPw ? "Default / example password on an account" : "Default / example credential",
              "Key " + e.key + " on line " + e.line + " holds a widely known default or example value (" + v.length + " characters). It is the first thing an attacker tries. (The value itself is never printed by this tool.)",
              "Replace it with a long, unique value and supply it from the environment.");
            return;
          }

          add("high", e.line, "plaintext-credential",
            "Plaintext credential stored in the config",
            "Key " + e.key + " on line " + e.line + " holds a plaintext credential of " + v.length + " characters. Anyone who can read this file — a backup, a screenshot, a shared paste — owns that credential. (Reported by key, line, and length only; the value is never shown.)",
            "Move the value into an environment variable or a secrets file outside the config, and rotate it if this file was ever shared.");
        });

        /* --- Connection strings with an embedded password --- */
        entries.forEach(function(e){
          var v = e.value || "";
          var m = v.match(/^[a-z][a-z0-9+.\-]*:\/\/[^:\/@]+:([^@]+)@/i);
          if (m && !isEnvRef(v)) {
            add("high", e.line, "plaintext-credential",
              "Password embedded in a connection string",
              "Key " + e.key + " on line " + e.line + " embeds a plaintext password of " + m[1].length + " characters inside a connection URL. (The password itself is never shown.)",
              "Move the credential into an environment variable and reference it instead of writing it into the URL.");
          }
        });

        /* --- Anonymous uploads --- */
        entries.forEach(function(e){
          var k = normKey(e.key);
          if (/upload/.test(k) && /anon/.test(k) && e.value !== null && isTruthy(e.value)) {
            add("critical", e.line, "anonymous-uploads",
              "Uploads enabled for anonymous users",
              "Key " + e.key + " on line " + e.line + " lets visitors with no account upload files to the server. Anonymous upload is a standing invitation to store arbitrary files on your machine.",
              "Turn anonymous uploads off; allow uploads only for named, signed-in users who need them.");
          } else if (/upload/.test(k) && e.value !== null && isTruthy(e.value) && authOffEntry) {
            add("critical", e.line, "anonymous-uploads",
              "Uploads enabled while authentication is disabled",
              "Key " + e.key + " on line " + e.line + " enables uploads, and authentication is off (line " + authOffEntry.line + ") — in practice that means anyone can upload.",
              "Turn authentication on, or disable uploads.");
          }
        });

        /* --- Public registration / open signup --- */
        entries.forEach(function(e){
          var k = normKey(e.key);
          if (/(public_registration|allow_registration|open_signup|allow_signup|self_registration|enable_registration|registration|signup|sign_up)/.test(k)
              && e.value !== null && isTruthy(e.value)) {
            add("high", e.line, "public-registration",
              "Public registration / open signup is on",
              "Key " + e.key + " on line " + e.line + " lets anyone on the network create their own account. On a home library server that hands library access to strangers.",
              "Turn public registration off and create accounts yourself for the people who need them.");
          }
        });

        /* --- Trusted-IP / local-network auth bypass ranges --- */
        entries.forEach(function(e){
          var k = normKey(e.key);
          if (!/(trusted|bypass|local_network|whitelist|allow_list|allowlist|no_auth|auth_exempt)/.test(k)) return;
          var v = e.value || "";
          if (!v) return;
          var worst = null; /* smallest prefix length seen */
          var parts = v.split(/[\s,;]+/);
          for (var i = 0; i < parts.length; i++) {
            var p = parts[i];
            if (p === "0.0.0.0" || p === "*" || p === "::") { worst = 0; break; }
            var cm = p.match(/\/(\d{1,3})$/);
            if (cm) { var n = parseInt(cm[1], 10); if (worst === null || n < worst) worst = n; }
          }
          if (worst === 0) {
            add("critical", e.line, "trusted-range",
              "Auth-bypass trusted range covers the entire internet",
              "Key " + e.key + " on line " + e.line + " trusts a range equivalent to 0.0.0.0/0. Every address on the internet is treated as trusted, so the auth bypass applies to everyone.",
              "Trust only the exact proxy or LAN addresses that need it, as narrow /32 entries.");
          } else if (worst !== null && worst <= 8) {
            add("high", e.line, "trusted-range",
              "Auth-bypass trusted range is overly broad",
              "Key " + e.key + " on line " + e.line + " trusts a /" + worst + " range — millions of addresses are treated as trusted and skip normal authentication.",
              "Narrow the range to the specific hosts that need the bypass.");
          } else if (worst !== null && worst <= 16) {
            add("medium", e.line, "trusted-range",
              "Auth-bypass trusted range is broad",
              "Key " + e.key + " on line " + e.line + " trusts a /" + worst + " range — up to 65,536 addresses skip normal authentication under this rule.",
              "Narrow the range to the specific hosts that need the bypass, if you can.");
          }
        });

        /* --- Plain-HTTP public URL --- */
        var proxyNote = /reverse[- ]?proxy/i.test(rawText) && /(https|tls|ssl|terminat|x-forwarded)/i.test(rawText);
        entries.forEach(function(e){
          var v = e.value || "";
          var hm = v.match(/^http:\/\/([^\/:?#]+)/i);
          if (!hm) return;
          var host = hm[1].toLowerCase();
          var isPrivate = host === "localhost" || host === "127.0.0.1" || host === "[::1]"
            || /^192\.168\./.test(host) || /^10\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host)
            || /\.local$/.test(host) || /\.lan$/.test(host) || /\.internal$/.test(host);
          if (isPrivate || proxyNote) return;
          add("medium", e.line, "plain-http",
            "Public URL uses plain HTTP",
            "Key " + e.key + " on line " + e.line + " points at http://" + host + " with no reverse-proxy HTTPS note anywhere in the paste. Logins and downloads cross the network unencrypted.",
            "Serve the library over HTTPS — directly, or behind a reverse proxy that terminates HTTPS — and update this URL to https://.");
        });

        /* --- Debug mode --- */
        entries.forEach(function(e){
          var k = normKey(e.key);
          if ((/(^|_)debug($|_)/.test(k) || k === "debug") && e.value !== null && isTruthy(e.value)) {
            add("medium", e.line, "debug-mode",
              "Debug mode is on",
              "Key " + e.key + " on line " + e.line + " enables debug mode, which can leak stack traces, settings, and file paths to anyone who triggers an error.",
              "Turn debug off for any server other people can reach.");
          }
          if (k === "debug" && e.kind === "flag" && e.value === null) {
            add("medium", e.line, "debug-mode",
              "Debug mode is on",
              "The --debug flag on line " + e.line + " enables debug mode, which can leak stack traces, settings, and file paths to anyone who triggers an error.",
              "Remove the --debug flag for any server other people can reach.");
          }
        });

        /* --- Verdict --- */
        var counts = countSeverities(findings);
        var verdict, reason;
        if (counts.critical > 0) {
          verdict = "DO NOT DEPLOY";
          reason = counts.critical + " critical finding" + (counts.critical === 1 ? "" : "s") + " — fix " + (counts.critical === 1 ? "it" : "them") + " before this config goes anywhere near a running server.";
        } else if (findings.length > 0) {
          verdict = "DEPLOY WITH FIXES";
          reason = "No critical findings, but " + findings.length + " issue" + (findings.length === 1 ? "" : "s") + " to fix before deploying.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "No findings. Every checked setting in this paste passed. (This grades the paste only — it cannot confirm the server will start.)";
        }
        findings.sort(function(x, y){
          var rank = { critical: 0, high: 1, medium: 2, low: 3 };
          if (rank[x.severity] !== rank[y.severity]) return rank[x.severity] - rank[y.severity];
          return x.line - y.line;
        });
        return { verdict: verdict, reason: reason, entries: entries, findings: findings, lineCount: lines.length, counts: counts };
      }

      function countSeverities(findings){
        var c = { critical: 0, high: 0, medium: 0, low: 0 };
        findings.forEach(function(f){ if (c[f.severity] !== undefined) c[f.severity]++; });
        return c;
      }

      /* ---------------- Report / JSON ---------------- */

      function buildReport(result){
        var out = [];
        out.push("J-Dawgs Calibre Server Config Safety Auditor\u2122 \u2014 Config Audit Report");
        out.push("================================================================");
        out.push("Verdict: " + result.verdict);
        if (result.reason) out.push(result.reason);
        out.push("Lines pasted: " + result.lineCount + " | Settings recognized: " + result.entries.length);
        if (result.counts) {
          out.push("Findings: " + result.findings.length + " total \u2014 " + result.counts.critical + " critical, " + result.counts.high + " high, " + result.counts.medium + " medium, " + result.counts.low + " low");
        }
        out.push("");
        if (result.findings.length === 0 && result.verdict === "SAFE TO DEPLOY") {
          out.push("No findings. Every checked setting in the paste passed.");
        }
        result.findings.forEach(function(f, idx){
          out.push((idx + 1) + ". [" + f.severity.toUpperCase() + "] Line " + f.line + " \u2014 " + f.title);
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
          out.push("");
        });
        out.push("----------------------------------------------------------------");
        out.push("Secret values are never printed in this report: credential findings name the key, the line, and the value length only.");
        out.push("Generated locally in your browser. Nothing was uploaded, saved, or sent anywhere.");
        return out.join("\n");
      }

      function buildJSON(result){
        return JSON.stringify({
          tool: "J-Dawgs Calibre Server Config Safety Auditor\u2122",
          version: 1,
          verdict: result.verdict,
          reason: result.reason || "",
          stats: {
            linesPasted: result.lineCount,
            settingsRecognized: result.entries.length,
            findingsTotal: result.findings.length,
            bySeverity: result.counts || countSeverities(result.findings)
          },
          findings: result.findings.map(function(f){
            return { severity: f.severity, line: f.line, check: f.check, title: f.title, detail: f.detail, fix: f.fix };
          }),
          note: "Secret values are never included; credential findings name the key, the line, and the value length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_RE": (typeof EXAMPLE_RE !== 'undefined' ? EXAMPLE_RE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-calibre-server-config-safety-auditortm',
  name: 'J-Dawgs Calibre Server Config Safety Auditor',
  description: 'Grades a pasted Calibre / calibre-web server config offline into one deploy verdict: authentication and bind exposure, plaintext credentials, and unsafe library access caught before anything runs; secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_RE": __core["EXAMPLE_RE"] }
};
