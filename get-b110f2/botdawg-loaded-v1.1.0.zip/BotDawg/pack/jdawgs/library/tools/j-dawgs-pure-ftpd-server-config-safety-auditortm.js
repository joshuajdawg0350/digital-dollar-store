'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Pure-FTPd Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- helpers ---------- */
function $(id){ return document.getElementById(id); }
function trim(s){ return String(s == null ? "" : s).replace(/^\s+|\s+$/g, ""); }
function tokenize(str){
  var out = [], m, re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  while ((m = re.exec(str)) !== null){ out.push(m[1] !== undefined ? m[1] : (m[2] !== undefined ? m[2] : m[3])); }
  return out;
}
var SECRET_NAME = /(pass(word|wd)?|secret|token|api[-_]?key|bindpw|private[-_]?key|credential)/i;

var VALUE_SHORT = { S:1, l:1, Y:1, u:1, U:1, p:1, P:1, q:1, Q:1, t:1, T:1, c:1, C:1, I:1, n:1, L:1, m:1, f:1, g:1, F:1, O:1, V:1, y:1, a:1, k:1 };
var VALUE_LONG = { bind:1, login:1, tls:1, certfile:1, tlscertfile:1, minuid:1, umask:1, passiveportrange:1,
  uploadratio:1, userratio:1, anonymousratio:1, quota:1, maxclients:1, maxidletime:1, authentication:1,
  forcepassiveip:1, trusteduid:1, filequota:1 };

var DIRECTIVES = {
  bind:"bind", noanonymous:"noanonymous", anonymousonly:"anonymousonly", authenticatedonly:"authenticatedonly",
  tls:"tls", certfile:"cert", tlscertfile:"cert", chrooteveryone:"chroot", puredb:"authpuredb",
  pamauthentication:"authpam", unixauthentication:"authunix", minuid:"minuid", umask:"umask",
  passiveportrange:"passive", userratio:"ratio", anonymousratio:"ratio", quota:"quota",
  maxclientsnumber:"maxclients", maxidletime:"idle", anonymouscanupload:"anonupload",
  anonymouscancreatedirs:"anoncreatedirs", daemonize:"ignore", dontresolve:"ignore"
};

/* ---------- parsing ---------- */
function detectForm(text){
  if (/^\s*\[(Unit|Service|Install)\]/m.test(text) || /ExecStart\s*=/.test(text)){
    return { key:"systemd", label:"systemd unit — flags taken from the ExecStart line(s)" };
  }
  var lines = text.split(/\r?\n/).filter(function(l){ return trim(l) !== ""; });
  var dashLines = 0, directiveLines = 0;
  lines.forEach(function(l){
    var t = trim(l);
    if (t.charAt(0) === "#") return;
    if (t.charAt(0) === "-") dashLines++;
    else if (/^[A-Za-z][A-Za-z0-9]*\s+\S/.test(t) || /^[A-Za-z][A-Za-z0-9]*\s*=/.test(t)) directiveLines++;
  });
  if (lines.length >= 2 && directiveLines > dashLines && directiveLines >= 1 && dashLines === 0){
    return { key:"directives", label:"configuration file — directive name and value, one per line" };
  }
  if (lines.length >= 2){
    return { key:"flagsfile", label:"flags file — one flag per line" };
  }
  return { key:"cmdline", label:"command line — space-separated flags on one line" };
}

function parseConfig(text){
  var entries = [];       // {flag, value|null, line, pos, kind}
  var secrets = [];       // {name, line, pos, len}
  var secretKeys = {};    // dedupe "line|name"
  var unrecognized = 0;
  var pos = 0;

  function noteSecret(name, line, p, len){
    var k = line + "|" + name.toLowerCase();
    if (secretKeys[k]) return;
    secretKeys[k] = 1;
    secrets.push({ name:name, line:line, pos:p, len:len });
  }
  function addEntry(flag, value, line, kind){
    pos++;
    entries.push({ flag:flag, value:value, line:line, pos:pos, kind:kind || "flag" });
    return entries[entries.length-1];
  }
  function handleTokens(tokens, line){
    var i = 0;
    while (i < tokens.length){
      var tok = tokens[i];
      if (tok === "\\"){ i++; continue; }
      if (tok.indexOf("--") === 0){
        var body = tok.slice(2), eq = body.indexOf("="), name = eq >= 0 ? body.slice(0, eq) : body;
        var inlineVal = eq >= 0 ? body.slice(eq + 1) : null;
        var lname = name.toLowerCase();
        if (SECRET_NAME.test(name)){
          var sv = inlineVal;
          if (sv === null && i + 1 < tokens.length && tokens[i+1].charAt(0) !== "-"){ sv = tokens[i+1]; i++; }
          pos++;
          noteSecret("--" + name, line, pos, sv ? sv.length : 0);
          i++; continue;
        }
        var val = inlineVal;
        if (val === null && VALUE_LONG[lname] && i + 1 < tokens.length && tokens[i+1].charAt(0) !== "-"){ val = tokens[i+1]; i++; }
        addEntry("--" + name, val, line);
        i++; continue;
      }
      if (tok.charAt(0) === "-" && tok.length >= 2 && !/^-\d/.test(tok)){
        var chars = tok.slice(1);
        if (chars.length > 1 && !VALUE_SHORT[chars.charAt(0)]){
          var allBool = true;
          for (var c = 0; c < chars.length; c++){ if (VALUE_SHORT[chars.charAt(c)]){ allBool = false; break; } }
          if (allBool){
            for (var b = 0; b < chars.length; b++){ addEntry("-" + chars.charAt(b), null, line); }
            i++; continue;
          }
        }
        var f = chars.charAt(0);
        if (VALUE_SHORT[f]){
          var v = chars.length > 1 ? chars.slice(1) : null;
          if (v === null && i + 1 < tokens.length && tokens[i+1].charAt(0) !== "-"){ v = tokens[i+1]; i++; }
          if (SECRET_NAME.test(f)){ pos++; noteSecret("-" + f, line, pos, v ? v.length : 0); }
          else { addEntry("-" + f, v, line); }
          i++; continue;
        }
        addEntry("-" + f, chars.length > 1 ? chars.slice(1) : null, line);
        i++; continue;
      }
      if (/pure-ftpd/i.test(tok) || tok.indexOf("/") >= 0){ i++; continue; } // binary path
      unrecognized++;
      i++;
    }
  }
  function handleDirective(name, value, line){
    var lname = name.toLowerCase();
    if (SECRET_NAME.test(name)){
      pos++;
      noteSecret(name, line, pos, value ? trim(value).length : 0);
      return;
    }
    pos++;
    entries.push({ flag:name, value: value === null ? null : trim(value), line:line, pos:pos, kind:"directive" });
  }
  function lineSecretScan(lineText, line){
    var m = /(password|passwd|secret|token|api[-_]?key)\s*[:=]\s*(\S+)/i.exec(lineText);
    if (m){ pos++; noteSecret(m[1], line, pos, m[2].length); }
    var uri = /:\/\/[^/\s:]+:([^@\s]+)@/.exec(lineText);
    if (uri){ pos++; noteSecret("embedded URI password", line, pos, uri[1].length); }
  }

  var form = detectForm(text);
  var rawLines = text.split(/\r?\n/);

  if (form.key === "systemd"){
    var inExec = false;
    rawLines.forEach(function(raw, idx){
      var lineNo = idx + 1, t = trim(raw);
      if (/^Exec(Start|StartPre|StartPost)\s*=/.test(t)){
        inExec = true;
        var after = t.slice(t.indexOf("=") + 1);
        handleTokens(tokenize(after), lineNo);
        lineSecretScan(t, lineNo);
        if (!/\\\s*$/.test(t)) inExec = false;
        return;
      }
      if (inExec){
        handleTokens(tokenize(t), lineNo);
        lineSecretScan(t, lineNo);
        if (!/\\\s*$/.test(t)) inExec = false;
        return;
      }
      var dm = /^([A-Za-z][A-Za-z0-9]*)\s*=\s*(.*)$/.exec(t);
      if (dm && SECRET_NAME.test(dm[1])){ pos++; noteSecret(dm[1], lineNo, pos, trim(dm[2]).length); }
    });
  } else {
    rawLines.forEach(function(raw, idx){
      var lineNo = idx + 1, t = trim(raw);
      if (t === "" || t.charAt(0) === "#" || t.charAt(0) === ";") return;
      if (t.charAt(0) === "-"){ handleTokens(tokenize(t), lineNo); lineSecretScan(t, lineNo); return; }
      var dm = /^([A-Za-z][A-Za-z0-9]*)\s*=\s*(.*)$/.exec(t);
      if (dm){ handleDirective(dm[1], dm[2], lineNo); return; }
      var sm = /^([A-Za-z][A-Za-z0-9]*)\s+(.+)$/.exec(t);
      if (sm && (DIRECTIVES[sm[1].toLowerCase()] || SECRET_NAME.test(sm[1]) || /^[A-Z]/.test(sm[1]))){
        handleDirective(sm[1], sm[2], lineNo); return;
      }
      if (/\s/.test(t) && t.indexOf("-") >= 0){ handleTokens(tokenize(t), lineNo); lineSecretScan(t, lineNo); return; }
      unrecognized++;
    });
  }
  return { entries:entries, secrets:secrets, form:form, unrecognized:unrecognized };
}

/* ---------- model ---------- */
function buildModel(entries){
  var m = { bind:null, anonOnly:null, noAnon:null, anonAllowed:null, tls:null, tlsLevel:null, cert:null,
    chrootTrue:null, chrootFalse:null, auth:[], minuid:null, umask:null, passive:null, ratio:[],
    quota:null, bandwidth:[], maxclients:null, idle:null, anonUpload:null, anonCreateDirs:null };
  function yes(v){ return v === null || /^(yes|true|1|on)$/i.test(trim(v)); }
  function no(v){ return /^(no|false|0|off)$/i.test(trim(v || "")); }
  entries.forEach(function(e){
    var f = e.flag, lf = f.toLowerCase();
    if (e.kind === "flag"){
      if (f === "-S" || lf === "--bind"){ m.bind = e; }
      else if (f === "-e" || lf === "--anonymousonly"){ m.anonOnly = e; }
      else if (f === "-E" || lf === "--noanonymous"){ m.noAnon = e; }
      else if (f === "-Y" || lf === "--tls"){ m.tls = e; m.tlsLevel = e.value === null ? null : parseInt(e.value, 10); }
      else if (lf === "--certfile" || lf === "--tlscertfile"){ m.cert = e; }
      else if (f === "-A" || lf === "--chrooteveryone" || lf === "--chroot"){ m.chrootTrue = e; }
      else if (f === "-l" || lf === "--login"){ m.auth.push(e); }
      else if (f === "-u" || lf === "--minuid"){ m.minuid = e; }
      else if (f === "-U" || lf === "--umask"){ m.umask = e; }
      else if (f === "-p" || lf === "--passiveportrange"){ m.passive = e; }
      else if (f === "-q" || f === "-Q" || lf === "--uploadratio" || lf === "--userratio" || lf === "--anonymousratio"){ m.ratio.push(e); }
      else if (f === "-n" || lf === "--quota"){ m.quota = e; }
      else if (f === "-t" || f === "-T"){ m.bandwidth.push(e); }
      else if (f === "-c" || lf === "--maxclients"){ m.maxclients = e; }
      else if (f === "-I" || lf === "--maxidletime"){ m.idle = e; }
      else if (f === "-M"){ m.anonCreateDirs = e; }
    } else {
      var d = DIRECTIVES[lf];
      if (d === "bind"){ m.bind = e; }
      else if (d === "noanonymous"){ if (yes(e.value)) m.noAnon = e; else if (no(e.value)) m.anonAllowed = e; }
      else if (d === "anonymousonly"){ if (yes(e.value)) m.anonOnly = e; }
      else if (d === "authenticatedonly"){ if (yes(e.value)) m.noAnon = e; }
      else if (d === "tls"){ m.tls = e; m.tlsLevel = e.value === null ? null : parseInt(e.value, 10); }
      else if (d === "cert"){ m.cert = e; }
      else if (d === "chroot"){ if (yes(e.value)) m.chrootTrue = e; else if (no(e.value)) m.chrootFalse = e; }
      else if (d === "authpuredb"){ m.auth.push(e); }
      else if (d === "authpam"){ if (yes(e.value)) m.auth.push(e); }
      else if (d === "authunix"){ if (yes(e.value)) m.auth.push(e); }
      else if (d === "minuid"){ m.minuid = e; }
      else if (d === "umask"){ m.umask = e; }
      else if (d === "passive"){ m.passive = e; }
      else if (d === "ratio"){ m.ratio.push(e); }
      else if (d === "quota"){ m.quota = e; }
      else if (d === "maxclients"){ m.maxclients = e; }
      else if (d === "idle"){ m.idle = e; }
      else if (d === "anonupload"){ if (yes(e.value)) m.anonUpload = e; }
      else if (d === "anoncreatedirs"){ if (yes(e.value)) m.anonCreateDirs = e; }
    }
    if (/cert/i.test(f) && e.value && !m.cert) m.cert = e;
  });
  return m;
}

function authKind(e){
  if (e.kind === "directive"){
    var d = DIRECTIVES[e.flag.toLowerCase()];
    if (d === "authpuredb") return "puredb";
    if (d === "authpam") return "pam";
    if (d === "authunix") return "unix";
    return "other";
  }
  var v = (e.value || "").toLowerCase();
  if (v.indexOf("puredb") === 0) return "puredb";
  if (v.indexOf("unix") === 0) return "unix";
  if (v.indexOf("pam") === 0) return "pam";
  if (v.indexOf("ldap") === 0) return "ldap";
  if (v.indexOf("mysql") === 0 || v.indexOf("pgsql") === 0) return "sql";
  if (v.indexOf("extauth") === 0) return "extauth";
  return "other";
}

/* ---------- audit ---------- */
function audit(text, intent){
  var parsed = parseConfig(text);
  var m = buildModel(parsed.entries);
  var findings = [];
  function add(sev, entry, flagLabel, issue, fix){
    findings.push({ severity:sev, line: entry ? entry.line : null, pos: entry ? entry.pos : null,
      flag: flagLabel, issue: issue, fix: fix });
  }
  var intentName = intent === "public" ? "public file distribution" : (intent === "dropbox" ? "upload drop box" : "private authenticated file transfer");

  /* secrets */
  parsed.secrets.forEach(function(s){
    findings.push({ severity:"BLOCKER", line:s.line, pos:s.pos, flag:s.name,
      issue:"Plaintext secret stored in the configuration under “" + s.name + "” (value length: " + s.len + " characters; the value itself is never reproduced in this audit). Anyone who can read this file, unit, or process list owns the credential.",
      fix:"Remove the secret from the configuration text. Load it from a root-only credential file or your service manager's credential mechanism, and rotate the exposed value now that it has been pasted in plaintext." });
  });

  /* anonymous vs intent */
  if (m.anonOnly){
    if (intent === "private"){
      add("BLOCKER", m.anonOnly, "-e (anonymous-only)", "Anonymous access is not just on — it is the only way in. For " + intentName + " that is backwards: anyone on the network can connect with no account, and your named users cannot log in at all.",
        "Remove -e and add -E to disable anonymous access, then authenticate named users with -l puredb:/etc/pureftpd.pdb.");
    } else if (intent === "dropbox"){
      add("WARNING", m.anonOnly, "-e (anonymous-only)", "Anonymous-only mode is on. A drop box can accept anonymous uploads, but with no authenticated accounts there is no per-user accountability for what lands on the server.",
        "Prefer authenticated accounts (-E with -l puredb:…). If anonymous drops are required, pair them with upload-only restrictions and quotas, and review drops before use.");
    } else {
      add("WARNING", m.anonOnly, "-e (anonymous-only)", "Anonymous-only mode fits public distribution, but it also locks out authenticated accounts you might want for uploads and administration.",
        "Keep -e only if the server truly never needs named accounts; otherwise run separate instances for public downloads and authenticated access.");
    }
  } else if (m.anonAllowed){
    if (intent === "private"){
      add("BLOCKER", m.anonAllowed, m.anonAllowed.flag + " (anonymous allowed)", "Anonymous access is explicitly allowed (NoAnonymous is off) on a server intended for " + intentName + ". Unauthenticated visitors can browse and download whatever the anonymous account can reach.",
        "Set NoAnonymous to yes (or use the -E flag) so only named, authenticated users can log in.");
    } else if (intent === "dropbox"){
      add("WARNING", m.anonAllowed, m.anonAllowed.flag + " (anonymous allowed)", "Anonymous access is allowed on an upload drop box. That can be the design — but only if anonymous sessions are upload-only and cannot list or download other people's files.",
        "Restrict anonymous sessions to uploads, disable anonymous downloads and directory creation except a single drop folder, and add quotas.");
    } else {
      add("INFO", m.anonAllowed, m.anonAllowed.flag + " (anonymous allowed)", "Anonymous access is on, which matches public file distribution. The remaining risk is scope: what the anonymous account can see and whether it can upload.",
        "Keep the anonymous account chrooted to the public tree, disable anonymous uploads, and re-check the TLS and bind findings below.");
    }
  } else if (!m.noAnon){
    if (intent === "private"){
      add("WARNING", null, "-E (anonymous off) — absent", "The configuration never states the anonymous posture. Whether anonymous logins are accepted is left to build defaults and the presence of an anonymous account on the host — exactly the kind of ambiguity that ships by accident.",
        "Add -E (or NoAnonymous yes) to disable anonymous access explicitly.");
    } else if (intent === "dropbox"){
      add("WARNING", null, "-E (anonymous off) — absent", "The configuration never states the anonymous posture, so the drop box's front door depends on host defaults rather than on a decision in this file.",
        "State it on purpose: -E for account-only drops, or an explicit anonymous setup with upload-only restrictions.");
    } else {
      add("INFO", null, "anonymous posture — not stated", "No flag states the anonymous posture. A public mirror normally enables anonymous downloads deliberately; silence in the file means the behaviour comes from host defaults.",
        "State the choice in the configuration (anonymous on for the mirror, read-only and chrooted) so the next reader does not have to guess.");
    }
  }

  /* TLS */
  var tlsKnown = m.tls && m.tlsLevel !== null && !isNaN(m.tlsLevel);
  if (!m.tls){
    add(intent === "public" ? "WARNING" : "BLOCKER", null, "-Y (TLS) — absent",
      "No TLS flag was found, so FTP sessions — including usernames and passwords — travel in plaintext across the network. Anyone on the path can read the credentials and the files.",
      "Add -Y 2 to require TLS, together with a certificate flag such as --certfile /etc/ssl/private/pure-ftpd.pem (or the CertFile directive).");
  } else if (!tlsKnown){
    add("WARNING", m.tls, m.tls.flag + " (TLS)", "A TLS flag is present but its level could not be read, so the audit cannot confirm whether TLS is off, optional, or required.",
      "Set the level explicitly: -Y 2 requires TLS for every session.");
  } else if (m.tlsLevel === 0){
    add(intent === "public" ? "WARNING" : "BLOCKER", m.tls, "-Y 0 (TLS disabled)",
      "TLS is explicitly disabled (-Y 0). Logins and file contents move in plaintext; with password authentication that means reusable credentials on the wire.",
      "Change -Y 0 to -Y 2 and provide a certificate file so TLS is required, not merely available.");
  } else if (m.tlsLevel === 1){
    add(intent === "public" ? "WARNING" : "BLOCKER", m.tls, "-Y 1 (TLS optional)",
      "TLS is optional (-Y 1): clients may connect in plaintext, and many will. Optional encryption grades the same as no encryption for the sessions that skip it — credentials included.",
      "Raise it to -Y 2 so TLS is required for every session, and supply a certificate flag.");
  }
  if (tlsKnown && m.tlsLevel >= 1 && !m.cert){
    add("WARNING", m.tls, "certificate flag — absent",
      "TLS is enabled but no certificate flag (CertFile / --certfile) appears in the configuration. The daemon falls back to a default certificate path; if that file is missing or stale, TLS fails or ships a certificate clients cannot trust.",
      "Name the certificate explicitly, e.g. --certfile /etc/ssl/private/pure-ftpd.pem, and keep the key file readable only by root.");
  }
  if (tlsKnown && m.tlsLevel === 0 && m.cert){
    add("INFO", m.cert, m.cert.flag + " (certificate)", "A certificate is configured but TLS is disabled, so the certificate is never used.",
      "Enable required TLS (-Y 2) so the certificate actually protects sessions.");
  }

  /* bind */
  if (!m.bind){
    add(intent === "public" ? "WARNING" : "BLOCKER", null, "-S (bind address) — absent",
      "No bind flag (-S) was found, so the daemon listens on all interfaces — every network the host touches, including ones this service was never meant for.",
      "Bind one address on purpose, e.g. -S 192.168.1.20,21 for a LAN service or -S 127.0.0.1,21 for local-only use.");
  } else {
    var host = trim((m.bind.value || "").split(",")[0]);
    if (host === "0.0.0.0" || host === "::" || host === "[::]" || host === "*" || host === ""){
      add(intent === "public" ? "WARNING" : "BLOCKER", m.bind, "-S (bind address)",
        "The bind address is " + (host === "" ? "empty" : host) + " — the daemon listens on all interfaces, so the FTP port answers on every attached network.",
        "Bind a specific address instead, e.g. -S 192.168.1.20,21, or -S 127.0.0.1,21 if only local processes should reach it, and firewall the rest.");
    } else if (host === "127.0.0.1" || host === "::1" || host === "localhost"){
      add("INFO", m.bind, "-S (bind address)", "The server binds to loopback only (" + host + "). Nothing off the host can connect — safest bind there is, if that is the intent.",
        "No change needed for local-only service; if remote users must connect, bind the specific LAN/WAN address instead of all interfaces.");
    }
  }

  /* chroot */
  if (m.chrootFalse){
    add(intent === "public" ? "WARNING" : "BLOCKER", m.chrootFalse, m.chrootFalse.flag + " (chroot off)",
      "Chroot is explicitly off (" + m.chrootFalse.flag + " no): logged-in users are not jailed to their home directories and can browse whatever the account's permissions allow across the filesystem. No chroot means one weak account becomes a tour of the whole disk.",
      "Turn it on: ChrootEveryone yes, or the -A flag, so every user is jailed to their own directory.");
  } else if (!m.chrootTrue){
    add(intent === "public" ? "WARNING" : "BLOCKER", null, "-A / ChrootEveryone (chroot) — absent",
      "No chroot flag was found: users are not jailed to their home directories. Without a jail, any authenticated (or anonymous) account can wander the filesystem as far as its permissions reach — no chroot is one of the classic ways an FTP server leaks the host.",
      "Add -A (chroot everyone except root) or set ChrootEveryone yes so each user stays inside their own directory.");
  }

  /* authentication */
  if (m.auth.length === 0 && !m.anonOnly){
    add("WARNING", null, "-l (authentication) — absent",
      "No authentication flag (-l) was found, so who can log in — and with what — is decided by daemon defaults instead of by this configuration.",
      "Name the method explicitly, e.g. -l puredb:/etc/pureftpd.pdb for dedicated FTP accounts kept separate from system logins.");
  }
  m.auth.forEach(function(e){
    var kind = authKind(e);
    if (kind === "unix" || kind === "pam"){
      var label = e.kind === "directive" ? e.flag + " (system passwords)" : "-l " + kind + " (system passwords)";
      add("WARNING", e, label,
        "Authentication uses system passwords (" + (kind === "pam" ? "PAM" : "Unix") + "): real operating-system accounts double as FTP accounts, so every shell user is an FTP user and those passwords are only as safe as the TLS posture above.",
        "Prefer dedicated FTP accounts with -l puredb:/etc/pureftpd.pdb so FTP credentials are separate from system logins; if system auth must stay, TLS required (-Y 2) and a high minimum UID are mandatory.");
    } else if (kind === "ldap" || kind === "sql"){
      add("INFO", e, "-l " + kind + " (external authentication)",
        "Authentication is delegated to an external " + (kind === "ldap" ? "LDAP directory" : "database") + ". That is a reasonable design — the risk moves to the bind credentials and the connection to that backend.",
        "Keep backend credentials out of this file (see the secret check), use a read-only bind account, and encrypt the backend connection.");
    }
  });

  /* root login / min UID */
  if (!m.minuid){
    add("WARNING", null, "-u (minimum UID) — absent",
      "No minimum UID (-u) was set, so the root-login posture depends on defaults: nothing in this configuration states that root and system accounts are refused.",
      "Add -u 1000 so accounts with a UID below 1000 — root included — cannot log in over FTP.");
  } else {
    var uid = parseInt(m.minuid.value, 10);
    if (!isNaN(uid) && uid === 0){
      add("BLOCKER", m.minuid, "-u 0 (minimum UID)", "The minimum UID is 0, so root login over FTP is allowed. Root's password crossing an FTP login — especially with TLS optional or off — is the single worst credential this service can leak.",
        "Set -u 1000 so root and system accounts are refused, and administer the server over SSH instead.");
    } else if (!isNaN(uid) && uid < 100){
      add("WARNING", m.minuid, "-u " + uid + " (minimum UID)", "The minimum UID is " + uid + ", which still admits low-numbered system service accounts.",
        "Raise it to -u 1000 so only ordinary user accounts can authenticate.");
    }
  }

  /* passive range */
  if (!m.passive){
    add("WARNING", null, "-p (passive port range) — absent",
      "No passive port range (-p) was set. Passive data connections then land on whatever the OS picks, which firewalls and NAT handle unpredictably — and nobody can firewall a range that was never declared.",
      "Declare a tight range you can open in the firewall, e.g. -p 40000:40100, and forward exactly that range.");
  } else {
    var nums = (m.passive.value || "").match(/\d+/g);
    if (nums && nums.length >= 2){
      var lo = parseInt(nums[0], 10), hi = parseInt(nums[1], 10), width = hi - lo + 1;
      if (width > 2000){
        add("WARNING", m.passive, "-p (passive port range)", "The passive port range spans " + width + " ports (" + lo + "–" + hi + "). Every one of those ports must be open through the firewall, so a wide range is a wide hole.",
          "Narrow it to what concurrent transfers actually need, e.g. -p 40000:40100, and match the firewall rule to it.");
      }
      if (lo < 1024){
        add("WARNING", m.passive, "-p (passive port range)", "The passive range starts at " + lo + ", inside the privileged port range below 1024, where it can collide with system services.",
          "Move the range above 1024, e.g. -p 40000:40100.");
      }
    } else {
      add("INFO", m.passive, "-p (passive port range)", "A passive port range is set but could not be read as a low:high pair, so its width was not graded.",
        "Write it as one pair, e.g. -p 40000:40100.");
    }
  }

  /* ratio / quota / limits */
  if (m.ratio.length === 0){
    add("WARNING", null, "-Q (upload/download ratio) — absent",
      "No upload/download ratio flag (-q / -Q) was found, so transfer ratios are unlimited in both directions by default.",
      "Set a ratio that matches the job, e.g. -Q 1:10 for a download-heavy service, so uploads cannot be traded for unbounded downloads.");
  }
  if (!m.quota){
    add(intent === "dropbox" ? "BLOCKER" : "WARNING", null, "-n (quota) — absent",
      "No quota or size limit flag was found. One user — or one abusive uploader — can fill the disk, and a full disk takes down more than FTP.",
      "Add a quota, e.g. -n 2000:250 (max files : max megabytes per user), and per-user quotas in the PureDB account database.");
  }
  if (m.bandwidth.length === 0){
    add("INFO", null, "-T (bandwidth throttle) — absent", "No bandwidth throttle flag was found. Not a safety hole by itself, but one fast client can saturate the link for everyone.",
      "Optional: add -T upload:download (KB/s), e.g. -T 200:2000, sized to your connection.");
  }
  if (!m.maxclients){
    add("INFO", null, "-c (max clients) — absent", "No maximum-clients flag was found, so connection count is bounded only by the host. A connection flood is a cheap denial of service.",
      "Optional: add -c 25 and a per-address cap such as -C 4.");
  }
  if (!m.idle){
    add("INFO", null, "-I (idle timeout) — absent", "No idle timeout was set, so forgotten sessions can sit open indefinitely, holding slots and authenticated state.",
      "Optional: add -I 900 to drop sessions idle for 15 minutes.");
  }

  /* anonymous upload surface */
  var anonOn = !!(m.anonOnly || m.anonAllowed);
  if (anonOn && m.anonCreateDirs){
    add("WARNING", m.anonCreateDirs, "-M (anonymous directory creation)", "Anonymous users may create directories. On a public or drop-box server that invites warez-style abuse — nested folders of other people's content under your address.",
      "Remove -M unless anonymous directory creation is a deliberate, monitored feature.");
  }
  if (anonOn && m.anonUpload){
    add("WARNING", m.anonUpload, m.anonUpload.flag + " (anonymous upload)", "Anonymous uploads are explicitly allowed. Combined with anonymous downloads that is the classic open drop-and-fetch relay.",
      "Make anonymous sessions upload-only (no listing, no download) or require accounts for uploads.");
  }

  /* umask */
  if (!m.umask){
    add("INFO", null, "-U (umask) — absent", "No umask flag was set, so uploaded-file permissions come from the daemon default rather than a decision in this file.",
      "State it explicitly, e.g. -U 133:022, so uploaded files are not group/world-writable.");
  } else {
    var parts = (m.umask.value || "").split(/[:\s]+/).filter(function(x){ return x !== ""; });
    var bad = null;
    parts.forEach(function(p){
      var v = parseInt(p, 8);
      if (!isNaN(v) && (v & 2) === 0 && bad === null) bad = p;
      if (!isNaN(v) && v === 0 && bad === null) bad = p;
    });
    var zero = parts.some(function(p){ return parseInt(p, 8) === 0; });
    if (zero){
      add("WARNING", m.umask, "-U (umask)", "The umask includes 000, so uploaded files and directories are created readable and writable by everyone on the host. Other local accounts — and other jailed services — can alter what your FTP users uploaded.",
        "Use a restrictive umask such as -U 133:022 (files : directories).");
    } else if (bad !== null){
      add("WARNING", m.umask, "-U (umask)", "The umask value " + (m.umask.value || "") + " leaves the world-write bit unmasked in at least one part, so uploads can end up world-writable.",
        "Use -U 133:022 so other users on the host cannot modify uploaded files.");
    }
  }

  var counts = { BLOCKER:0, WARNING:0, INFO:0 };
  findings.forEach(function(f){ counts[f.severity]++; });
  var verdict = counts.BLOCKER > 0 ? "DO NOT RUN" : (counts.WARNING > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");
  return { verdict:verdict, counts:counts, findings:findings, form:parsed.form,
    entryCount: parsed.entries.length, unrecognized: parsed.unrecognized, intent:intent, intentName:intentName };
}

/* ---------- rendering ---------- */
function locText(f){
  if (f.line !== null && f.pos !== null) return "Line " + f.line + " · flag #" + f.pos;
  return "Config-wide — flag absent";
}
function esc(s){
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function buildReport(r){
  var L = [];
  L.push("J-Dawgs Pure-FTPd Server Config Safety Auditor™ — Audit Report");
  L.push("Intent: " + r.intentName);
  L.push("Detected form: " + r.form.label);
  L.push("Verdict: " + r.verdict);
  L.push("Counts: BLOCKER " + r.counts.BLOCKER + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO);
  L.push("");
  if (r.findings.length === 0){
    L.push("Findings: none. Every graded check passed.");
  } else {
    L.push("Findings:");
    r.findings.forEach(function(f, i){
      L.push((i + 1) + ". [" + f.severity + "] " + locText(f) + " · " + f.flag);
      L.push("   Problem: " + f.issue);
      L.push("   Fix: " + f.fix);
    });
  }
  L.push("");
  L.push("Heuristic text audit generated locally in your browser. No server was contacted, Pure-FTPd was not started, and no certificate was verified. Secret values are reported by name, line, and length only — never reproduced.");
  return L.join("\n");
}
function buildJSON(r){
  var obj = {
    tool: "J-Dawgs Pure-FTPd Server Config Safety Auditor™",
    intent: r.intentName,
    detectedForm: r.form.label,
    verdict: r.verdict,
    counts: { blocker: r.counts.BLOCKER, warning: r.counts.WARNING, info: r.counts.INFO },
    findings: r.findings.map(function(f){
      return { severity: f.severity, line: f.line, flagPosition: f.pos, flag: f.flag, issue: f.issue, fix: f.fix };
    })
  };
  return JSON.stringify(obj, null, 2);
}

function showMessage(msg){
  var box = $("message");
  box.textContent = msg;
  box.style.display = "block";
  $("results").style.display = "none";
}
function hideMessage(){ $("message").style.display = "none"; }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pure-ftpd-server-config-safety-auditortm',
  name: 'J-Dawgs Pure-FTPd Server Config Safety Auditor',
  description: 'Pure-FTPd\'s own checks only answer whether the daemon starts on the host; ours grades a pasted Pure-FTPd configuration fully offline — anonymous access, TLS posture, bind, chroot, root login, with secrets shown by name/line/length only — into one verdict: SAFE TO RUN / RUN WITH FIXES / DO NOT RUN.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
