'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Karakeep Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var RISKY = document.getElementById('riskyPre').textContent.replace(/\n$/,'');
var HARDENED = document.getElementById('hardenedPre').textContent.replace(/\n$/,'');

var KNOWN_PREFIXES = ['NEXTAUTH_','MEILI_','MEILISEARCH_','OPENAI_','ANTHROPIC_','DISABLE_SIGNUPS','DATA_DIR','CRAWLER_','BROWSER_','OCR_','INFERENCE_','EMBEDDING_','OLLAMA_','GOOGLE_','AZURE_','PORT','HOSTNAME','NEXT_PUBLIC_'];
var PROVIDER_KEYS = ['OPENAI_API_KEY','ANTHROPIC_API_KEY','GOOGLE_API_KEY','AZURE_OPENAI_API_KEY','OPENROUTER_API_KEY','GROQ_API_KEY','MISTRAL_API_KEY','COHERE_API_KEY'];
var EXAMPLE_RE = /^(secret|changeme|change-me|change_me|example|test|testing|password|passwd|admin|letmein|masterkey|master-key|supersecret|default|demo|sample|your[-_ ].*|xxx+|123456.*|abc123.*|placeholder|replace[-_ ].*|todo)$/i;

function isKnownKey(k){
  for(var i=0;i<KNOWN_PREFIXES.length;i++){ if(k.indexOf(KNOWN_PREFIXES[i])===0) return true; }
  return false;
}
function isRef(v){ return v.indexOf('${')!==-1 || v.indexOf('$(')!==-1 || /^\$[A-Z_][A-Z0-9_]*$/.test(v); }
function stripQuotes(v){ v=v.trim(); if(v.length>=2 && ((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'"))) v=v.slice(1,-1); return v.trim(); }

function parse(text){
  var lines = String(text||'').split(/\r?\n/);
  var entries = [];
  for(var i=0;i<lines.length;i++){
    var raw = lines[i];
    var t = raw.trim();
    if(!t || t.charAt(0)==='#') continue;
    var m = t.match(/^[-]?\s*([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
    if(m){ entries.push({line:i+1, key:m[1].toUpperCase(), value:stripQuotes(m[2]), raw:t}); }
    else { entries.push({line:i+1, key:null, value:'', raw:t}); }
  }
  return {lines:lines, entries:entries};
}

function audit(text){
  var parsed = parse(text);
  var entries = parsed.entries;
  var findings = [];
  function add(line, sev, key, msg, len){
    var f = {line:line, severity:sev, key:key, message:msg};
    if(typeof len==='number') f.valueLength = len;
    findings.push(f);
  }
  var keyed = entries.filter(function(e){return e.key && isKnownKey(e.key);});
  var hasPortLine = entries.some(function(e){ return /(^|\D)(7700|9222)\s*:/.test(e.raw); });
  if(keyed.length < 2 && !hasPortLine){
    return {verdict:'NOT ENOUGH TO GRADE', findings:[], recognisedKeys:keyed.length, totalLines:parsed.lines.length};
  }
  var byKey = {};
  entries.forEach(function(e){ if(e.key) byKey[e.key]=e; });

  entries.forEach(function(e){
    // Port exposure — scan every raw line, keyed or not
    if(/(^|\D)7700\s*:\s*7700/.test(e.raw) || /["']7700:/.test(e.raw)){
      add(e.line,'CRITICAL', e.key||'PORT_EXPOSURE', 'Meilisearch port 7700 is published to the host. Keep Meilisearch on the internal container network only — anyone who can reach it can query your search index.');
    }
    if(/(^|\D)9222\s*:\s*9222/.test(e.raw) || /["']9222:/.test(e.raw)){
      add(e.line,'CRITICAL', e.key||'PORT_EXPOSURE', 'Browser remote-debugging port 9222 is published to the host. A published debugging port gives full control of the crawler browser to anyone who can reach it.');
    }
    if(!e.key) return;
    var k=e.key, v=e.value, fileRef = /_FILE$/.test(k), ref = isRef(v) || fileRef;

    // NEXTAUTH_SECRET and *_FILE variant
    if(k==='NEXTAUTH_SECRET' || k==='MEILI_MASTER_KEY'){
      if(ref) return;
      var minLen = (k==='NEXTAUTH_SECRET') ? 32 : 16;
      var label = (k==='NEXTAUTH_SECRET') ? 'Session secret NEXTAUTH_SECRET' : 'Meilisearch master key MEILI_MASTER_KEY';
      if(!v){ add(e.line,'CRITICAL',k,label+' is empty.',0); return; }
      if(EXAMPLE_RE.test(v) || /changeme|example|placeholder/i.test(v)){ add(e.line,'CRITICAL',k,label+' is a known example / placeholder value. Generate a fresh random value before deploying.',v.length); return; }
      if(v.length < minLen){ add(e.line,'CRITICAL',k,label+' is too short at '+v.length+' characters (minimum '+minLen+'). Generate a long random value.',v.length); return; }
    }
    if(PROVIDER_KEYS.indexOf(k)!==-1){
      if(ref) return;
      if(!v){ add(e.line,'WARNING',k,'Provider API key '+k+' is present but empty — inference / OCR calls will fail at runtime.',0); return; }
      add(e.line,'WARNING',k,'Provider API key '+k+' is stored as a plaintext literal in this file. Supply it with a ${...} reference or a '+k+'_FILE secret file so the key does not travel with the config.',v.length);
      return;
    }
    if(k==='NEXTAUTH_URL'){
      if(ref) return;
      if(/^http:\/\//i.test(v)){
        if(/^http:\/\/(localhost|127\.0\.0\.1|\[::1\])([:\/]|$)/i.test(v)){
          add(e.line,'WARNING',k,'NEXTAUTH_URL uses http on localhost. Fine for local testing; switch to https before any public deployment.',v.length);
        } else {
          add(e.line,'CRITICAL',k,'NEXTAUTH_URL uses plain http on a public host. Session cookies and sign-in traffic will cross the network unencrypted — use https.',v.length);
        }
      } else if(!/^https:\/\//i.test(v) && v){
        add(e.line,'WARNING',k,'NEXTAUTH_URL does not start with https:// — check the value matches the exact public address users sign in from.',v.length);
      }
      return;
    }
    if(k==='DISABLE_SIGNUPS'){
      var lv=v.toLowerCase();
      if(lv==='false'||lv==='0'||lv==='no'){ add(e.line,'CRITICAL',k,'DISABLE_SIGNUPS is false — anyone who can reach the server can create an account. Set it to true once your own account exists.',v.length); }
      return;
    }
    if(/ALLOW_PRIVATE/.test(k) || /DISABLE_SSRF/.test(k)){
      var lv2=v.toLowerCase();
      if(lv2==='true'){ add(e.line,'CRITICAL',k,k+' is true — the crawler / fetcher can be pointed at private LAN addresses (SSRF risk). Leave private-network fetching off unless you fully trust every user.',v.length); }
      return;
    }
    if(/_SECRET$|_MASTER_KEY$|_PASSWORD$|_TOKEN$/.test(k) && PROVIDER_KEYS.indexOf(k)===-1){
      if(ref || !v) return;
      if(EXAMPLE_RE.test(v)){ add(e.line,'CRITICAL',k,'Secret '+k+' is a known example / placeholder value.',v.length); }
      else if(v.length < 16){ add(e.line,'CRITICAL',k,'Secret '+k+' is too short at '+v.length+' characters (minimum 16).',v.length); }
      return;
    }
  });

  // Presence checks
  if(!byKey['NEXTAUTH_SECRET'] && !byKey['NEXTAUTH_SECRET_FILE']){
    add(null,'CRITICAL','NEXTAUTH_SECRET','NEXTAUTH_SECRET is missing. Karakeep needs a long random session secret — without one, sessions cannot be trusted.');
  }
  if(!byKey['MEILI_MASTER_KEY'] && !byKey['MEILI_MASTER_KEY_FILE']){
    add(null,'WARNING','MEILI_MASTER_KEY','MEILI_MASTER_KEY is missing from this config. If Meilisearch runs without a master key, its API is unauthenticated on its network.');
  }
  if(!byKey['NEXTAUTH_URL']){
    add(null,'WARNING','NEXTAUTH_URL','NEXTAUTH_URL is missing. Auth redirects and callbacks need the exact public URL of the server.');
  }
  if(!byKey['DISABLE_SIGNUPS']){
    add(null,'WARNING','DISABLE_SIGNUPS','DISABLE_SIGNUPS is not set. Set DISABLE_SIGNUPS=true after creating your account so registration is not left open by default.');
  }

  findings.sort(function(a,b){ var la=(a.line==null?9999:a.line), lb=(b.line==null?9999:b.line); return la-lb; });
  var hasCrit = findings.some(function(f){return f.severity==='CRITICAL';});
  var hasWarn = findings.some(function(f){return f.severity==='WARNING';});
  var verdict = hasCrit ? 'DO NOT DEPLOY' : (hasWarn ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY');
  return {verdict:verdict, findings:findings, recognisedKeys:keyed.length, totalLines:parsed.lines.length};
}

function reportText(r){
  var out = [];
  out.push('J-Dawgs Karakeep Server Config Safety Auditor — report');
  out.push('Verdict: '+r.verdict);
  out.push('Recognised Karakeep keys: '+r.recognisedKeys+' · Lines scanned: '+r.totalLines+' · Findings: '+r.findings.length);
  out.push('Secrets are reported by key name, line, and value length only.');
  out.push('');
  if(r.verdict==='NOT ENOUGH TO GRADE'){ out.push('Not enough recognisable Karakeep configuration to grade. Paste a .env, compose, or YAML-ish config with at least two Karakeep keys.'); }
  else if(r.findings.length===0){ out.push('No findings. No rule fired on the pasted config.'); }
  else{
    r.findings.forEach(function(f){
      var loc = (f.line==null) ? 'Line — (missing)' : 'Line '+f.line;
      var len = (typeof f.valueLength==='number') ? ' (value length: '+f.valueLength+')' : '';
      out.push(loc+' ['+f.severity+'] '+f.key+len+' — '+f.message);
    });
  }
  out.push('');
  out.push('Heuristic text audit only. This report does not verify a running server.');
  return out.join('\n');
}
function jsonText(r){
  return JSON.stringify({tool:'J-Dawgs Karakeep Server Config Safety Auditor', verdict:r.verdict, recognisedKeys:r.recognisedKeys, linesScanned:r.totalLines, findings:r.findings.map(function(f){ var o={line:f.line, severity:f.severity, key:f.key, message:f.message}; if(typeof f.valueLength==='number') o.valueLength=f.valueLength; return o; })}, null, 2);
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RE": (typeof EXAMPLE_RE !== 'undefined' ? EXAMPLE_RE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-karakeep-server-config-safety-auditor',
  name: 'J-Dawgs Karakeep Server Config Safety Auditor',
  description: 'Grades a pasted Karakeep .env/config offline into one deploy verdict: short or example NEXTAUTH_SECRET and MEILI_MASTER_KEY values, an http NEXTAUTH_URL, and open signups all graded, with secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RE": __core["EXAMPLE_RE"] }
};
