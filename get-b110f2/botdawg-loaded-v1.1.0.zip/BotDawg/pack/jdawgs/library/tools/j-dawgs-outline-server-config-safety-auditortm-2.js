'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Outline Server Config Safety Auditor™; builder assigned the -2 slug because the base slug already existed in the catalog".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Outline config - RISKY worked example (do not deploy)",
          "SECRET_KEY=shortkey123",
          "UTILS_SECRET=changeme",
          "DATABASE_URL=postgres://outline:dbpass@db.internal:5432/outline",
          "REDIS_URL=redis://:redispw@redis.internal:6379",
          "URL=http://wiki.example.com",
          "FORCE_HTTPS=false",
          "DEBUG=true",
          "ENABLE_UPDATES=true",
          "ALLOWED_DOMAINS=*",
          "AWS_ACCESS_KEY_ID=AKIAEXAMPLE123",
          "AWS_SECRET_ACCESS_KEY=awssecretshort",
          "SMTP_HOST=smtp.example.com",
          "SMTP_USERNAME=outline@example.com",
          "SMTP_PASSWORD=smtppass123",
          "SMTP_FROM_EMAIL=outline@example.com"
        ].join("\n");

        var HARDENED = [
          "# Outline config - HARDENED example",
          "SECRET_KEY=f47ac10b58cc4372a5670e02b2c3d479f47ac10b58cc4372a5670e02b2c3d479aa",
          "UTILS_SECRET=9d2f8a41c6e74b05a1d3f8c2e6b94a07d5f1c8a3e6b2094f7d5a1c8e3b6f90247",
          "DATABASE_URL=postgres://outline:V3ryLongDbPassw0rd-4821@db.internal:5432/outline?sslmode=require",
          "REDIS_URL=redis://:R3disLongPassw0rd-7392@redis.internal:6379",
          "URL=https://wiki.example.com",
          "FORCE_HTTPS=true",
          "DEBUG=false",
          "ENABLE_UPDATES=false",
          "ALLOWED_DOMAINS=docs.example.com",
          "AWS_ACCESS_KEY_ID=AKIA7F3K9D2M8Q1XZ4PL",
          "AWS_SECRET_ACCESS_KEY=k8f2N9pQ4rT7vX1zB5mD8sH3jL6wY0aC4eG9iK2nP5",
          "SMTP_HOST=smtp.example.com",
          "SMTP_USERNAME=outline@example.com",
          "SMTP_PASSWORD=Sm7pLongPassw0rd-5519",
          "SMTP_FROM_EMAIL=outline@example.com"
        ].join("\n");

        var RECOGNIZED = {
          SECRET_KEY:1, UTILS_SECRET:1, DATABASE_URL:1, REDIS_URL:1, URL:1, FORCE_HTTPS:1,
          DEBUG:1, ENABLE_UPDATES:1, ALLOWED_DOMAINS:1, ALLOWED_HOST_DOMAINS:1,
          AWS_ACCESS_KEY_ID:1, AWS_SECRET_ACCESS_KEY:1, AWS_REGION:1, AWS_S3_UPLOAD_BUCKET_NAME:1,
          SMTP_HOST:1, SMTP_PORT:1, SMTP_USERNAME:1, SMTP_PASSWORD:1, SMTP_FROM_EMAIL:1, SMTP_SECURE:1,
          GOOGLE_CLIENT_ID:1, GOOGLE_CLIENT_SECRET:1, OIDC_CLIENT_ID:1, OIDC_CLIENT_SECRET:1,
          SLACK_CLIENT_ID:1, SLACK_CLIENT_SECRET:1, PORT:1, NODE_ENV:1, PGSSLMODE:1, FILE_STORAGE:1
        };
        var SECRET_KEYS = { SECRET_KEY:1, UTILS_SECRET:1, AWS_SECRET_ACCESS_KEY:1, AWS_ACCESS_KEY_ID:1,
          SMTP_PASSWORD:1, GOOGLE_CLIENT_SECRET:1, OIDC_CLIENT_SECRET:1, SLACK_CLIENT_SECRET:1 };
        var EXAMPLE_PATTERNS = ["changeme","change-me","change_me","example","secret","password","passwd",
          "letmein","placeholder","replace-me","replace_me","your-secret","your_secret","shortkey",
          "default","test123","demo123","123456","abcdef","xxxxxx","todo"];

        var els = {};
        ["configInput","runBtn","loadRiskyBtn","loadHardenedBtn","clearBtn","runStatus","verdictBox",
         "countsBox","leakBox","findingsWrap","passedList","reportOut","jsonOut","copyReportBtn",
         "copyJsonBtn","downloadJsonBtn","copyStatus","workedExample","copyExampleBtn","useExampleBtn",
         "pitchStatus"].forEach(function(id){ els[id] = document.getElementById(id); });

        var lastReport = "", lastJson = "", lastJsonObj = null;

        function stripQuotes(v){
          v = v.trim();
          if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
            return v.slice(1,-1);
          }
          return v;
        }
        function isExampleValue(v){
          var low = v.toLowerCase();
          for (var i=0;i<EXAMPLE_PATTERNS.length;i++){ if (low.indexOf(EXAMPLE_PATTERNS[i]) !== -1) return true; }
          return false;
        }
        function urlPassword(url){
          var m = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^@]*)@/.exec(url);
          if (!m) return null;
          var seg = m[1], colon = seg.indexOf(":");
          if (colon !== -1) return seg.slice(colon + 1);
          // redis://password@host form (no user, no colon)
          if (/^redis/i.test(url) && seg) return seg;
          return null;
        }
        function countOccurrences(haystack, needle){
          if (!needle) return 0;
          var n = 0, idx = 0;
          while (true){ idx = haystack.indexOf(needle, idx); if (idx === -1) break; n++; idx += needle.length; }
          return n;
        }

        function audit(text){
          var findings = [], passed = [], secretValues = [];
          function add(sev, line, key, len, issue, fix){
            findings.push({severity:sev, line:(line==null?null:line), key:key,
              valueLength:(len==null?null:len), issue:issue, fix:fix});
          }
          function pass(msg){ passed.push(msg); }

          var lines = String(text || "").split(/\r?\n/);
          var entries = {}, entryList = [], configLines = 0, recognized = 0;
          for (var i=0;i<lines.length;i++){
            var raw = lines[i];
            var m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(raw);
            if (m){
              configLines++;
              var key = m[1].toUpperCase();
              var val = stripQuotes(m[2]);
              var e = {key:key, value:val, line:i+1};
              entries[key] = e; entryList.push(e);
              if (RECOGNIZED[key]) recognized++;
              if (SECRET_KEYS[key] && val) secretValues.push(val);
              if ((key==="DATABASE_URL" || key==="REDIS_URL")){
                var pw = urlPassword(val);
                if (pw) secretValues.push(pw);
              }
            }
          }

          if (configLines < 3 || recognized < 2){
            return { verdict:"NOT ENOUGH TO GRADE", findings:[], passed:[],
              linesScanned:lines.length, configLines:configLines, recognized:recognized,
              secretValues:secretValues, insufficient:true,
              note:"The pasted text does not look like an env-style config (found " + configLines +
                " key=value line(s), " + recognized + " recognized Outline key(s)). Paste a .env-style config with keys such as SECRET_KEY, DATABASE_URL, and URL." };
          }

          // --- SECRET_KEY / UTILS_SECRET ---
          ["SECRET_KEY","UTILS_SECRET"].forEach(function(k){
            var e = entries[k];
            if (!e){ add("HIGH", null, k, 0, k + " is not set. Outline needs a long random value here; an unset or defaulted secret undermines session security.", "Set " + k + " to a fresh random value of at least 32 characters (64 is a good target) from a password generator or secret manager."); return; }
            if (isExampleValue(e.value)){ add("CRITICAL", e.line, k, e.value.length, k + " matches a known example/placeholder pattern and is only " + e.value.length + " characters long. Anyone who has seen the docs can guess it.", "Replace " + k + " with a fresh random value of at least 32 characters that appears nowhere public."); }
            else if (e.value.length < 32){ add("HIGH", e.line, k, e.value.length, k + " is only " + e.value.length + " characters long (minimum checked: 32). Short secrets are brute-forceable.", "Regenerate " + k + " at 32+ characters (64 recommended) and restart the server."); }
            else pass(k + " (line " + e.line + ") is " + e.value.length + " characters and matches no known example pattern.");
          });

          // --- DATABASE_URL ---
          (function(){
            var e = entries.DATABASE_URL;
            if (!e){ add("HIGH", null, "DATABASE_URL", 0, "DATABASE_URL is not set, so the database connection cannot be graded.", "Set DATABASE_URL explicitly with a dedicated database user and a long password."); return; }
            var pw = urlPassword(e.value);
            if (pw === null){ add("MEDIUM", e.line, "DATABASE_URL", null, "DATABASE_URL carries no embedded password (length not measurable). If the database expects one, the connection relies on ambient trust.", "Prefer an explicit password in the URL or a managed secret reference, with a dedicated least-privilege database user."); }
            else if (isExampleValue(pw)){ add("CRITICAL", e.line, "DATABASE_URL", pw.length, "The password embedded in DATABASE_URL matches a known example/placeholder pattern and is " + pw.length + " characters long. The value itself is never printed here.", "Rotate the database password to a fresh random value of 16+ characters and update DATABASE_URL."); }
            else if (pw.length < 16){ add("HIGH", e.line, "DATABASE_URL", pw.length, "The password embedded in DATABASE_URL is only " + pw.length + " characters long (minimum checked: 16). The value itself is never printed here.", "Rotate the database password to a fresh random value of 16+ characters and update DATABASE_URL."); }
            else pass("DATABASE_URL (line " + e.line + ") embeds a password of " + pw.length + " characters with no example pattern.");
            if (!/[?&]sslmode=require/.test(e.value) && !/ssl=true/i.test(e.value)){
              add("MEDIUM", e.line, "DATABASE_URL", null, "DATABASE_URL does not request TLS (no sslmode=require). Credentials and content may cross the network in plaintext if the database is remote.", "Add sslmode=require (or your provider's TLS setting) when the database is not on the same trusted host.");
            } else pass("DATABASE_URL (line " + e.line + ") requests a TLS connection.");
          })();

          // --- REDIS_URL ---
          (function(){
            var e = entries.REDIS_URL;
            if (!e){ add("LOW", null, "REDIS_URL", 0, "REDIS_URL is not set. Fine for a single-process trial, but sessions and queues expect Redis in a real deployment.", "Set REDIS_URL with a password-protected Redis instance for production."); return; }
            var pw = urlPassword(e.value);
            if (pw === null || pw === ""){ add("MEDIUM", e.line, "REDIS_URL", 0, "REDIS_URL carries no password. Anyone who can reach the Redis port can read or flush session data.", "Require a Redis password (requirepass / ACL) and include it in REDIS_URL."); }
            else if (isExampleValue(pw) || pw.length < 16){ add("HIGH", e.line, "REDIS_URL", pw.length, "The password embedded in REDIS_URL is " + pw.length + " characters long" + (isExampleValue(pw) ? " and matches a known example/placeholder pattern" : "") + " (minimum checked: 16). The value itself is never printed here.", "Rotate the Redis password to a fresh random value of 16+ characters and update REDIS_URL."); }
            else pass("REDIS_URL (line " + e.line + ") embeds a password of " + pw.length + " characters with no example pattern.");
          })();

          // --- URL + FORCE_HTTPS ---
          (function(){
            var e = entries.URL;
            if (!e){ add("HIGH", null, "URL", 0, "URL is not set. Outline builds links and cookies from it, so it must be the exact public address.", "Set URL to the full public address users visit, starting with https://."); }
            else if (/^http:\/\//i.test(e.value)){ add("HIGH", e.line, "URL", null, "URL uses plain http://. Logins and content would travel unencrypted.", "Serve Outline over https:// (directly or behind a TLS-terminating proxy) and update URL to match."); }
            else if (/^https:\/\//i.test(e.value)){ pass("URL (line " + e.line + ") uses https://."); }
            else add("MEDIUM", e.line, "URL", null, "URL does not start with http:// or https://, so its scheme cannot be graded.", "Set URL to the full public address including the https:// scheme.");
            var f = entries.FORCE_HTTPS;
            if (!f){ add("MEDIUM", null, "FORCE_HTTPS", 0, "FORCE_HTTPS is not set. Unless the proxy handles it, http requests may not be redirected to https.", "Set FORCE_HTTPS=true when Outline is served over HTTPS."); }
            else if (f.value.toLowerCase() !== "true"){ add("HIGH", f.line, "FORCE_HTTPS", null, "FORCE_HTTPS is not true, so the server will not force HTTPS even if the public URL is https.", "Set FORCE_HTTPS=true (after HTTPS is actually terminated in front of Outline)."); }
            else pass("FORCE_HTTPS (line " + f.line + ") is true.");
          })();

          // --- DEBUG ---
          (function(){
            var e = entries.DEBUG;
            if (e && e.value.toLowerCase() === "true"){ add("HIGH", e.line, "DEBUG", null, "DEBUG=true turns on verbose debug behavior that can leak internals and is meant for local troubleshooting only.", "Set DEBUG=false (or remove it) for any deployed server."); }
            else if (e){ pass("DEBUG (line " + e.line + ") is not enabled."); }
          })();

          // --- ENABLE_UPDATES ---
          (function(){
            var e = entries.ENABLE_UPDATES;
            if (!e){ add("LOW", null, "ENABLE_UPDATES", 0, "ENABLE_UPDATES is not set, so the update posture is whatever the default is — decide it on purpose.", "Set ENABLE_UPDATES explicitly: false for controlled/manual upgrades, true only if in-app update checks fit your process."); }
            else if (e.value.toLowerCase() === "true"){ add("MEDIUM", e.line, "ENABLE_UPDATES", null, "ENABLE_UPDATES=true: the server will check for and surface updates in-app. That is a posture choice, not a defect — make sure it matches how you actually patch.", "Keep true only if someone acts on update prompts promptly; otherwise set false and upgrade on a schedule you control."); }
            else pass("ENABLE_UPDATES (line " + e.line + ") is off — updates are a deliberate, manual act.");
          })();

          // --- ALLOWED_DOMAINS ---
          (function(){
            var e = entries.ALLOWED_DOMAINS || entries.ALLOWED_HOST_DOMAINS;
            var k = entries.ALLOWED_DOMAINS ? "ALLOWED_DOMAINS" : "ALLOWED_HOST_DOMAINS";
            if (!e){ add("MEDIUM", null, "ALLOWED_DOMAINS", 0, "ALLOWED_DOMAINS is not set, so which domains may sign up or be embedded is left to defaults.", "Set ALLOWED_DOMAINS to the specific domain(s) your team uses."); return; }
            if (e.value.trim() === ""){ add("HIGH", e.line, k, 0, k + " is set but empty, which can behave like no restriction at all depending on version and defaults.", "List the specific allowed domain(s), or remove the key entirely if you have confirmed the default behavior you want."); }
            else if (e.value.indexOf("*") !== -1){ add("HIGH", e.line, k, null, k + " contains a wildcard, which allows far more than one organization's domain.", "Replace the wildcard with the specific domain(s) your team uses."); }
            else pass(k + " (line " + e.line + ") names specific domain(s) with no wildcard.");
          })();

          // --- AWS / S3 ---
          (function(){
            var id = entries.AWS_ACCESS_KEY_ID, sec = entries.AWS_SECRET_ACCESS_KEY;
            if (!id && !sec){ add("INFO", null, "AWS_*", null, "No AWS access keys found. Fine if file storage is local or provided another way; ungraded either way.", "No action needed unless you use S3 storage — then set dedicated, least-privilege keys."); }
            if (id){
              if (isExampleValue(id.value)){ add("HIGH", id.line, "AWS_ACCESS_KEY_ID", id.value.length, "AWS_ACCESS_KEY_ID matches a known example/placeholder pattern — it reads like the sample key from documentation, not a real issued key. The value itself is never printed here.", "Use the real access key ID issued for a dedicated IAM user, or remove the sample."); }
              else if (id.value.length < 16){ add("MEDIUM", id.line, "AWS_ACCESS_KEY_ID", id.value.length, "AWS_ACCESS_KEY_ID is only " + id.value.length + " characters long, shorter than an issued key ID.", "Check the key ID was pasted in full."); }
              else pass("AWS_ACCESS_KEY_ID (line " + id.line + ") is " + id.value.length + " characters with no example pattern.");
            }
            if (sec){
              if (isExampleValue(sec.value)){ add("CRITICAL", sec.line, "AWS_SECRET_ACCESS_KEY", sec.value.length, "AWS_SECRET_ACCESS_KEY matches a known example/placeholder pattern and is " + sec.value.length + " characters long. The value itself is never printed here.", "Rotate the IAM secret access key and store the new one in a secret manager, not in a shared file."); }
              else if (sec.value.length < 32){ add("HIGH", sec.line, "AWS_SECRET_ACCESS_KEY", sec.value.length, "AWS_SECRET_ACCESS_KEY is only " + sec.value.length + " characters long (minimum checked: 32). The value itself is never printed here.", "Rotate the IAM secret access key; issued secrets are longer than this. Keep the new one in a secret manager."); }
              else pass("AWS_SECRET_ACCESS_KEY (line " + sec.line + ") is " + sec.value.length + " characters with no example pattern.");
            }
            if (id && !sec){ add("MEDIUM", id.line, "AWS_SECRET_ACCESS_KEY", 0, "An AWS access key ID is set but AWS_SECRET_ACCESS_KEY is missing, so S3 storage cannot authenticate.", "Set both halves of the key pair, or neither."); }
          })();

          // --- SMTP ---
          (function(){
            var pw = entries.SMTP_PASSWORD, user = entries.SMTP_USERNAME, host = entries.SMTP_HOST;
            if (pw){
              if (isExampleValue(pw.value)){ add("CRITICAL", pw.line, "SMTP_PASSWORD", pw.value.length, "SMTP_PASSWORD matches a known example/placeholder pattern and is " + pw.value.length + " characters long. The value itself is never printed here.", "Rotate the mailbox/app password and store the new one in a secret manager."); }
              else if (pw.value.length < 16){ add("HIGH", pw.line, "SMTP_PASSWORD", pw.value.length, "SMTP_PASSWORD is only " + pw.value.length + " characters long (minimum checked: 16). The value itself is never printed here.", "Use a dedicated app password of 16+ characters for the sending mailbox and rotate the current one."); }
              else pass("SMTP_PASSWORD (line " + pw.line + ") is " + pw.value.length + " characters with no example pattern.");
            } else if (user || host){
              add("MEDIUM", (user||host).line, "SMTP_PASSWORD", 0, "SMTP is configured but SMTP_PASSWORD is not set, so outgoing mail (invites, resets) likely cannot authenticate.", "Set SMTP_PASSWORD to a dedicated app password for the sending mailbox.");
            } else {
              add("INFO", null, "SMTP_*", null, "No SMTP settings found. Outline needs working email for invites and password resets in most deployments; ungraded here.", "Configure SMTP_* for production, or confirm another mail path exists.");
            }
          })();

          var counts = {CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0};
          findings.forEach(function(f){ counts[f.severity]++; });
          var verdict;
          if (counts.CRITICAL > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
          else if (counts.MEDIUM > 0 || counts.LOW > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";
          return { verdict:verdict, findings:findings, passed:passed, linesScanned:lines.length,
            configLines:configLines, recognized:recognized, secretValues:secretValues, counts:counts, insufficient:false };
        }

        function buildOutputs(r){
          var counts = r.counts || {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0};
          var rep = [];
          rep.push("J-DAWGS OUTLINE SERVER CONFIG SAFETY AUDITOR - REPORT");
          rep.push("Verdict: " + r.verdict);
          rep.push("Lines scanned: " + r.linesScanned + " | Config lines: " + r.configLines + " | Recognized Outline keys: " + r.recognized);
          rep.push("Findings: " + r.findings.length + " (CRITICAL " + counts.CRITICAL + ", HIGH " + counts.HIGH + ", MEDIUM " + counts.MEDIUM + ", LOW " + counts.LOW + ", INFO " + counts.INFO + ") | Checks passed: " + r.passed.length);
          rep.push("Secret handling: secret values are never printed. Findings report key name, line, and value length only.");
          rep.push("");
          if (r.insufficient){
            rep.push("Why it cannot be graded:");
            rep.push("- " + r.note);
          } else {
            rep.push("Findings:");
            if (!r.findings.length) rep.push("- None.");
            r.findings.forEach(function(f){
              rep.push("- [" + f.severity + "] " + (f.line ? "Line " + f.line : "Line - (key not present)") + " - " + f.key +
                (f.valueLength != null ? " (value length: " + f.valueLength + ")" : "") + ": " + f.issue + " Fix: " + f.fix);
            });
            rep.push("");
            rep.push("Checks passed:");
            if (!r.passed.length) rep.push("- None.");
            r.passed.forEach(function(p){ rep.push("- " + p); });
          }
          rep.push("");
          rep.push("Limits: heuristic text audit only. This tool does not start Outline and cannot verify secrets against a live server.");
          var report = rep.join("\n");

          var obj = {
            tool: "J-Dawgs Outline Server Config Safety Auditor",
            verdict: r.verdict,
            linesScanned: r.linesScanned,
            configLines: r.configLines,
            recognizedKeys: r.recognized,
            counts: counts,
            findings: r.findings,
            passedChecks: r.passed,
            secretValuesPrinted: 0,
            note: r.insufficient ? r.note : "Secret values are excluded by construction: findings carry key name, line, severity, and value length only.",
            limits: "Heuristic text audit only. Does not start Outline; cannot verify secrets against a live server."
          };
          var json = JSON.stringify(obj, null, 2);
          return { report: report, json: json, obj: obj };
        }

        function esc(s){
          return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
        }

        function render(r){
          var vb = els.verdictBox;
          vb.className = "verdict show " + (r.verdict==="DO NOT DEPLOY" ? "v-dnd" : r.verdict==="DEPLOY WITH FIXES" ? "v-fixes" : r.verdict==="SAFE TO DEPLOY" ? "v-safe" : "v-neg");
          var small = r.verdict==="DO NOT DEPLOY" ? "Critical or high-severity problems must be fixed before this config goes live."
            : r.verdict==="DEPLOY WITH FIXES" ? "No critical or high findings, but the medium/low items below should be fixed first."
            : r.verdict==="SAFE TO DEPLOY" ? "No findings on the checks this auditor runs. The honest limits below still apply."
            : "The pasted text does not look like an env-style config, so there is nothing fair to grade.";
          vb.innerHTML = esc(r.verdict) + "<small>" + esc(small) + "</small>";

          var counts = r.counts || {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0};
          els.countsBox.innerHTML = [
            ["Lines scanned", r.linesScanned], ["Config lines", r.configLines], ["Recognized keys", r.recognized],
            ["CRITICAL", counts.CRITICAL], ["HIGH", counts.HIGH], ["MEDIUM", counts.MEDIUM],
            ["LOW", counts.LOW], ["INFO", counts.INFO], ["Passed", r.passed.length]
          ].map(function(c){ return '<span class="chip">' + esc(c[0]) + ": " + esc(c[1]) + "</span>"; }).join("");

          if (r.insufficient){
            els.findingsWrap.innerHTML = "<p>" + esc(r.note) + "</p>";
            els.passedList.innerHTML = "<li>—</li>";
          } else if (!r.findings.length){
            els.findingsWrap.innerHTML = "<p>No findings. Every check this auditor runs passed on the pasted config.</p>";
            els.passedList.innerHTML = r.passed.map(function(p){ return "<li>" + esc(p) + "</li>"; }).join("") || "<li>—</li>";
          } else {
            var rows = r.findings.map(function(f){
              return "<tr><td data-l='Severity'><span class='sev sev-" + f.severity + "'>" + f.severity + "</span></td>" +
                "<td data-l='Line'>" + (f.line ? f.line : "—") + "</td>" +
                "<td data-l='Key'><code>" + esc(f.key) + "</code>" + (f.valueLength != null ? "<br>value length: " + f.valueLength : "") + "</td>" +
                "<td data-l='Issue'>" + esc(f.issue) + "</td>" +
                "<td data-l='Fix'>" + esc(f.fix) + "</td></tr>";
            }).join("");
            els.findingsWrap.innerHTML = "<table><thead><tr><th>Severity</th><th>Line</th><th>Key</th><th>Issue</th><th>Fix</th></tr></thead><tbody>" + rows + "</tbody></table>";
            els.passedList.innerHTML = r.passed.map(function(p){ return "<li>" + esc(p) + "</li>"; }).join("") || "<li>—</li>";
          }

          var out = buildOutputs(r);
          lastReport = out.report; lastJson = out.json; lastJsonObj = out.obj;
          els.reportOut.textContent = lastReport;
          els.jsonOut.textContent = lastJson;

          // Provable leak check: scan both outputs for every secret value found in the paste.
          var combined = lastReport + "\n" + lastJson;
          var hits = 0;
          r.secretValues.forEach(function(v){ if (v && v.length >= 4) hits += countOccurrences(combined, v); });
          lastJsonObj.secretValuesPrinted = hits;
          lastJson = JSON.stringify(lastJsonObj, null, 2);
          els.jsonOut.textContent = lastJson;
          var combined2 = lastReport + "\n" + lastJson;
          var hits2 = 0;
          r.secretValues.forEach(function(v){ if (v && v.length >= 4) hits2 += countOccurrences(combined2, v); });
          els.leakBox.className = "leak show";
          els.leakBox.textContent = "Secret-leak check: scanned the text report and JSON for every secret value in your paste (" +
            r.secretValues.length + " secret value(s) tracked, reported by length only) — occurrences in outputs: " + hits2 + ".";
          els.runStatus.textContent = "Audit complete: " + r.verdict + " — " + r.findings.length + " finding(s), " + r.passed.length + " check(s) passed.";
        }

        function runAudit(){
          var r;
          try { r = audit(els.configInput.value); }
          catch (err){
            r = { verdict:"NOT ENOUGH TO GRADE", findings:[], passed:[], linesScanned:0, configLines:0,
              recognized:0, secretValues:[], counts:{CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0},
              insufficient:true, note:"That input could not be parsed as config text. Paste a .env-style config and try again." };
          }
          render(r);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_PATTERNS": (typeof EXAMPLE_PATTERNS !== 'undefined' ? EXAMPLE_PATTERNS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-outline-server-config-safety-auditortm-2',
  name: 'J-Dawgs Outline Server Config Safety Auditor™; builder assigned the -2 slug because the base slug already existed in the catalog',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_PATTERNS": __core["EXAMPLE_PATTERNS"] }
};
