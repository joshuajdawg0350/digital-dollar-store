'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs JSONPath & Selector Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the evaluate function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var EXAMPLE_JSON = [
        '{',
        '  "orderId": "ORD-1042",',
        '  "customer": {',
        '    "name": "Ada Lovelace",',
        '    "email": "ada@example.com"',
        '  },',
        '  "items": [',
        '    { "sku": "WDG-100", "price": 12.50, "qty": 1 },',
        '    { "sku": "WDG-250", "price": 8.00,  "qty": 3 },',
        '    { "sku": "CBL-075", "price": 4.25,  "qty": 2 }',
        '  ],',
        '  "total": 37.50',
        '}'
      ].join("\n");

      var EXAMPLE_SELECTORS = [
        "# Worked example — expected grades are noted in each comment.",
        "# $.customer.name ............ LIVE (1 match)",
        "# $.items[*].sku | min: 2 .... LIVE (3 matches, min met)",
        "# $.order.customers .......... EMPTY (plural typo; stops at .order)",
        "# $.total | expect: string ... TYPE MISMATCH (total is a number)",
        "# $.items[?( @.qty > 2 )] .... NOT SUPPORTED (filter expression)",
        "$.customer.name",
        "$.items[*].sku | min: 2",
        "$.order.customers",
        "$.total | expect: string",
        "$.items[?( @.qty > 2 )]"
      ].join("\n");

      var TYPES = ["string", "number", "boolean", "array", "object", "null", "any"];

      function $(id) { return document.getElementById(id); }

      /* ---------- selector line format ---------- */

      function parseLine(line) {
        var parts = line.split("|");
        var path = parts[0].trim();
        var expect = null, min = null;
        for (var p = 1; p < parts.length; p++) {
          var d = parts[p].trim();
          var m = /^expect\s*:\s*(\S+)$/i.exec(d);
          if (m) {
            var t = m[1].toLowerCase();
            if (TYPES.indexOf(t) === -1) {
              return { error: 'unknown expect type "' + m[1] + '" (use string, number, boolean, array, object, null, or any)' };
            }
            expect = t;
            continue;
          }
          m = /^min\s*:\s*(\S+)$/i.exec(d);
          if (m) {
            if (!/^\d+$/.test(m[1])) {
              return { error: 'min must be a non-negative integer, got "' + m[1] + '"' };
            }
            min = parseInt(m[1], 10);
            continue;
          }
          return { error: 'unrecognized directive "' + d + '" (use "expect: TYPE" or "min: N")' };
        }
        if (!path) return { error: "empty path before the first |" };
        return { path: path, expect: expect, min: min };
      }

      /* ---------- path parser (documented subset only) ---------- */

      function readField(path, i) {
        var start = i;
        while (i < path.length && path[i] !== "." && path[i] !== "[") i++;
        var name = path.slice(start, i);
        if (!name) return { error: "empty field name at position " + start };
        return { name: name, next: i };
      }

      function parseBracket(path, i) {
        // path[i] === '[' ; find the closing ']' outside quotes
        var j = i + 1, quote = null;
        while (j < path.length) {
          var ch = path[j];
          if (quote) {
            if (ch === "\\") { j += 2; continue; }
            if (ch === quote) quote = null;
          } else if (ch === "'" || ch === '"') {
            quote = ch;
          } else if (ch === "]") {
            break;
          }
          j++;
        }
        if (j >= path.length) return { error: "unterminated [ at position " + i };
        var inner = path.slice(i + 1, j).trim();
        var next = j + 1;

        if (inner.charAt(0) === "'" || inner.charAt(0) === '"') {
          var q = inner.charAt(0), name = "", k = 1, closed = false;
          while (k < inner.length) {
            var c = inner[k];
            if (c === "\\" && k + 1 < inner.length) { name += inner[k + 1]; k += 2; continue; }
            if (c === q) { closed = true; k++; break; }
            name += c; k++;
          }
          if (!closed) return { error: "unterminated quoted name in [" + inner + "]" };
          if (inner.slice(k).trim() !== "") {
            if (inner.indexOf(",", k) !== -1) return { unsupported: "union [" + inner + "]" };
            return { error: "unexpected text after quoted name in [" + inner + "]" };
          }
          return { step: { kind: "child", name: name, label: "['" + name + "']" }, next: next };
        }
        if (inner.indexOf("?(") === 0) return { unsupported: "filter expression [?(...)]" };
        if (inner.indexOf(",") !== -1) return { unsupported: "union [" + inner + "]" };
        if (inner === "*") return { step: { kind: "wildcard", label: "[*]" }, next: next };
        if (/^-?\d+$/.test(inner)) {
          return { step: { kind: "index", index: parseInt(inner, 10), label: "[" + inner + "]" }, next: next };
        }
        if (inner.indexOf(":") !== -1) {
          var bits = inner.split(":");
          if (bits.length > 2) return { unsupported: "slice with step [" + inner + "]" };
          var start = bits[0].trim(), end = bits[1].trim();
          if ((start !== "" && !/^-?\d+$/.test(start)) || (end !== "" && !/^-?\d+$/.test(end))) {
            return { error: 'slice bounds must be integers in "[' + inner + ']"' };
          }
          return {
            step: {
              kind: "slice",
              start: start === "" ? null : parseInt(start, 10),
              end: end === "" ? null : parseInt(end, 10),
              label: "[" + inner + "]"
            },
            next: next
          };
        }
        if (inner.indexOf("(") !== -1 || inner.charAt(0) === "@" || inner.charAt(0) === "$" || inner.charAt(0) === "?") {
          return { unsupported: "script expression [" + inner + "]" };
        }
        if (inner === "") return { error: "empty brackets [] at position " + i };
        return { error: 'unrecognized bracket contents "[' + inner + ']" at position ' + i };
      }

      function parsePath(path) {
        if (!path) return { error: "empty path" };
        if (path.charAt(0) !== "$") return { error: 'path must start with $ (the root), got "' + path.charAt(0) + '"' };
        var steps = [];
        var i = 1;
        while (i < path.length) {
          var c = path[i];
          if (c === ".") {
            if (path[i + 1] === ".") {
              i += 2;
              if (i >= path.length) return { error: "recursive descent .. at end of path with nothing after it" };
              if (path[i] === "[") {
                var br = parseBracket(path, i);
                if (br.error || br.unsupported) return br;
                if (br.step.kind === "child" || br.step.kind === "wildcard") {
                  br.step.recursive = true;
                  br.step.label = ".." + br.step.label;
                  steps.push(br.step);
                  i = br.next;
                } else {
                  return { unsupported: "recursive descent before " + br.step.label };
                }
              } else {
                if (path[i] === "*") return { unsupported: "recursive wildcard (..*)" };
                var rf = readField(path, i);
                if (rf.error) return rf;
                steps.push({ kind: "child", name: rf.name, label: ".." + rf.name, recursive: true });
                i = rf.next;
              }
            } else {
              i += 1;
              if (i >= path.length) return { error: "path ends with a bare ." };
              if (path[i] === "*") return { unsupported: "dot-wildcard (.*) — use [*] instead" };
              var f = readField(path, i);
              if (f.error) return f;
              steps.push({ kind: "child", name: f.name, label: "." + f.name });
              i = f.next;
            }
          } else if (c === "[") {
            var b = parseBracket(path, i);
            if (b.error || b.unsupported) return b;
            steps.push(b.step);
            i = b.next;
          } else {
            return { error: 'unexpected character "' + c + '" at position ' + i };
          }
        }
        return { steps: steps };
      }

      /* ---------- evaluation ---------- */

      function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }

      function collectAll(node, out) {
        out.push(node);
        if (Array.isArray(node)) {
          for (var a = 0; a < node.length; a++) collectAll(node[a], out);
        } else if (isObj(node)) {
          var keys = Object.keys(node);
          for (var k = 0; k < keys.length; k++) collectAll(node[keys[k]], out);
        }
      }

      function applyPlain(node, step, out) {
        var idx, keys, s;
        if (step.kind === "child") {
          if (isObj(node) && Object.prototype.hasOwnProperty.call(node, step.name)) out.push(node[step.name]);
        } else if (step.kind === "index") {
          if (Array.isArray(node)) {
            idx = step.index < 0 ? node.length + step.index : step.index;
            if (idx >= 0 && idx < node.length) out.push(node[idx]);
          }
        } else if (step.kind === "wildcard") {
          if (Array.isArray(node)) {
            for (s = 0; s < node.length; s++) out.push(node[s]);
          } else if (isObj(node)) {
            keys = Object.keys(node);
            for (s = 0; s < keys.length; s++) out.push(node[keys[s]]);
          }
        } else if (step.kind === "slice") {
          if (Array.isArray(node)) {
            var sliced = node.slice(step.start === null ? undefined : step.start, step.end === null ? undefined : step.end);
            for (s = 0; s < sliced.length; s++) out.push(sliced[s]);
          }
        }
      }

      function applyStep(node, step, out) {
        if (step.recursive) {
          var all = [];
          collectAll(node, all);
          for (var k = 0; k < all.length; k++) applyPlain(all[k], step, out);
        } else {
          applyPlain(node, step, out);
        }
      }

      function typeOf(v) {
        if (v === null) return "null";
        if (Array.isArray(v)) return "array";
        return typeof v;
      }

      function describeStop(node, step) {
        var t = typeOf(node);
        if (step.recursive) {
          return "no " + (step.kind === "child" ? 'key "' + step.name + '"' : "matching value") + " exists at any depth below this point";
        }
        if (step.kind === "child") {
          if (isObj(node)) return 'the object here has no key "' + step.name + '"';
          if (Array.isArray(node)) return "the value here is an array, and ." + step.name + " does not descend into array elements (use [*] or an index)";
          return "the value here is " + (t === "null" ? "null" : "a " + t) + ", which has no fields";
        }
        if (step.kind === "index") {
          if (Array.isArray(node)) return "index " + step.index + " is out of range (array length " + node.length + ")";
          return "the value here is " + (t === "null" ? "null" : "a " + t) + ", not an array";
        }
        if (step.kind === "wildcard") return "the value here is " + (t === "null" ? "null" : "a " + t) + ", which has no elements or values to iterate";
        if (step.kind === "slice") return "the value here is " + (t === "null" ? "null" : "a " + t) + ", not an array";
        return "";
      }

      function evaluate(doc, steps) {
        var nodes = [doc];
        for (var s = 0; s < steps.length; s++) {
          var next = [];
          for (var n = 0; n < nodes.length; n++) applyStep(nodes[n], steps[s], next);
          if (next.length === 0) {
            return { matches: [], stoppedAt: steps[s], stopNode: nodes[0] };
          }
          nodes = next;
        }
        return { matches: nodes, stoppedAt: null };
      }

      /* ---------- grading ---------- */

      function sampleOf(v) {
        var s;
        try { s = JSON.stringify(v); } catch (e) { s = undefined; }
        if (s === undefined) s = String(v);
        if (s.length > 80) s = s.slice(0, 77) + "...";
        return s;
      }

      function gradeSelector(doc, lineInfo) {
        var parsed = parsePath(lineInfo.path);
        if (parsed.unsupported) {
          return { status: "NOT SUPPORTED", count: 0, detail: "Uses a construct outside the supported subset: " + parsed.unsupported + ". Not evaluated.", samples: [] };
        }
        if (parsed.error) {
          return { status: "SYNTAX ERROR", count: 0, detail: parsed.error, samples: [] };
        }
        var ev = evaluate(doc, parsed.steps);
        if (ev.matches.length === 0) {
          var stopLabel = ev.stoppedAt ? ev.stoppedAt.label : "$";
          var why = ev.stoppedAt ? describeStop(ev.stopNode, ev.stoppedAt) : "";
          return {
            status: "EMPTY", count: 0,
            detail: "Path is valid but matched zero values (not found in this document). Matching stopped at segment " + stopLabel + (why ? " — " + why : "") + ".",
            samples: []
          };
        }
        var samples = ev.matches.slice(0, 3).map(sampleOf);
        if (lineInfo.expect && lineInfo.expect !== "any") {
          var badTypes = [];
          for (var m = 0; m < ev.matches.length; m++) {
            var t = typeOf(ev.matches[m]);
            if (t !== lineInfo.expect && badTypes.indexOf(t) === -1) badTypes.push(t);
          }
          if (badTypes.length) {
            return {
              status: "TYPE MISMATCH", count: ev.matches.length,
              detail: "Expected " + lineInfo.expect + ", found " + badTypes.join(", ") + ".",
              samples: samples
            };
          }
        }
        if (lineInfo.min !== null && ev.matches.length < lineInfo.min) {
          return {
            status: "COUNT SHORTFALL", count: ev.matches.length,
            detail: "Matched " + ev.matches.length + " value" + (ev.matches.length === 1 ? "" : "s") + ", fewer than the required min: " + lineInfo.min + ".",
            samples: samples
          };
        }
        var notes = [];
        if (lineInfo.expect && lineInfo.expect !== "any") notes.push("type " + lineInfo.expect + " confirmed");
        if (lineInfo.min !== null) notes.push("min: " + lineInfo.min + " met");
        return {
          status: "LIVE", count: ev.matches.length,
          detail: "Matched and expectations met" + (notes.length ? " (" + notes.join("; ") + ")" : "") + ".",
          samples: samples
        };
      }

      /* ---------- audit run ---------- */

      function jsonErrorInfo(err, text) {
        var msg = err && err.message ? err.message : String(err);
        var out = "JSON parse error: " + msg;
        var pos = null;
        var pm = /position (\d+)/.exec(msg);
        if (pm) pos = parseInt(pm[1], 10);
        if (pos !== null) {
          var upto = text.slice(0, pos);
          var line = upto.split("\n").length;
          var col = pos - upto.lastIndexOf("\n");
          out += "\nParser position: character " + pos + " (line " + line + ", column " + col + ").";
        } else {
          var lm = /line (\d+) column (\d+)/.exec(msg);
          if (lm) out += "\nParser position: line " + lm[1] + ", column " + lm[2] + " (as reported by the parser).";
        }
        return out;
      }

      function chipClass(status) {
        if (status === "LIVE") return "live";
        if (status === "EMPTY") return "empty";
        if (status === "TYPE MISMATCH") return "mismatch";
        if (status === "COUNT SHORTFALL") return "shortfall";
        if (status === "SYNTAX ERROR") return "syntax";
        return "unsupported";
      }
  return { "evaluate": (typeof evaluate !== 'undefined' ? evaluate : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_JSON": (typeof EXAMPLE_JSON !== 'undefined' ? EXAMPLE_JSON : undefined), "EXAMPLE_SELECTORS": (typeof EXAMPLE_SELECTORS !== 'undefined' ? EXAMPLE_SELECTORS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["evaluate"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-jsonpath-selector-pre-flight-auditor',
  name: 'J-Dawgs JSONPath & Selector Pre-Flight Auditor',
  description: 'Pre-flights a batch of JSONPath selectors against one pasted JSON document — LIVE / EMPTY (stopping segment named) / TYPE MISMATCH / COUNT SHORTFALL per selector, unsupported constructs named, and one ship verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["evaluate"]) return { ok: false, output: null, summary: 'Extracted core has no evaluate function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_JSON": __core["EXAMPLE_JSON"], "EXAMPLE_SELECTORS": __core["EXAMPLE_SELECTORS"] }
};
