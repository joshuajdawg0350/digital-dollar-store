'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Redirect Chain & Canonical Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var STORE_URL = "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8";
      var EXCHANGE_URL = "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";
      var PITCH1 = "Paste your redirect rules, get the whole graph audited \u2014 loops, 4+ hop chains, https downgrades, canonical conflicts \u2014 before launch: J-Dawgs Redirect Chain & Canonical Auditor\u2122. " + STORE_URL;
      var PITCH2 = "Migrating pages one redirect at a time? Nobody checks the accumulated graph \u2014 this audits it from the rules alone, no fetching: J-Dawgs Redirect Chain & Canonical Auditor\u2122. " + STORE_URL;
      var COPY_TEXTS = { pitch1: PITCH1, pitch2: PITCH2, storeUrl: STORE_URL, exchangeUrl: EXCHANGE_URL };

      var BAD_RULES = [
        "# Worked example \u2014 every problem below is planted on purpose.",
        "# 1) A 3-node loop: old-a -> old-b -> old-c -> old-a",
        "https://example.com/old-a -> https://example.com/old-b 301",
        "https://example.com/old-b -> https://example.com/old-c 301",
        "https://example.com/old-c -> https://example.com/old-a 301",
        "",
        "# 2) A 4-hop chain that should be flattened (and it ends on a temporary 302)",
        "https://example.com/start -> https://example.com/step-2 301",
        "https://example.com/step-2 -> https://example.com/step-3 301",
        "https://example.com/step-3 -> https://example.com/step-4 301",
        "https://example.com/step-4 -> https://example.com/final 302",
        "",
        "# 3) An https-to-http downgrade (critical)",
        "https://example.com/secure-page -> http://example.com/secure-page 301",
        "",
        "# 4) A good http-to-https upgrade",
        "http://example.com/home -> https://example.com/home 301",
        "",
        "# 5) One source, two conflicting destinations",
        "https://example.com/promo -> https://example.com/sale 301",
        "https://example.com/promo -> https://example.com/clearance 301",
        "",
        "# 6) /landing redirects to /gadgets (its canonical below disagrees)",
        "https://example.com/landing -> https://example.com/gadgets 301"
      ].join("\n");

      var BAD_CANON = [
        "# /final declares itself canonical \u2014 good.",
        "https://example.com/final -> https://example.com/final",
        "# /start's canonical points at step-2, which itself redirects \u2014 mismatch.",
        "https://example.com/start -> https://example.com/step-2",
        "# /landing's canonical contradicts where /landing actually redirects \u2014 mismatch.",
        "https://example.com/landing -> https://example.com/widgets"
      ].join("\n");

      var CLEAN_RULES = [
        "# Clean example \u2014 short hops, permanent statuses, https everywhere.",
        "http://example.com/ -> https://example.com/ 301",
        "https://example.com/old-widget -> https://example.com/widgets 301",
        "https://example.com/blog/2020/intro-post -> https://example.com/blog/intro-post 301",
        "https://example.com/shop/cart-old -> https://example.com/cart 308"
      ].join("\n");

      var CLEAN_CANON = [
        "https://example.com/widgets -> https://example.com/widgets",
        "https://example.com/blog/intro-post -> https://example.com/blog/intro-post",
        "https://example.com/cart -> https://example.com/cart"
      ].join("\n");

      var STATUSES = { "301":1, "302":1, "303":1, "307":1, "308":1, "meta":1, "js":1 };
      var TEMP_STATUSES = { "302":1, "307":1 };

      function $(id){ return document.getElementById(id); }

      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }

      /* Comparison key: lowercase scheme+host, strip one trailing slash (except root path kept as "/"). */
      function normKey(u){
        var s = String(u).trim();
        var m = s.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/([^\/:?#]*)([\s\S]*)$/);
        if(m){
          var rest = m[3] || "";
          if(rest.length > 1 && rest.charAt(rest.length-1) === "/") rest = rest.slice(0,-1);
          if(rest === "") rest = "/";
          return m[1].toLowerCase() + "://" + m[2].toLowerCase() + rest;
        }
        var t = s;
        if(t.length > 1 && t.charAt(t.length-1) === "/") t = t.slice(0,-1);
        return t.toLowerCase();
      }
      function schemeOf(u){
        var m = String(u).trim().match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : "";
      }

      function parseRedirects(text){
        var rules = [], errors = [];
        var lines = String(text).split(/\r?\n/);
        for(var i=0;i<lines.length;i++){
          var raw = lines[i].trim();
          if(!raw || raw.charAt(0) === "#") continue;
          var parts = raw.split("->");
          if(parts.length !== 2 || !parts[0].trim()){
            errors.push({ line: i+1, text: raw });
            continue;
          }
          var from = parts[0].trim();
          var rhs = parts[1].trim();
          var status = "unspecified";
          var to = rhs;
          var toks = rhs.split(/\s+/);
          if(toks.length > 1){
            var last = toks[toks.length-1].replace(/^\[/,"").replace(/\]$/,"").toLowerCase();
            if(STATUSES[last]){
              status = last;
              to = toks.slice(0, toks.length-1).join(" ");
            }
          }
          if(!to){ errors.push({ line: i+1, text: raw }); continue; }
          rules.push({ from: from, to: to, status: status, line: i+1,
                       fromKey: normKey(from), toKey: normKey(to) });
        }
        return { rules: rules, errors: errors };
      }

      function parseCanonicals(text){
        var list = [], errors = [];
        var lines = String(text).split(/\r?\n/);
        for(var i=0;i<lines.length;i++){
          var raw = lines[i].trim();
          if(!raw || raw.charAt(0) === "#") continue;
          var parts = raw.split("->");
          if(parts.length !== 2 || !parts[0].trim() || !parts[1].trim()){
            errors.push({ line: i+1, text: raw });
            continue;
          }
          var page = parts[0].trim(), canon = parts[1].trim();
          list.push({ page: page, canon: canon, line: i+1,
                      pageKey: normKey(page), canonKey: normKey(canon) });
        }
        return { list: list, errors: errors };
      }

      function audit(rulesText, canonText){
        var pr = parseRedirects(rulesText);
        var pc = parseCanonicals(canonText);
        var critical = [], warnings = [], good = [], info = [];

        /* Build graph; first rule wins for a source; conflicting seconds are findings. */
        var graph = {};      /* fromKey -> rule */
        var display = {};    /* key -> first-seen original URL */
        var allRules = pr.rules;
        var i, r;
        for(i=0;i<allRules.length;i++){
          r = allRules[i];
          if(!display[r.fromKey]) display[r.fromKey] = r.from;
          if(!display[r.toKey]) display[r.toKey] = r.to;
        }
        for(i=0;i<allRules.length;i++){
          r = allRules[i];
          if(!graph[r.fromKey]){
            graph[r.fromKey] = r;
          } else if(graph[r.fromKey].toKey !== r.toKey){
            critical.push({
              kind: "duplicate",
              title: "Conflicting duplicate source",
              body: "The source " + r.from + " is redirected by two rules with two different destinations. A server will apply only one of them \u2014 which one wins is configuration order, not intent. Delete one rule.",
              hops: [graph[r.fromKey].from, graph[r.fromKey].to],
              hops2: [r.from, r.to],
              text: "CONFLICTING DUPLICATE SOURCE: " + r.from + " -> " + graph[r.fromKey].to +
                    " (line " + graph[r.fromKey].line + ") AND -> " + r.to + " (line " + r.line + "). Only one can win; delete one rule."
            });
          } else {
            info.push({
              kind: "dup-same",
              title: "Exact duplicate rule",
              body: r.from + " -> " + r.to + " appears more than once with the same destination. Harmless, but worth tidying.",
              text: "EXACT DUPLICATE RULE: " + r.from + " -> " + r.to + " appears more than once (same destination). Harmless; tidy it."
            });
          }
        }

        /* Scheme upgrades / downgrades per graph edge. */
        var keys = Object.keys(graph);
        for(i=0;i<keys.length;i++){
          r = graph[keys[i]];
          var fs = schemeOf(r.from), ts = schemeOf(r.to);
          if(fs === "https" && ts === "http"){
            critical.push({
              kind: "downgrade",
              title: "HTTPS \u2192 HTTP downgrade (critical)",
              body: "This hop sends visitors from a secure page back to plain http: " + r.from + " -> " + r.to + ". Browsers warn, referrers leak, and any SEO or trust benefit of https is thrown away mid-journey. Point it at the https URL.",
              hops: [r.from, r.to],
              text: "DOWNGRADE (critical): " + r.from + " -> " + r.to + " sends https back to http. Point it at the https URL."
            });
          } else if(fs === "http" && ts === "https"){
            good.push({
              kind: "upgrade",
              title: "HTTP \u2192 HTTPS upgrade",
              body: r.from + " -> " + r.to + " upgrades visitors to the secure scheme. Correct.",
              hops: [r.from, r.to],
              text: "UPGRADE (good): " + r.from + " -> " + r.to
            });
          }
        }

        /* Loop detection: DFS with a path stack; record each distinct cycle once. */
        var state = {}; /* key -> 0 unvisited, 1 on stack, 2 done */
        var stack = [];
        var seenCycles = {};
        var loops = [];
        function dfs(node){
          state[node] = 1;
          stack.push(node);
          var edge = graph[node];
          if(edge){
            var nxt = edge.toKey;
            if(graph[nxt]){
              if(state[nxt] === 1){
                var idx = stack.indexOf(nxt);
                var cyc = stack.slice(idx);
                var sig = cyc.slice().sort().join("|");
                if(!seenCycles[sig]){
                  seenCycles[sig] = 1;
                  loops.push(cyc);
                }
              } else if(!state[nxt]){
                dfs(nxt);
              }
            }
          }
          stack.pop();
          state[node] = 2;
        }
        for(i=0;i<keys.length;i++){ if(!state[keys[i]]) dfs(keys[i]); }
        for(i=0;i<loops.length;i++){
          var cycKeys = loops[i];
          var cycNames = cycKeys.map(function(k){ return display[k]; });
          var seq = cycNames.concat([cycNames[0]]);
          critical.push({
            kind: "loop",
            title: "Redirect loop \u2014 " + cycNames.length + " nodes",
            body: "These pages redirect to each other forever. A browser gives up with ERR_TOO_MANY_REDIRECTS and a crawler abandons the whole cluster. Break the cycle: point one hop at a page that actually serves content.",
            hops: seq,
            text: "LOOP (" + cycNames.length + " nodes): " + seq.join(" -> ") + ". Break the cycle by pointing one hop at a page that serves content."
          });
        }

        /* Chains: maximal walks starting at sources nothing else points to. */
        var targeted = {};
        for(i=0;i<keys.length;i++){ targeted[graph[keys[i]].toKey] = 1; }
        var longest = 0;
        var chains = [];
        for(i=0;i<keys.length;i++){
          var start = keys[i];
          if(targeted[start]) continue; /* mid-chain or in a cycle with an entry edge */
          var path = [start], pathRules = [], seen = {}, cur = start, hitLoop = false;
          seen[start] = 1;
          while(graph[cur]){
            var e = graph[cur];
            pathRules.push(e);
            cur = e.toKey;
            if(seen[cur]){ hitLoop = true; break; }
            seen[cur] = 1;
            path.push(cur);
          }
          var hopsCount = pathRules.length;
          if(hopsCount > longest) longest = hopsCount;
          if(hitLoop) continue; /* reported as a loop */
          if(hopsCount > 3){
            var names = path.map(function(k){ return display[k]; });
            var first = pathRules[0], last = pathRules[pathRules.length-1];
            chains.push({ names: names, hopsCount: hopsCount, first: first, lastRule: last, finalTo: display[path[path.length-1]] });
          }
        }
        /* Also measure longest simple walk for the stats row (loop-safe). */
        for(i=0;i<chains.length;i++){
          var ch = chains[i];
          warnings.push({
            kind: "chain",
            title: "Chain of " + ch.hopsCount + " hops (over the 3-hop limit)",
            body: "Every extra hop costs load time and bleeds link equity; crawlers budget a handful of hops and then stop following. Flatten it: point the first hop straight at the final destination.",
            hops: ch.names,
            suggest: ch.first.from + " -> " + ch.finalTo + " " + (ch.first.status !== "unspecified" ? ch.first.status : "301"),
            text: "CHAIN (" + ch.hopsCount + " hops): " + ch.names.join(" -> ") +
                  "\n  FLATTEN: " + ch.first.from + " -> " + ch.finalTo + " " + (ch.first.status !== "unspecified" ? ch.first.status : "301")
          });
          if(TEMP_STATUSES[ch.lastRule.status]){
            warnings.push({
              kind: "temp-end",
              title: "Temporary " + ch.lastRule.status + " ends a long chain",
              body: "The last hop of this " + ch.hopsCount + "-hop chain \u2014 " + ch.lastRule.from + " -> " + ch.lastRule.to + " \u2014 uses a temporary status (" + ch.lastRule.status + "). A chain built up over successive moves almost always means the final home is permanent; a temporary status tells search engines to keep indexing the old URL. If the move is forever, make it a 301 or 308.",
              hops: [ch.lastRule.from, ch.lastRule.to],
              text: "TEMPORARY STATUS ENDING A LONG CHAIN: " + ch.lastRule.from + " -> " + ch.lastRule.to + " uses " + ch.lastRule.status +
                    " as the last hop of a " + ch.hopsCount + "-hop chain. If the move is permanent, use 301 or 308."
            });
          }
        }

        /* Canonical checks. */
        function finalDest(key){
          var seen2 = {}, cur2 = key, steps = 0;
          while(graph[cur2]){
            if(seen2[cur2]) return null; /* loop */
            seen2[cur2] = 1;
            cur2 = graph[cur2].toKey;
            steps++;
            if(steps > 500) return null;
          }
          return cur2;
        }
        var canonList = pc.list;
        for(i=0;i<canonList.length;i++){
          var c = canonList[i];
          if(graph[c.canonKey]){
            warnings.push({
              kind: "canon-redirects",
              title: "Canonical mismatch \u2014 canonical URL itself redirects",
              body: "The canonical tag on " + c.page + " points at " + c.canon + ", but that URL is itself redirected to " + graph[c.canonKey].to + ". A canonical must name the final, live URL \u2014 pointing it at a redirect makes engines discount or ignore it. Change the canonical to the final destination.",
              hops: [c.page, c.canon, graph[c.canonKey].to],
              text: "CANONICAL MISMATCH: " + c.page + " declares canonical " + c.canon + ", but " + c.canon + " itself redirects to " + graph[c.canonKey].to +
                    ". Point the canonical at the final destination."
            });
          } else if(graph[c.pageKey]){
            var fd = finalDest(c.pageKey);
            if(fd && fd !== c.canonKey){
              warnings.push({
                kind: "canon-contradicts",
                title: "Canonical mismatch \u2014 contradicts the redirect",
                body: c.page + " redirects (eventually) to " + display[fd] + ", but its canonical tag claims " + c.canon + " is the canonical URL. The redirect and the canonical tell two different stories about where this page lives. Make them agree.",
                hops: [c.page, display[fd]],
                text: "CANONICAL MISMATCH: " + c.page + " redirects to " + display[fd] + " but declares canonical " + c.canon + ". Make the redirect and the canonical agree."
              });
            } else if(fd && fd === c.canonKey){
              good.push({
                kind: "canon-agrees",
                title: "Canonical agrees with the redirect",
                body: c.page + " redirects to " + display[fd] + " and declares exactly that URL as canonical. Consistent.",
                text: "CANONICAL AGREES (good): " + c.page + " redirects to " + display[fd] + " and declares it canonical."
              });
            }
          } else if(c.pageKey === c.canonKey){
            good.push({
              kind: "self-canon",
              title: "Self-canonical confirmed",
              body: c.page + " declares itself as its own canonical and does not redirect anywhere. Correct for a final, live page.",
              text: "SELF-CANONICAL (good): " + c.page + " canonical is itself."
            });
          } else {
            info.push({
              kind: "canon-other",
              title: "Canonical points at another live page",
              body: c.page + " declares " + c.canon + " as canonical, and neither URL redirects in the pasted rules. No conflict found in the pasted rules.",
              text: "CANONICAL (no conflict in pasted rules): " + c.page + " -> canonical " + c.canon + "."
            });
          }
        }

        /* Parse errors. */
        for(i=0;i<pr.errors.length;i++){
          warnings.push({
            kind: "parse",
            title: "Unparsed redirect line " + pr.errors[i].line,
            body: "\u201C" + pr.errors[i].text + "\u201D does not match FROM -> TO [status], so it was left out of the graph. Fix the line and re-run.",
            text: "UNPARSED REDIRECT LINE " + pr.errors[i].line + ": " + pr.errors[i].text + " (expected FROM -> TO [status]; left out of the graph)."
          });
        }
        for(i=0;i<pc.errors.length;i++){
          warnings.push({
            kind: "parse-canon",
            title: "Unparsed canonical line " + pc.errors[i].line,
            body: "\u201C" + pc.errors[i].text + "\u201D does not match PAGE -> CANONICAL_URL, so it was not checked.",
            text: "UNPARSED CANONICAL LINE " + pc.errors[i].line + ": " + pc.errors[i].text + " (expected PAGE -> CANONICAL_URL; not checked)."
          });
        }

        var verdict, verdictClass;
        if(critical.length){
          verdict = "LOOPS OR DOWNGRADES PRESENT"; verdictClass = "bad";
        } else if(warnings.length){
          verdict = "FIX BEFORE LAUNCH"; verdictClass = "fix";
        } else {
          verdict = "CLEAN"; verdictClass = "clean";
        }

        return {
          critical: critical, warnings: warnings, good: good, info: info,
          verdict: verdict, verdictClass: verdictClass,
          ruleCount: allRules.length, canonCount: canonList.length,
          uniqueUrls: Object.keys(display).length, longest: longest,
          parsedOk: allRules.length + canonList.length
        };
      }

      function hopChainHTML(hops){
        var parts = hops.map(function(h){ return esc(h); });
        return '<div class="hopchain">' + parts.join(' <span class="arr">-&gt;</span> ') + '</div>';
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-redirect-chain-canonical-auditor',
  name: 'J-Dawgs Redirect Chain & Canonical Auditor',
  description: 'Audits a pasted redirect graph: loops, chains over 3 hops, https-to-http downgrades, and canonical mismatches; never fetches a URL',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
