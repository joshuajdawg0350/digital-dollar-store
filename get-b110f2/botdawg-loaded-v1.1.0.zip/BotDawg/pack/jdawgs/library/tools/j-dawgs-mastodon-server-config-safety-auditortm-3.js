'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mastodon Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var KNOWN_KEYS = {
        LOCAL_DOMAIN: 1, WEB_DOMAIN: 1, ALTERNATE_DOMAINS: 1, LOCAL_HTTPS_PORT: 1,
        SECRET_KEY_BASE: 1, OTP_SECRET: 1, VAPID_PRIVATE_KEY: 1, VAPID_PUBLIC_KEY: 1,
        DB_HOST: 1, DB_PORT: 1, DB_NAME: 1, DB_USER: 1, DB_PASS: 1, DB_POOL: 1, DB_SSLMODE: 1,
        REDIS_HOST: 1, REDIS_PORT: 1, REDIS_PASSWORD: 1, REDIS_DB: 1,
        SMTP_SERVER: 1, SMTP_PORT: 1, SMTP_LOGIN: 1, SMTP_PASSWORD: 1, SMTP_FROM_ADDRESS: 1,
        SMTP_AUTH_METHOD: 1, SMTP_ENABLE_STARTTLS: 1, SMTP_TLS: 1, SMTP_SSL: 1,
        SMTP_OPENSSL_VERIFY_MODE: 1, SMTP_DOMAIN: 1, SMTP_DELIVERY_METHOD: 1,
        ES_ENABLED: 1, ES_HOST: 1, ES_PORT: 1, ES_USER: 1, ES_PASS: 1, ES_PREFIX: 1,
        OPEN_REGISTRATIONS: 1, SINGLE_USER_MODE: 1, AUTHORIZED_FETCH: 1,
        LIMITED_FEDERATION_MODE: 1, WHITELIST_MODE: 1,
        IP_RETENTION_PERIOD: 1, SESSION_RETENTION_PERIOD: 1,
        S3_ENABLED: 1, S3_BUCKET: 1, S3_REGION: 1, S3_HOSTNAME: 1, S3_ENDPOINT: 1,
        AWS_ACCESS_KEY_ID: 1, SECRET_ACCESS_KEY: 1, S3_PROTOCOL: 1, S3_ALIAS_HOST: 1,
        STREAMING_API_BASE_URL: 1, TRUSTED_PROXY_IP: 1, PREPARED_STATEMENTS: 1,
        DEFAULT_LOCALE: 1, MAX_THREADS: 1, SIDEKIQ_CONCURRENCY: 1,
        PAPERCLIP_ROOT_PATH: 1, MEDIA_DOMAIN: 1, PAM_ENABLED: 1, LDAP_ENABLED: 1,
        CAS_ENABLED: 1, SAML_ENABLED: 1, OAUTH_REDIRECT_AT_SIGN_IN: 1,
        PROFILE_DIRECTORY: 1, PREVIEW_CARD_PROVIDERS: 1, FULL_TEXT_SEARCH_ENABLED: 1,
        IP_BLOCKLIST: 1, SUSPENDED_AT_LIMIT: 1, HTTP_PROXY: 1, HTTPS_PROXY: 1
      };

      var REQUIRED_KEYS = ["LOCAL_DOMAIN", "SECRET_KEY_BASE", "OTP_SECRET",
        "VAPID_PRIVATE_KEY", "VAPID_PUBLIC_KEY", "DB_HOST", "DB_NAME", "DB_USER", "REDIS_HOST"];

      var PLACEHOLDER_RE = /change[-_ ]?me|example|placeholder|your[-_ ]|insert|replace[-_ ]?me|todo|dummy|sample|xxx|test[-_ ]?secret|default[-_ ]?secret/i;

      var SEV_ORDER = { Critical: 0, High: 1, Medium: 2, Low: 3, Info: 4 };

      function isPlaceholder(v) { return PLACEHOLDER_RE.test(v); }
      function parseBool(v) {
        var s = String(v).trim().toLowerCase();
        if (s === "true" || s === "yes" || s === "1") return true;
        if (s === "false" || s === "no" || s === "0") return false;
        return null;
      }
      function stripQuotes(v) {
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }
      function hostOf(v) {
        var s = String(v).trim();
        s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//i, "");
        s = s.split("/")[0].split(":")[0];
        return s.toLowerCase();
      }
      function isIPLiteral(host) {
        return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.indexOf(":") !== -1;
      }

      function parseConfig(text) {
        var rawLines = String(text).split(/\r\n|\r|\n/);
        var entries = {};   // KEY -> {key, value, line}
        var order = [];
        var notParsed = []; // line numbers only
        var duplicates = []; // {key, firstLine, line}
        for (var i = 0; i < rawLines.length; i++) {
          var lineNo = i + 1;
          var t = rawLines[i].trim();
          if (t === "" || t.charAt(0) === "#") continue;
          var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*[:=]\s*(.*)$/);
          if (!m) { notParsed.push(lineNo); continue; }
          var key = m[1].toUpperCase();
          var value = stripQuotes(m[2].trim());
          if (Object.prototype.hasOwnProperty.call(entries, key)) {
            duplicates.push({ key: key, firstLine: entries[key].line, line: lineNo });
            entries[key] = { key: key, value: value, line: lineNo };
          } else {
            entries[key] = { key: key, value: value, line: lineNo };
            order.push(key);
          }
        }
        return { entries: entries, order: order, notParsed: notParsed, duplicates: duplicates, totalLines: rawLines.length };
      }

      function audit(text) {
        var parsed = parseConfig(text);
        var E = parsed.entries;
        var findings = [];
        function add(sev, key, line, title, fix) {
          findings.push({ severity: sev, key: key, line: (typeof line === "number" ? line : null), title: title, fix: fix });
        }
        function has(k) { return Object.prototype.hasOwnProperty.call(E, k); }
        function val(k) { return has(k) ? E[k].value : null; }
        function ln(k) { return has(k) ? E[k].line : null; }

        var recognized = 0;
        for (var k in E) { if (Object.prototype.hasOwnProperty.call(E, k) && KNOWN_KEYS[k]) recognized++; }

        if (recognized < 3) {
          add("Info", "(input)", null,
            "Too little recognizable Mastodon configuration to grade (" + recognized + " recognized Mastodon key" + (recognized === 1 ? "" : "s") + " found).",
            "Paste the contents of a real .env.production (or equivalent env-style config) with at least the core keys — LOCAL_DOMAIN, SECRET_KEY_BASE, OTP_SECRET, the VAPID keys, and the database/Redis basics — then run the audit again.");
          return finish("NOT ENOUGH TO GRADE", findings, parsed, recognized,
            "This does not look like a Mastodon config yet — fewer than 3 recognizable Mastodon keys were found, so there is nothing honest to grade.");
        }

        /* ---- LOCAL_DOMAIN & HTTPS posture ---- */
        var domainPublic = false;
        if (!has("LOCAL_DOMAIN")) {
          add("Critical", "LOCAL_DOMAIN", null,
            "LOCAL_DOMAIN is missing — Mastodon cannot build account addresses or federation URLs without it.",
            "Set LOCAL_DOMAIN to the public domain the instance will live on (bare domain only, no scheme), e.g. LOCAL_DOMAIN=your-domain, before first boot; it cannot be changed safely afterwards.");
        } else if (val("LOCAL_DOMAIN").trim() === "") {
          add("Critical", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
            "LOCAL_DOMAIN is present but empty.",
            "Set LOCAL_DOMAIN to the public domain the instance will live on (bare domain only, no scheme) before first boot.");
        } else {
          var dv = val("LOCAL_DOMAIN");
          var host = hostOf(dv);
          if (/^http:\/\//i.test(dv.trim())) {
            add("Critical", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
              "LOCAL_DOMAIN carries a plain http:// scheme — the instance is postured for plain HTTP, so logins, sessions and federation traffic are exposed in transit.",
              "Serve the instance over HTTPS only: put a TLS-terminating reverse proxy in front, set LOCAL_DOMAIN to the bare domain (no scheme), and set LOCAL_HTTPS_PORT=443.");
          } else if (/^[a-z][a-z0-9+.-]*:\/\//i.test(dv.trim())) {
            add("Low", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
              "LOCAL_DOMAIN includes a URL scheme; Mastodon expects a bare domain.",
              "Set LOCAL_DOMAIN to the bare domain only (no https:// prefix, no path).");
          }
          if (host.indexOf("example") !== -1) {
            add("High", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
              "LOCAL_DOMAIN looks like a placeholder/example domain, not a real public domain.",
              "Replace it with the real domain you control and have DNS pointed at the host before deploying.");
          } else if (host === "localhost" || /\.local$/.test(host) || host === "0.0.0.0") {
            add("High", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
              "LOCAL_DOMAIN points at localhost / a local-only name — the instance cannot federate or be reached publicly under this name.",
              "Set LOCAL_DOMAIN to a real public domain with DNS pointed at the host.");
          } else if (isIPLiteral(host)) {
            add("Medium", "LOCAL_DOMAIN", ln("LOCAL_DOMAIN"),
              "LOCAL_DOMAIN is a raw IP address rather than a domain name — TLS certificates and federation identity do not work properly on a bare IP.",
              "Point a real domain name at the host and set LOCAL_DOMAIN to that domain.");
          } else {
            domainPublic = true;
          }
          if (!has("LOCAL_HTTPS_PORT")) {
            add("High", "LOCAL_HTTPS_PORT", null,
              "LOCAL_HTTPS_PORT is not set while LOCAL_DOMAIN is present — Mastodon will build URLs on the default port assumption, which breaks links and federation when the public HTTPS port differs.",
              "Set LOCAL_HTTPS_PORT=443 (or the actual public HTTPS port if you terminate TLS somewhere non-standard).");
          } else if (val("LOCAL_HTTPS_PORT").trim() !== "443") {
            add("Medium", "LOCAL_HTTPS_PORT", ln("LOCAL_HTTPS_PORT"),
              "LOCAL_HTTPS_PORT is set to a non-443 value while a public domain is configured — every URL Mastodon generates will carry that port.",
              "If the public HTTPS port really is not 443, keep it and make sure the proxy matches; otherwise set LOCAL_HTTPS_PORT=443.");
          }
        }

        /* ---- Core secrets: SECRET_KEY_BASE / OTP_SECRET ---- */
        function coreSecret(key, label) {
          if (!has(key)) {
            add("Critical", key, null,
              label + " is missing — Mastodon will not boot safely without it.",
              "Generate a fresh value on the host (for example with `rails secret` / a 128-character random hex string), set " + key + " in the environment, and keep it out of version control.");
            return;
          }
          var v = val(key);
          if (v.trim() === "") {
            add("Critical", key, ln(key), label + " is present but empty.",
              "Generate a fresh 128-character random value on the host and set " + key + " before deploying.");
          } else if (isPlaceholder(v)) {
            add("Critical", key, ln(key),
              label + " is set to an example/placeholder value (line " + ln(key) + ", length " + v.length + " — value never shown). Anyone who has seen the sample config can forge sessions or codes with it.",
              "Generate a fresh 128-character random value on the host, replace " + key + ", and rotate anywhere the placeholder was ever used.");
          } else if (v.length < 64) {
            add("Critical", key, ln(key),
              label + " is too short: " + v.length + " characters (line " + ln(key) + ", length only — value never shown). The floor is 64 characters; 128 is the standard generated length.",
              "Generate a fresh 128-character random value on the host and set " + key + " before deploying; treat the short value as compromised and do not reuse it.");
          }
        }
        coreSecret("SECRET_KEY_BASE", "SECRET_KEY_BASE");
        coreSecret("OTP_SECRET", "OTP_SECRET");

        /* ---- VAPID keys (Web Push) ---- */
        function vapid(key, label) {
          if (!has(key)) {
            add("High", key, null,
              label + " is missing — Web Push notifications cannot be signed, so browser/app push silently breaks.",
              "Generate a VAPID keypair on the host (`rails mastodon:webpush:generate_vapid_key`) and set both VAPID_PRIVATE_KEY and VAPID_PUBLIC_KEY.");
            return;
          }
          var v = val(key);
          if (v.trim() === "") {
            add("High", key, ln(key), label + " is present but empty.",
              "Generate a VAPID keypair on the host and set both VAPID keys.");
          } else if (isPlaceholder(v)) {
            add("High", key, ln(key),
              label + " is set to an example/placeholder value (line " + ln(key) + ", length " + v.length + " — value never shown).",
              "Generate a real VAPID keypair on the host and replace " + key + ".");
          } else if (v.length < 32) {
            add("High", key, ln(key),
              label + " looks truncated: " + v.length + " characters (line " + ln(key) + ", length only — value never shown). A generated VAPID key runs far longer than that.",
              "Regenerate the VAPID keypair on the host and paste the full value for " + key + ".");
          }
        }
        vapid("VAPID_PRIVATE_KEY", "VAPID_PRIVATE_KEY");
        vapid("VAPID_PUBLIC_KEY", "VAPID_PUBLIC_KEY");

        /* ---- Plaintext secrets sitting in the file ---- */
        var PLAINTEXT = [
          ["DB_PASS", "the database password"],
          ["REDIS_PASSWORD", "the Redis password"],
          ["SECRET_ACCESS_KEY", "the S3 secret access key"],
          ["SMTP_PASSWORD", "the SMTP password"]
        ];
        for (var pi = 0; pi < PLAINTEXT.length; pi++) {
          var pk = PLAINTEXT[pi][0];
          if (has(pk)) {
            var pv = val(pk);
            if (pv.trim() === "") {
              add("Low", pk, ln(pk), pk + " is present but empty.",
                "Either remove the empty " + pk + " line or inject the real value at runtime from your vault / secret manager.");
            } else {
              add("High", pk, ln(pk),
                pk + " (" + PLAINTEXT[pi][1] + ") is stored in plaintext in this file (line " + ln(pk) + ", value length " + pv.length + " — value never shown). Anyone who can read the file — a backup, a repo, a screenshot — owns that credential.",
                "Move " + pk + " out of the file: store it in a vault / secret manager and inject it into the environment at runtime, then rotate the credential since it has sat in plaintext.");
            }
          }
        }

        /* ---- Registration posture ---- */
        var openReg = has("OPEN_REGISTRATIONS") ? parseBool(val("OPEN_REGISTRATIONS")) : null;
        var singleUser = has("SINGLE_USER_MODE") ? parseBool(val("SINGLE_USER_MODE")) : null;
        var approvalMention = /approv/i.test(text) || has("REGISTRATION_APPROVAL") || has("REQUIRE_ADMIN_APPROVAL");
        if (singleUser === true && has("OPEN_REGISTRATIONS")) {
          add("High", "SINGLE_USER_MODE", ln("SINGLE_USER_MODE"),
            "SINGLE_USER_MODE=true is combined with an OPEN_REGISTRATIONS setting — the two contradict each other: single-user mode closes signups entirely, so the registration setting is dead weight that will confuse the next admin (and any future change to single-user mode silently re-opens whatever OPEN_REGISTRATIONS says).",
            "Pick one posture: for a personal instance keep SINGLE_USER_MODE=true and delete the OPEN_REGISTRATIONS line; for a community instance set SINGLE_USER_MODE=false and set OPEN_REGISTRATIONS deliberately.");
        }
        if (openReg === true && singleUser !== true && !approvalMention) {
          add("High", "OPEN_REGISTRATIONS", ln("OPEN_REGISTRATIONS"),
            "OPEN_REGISTRATIONS=true with no approval or limit posture anywhere in the config — anyone on the internet can create an account the moment the server is up, which is how new instances get flooded with spam and abuse accounts.",
            "Either close signups (OPEN_REGISTRATIONS=false), or keep them open only with admin approval required in the admin settings before launch, and re-check the posture after first boot.");
        }
        if (has("OPEN_REGISTRATIONS") && openReg === null) {
          add("Medium", "OPEN_REGISTRATIONS", ln("OPEN_REGISTRATIONS"),
            "OPEN_REGISTRATIONS is set to a value that is not a recognizable true/false, so the effective signup posture is unclear.",
            "Set OPEN_REGISTRATIONS to exactly true or false.");
        }
        if (has("SINGLE_USER_MODE") && singleUser === null) {
          add("Medium", "SINGLE_USER_MODE", ln("SINGLE_USER_MODE"),
            "SINGLE_USER_MODE is set to a value that is not a recognizable true/false.",
            "Set SINGLE_USER_MODE to exactly true or false.");
        }

        /* ---- SMTP / mail ---- */
        if (has("SMTP_SERVER") && val("SMTP_SERVER").trim() !== "") {
          var starttls = has("SMTP_ENABLE_STARTTLS") ? parseBool(val("SMTP_ENABLE_STARTTLS")) : null;
          var smtpTls = has("SMTP_TLS") ? parseBool(val("SMTP_TLS")) : null;
          if (starttls !== true && smtpTls !== true) {
            add("High", "SMTP_ENABLE_STARTTLS", ln("SMTP_SERVER"),
              "An SMTP server is configured but there is no TLS posture: SMTP_ENABLE_STARTTLS is not true and SMTP_TLS is not set — mail credentials and message content can cross the network unencrypted.",
              "Set SMTP_ENABLE_STARTTLS=true (for port 587 submission) or SMTP_TLS=true (for port 465 implicit TLS), matching what your mail provider expects.");
          }
          if (has("SMTP_PORT") && !/^\d+$/.test(val("SMTP_PORT").trim())) {
            add("Medium", "SMTP_PORT", ln("SMTP_PORT"),
              "SMTP_PORT is not a plain number, so the mailer cannot use it.",
              "Set SMTP_PORT to the numeric port your provider expects (587 for STARTTLS submission, 465 for implicit TLS).");
          }
        } else {
          add("Low", "SMTP_SERVER", null,
            "No SMTP_SERVER is configured — password resets, confirmations and admin mail cannot be delivered.",
            "Configure an SMTP server (with STARTTLS/TLS) before inviting users, or accept that email flows will not work.");
        }

        /* ---- Elasticsearch ---- */
        if (has("ES_ENABLED")) {
          var esOn = parseBool(val("ES_ENABLED"));
          if (esOn === null) {
            add("Medium", "ES_ENABLED", ln("ES_ENABLED"),
              "ES_ENABLED is set to a value that is not a recognizable true/false, so search indexing behavior is undefined.",
              "Set ES_ENABLED to exactly true or false.");
          } else if (esOn === true) {
            if (!has("ES_HOST") || val("ES_HOST").trim() === "") {
              add("High", "ES_HOST", ln("ES_ENABLED"),
                "ES_ENABLED=true but ES_HOST is missing — search indexing will fail against a host that is not configured.",
                "Set ES_HOST to the Elasticsearch host, or set ES_ENABLED=false if search is not deployed yet.");
            }
            if (!has("ES_PORT") || val("ES_PORT").trim() === "") {
              add("High", "ES_PORT", ln("ES_ENABLED"),
                "ES_ENABLED=true but ES_PORT is missing.",
                "Set ES_PORT to the Elasticsearch port (9200 by default), or set ES_ENABLED=false.");
            } else if (!/^\d+$/.test(val("ES_PORT").trim()) || +val("ES_PORT").trim() < 1 || +val("ES_PORT").trim() > 65535) {
              add("High", "ES_PORT", ln("ES_PORT"),
                "ES_ENABLED=true but ES_PORT is malformed — it is not a valid port number.",
                "Set ES_PORT to a valid numeric port (9200 by default).");
            }
          }
        }

        /* ---- Retention / privacy ---- */
        if (!has("IP_RETENTION_PERIOD")) {
          add("Medium", "IP_RETENTION_PERIOD", null,
            "IP_RETENTION_PERIOD is not set — sign-in IP addresses are kept on Mastodon's default schedule instead of one you chose, which is a privacy and data-retention exposure for your users.",
            "Set IP_RETENTION_PERIOD to the number of seconds you actually want to keep sign-in IPs (for example 31556952 for one year, or shorter), and note it in your privacy policy.");
        }
        if (!has("SESSION_RETENTION_PERIOD")) {
          add("Medium", "SESSION_RETENTION_PERIOD", null,
            "SESSION_RETENTION_PERIOD is not set — session data is kept on the default schedule instead of one you chose.",
            "Set SESSION_RETENTION_PERIOD to the number of seconds you want to keep session data (for example 31556952 for one year, or shorter).");
        }

        /* ---- Authorized fetch / secure mode ---- */
        var af = has("AUTHORIZED_FETCH") ? parseBool(val("AUTHORIZED_FETCH")) : null;
        var lfm = has("LIMITED_FEDERATION_MODE") ? parseBool(val("LIMITED_FEDERATION_MODE")) : null;
        if (domainPublic && af !== true && lfm !== true) {
          add("Medium", "AUTHORIZED_FETCH", has("AUTHORIZED_FETCH") ? ln("AUTHORIZED_FETCH") : null,
            "Authorized fetch (secure mode) is off: AUTHORIZED_FETCH is not true and LIMITED_FEDERATION_MODE is not true, while the instance is on a public domain — blocked and suspended instances can still fetch your public posts through unsigned requests.",
            "Set AUTHORIZED_FETCH=true unless you have a specific federation reason not to; it makes remote servers sign fetch requests so your blocks are respected.");
        }

        /* ---- Database / Redis basics ---- */
        var DB_BASICS = ["DB_HOST", "DB_NAME", "DB_USER"];
        for (var di = 0; di < DB_BASICS.length; di++) {
          var dk = DB_BASICS[di];
          if (!has(dk)) {
            add("Medium", dk, null, dk + " is missing — the database connection basics are incomplete and Mastodon cannot connect on boot.",
              "Set " + dk + " to match the PostgreSQL instance you provisioned.");
          }
        }
        if (!has("REDIS_HOST")) {
          add("Medium", "REDIS_HOST", null,
            "REDIS_HOST is missing — Sidekiq queues, timelines and streaming all depend on Redis, so the instance cannot run without it.",
            "Set REDIS_HOST to the Redis host (and REDIS_PORT if it is not 6379).");
        }
        if (has("DB_PORT") && !/^\d+$/.test(val("DB_PORT").trim())) {
          add("Low", "DB_PORT", ln("DB_PORT"), "DB_PORT is not a plain number.",
            "Set DB_PORT to the numeric PostgreSQL port (5432 by default).");
        }
        if (has("REDIS_PORT") && !/^\d+$/.test(val("REDIS_PORT").trim())) {
          add("Low", "REDIS_PORT", ln("REDIS_PORT"), "REDIS_PORT is not a plain number.",
            "Set REDIS_PORT to the numeric Redis port (6379 by default).");
        }

        /* ---- Empty values on required keys not already covered ---- */
        var coveredEmpty = { LOCAL_DOMAIN: 1, SECRET_KEY_BASE: 1, OTP_SECRET: 1, VAPID_PRIVATE_KEY: 1, VAPID_PUBLIC_KEY: 1 };
        for (var ri = 0; ri < REQUIRED_KEYS.length; ri++) {
          var rk = REQUIRED_KEYS[ri];
          if (coveredEmpty[rk]) continue;
          if (has(rk) && val(rk).trim() === "") {
            add("High", rk, ln(rk), rk + " is a required key but its value is empty.",
              "Set " + rk + " to a real value before deploying, or remove the line so the gap is obvious.");
          }
        }

        /* ---- Duplicates ---- */
        for (var ui = 0; ui < parsed.duplicates.length; ui++) {
          var dup = parsed.duplicates[ui];
          add("Medium", dup.key, dup.line,
            "Duplicate key: " + dup.key + " is set on line " + dup.firstLine + " and again on line " + dup.line + " — only the later value takes effect, so the file no longer says what it appears to say.",
            "Delete one of the two " + dup.key + " lines and keep the intended value.");
        }

        /* ---- Verdict ---- */
        var counts = countSev(findings);
        var verdict, why;
        if (counts.Critical > 0) {
          verdict = "DO NOT DEPLOY";
          why = counts.Critical + " critical finding" + (counts.Critical === 1 ? "" : "s") + " must be fixed before this config goes anywhere near a server.";
        } else if (counts.High > 0 || counts.Medium > 0) {
          verdict = "DEPLOY WITH FIXES";
          why = "Nothing here is an outright launch-blocker, but the high/medium findings above should be fixed first — several are one-line changes.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "All required keys are present and strong, no critical, high or medium findings — this config passes the audit. (The live server and admin-side state are outside what a text audit can see.)";
        }
        return finish(verdict, findings, parsed, recognized, why);
      }

      function countSev(findings) {
        var c = { Critical: 0, High: 0, Medium: 0, Low: 0, Info: 0 };
        for (var i = 0; i < findings.length; i++) c[findings[i].severity]++;
        return c;
      }

      function finish(verdict, findings, parsed, recognized, why) {
        findings.sort(function (a, b) {
          var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          if (d !== 0) return d;
          var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
          return la - lb;
        });
        return {
          verdict: verdict, why: why, findings: findings, counts: countSev(findings),
          notParsed: parsed.notParsed, totalLines: parsed.totalLines,
          parsedKeys: parsed.order.length, recognized: recognized
        };
      }

      /* ---------- Examples ---------- */
      var RISKY = [
        "# Risky Mastodon .env.production — training example, do not deploy",
        "LOCAL_DOMAIN=http://social.example.org",
        "SECRET_KEY_BASE=RISKYPLANTEDSECRET123",
        "OTP_SECRET=short-otp-123",
        "DB_HOST=localhost",
        "DB_PORT=5432",
        "DB_NAME=mastodon_production",
        "DB_USER=mastodon",
        "DB_PASS=plaintext-db-password-9",
        "REDIS_HOST=localhost",
        "REDIS_PORT=6379",
        "REDIS_PASSWORD=plaintext-redis-password-9",
        "OPEN_REGISTRATIONS=true",
        "SMTP_SERVER=mail.example.org",
        "SMTP_PORT=587",
        "SMTP_LOGIN=admin@example.org",
        "SMTP_PASSWORD=plaintext-smtp-password-9",
        "SMTP_FROM_ADDRESS=admin@example.org",
        "S3_ENABLED=true",
        "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE",
        "SECRET_ACCESS_KEY=plaintext-s3-secret-9",
        "ES_ENABLED=true",
        "AUTHORIZED_FETCH=false",
        "LIMITED_FEDERATION_MODE=false",
        "this line is not a config line at all"
      ].join("\n");

      var HARDENED = [
        "# Hardened Mastodon .env.production",
        "# Database, Redis, SMTP and S3 passwords are NOT stored in this file.",
        "# They are injected at runtime from the vault / secret manager.",
        "LOCAL_DOMAIN=mastodon.jdawgs.io",
        "LOCAL_HTTPS_PORT=443",
        "SECRET_KEY_BASE=442b3f5af267773caa33949e5c24e75a4a89e2e8797d991b60907b554e610ebbe96dadb84f9412705158659332ab544b06d66d5b7b916e3bfadbc3367e390e31",
        "OTP_SECRET=14c34a84ce890f8856a903b6971731f489bcdbbce9a9cc3cdc40389eee6ec370010c9f03478a4eee1afbc300b55927c2374454b474fc184583b67290cc95b91d",
        "VAPID_PRIVATE_KEY=AKBtZ9628vQH1Zgsrw30d6zuS8MUpxKwbfl1BbQRzfQZJeh8ReOCQhnusIk5gjblc9-86rdtJ2RgAurBwhcptPw",
        "VAPID_PUBLIC_KEY=zgL57U5WzAwtk68GYpLvXn6gjxpRYvN8uh2sajDt4dlWsxfXPXHaQrkpd-X4WLn90gET3M0FAjB6uFc4RdPNh28",
        "DB_HOST=db.internal",
        "DB_PORT=5432",
        "DB_NAME=mastodon_production",
        "DB_USER=mastodon",
        "REDIS_HOST=redis.internal",
        "REDIS_PORT=6379",
        "OPEN_REGISTRATIONS=false",
        "SINGLE_USER_MODE=false",
        "AUTHORIZED_FETCH=true",
        "LIMITED_FEDERATION_MODE=false",
        "SMTP_SERVER=mail.jdawgs.io",
        "SMTP_PORT=587",
        "SMTP_LOGIN=mastodon@jdawgs.io",
        "SMTP_FROM_ADDRESS=mastodon@jdawgs.io",
        "SMTP_ENABLE_STARTTLS=true",
        "ES_ENABLED=false",
        "IP_RETENTION_PERIOD=31556952",
        "SESSION_RETENTION_PERIOD=31556952"
      ].join("\n");

      /* ---------- Report builders (secret values never included) ---------- */
      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs Mastodon Server Config Safety Auditor — Audit Report");
        out.push("==============================================================");
        out.push("Verdict: " + r.verdict);
        out.push("Why: " + r.why);
        out.push("");
        out.push("Counts: Critical " + r.counts.Critical + " | High " + r.counts.High +
          " | Medium " + r.counts.Medium + " | Low " + r.counts.Low + " | Info " + r.counts.Info);
        out.push("Lines in input: " + r.totalLines + " | Keys parsed: " + r.parsedKeys +
          " | Recognized Mastodon keys: " + r.recognized);
        out.push("NOT PARSED lines: " + (r.notParsed.length ? r.notParsed.join(", ") : "none"));
        out.push("");
        out.push("Findings (" + r.findings.length + "):");
        if (!r.findings.length) out.push("  (none)");
        for (var i = 0; i < r.findings.length; i++) {
          var f = r.findings[i];
          out.push("");
          out.push((i + 1) + ". [" + f.severity + "] " + f.key +
            " — " + (f.line === null ? "not present / no line" : "line " + f.line));
          out.push("   " + f.title);
          out.push("   Fix: " + f.fix);
        }
        out.push("");
        out.push("Note: secret values were audited by key name, line and length only and never appear in this report.");
        return out.join("\n");
      }

      function buildJson(r) {
        return JSON.stringify({
          tool: "J-Dawgs Mastodon Server Config Safety Auditor",
          verdict: r.verdict,
          why: r.why,
          counts: r.counts,
          linesInInput: r.totalLines,
          keysParsed: r.parsedKeys,
          recognizedMastodonKeys: r.recognized,
          notParsedLines: r.notParsed,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, key: f.key, line: f.line, title: f.title, fix: f.fix };
          }),
          note: "Secret values were audited by key name, line and length only and are never included in this export."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mastodon-server-config-safety-auditortm-3',
  name: 'J-Dawgs Mastodon Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
