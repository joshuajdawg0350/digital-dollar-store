'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Readeck Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configs (exact) ---------- */
      var RISKY_EXAMPLE = [
        "# Readeck example — risky",
        "READECK_SERVER_HOST=0.0.0.0",
        "READECK_SERVER_PORT=8000",
        "READECK_SERVER_BASE_URL=http://readeck.example.com",
        "READECK_SECRET_KEY=changeme123",
        "READECK_DATABASE_SOURCE=postgres://readeck:Sup3rSecretDbPass99@db.internal:5432/readeck",
        "READECK_TRUSTED_PROXIES=*",
        "READECK_LOG_LEVEL=debug"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Readeck example — hardened",
        "READECK_SERVER_HOST=127.0.0.1",
        "READECK_SERVER_PORT=8000",
        "READECK_SERVER_BASE_URL=https://readeck.example.com",
        "READECK_SECRET_KEY=Kx9mP2vL8nQ4wR7tY3sD6fH1jN5bV0cXaZ2eG4hJ7kM9pQ",
        "READECK_DATABASE_SOURCE=postgres://readeck@db.internal:5432/readeck?sslmode=require",
        "READECK_TRUSTED_PROXIES=127.0.0.1,10.0.0.5",
        "READECK_LOG_LEVEL=info"
      ].join("\n");

      /* ---------- Key recognition ---------- */
      // Canonical field -> accepted normalized key names.
      // Normalization: lowercase, dots and dashes become underscores.
      var KEY_MAP = {
        "readeck_server_host": "host", "server_host": "host", "host": "host",
        "readeck_server_port": "port", "server_port": "port", "port": "port",
        "readeck_server_base_url": "base_url", "readeck_base_url": "base_url",
        "server_base_url": "base_url", "base_url": "base_url", "public_url": "base_url",
        "readeck_secret_key": "secret_key", "secret_key": "secret_key", "secret": "secret_key",
        "readeck_database_source": "database_source", "readeck_db_source": "database_source",
        "database_source": "database_source", "database_url": "database_source",
        "readeck_trusted_proxies": "trusted_proxies", "trusted_proxies": "trusted_proxies",
        "readeck_log_level": "log_level", "log_level": "log_level",
        "readeck_metrics_enabled": "metrics_enabled", "metrics_enabled": "metrics_enabled",
        "readeck_metrics": "metrics_enabled",
        "readeck_debug": "debug", "debug": "debug"
      };

      var DISPLAY_KEY = {
        "host": "READECK_SERVER_HOST",
        "port": "READECK_SERVER_PORT",
        "base_url": "READECK_SERVER_BASE_URL",
        "secret_key": "READECK_SECRET_KEY",
        "database_source": "READECK_DATABASE_SOURCE",
        "trusted_proxies": "READECK_TRUSTED_PROXIES",
        "log_level": "READECK_LOG_LEVEL",
        "metrics_enabled": "READECK_METRICS_ENABLED",
        "debug": "READECK_DEBUG"
      };

      function normalizeKey(raw) {
        return raw.trim().toLowerCase().replace(/[.\-]/g, "_").replace(/\s+/g, "_");
      }

      function unquote(v) {
        v = v.trim();
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        return v;
      }

      // Parse pasted text into entries: {field, key (as written), value, line}
      function parseConfig(text) {
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var s = raw.trim();
          if (s === "" || s.charAt(0) === "#") continue;
          if (/^export\s+/i.test(s)) s = s.replace(/^export\s+/i, "");
          var keyPart = null, valuePart = null;
          var eq = s.indexOf("=");
          if (eq > 0) {
            keyPart = s.slice(0, eq);
            valuePart = s.slice(eq + 1);
          } else {
            var colon = s.indexOf(":");
            if (colon > 0 && (colon === s.length - 1 || /\s/.test(s.charAt(colon + 1)))) {
              keyPart = s.slice(0, colon);
              valuePart = s.slice(colon + 1);
            }
          }
          if (keyPart === null) continue;
          var norm = normalizeKey(keyPart);
          var field = KEY_MAP[norm];
          if (!field) continue;
          entries.push({
            field: field,
            key: keyPart.trim(),
            value: unquote(valuePart == null ? "" : valuePart),
            line: lineNo
          });
        }
        return { entries: entries, totalLines: lines.length };
      }

      function lastEntry(entries, field) {
        var found = null;
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].field === field) found = entries[i];
        }
        return found;
      }

      function truthy(v) {
        var t = String(v).trim().toLowerCase();
        return t === "true" || t === "1" || t === "yes" || t === "on";
      }

      var PLACEHOLDER_WORDS = ["changeme", "secret", "example", "test", "password", "readeck", "letmein", "default", "placeholder", "insecure"];

      function isPlaceholderSecret(v) {
        var t = v.trim().toLowerCase();
        if (t === "") return false;
        var allSame = true;
        for (var i = 1; i < t.length; i++) { if (t.charAt(i) !== t.charAt(0)) { allSame = false; break; } }
        if (allSame) return true;
        for (var j = 0; j < PLACEHOLDER_WORDS.length; j++) {
          var w = PLACEHOLDER_WORDS[j];
          if (t === w || t.indexOf(w) === 0) return true;
        }
        return false;
      }

      // Returns the embedded password (for LENGTH measurement only) or null.
      // The returned value is used solely for .length and never rendered.
      function embeddedDbPassword(value) {
        var v = String(value);
        var m = v.match(/^[a-z][a-z0-9+.\-]*:\/\/[^\/:@\s]+:([^@\s\/]+)@/i);
        if (m) return m[1];
        var p = v.match(/(?:^|[?&\s;])password=([^&\s;]+)/i);
        if (p) return p[1];
        var p2 = v.match(/(?:^|[?&\s;])pwd=([^&\s;]+)/i);
        if (p2) return p2[1];
        return null;
      }

      var SEV_ORDER = { "CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3 };

      /* ---------- The audit ---------- */
      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];

        function add(severity, field, line, message, fix) {
          findings.push({
            severity: severity,
            key: DISPLAY_KEY[field] || field,
            line: line,
            message: message,
            fix: fix
          });
        }

        var host = lastEntry(entries, "host");
        var port = lastEntry(entries, "port");
        var baseUrl = lastEntry(entries, "base_url");
        var secret = lastEntry(entries, "secret_key");
        var db = lastEntry(entries, "database_source");
        var proxies = lastEntry(entries, "trusted_proxies");
        var logLevel = lastEntry(entries, "log_level");
        var metrics = lastEntry(entries, "metrics_enabled");
        var debugFlag = lastEntry(entries, "debug");

        var recognized = entries.length;

        // 1. All-interface bind
        if (host) {
          var hv = host.value.trim();
          if (hv === "0.0.0.0" || hv === "::" || hv === "[::]" || hv === "*") {
            add("CRITICAL", "host", host.line,
              "Server host binds to all network interfaces (" + hv + "), exposing Readeck to the whole network.",
              "Bind to 127.0.0.1 or a specific private interface address, unless a reverse proxy fronts Readeck.");
          } else if (hv === "" && baseUrl && /^https?:\/\//i.test(baseUrl.value.trim()) &&
                     !/^(https?:\/\/)?(localhost|127\.0\.0\.1|\[::1\])([:\/]|$)/i.test(baseUrl.value.trim())) {
            add("CRITICAL", "host", host.line,
              "Server host is empty while a public base URL is set, so the bind address is left to defaults on a publicly addressed install.",
              "Set the host explicitly to 127.0.0.1 or a specific private interface address, unless a reverse proxy fronts Readeck.");
          }
        }

        // 2. Public URL over plain http
        if (baseUrl) {
          var bv = baseUrl.value.trim();
          if (/^http:\/\//i.test(bv)) {
            add("CRITICAL", "base_url", baseUrl.line,
              "The public/base URL uses http://, so sessions, credentials, and saved content travel unencrypted.",
              "Serve Readeck over https:// behind TLS (for example a reverse proxy with a valid certificate) and set the base URL to the https:// address.");
          }
        }

        // 3 + 4. Secret key missing / weak
        if (!secret) {
          if (recognized > 0) {
            add("CRITICAL", "secret_key", null,
              "READECK_SECRET_KEY is not set anywhere in this config. Readeck needs a secret key to sign sessions and tokens safely.",
              "Set READECK_SECRET_KEY to a long random value of at least 32 characters, generated fresh for this install.");
          }
        } else {
          var sv = secret.value;
          var weak = sv.length < 32 || isPlaceholderSecret(sv);
          if (weak) {
            var why = sv.length < 32
              ? "only " + sv.length + " characters long (minimum 32)"
              : sv.length + " characters long but matches a known example/placeholder pattern";
            add("CRITICAL", "secret_key", secret.line,
              "READECK_SECRET_KEY (line " + secret.line + ", " + sv.length + " chars, value redacted) is " + why + ".",
              "Replace it with a long random value of at least 32 characters that is unique to this install, and keep it out of shared examples.");
          }
        }

        // 5. Embedded plaintext database password (length only, never the value)
        if (db) {
          var pw = embeddedDbPassword(db.value);
          if (pw !== null && pw.length > 0) {
            add("HIGH", "database_source", db.line,
              "READECK_DATABASE_SOURCE (line " + db.line + ") embeds a plaintext database password (" + pw.length + " chars, value redacted) directly in the connection string.",
              "Move the credential into a secrets file or a restricted-permissions env file, reference it from there, and rotate the database password since it has been handled in plaintext.");
          }
        }

        // 6. Wildcard trusted proxies
        if (proxies) {
          var pv = proxies.value.trim().toLowerCase();
          var tokens = pv.split(/[,\s]+/).filter(function (t) { return t !== ""; });
          var wild = pv === "*" || pv === "all" || pv === "0.0.0.0/0" || pv === "::/0" ||
                     tokens.indexOf("*") !== -1 || tokens.indexOf("0.0.0.0/0") !== -1 ||
                     tokens.indexOf("::/0") !== -1 || tokens.indexOf("all") !== -1;
          if (wild) {
            add("HIGH", "trusted_proxies", proxies.line,
              "Trusted proxies is set to a wildcard, so Readeck will trust forwarded headers (real IP, protocol, host) from any client — letting anyone spoof their address or scheme.",
              "List only the actual reverse-proxy IP addresses or CIDR ranges that front this Readeck install.");
          }
        }

        // 7. Debug logging / debug mode
        if (logLevel) {
          var lv = logLevel.value.trim().toLowerCase();
          if (lv === "debug" || lv === "trace") {
            add("MEDIUM", "log_level", logLevel.line,
              "Log level is set to \"" + lv + "\", which can write request details and internal state into logs that are rarely treated as sensitive.",
              "Use info or warn in production; raise to debug only briefly while troubleshooting.");
          }
        }
        if (debugFlag && truthy(debugFlag.value)) {
          add("MEDIUM", "debug", debugFlag.line,
            "Debug mode is switched on, which can expose verbose errors and internal details.",
            "Turn debug off in production (READECK_DEBUG=false) and use info or warn logging.");
        }

        // 8. Metrics enabled
        if (metrics && truthy(metrics.value)) {
          add("MEDIUM", "metrics_enabled", metrics.line,
            "Metrics are enabled. Metrics endpoints can reveal usage patterns and internals if they are reachable by anyone.",
            "Confirm the metrics endpoint is restricted to your monitoring network or reverse proxy, or disable metrics if you do not use them.");
        }

        // 9. Missing port / base URL (review notes)
        if (recognized > 0) {
          if (!port) {
            add("LOW", "port", null,
              "No server port is set in this config, so Readeck will use its built-in default.",
              "Set READECK_SERVER_PORT explicitly so the port is a deliberate choice and matches your proxy/firewall rules.");
          }
          if (!baseUrl) {
            add("LOW", "base_url", null,
              "No base/public URL is set in this config, so generated links depend on request headers and proxy behavior.",
              "Set READECK_SERVER_BASE_URL to the exact public https:// address users reach Readeck at.");
          }
        }

        findings.sort(function (a, b) {
          var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          if (d !== 0) return d;
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var counts = { critical: 0, high: 0, medium: 0, low: 0 };
        findings.forEach(function (f) { counts[f.severity.toLowerCase()]++; });

        var verdict;
        if (String(text == null ? "" : text).trim() === "" || recognized === 0) {
          verdict = "NOT ENOUGH TO GRADE";
        } else if (counts.critical > 0) {
          verdict = "DO NOT DEPLOY";
        } else if (counts.high > 0 || counts.medium > 0) {
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        return {
          verdict: verdict,
          findings: findings,
          counts: counts,
          totalLines: parsed.totalLines,
          recognizedKeys: recognized
        };
      }

      /* ---------- Report + JSON builders (redacted by construction) ---------- */
      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Readeck Server Config Safety Auditor — audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Lines in config: " + result.totalLines);
        out.push("Recognized Readeck keys: " + result.recognizedKeys);
        out.push("Findings: " + result.findings.length +
          " (CRITICAL " + result.counts.critical +
          ", HIGH " + result.counts.high +
          ", MEDIUM " + result.counts.medium +
          ", LOW " + result.counts.low + ")");
        out.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          out.push("No recognizable Readeck settings were found in the pasted text, so there is nothing to grade.");
        } else if (result.findings.length === 0) {
          out.push("No findings. No CRITICAL, HIGH, MEDIUM, or LOW issues were detected in the recognized settings.");
        } else {
          result.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.severity + "] " + f.key +
              (f.line != null ? " (line " + f.line + ")" : " (not set)"));
            out.push("   " + f.message);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        out.push("Note: secret values are never included in this report. Findings reference secrets by key name, line number, and character length only.");
        return out.join("\n");
      }

      function buildJson(result) {
        var obj = {
          tool: "J-Dawgs Readeck Server Config Safety Auditor",
          verdict: result.verdict,
          counts: {
            totalLines: result.totalLines,
            recognizedKeys: result.recognizedKeys,
            critical: result.counts.critical,
            high: result.counts.high,
            medium: result.counts.medium,
            low: result.counts.low
          },
          findings: result.findings.map(function (f) {
            return {
              severity: f.severity,
              key: f.key,
              line: f.line,
              message: f.message,
              fix: f.fix
            };
          })
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-readeck-server-config-safety-auditortm',
  name: 'J-Dawgs Readeck Server Config Safety Auditor',
  description: 'Grades a pasted Readeck read-it-later server config offline into one deploy verdict: an http public URL, wildcard trusted proxies, a plaintext DB password and debug logging flagged, with secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
