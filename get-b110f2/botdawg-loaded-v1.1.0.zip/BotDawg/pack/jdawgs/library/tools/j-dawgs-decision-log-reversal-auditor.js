'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Decision Log & Reversal Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var WORKED_EXAMPLE = [
          "2026-10-01 | Deploy target | Vercel | Chosen for the free tier and fast deploys | acted",
          "2026-10-02 | Pricing | $1.00 per tool use |  | acted",
          "2026-10-04 | Database choice | SQLite | Single file, no server to run or maintain | acted",
          "2026-10-08 | Deploy target | Self-hosted box in the shop | Felt like the safer call at the time | acted",
          "2026-10-09 | Database choice | Postgres | Switched because the load test failed under real traffic | acted",
          "2026-10-10 | Pricing | $1.00 per tool use | Recheck the price once the first sales land | pending",
          "2026-10-15 | Deploy target | Self-hosted box in the shop | The box is already set up and running | acted",
          "2026-10-20 | Database choice | Postgres | Holding after the load test passed clean | acted"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "2026-11-01 | Deploy target | Vercel | Free tier covers the current traffic | acted",
          "2026-11-02 | Database choice | SQLite | Single file, nothing extra to run | acted",
          "2026-11-05 | Database choice | Postgres | Moved because the load test failed at 200 users | acted",
          "2026-11-06 | Pricing | $1.00 per tool use | In line with what similar tools charge | acted",
          "2026-11-08 | Deploy target | Vercel | Still the cheapest route at this size | acted"
        ].join("\n");

        var PITCHES = {
          "pitch-store": "AI Tool Store — the tool store where the AI is the customer. Working tools an agent can pick up and use right away, from single tools to the Everything Stack and the one-time Unlimited Pass.\nhttps://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
          "pitch-exchange": "J-Dawgs Agent Exchange — where agents swap tools, stacks, and services with each other. List what your agent built, pick up what it needs.\nhttps://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
          "pitch-stack": "Trust the Chain, Trust the Record Stack — two audits that belong together: the Certificate Chain & Expiry Auditor checks that a site's certificate chain holds up, and the Decision Log & Reversal Auditor checks that a decision record does. One stack, $1.50 full pass for both tools."
        };

        var EXPLAIN_WORDS = ["because", "new", "found", "learned", "failed", "changed", "evidence", "after"];
        var DAY = 86400000;

        var input = document.getElementById("logInput");
        var thresholdInput = document.getElementById("threshold");
        var resultsEl = document.getElementById("results");
        var emptyEl = document.getElementById("emptyState");
        var verdictBox = document.getElementById("verdictBox");
        var verdictText = document.getElementById("verdictText");
        var verdictWhy = document.getElementById("verdictWhy");
        var statsRow = document.getElementById("statsRow");
        var findingsRoot = document.getElementById("findingsRoot");
        var timelineRoot = document.getElementById("timelineRoot");
        var unresolvedBox = document.getElementById("unresolvedBox");

        var lastReportText = "";
        var lastUnresolvedText = "";

        /* ---------- helpers ---------- */
        function el(tag, cls, text) {
          var n = document.createElement(tag);
          if (cls) n.className = cls;
          if (text != null) n.textContent = text;
          return n;
        }
        function normText(s) { return s.trim().replace(/\s+/g, " ").toLowerCase(); }
        function parseDate(s) {
          var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
          if (!m) return null;
          var y = +m[1], mo = +m[2], d = +m[3];
          var t = Date.UTC(y, mo - 1, d);
          var dt = new Date(t);
          if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
          return t;
        }
        function hasExplainWord(reason) {
          var words = normText(reason).split(/[^a-z]+/);
          for (var i = 0; i < words.length; i++) {
            if (EXPLAIN_WORDS.indexOf(words[i]) !== -1) return words[i];
          }
          return null;
        }
        function lineRef(e) { return "line " + e.line; }

        /* ---------- parsing ---------- */
        function parseLog(text) {
          var entries = [], bad = [];
          var rawLines = text.split(/\r?\n/);
          for (var i = 0; i < rawLines.length; i++) {
            var raw = rawLines[i];
            var lineNo = i + 1;
            if (!raw.trim()) continue;
            var parts = raw.split("|");
            for (var p = 0; p < parts.length; p++) parts[p] = parts[p].trim();
            if (parts.length < 3 || parts.length > 5) {
              bad.push({ line: lineNo, text: raw.trim(), why: "Expected DATE | TOPIC | DECISION, plus optional REASON and STATUS — this line has " + parts.length + " field" + (parts.length === 1 ? "" : "s") + "." });
              continue;
            }
            var dateStr = parts[0], topic = parts[1], decision = parts[2];
            var reason = parts.length > 3 ? parts[3] : "";
            var statusRaw = parts.length > 4 ? parts[4] : "";
            if (!topic || !decision) {
              bad.push({ line: lineNo, text: raw.trim(), why: "Topic and decision must both be filled in." });
              continue;
            }
            var t = parseDate(dateStr);
            if (t === null) {
              bad.push({ line: lineNo, text: raw.trim(), why: "Date “" + dateStr + "” is unparsable — dates must be YYYY-MM-DD." });
              continue;
            }
            var st = normText(statusRaw);
            var status = (st === "acted") ? "acted" : (st === "pending") ? "pending" : "";
            entries.push({
              line: lineNo, dateStr: dateStr, time: t,
              topic: topic, topicKey: normText(topic),
              decision: decision, decisionNorm: normText(decision),
              reason: reason, status: status, flags: []
            });
          }
          return { entries: entries, bad: bad };
        }

        /* ---------- audit ---------- */
        function audit(entries, thresholdDays) {
          var byTopic = {}, topicOrder = [];
          entries.forEach(function (e) {
            if (!byTopic[e.topicKey]) { byTopic[e.topicKey] = { key: e.topicKey, name: e.topic, items: [] }; topicOrder.push(e.topicKey); }
            byTopic[e.topicKey].items.push(e);
          });
          topicOrder.forEach(function (k) {
            byTopic[k].items.sort(function (a, b) { return (a.time - b.time) || (a.line - b.line); });
          });

          var silentReversals = [], explainedReversals = [], contradictions = [];
          topicOrder.forEach(function (k) {
            var items = byTopic[k].items;
            for (var j = 1; j < items.length; j++) {
              var prev = items[j - 1], cur = items[j];
              if (cur.decisionNorm === prev.decisionNorm) continue;
              if (cur.dateStr === prev.dateStr) {
                contradictions.push({ topic: byTopic[k].name, a: prev, b: cur });
                cur.flags.push({ kind: "bad", label: "Contradiction" });
                prev.flags.push({ kind: "bad", label: "Contradiction" });
              } else {
                var w = hasExplainWord(cur.reason);
                if (w) {
                  explainedReversals.push({ topic: byTopic[k].name, from: prev, to: cur, word: w });
                  cur.flags.push({ kind: "good", label: "Explained reversal" });
                } else {
                  silentReversals.push({ topic: byTopic[k].name, from: prev, to: cur });
                  cur.flags.push({ kind: "bad", label: "Silent reversal" });
                }
              }
            }
          });

          var reasonless = entries.filter(function (e) { return e.reason === ""; });
          reasonless.forEach(function (e) { e.flags.push({ kind: "warn", label: "No reason" }); });

          var newest = null;
          entries.forEach(function (e) { if (newest === null || e.time > newest) newest = e.time; });
          var orphans = [];
          if (newest !== null) {
            topicOrder.forEach(function (k) {
              var items = byTopic[k].items;
              var latest = items[items.length - 1];
              var ageDays = Math.round((newest - latest.time) / DAY);
              if (latest.status !== "acted" && ageDays > thresholdDays) {
                orphans.push({ topic: byTopic[k].name, entry: latest, ageDays: ageDays });
                latest.flags.push({ kind: "warn", label: "Orphan — never acted on" });
              }
            });
          }

          /* possible split topics: differ by one trailing word, or trailing punctuation only */
          var splitHints = [];
          function stripTrailPunct(s) { return s.replace(/[\s.,;:!?]+$/, ""); }
          for (var a = 0; a < topicOrder.length; a++) {
            for (var b = a + 1; b < topicOrder.length; b++) {
              var ka = topicOrder[a], kb = topicOrder[b];
              var hint = false;
              if (stripTrailPunct(ka) === stripTrailPunct(kb)) hint = true;
              else {
                var wa = stripTrailPunct(ka).split(" "), wb = stripTrailPunct(kb).split(" ");
                if (wa.length === wb.length) {
                  /* same shape, final word differs only by a trailing "s" (target / targets) */
                  var sameHead = true;
                  for (var h = 0; h < wa.length - 1; h++) if (wa[h] !== wb[h]) { sameHead = false; break; }
                  var la = wa[wa.length - 1].replace(/s$/, ""), lb = wb[wb.length - 1].replace(/s$/, "");
                  if (sameHead && la === lb) hint = true;
                } else {
                  var longer = wa.length > wb.length ? wa : wb;
                  var shorter = wa.length > wb.length ? wb : wa;
                  if (longer.length === shorter.length + 1) {
                    var prefix = true;
                    for (var q = 0; q < shorter.length; q++) if (longer[q] !== shorter[q]) { prefix = false; break; }
                    if (prefix) hint = true;
                  }
                }
              }
              if (hint) splitHints.push([byTopic[ka].name, byTopic[kb].name]);
            }
          }

          var verdict, verdictClass;
          if (silentReversals.length > 0 || contradictions.length > 0) { verdict = "DO NOT TRUST THIS LOG YET"; verdictClass = "bad"; }
          else if (reasonless.length > 0 || orphans.length > 0) { verdict = "LOG HAS GAPS"; verdictClass = "warn"; }
          else { verdict = "LOG HOLDS UP"; verdictClass = "good"; }

          return {
            byTopic: byTopic, topicOrder: topicOrder, newest: newest,
            silentReversals: silentReversals, explainedReversals: explainedReversals,
            contradictions: contradictions, reasonless: reasonless, orphans: orphans,
            splitHints: splitHints, verdict: verdict, verdictClass: verdictClass
          };
        }

        /* ---------- plain-text lines shared by page + report ---------- */
        function silentLine(r) {
          return "SILENT REVERSAL — " + lineRef(r.to) + " (" + r.to.dateStr + ", " + r.topic + "): “" + r.to.decision + "” reversed " + lineRef(r.from) + " (" + r.from.dateStr + "): “" + r.from.decision + "” — no explanation given.";
        }
        function contradictionLine(c) {
          return "CONTRADICTION — " + c.topic + ", " + c.a.dateStr + ": " + lineRef(c.a) + " says “" + c.a.decision + "” but " + lineRef(c.b) + " says “" + c.b.decision + "” on the same date.";
        }
        function reasonlessLine(e) {
          return "NO REASON — " + lineRef(e) + " (" + e.dateStr + ", " + e.topic + "): “" + e.decision + "” was logged with no reason.";
        }
        function orphanLine(o) {
          var st = o.entry.status === "pending" ? "still pending" : "with no status recorded";
          return "ORPHAN — " + lineRef(o.entry) + " (" + o.entry.dateStr + ", " + o.topic + "): “" + o.entry.decision + "” is " + st + ", " + o.ageDays + " days older than the newest entry in the log, and nothing newer exists on this topic.";
        }
        function explainedLine(r) {
          return "EXPLAINED REVERSAL — " + lineRef(r.to) + " (" + r.to.dateStr + ", " + r.topic + "): “" + r.from.decision + "” → “" + r.to.decision + "”. Reason given: “" + r.to.reason + "”";
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-decision-log-reversal-auditor',
  name: 'J-Dawgs Decision Log & Reversal Auditor',
  description: 'Paste an agent decision log and it flags silent reversals (quoted side by side), contradiction pairs, reason-less decisions, and never-acted-on orphans by line, with a copyable unresolved list',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
