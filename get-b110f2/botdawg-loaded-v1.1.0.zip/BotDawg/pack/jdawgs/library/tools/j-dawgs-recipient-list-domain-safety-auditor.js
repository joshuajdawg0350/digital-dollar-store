'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Recipient List & Domain Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var ROLE_LOCALS = {
          postmaster: 1, abuse: 1, noreply: 1, "no-reply": 1, hostmaster: 1,
          webmaster: 1, admin: 1, root: 1, info: 1, support: 1, help: 1,
          "mailer-daemon": 1
        };

        var RISKY = {
          recipients: "ana@example.com\nAna@example.com\nbob@exampel.com\ncarol@partner.org\ndave+alerts@example.com\nnot-an-email",
          trusted: "example.com",
          context: "internal"
        };
        var CLEAN = {
          recipients: "ana@example.com\nben@example.com\ncyd@example.com",
          trusted: "example.com",
          context: "internal"
        };

        function $(id) { return document.getElementById(id); }

        function parseRecipients(text) {
          var entries = [];
          var lines = String(text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var parts = lines[i].split(/[,;]/);
            for (var j = 0; j < parts.length; j++) {
              var t = parts[j].trim();
              if (t) entries.push({ raw: t, line: i + 1 });
            }
          }
          return entries;
        }

        function parseTrusted(text) {
          var seen = {}, out = [];
          var parts = String(text).split(/[\r\n,;]+/);
          for (var i = 0; i < parts.length; i++) {
            var d = parts[i].trim().toLowerCase();
            if (d.charAt(0) === "@") d = d.slice(1);
            if (d.charAt(d.length - 1) === ".") d = d.slice(0, -1);
            if (d && !seen[d]) { seen[d] = 1; out.push(d); }
          }
          return out;
        }

        function isPlausibleEmail(addr) {
          var at = addr.indexOf("@");
          if (at <= 0 || at !== addr.lastIndexOf("@")) return false;
          var local = addr.slice(0, at);
          var domain = addr.slice(at + 1);
          if (!/^[A-Za-z0-9!#$%&'*+\/=?^_`{|}~.-]+$/.test(local)) return false;
          if (local.charAt(0) === "." || local.charAt(local.length - 1) === ".") return false;
          if (local.indexOf("..") !== -1) return false;
          if (!domain || domain.indexOf(".") === -1) return false;
          if (domain.indexOf("..") !== -1) return false;
          var labels = domain.split(".");
          for (var i = 0; i < labels.length; i++) {
            var lab = labels[i];
            if (!lab) return false;
            if (/[\s@\/,;:]/.test(lab)) return false;
            if (lab.charAt(0) === "-" || lab.charAt(lab.length - 1) === "-") return false;
          }
          var tld = labels[labels.length - 1];
          if (tld.length < 2) return false;
          return true;
        }

        function hasNonAscii(s) {
          for (var i = 0; i < s.length; i++) {
            if (s.charCodeAt(i) > 127) return true;
          }
          return false;
        }

        // True Damerau-Levenshtein distance (substitution, insertion,
        // deletion, and adjacent transposition each cost 1).
        function damerau(a, b) {
          var la = a.length, lb = b.length;
          if (Math.abs(la - lb) > 2) return 3;
          if (la === 0) return lb;
          if (lb === 0) return la;
          var INF = la + lb;
          var d = [];
          var i, j;
          for (i = 0; i <= la + 1; i++) { d.push(new Array(lb + 2).fill(0)); }
          d[0][0] = INF;
          for (i = 0; i <= la; i++) { d[i + 1][0] = INF; d[i + 1][1] = i; }
          for (j = 0; j <= lb; j++) { d[0][j + 1] = INF; d[1][j + 1] = j; }
          var da = {};
          for (i = 1; i <= la; i++) {
            var db = 0;
            for (j = 1; j <= lb; j++) {
              var i1 = da[b.charAt(j - 1)] || 0;
              var j1 = db;
              var cost = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
              if (cost === 0) db = j;
              var sub = d[i][j] + cost;
              var ins = d[i + 1][j] + 1;
              var del = d[i][j + 1] + 1;
              var tra = d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1);
              d[i + 1][j + 1] = Math.min(sub, ins, del, tra);
            }
            da[a.charAt(i - 1)] = i;
          }
          return d[la + 1][lb + 1];
        }

        function nearestTrusted(domain, trusted) {
          var best = null, bestDist = 99;
          for (var i = 0; i < trusted.length; i++) {
            var dist = damerau(domain, trusted[i]);
            if (dist < bestDist) { bestDist = dist; best = trusted[i]; }
          }
          return { domain: best, distance: bestDist };
        }

        function audit(recipientText, trustedText, context) {
          var entries = parseRecipients(recipientText);
          var trusted = parseTrusted(trustedText);
          var trustedSet = {};
          trusted.forEach(function (d) { trustedSet[d] = 1; });

          var findings = []; // {level, cls, text}
          var invalid = [];
          var valid = [];
          entries.forEach(function (e) {
            if (isPlausibleEmail(e.raw)) {
              var at = e.raw.indexOf("@");
              valid.push({
                raw: e.raw, line: e.line,
                local: e.raw.slice(0, at),
                domain: e.raw.slice(at + 1),
                lower: e.raw.toLowerCase()
              });
            } else {
              invalid.push(e);
            }
          });

          invalid.forEach(function (e) {
            findings.push({ level: "FIX", cls: "Invalid address",
              text: "Line " + e.line + ": \"" + e.raw + "\" is not a plausible email address. Excluded from the cleaned list." });
          });

          // Exact duplicates, case-insensitive. Cleaned list keeps first.
          var firstByLower = {};
          var dupGroups = [];
          var cleaned = [];
          valid.forEach(function (v) {
            if (firstByLower[v.lower]) {
              firstByLower[v.lower].extra.push(v);
            } else {
              var rec = { first: v, extra: [] };
              firstByLower[v.lower] = rec;
              dupGroups.push(rec);
              cleaned.push(v);
            }
          });
          var extraCopies = 0;
          dupGroups.forEach(function (g) {
            if (g.extra.length) {
              extraCopies += g.extra.length;
              var lines = [g.first.line].concat(g.extra.map(function (x) { return x.line; })).join(", ");
              findings.push({ level: "FIX", cls: "Exact duplicate",
                text: g.first.raw + " appears " + (g.extra.length + 1) + " times (lines " + lines + "). The cleaned list keeps the first occurrence only." });
            }
          });

          // Per-recipient domain checks on the cleaned list.
          var lookBlock = 0, lookWarn = 0, extBlock = 0, extWarn = 0, homoglyph = 0, roleCount = 0;
          cleaned.forEach(function (v) {
            var domLower = v.domain.toLowerCase();
            var isTrusted = !!trustedSet[domLower];
            var lookalike = false;

            if (hasNonAscii(v.domain)) {
              homoglyph++;
              findings.push({ level: "BLOCKER", cls: "Punycode / homoglyph review",
                text: "Line " + v.line + ": " + v.raw + " — the domain \"" + v.domain + "\" contains non-ASCII characters. It may be a homoglyph or punycode lookalike; verify it character by character before sending. (Heuristic flag.)" });
            }

            if (!isTrusted && trusted.length) {
              var near = nearestTrusted(domLower, trusted);
              if (near.distance === 1) {
                lookalike = true; lookBlock++;
                findings.push({ level: "BLOCKER", cls: "Lookalike domain",
                  text: "Line " + v.line + ": " + v.raw + " — domain \"" + domLower + "\" is one edit away from trusted domain \"" + near.domain + "\". A near-miss like this is how internal mail leaks to a stranger's domain." });
              } else if (near.distance === 2) {
                lookalike = true; lookWarn++;
                findings.push({ level: "WARNING", cls: "Lookalike domain",
                  text: "Line " + v.line + ": " + v.raw + " — domain \"" + domLower + "\" is two edits away from trusted domain \"" + near.domain + "\". Check it before sending." });
              }
            }

            if (!isTrusted && !lookalike) {
              if (context === "internal") {
                extBlock++;
                findings.push({ level: "BLOCKER", cls: "External address in internal-only send",
                  text: "Line " + v.line + ": " + v.raw + " — domain \"" + domLower + "\" is not in the trusted list, and this send is internal-only. This recipient would take the message outside." });
              } else if (context === "mixed") {
                extWarn++;
                findings.push({ level: "WARNING", cls: "External address",
                  text: "Line " + v.line + ": " + v.raw + " — domain \"" + domLower + "\" is not in the trusted list. Fine only if this outside recipient is approved for this send." });
              }
            }

            var localBase = v.local.toLowerCase().split("+")[0];
            if (ROLE_LOCALS[localBase]) {
              roleCount++;
              findings.push({ level: "INFO", cls: "Role / generic address",
                text: "Line " + v.line + ": " + v.raw + " — a role address. Mail to role addresses is often unmonitored; confirm a human reads it if the message matters." });
            }
          });

          // Plus-addressing possible duplicates among cleaned entries.
          var byBase = {};
          cleaned.forEach(function (v) {
            var base = v.local.toLowerCase().split("+")[0] + "@" + v.domain.toLowerCase();
            if (!byBase[base]) byBase[base] = [];
            byBase[base].push(v);
          });
          var possDupGroups = 0;
          Object.keys(byBase).forEach(function (base) {
            var group = byBase[base];
            if (group.length > 1) {
              possDupGroups++;
              var desc = group.map(function (v) { return v.raw + " (line " + v.line + ")"; }).join(" and ");
              findings.push({ level: "WARNING", cls: "Possible duplicate (plus-addressing)",
                text: desc + " share the base address " + base + ". Plus-addressing usually delivers to the same mailbox, so this may double-send. Flagged only — never auto-merged." });
            }
          });

          var blockers = findings.filter(function (f) { return f.level === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.level === "WARNING"; }).length;
          var fixes = findings.filter(function (f) { return f.level === "FIX"; }).length;

          var verdict, verdictClass, why;
          if (blockers > 0) {
            verdict = "DO NOT SEND — LIST RISKS PRESENT";
            verdictClass = "bad";
            why = blockers + " blocker" + (blockers === 1 ? "" : "s") + " found. Fix or remove the flagged recipients before this list goes anywhere.";
          } else if (warnings > 0 || fixes > 0) {
            verdict = "SEND WITH FIXES";
            verdictClass = "fix";
            why = "No blockers, but " + (warnings + fixes) + " item" + ((warnings + fixes) === 1 ? "" : "s") + " need a decision or a cleanup first. The cleaned list below already drops exact duplicates and invalid lines.";
          } else {
            verdict = "SAFE TO SEND";
            verdictClass = "ok";
            why = "No duplicates, no invalid lines, no lookalike or unexpected external domains for this send context." + (roleCount ? " Role addresses are noted below as information only." : "");
          }

          var counts = [
            { n: entries.length, t: "addresses parsed" },
            { n: invalid.length, t: "invalid lines" },
            { n: extraCopies, t: "duplicate copies removed" },
            { n: possDupGroups, t: "possible duplicates (plus)" },
            { n: lookBlock, t: "lookalike blockers" },
            { n: lookWarn, t: "lookalike warnings" },
            { n: extBlock + extWarn, t: context === "internal" ? "external blockers" : "external warnings" },
            { n: homoglyph, t: "homoglyph reviews" },
            { n: roleCount, t: "role addresses (info)" },
            { n: cleaned.length, t: "addresses in cleaned list" }
          ];

          return {
            verdict: verdict, verdictClass: verdictClass, why: why,
            findings: findings, counts: counts,
            cleaned: cleaned.map(function (v) { return v.raw; }),
            trusted: trusted, context: context,
            blockers: blockers, warnings: warnings, fixes: fixes
          };
        }

        function contextName(c) {
          return c === "internal" ? "Internal-only" : c === "mixed" ? "Mixed approved" : "Public announcement";
        }

        function buildReport(r) {
          var lines = [];
          lines.push("J-Dawgs Recipient List & Domain Safety Auditor — Report");
          lines.push("Send context: " + contextName(r.context));
          lines.push("Trusted domains: " + (r.trusted.length ? r.trusted.join(", ") : "(none supplied)"));
          lines.push("");
          lines.push("VERDICT: " + r.verdict);
          lines.push("");
          lines.push("Counts:");
          r.counts.forEach(function (c) { lines.push("  " + c.t + ": " + c.n); });
          lines.push("");
          if (r.findings.length) {
            lines.push("Findings:");
            r.findings.forEach(function (f) { lines.push("  [" + f.level + " · " + f.cls + "] " + f.text); });
          } else {
            lines.push("Findings: none.");
          }
          lines.push("");
          lines.push("Cleaned list (exact duplicates and invalid lines removed; flagged addresses stay — only a human may decide they are wrong):");
          r.cleaned.forEach(function (a) { lines.push("  " + a); });
          lines.push("");
          lines.push("This audit never sends mail and does not check whether a mailbox exists or a domain resolves. Lookalike detection is a text heuristic against the trusted list supplied.");
          return lines.join("\n");
        }

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        var lastCleaned = "", lastReport = "";

        function run() {
          var r = audit($("recipients").value, $("trusted").value, $("context").value);
          $("results").classList.remove("hidden");
          var box = $("verdictBox");
          box.className = "verdict " + r.verdictClass;
          $("verdictText").textContent = r.verdict;
          $("verdictWhy").textContent = r.why;

          $("counts").innerHTML = r.counts.map(function (c) {
            return '<div class="count"><span class="n">' + c.n + '</span><span class="t">' + esc(c.t) + "</span></div>";
          }).join("");

          if (r.findings.length) {
            $("findings").innerHTML = r.findings.map(function (f) {
              var chipClass = f.level === "BLOCKER" ? "blocker" : f.level === "WARNING" ? "warning" : f.level === "FIX" ? "fix" : "info";
              return '<div class="finding"><span class="chip ' + chipClass + '">' + f.level + "</span>" + esc(f.text) + "</div>";
            }).join("");
          } else {
            $("findings").innerHTML = '<p class="none-note">No findings. Every address parsed, no duplicates, and every domain matches the trusted list for this context.</p>';
          }

          lastCleaned = r.cleaned.join("\n");
          lastReport = buildReport(r);
          $("cleanedOut").textContent = lastCleaned || "(nothing left — every line was invalid or a duplicate)";
          $("reportOut").textContent = lastReport;
          $("results").scrollIntoView({ behavior: "smooth", block: "start" });
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-recipient-list-domain-safety-auditor',
  name: 'J-Dawgs Recipient List & Domain Safety Auditor',
  description: 'Mail clients validate address syntax only; ours pre-flights the list itself before a send — exact duplicates, plus-addressing variants, edit-distance lookalike domains checked against your trusted-domains list, external addresses hiding in an internal-only send — and returns one send verdict plus a ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
