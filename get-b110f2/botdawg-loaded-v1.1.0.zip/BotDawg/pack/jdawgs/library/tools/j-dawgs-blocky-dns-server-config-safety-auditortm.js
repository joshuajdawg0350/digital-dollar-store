'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Blocky DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Blocky config — risky worked example",
        "ports:",
        "  dns: 53",
        "  http: 0.0.0.0:4000",
        "  https: 0.0.0.0:443",
        "  tls: 853",
        "httpPort: 4000",
        "upstreams:",
        "  groups:",
        "    default:",
        "      - 8.8.8.8",
        "      - 1.1.1.1",
        "      - tcp:9.9.9.9",
        "blocking:",
        "  blockType: zeroIp",
        "  blackLists:",
        "  whiteLists:",
        "queryLog:",
        "  type: file",
        "  target: /var/log/blocky",
        "  retentionDays: 365",
        "  fields:",
        "    - clientIP",
        "    - question",
        "prometheus:",
        "  enable: true",
        "  path: /metrics",
        "caching:",
        "  minTime: 2h",
        "  maxTime: 1h",
        "  prefetching: false",
        "conditional:",
        "  mapping:",
        "    corp.internal: 8.8.4.4",
        "hostsFile:",
        "  sources:",
        "    - http://example.org/hosts.txt",
        "redis:",
        "  address: redis:6379",
        "  password: blocky-prod-password-123"
      ].join("\n");

      var HARDENED = [
        "# Blocky config — hardened worked example",
        "ports:",
        "  dns: 127.0.0.1:53",
        "  http: 127.0.0.1:4000",
        "upstreams:",
        "  groups:",
        "    default:",
        "      - https://dns.quad9.net/dns-query",
        "      - https://cloudflare-dns.com/dns-query",
        "      - tcp-tls:dns.quad9.net:853",
        "blocking:",
        "  blockType: zeroIp",
        "  blackLists:",
        "    ads:",
        "      - https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "  whiteLists:",
        "    ads:",
        "      - whitelist.txt",
        "  blockTTL: 1m",
        "queryLog:",
        "  type: none",
        "  retentionDays: 0",
        "prometheus:",
        "  enable: false",
        "caching:",
        "  minTime: 5m",
        "  maxTime: 30m",
        "  prefetching: true",
        "conditional:",
        "  mapping:",
        "    lan: 127.0.0.53",
        "hostsFile:",
        "  sources:",
        "    - /etc/blocky/hosts.txt",
        "  hostsTTL: 30m",
        "log:",
        "  level: info",
        "  privacy: true"
      ].join("\n");

      var KNOWN_TOP = ["ports","upstreams","blocking","querylog","prometheus","caching","conditional","hostsfile","httpport","httpsport","log","bootstrapdns","redis","customdns","clientgroupsblock","startverifyupstream","fqdnonly","filtering","ecs","suds","rewriter"];
      var BIND_KEYS = ["dns","http","https","tls"];
      var SECRET_RE = /(password|passwd|pwd|token|secret|api[-_]?key|apikey|credential|private[-_]?key|auth)/i;
      var SEV_RANK = {CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4, PASS:5};
      var CHECKS = ["Ports & binds","HTTP listeners","Upstreams","Blocking","Query log","Prometheus","Caching","Conditional mapping","Hosts file","Secrets","Parse"];

      function stripQuotes(s){ return s.replace(/^["']|["']$/g,""); }
      function isAllInterfaces(host){ return host===""||host==="0.0.0.0"||host==="::"||host==="*"; }
      function isLoopback(host){ return host==="127.0.0.1"||host==="::1"||host==="localhost"||host.indexOf("127.")===0; }
      function isPrivateTarget(t){
        return /^127\./.test(t)||/^10\./.test(t)||/^192\.168\./.test(t)||/^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(t)||t==="::1"||/^localhost/.test(t);
      }
      function splitBind(v){
        v = stripQuotes(v.trim());
        if(/^\d+$/.test(v)) return {host:"", port:v};
        var idx = v.lastIndexOf(":");
        if(idx===-1) return {host:v, port:""};
        var host = v.slice(0,idx).replace(/^\[|\]$/g,"");
        return {host:host, port:v.slice(idx+1)};
      }
      function parseDurationMinutes(v){
        if(v==null) return null;
        var m = String(v).trim().match(/^(-?\d+(?:\.\d+)?)\s*(ms|s|m|h|d)?$/);
        if(!m) return null;
        var n = parseFloat(m[1]); var u = m[2]||"s";
        if(u==="ms") return n/60000;
        if(u==="s") return n/60;
        if(u==="m") return n;
        if(u==="h") return n*60;
        if(u==="d") return n*1440;
        return null;
      }

      function audit(text){
        var lines = String(text||"").split(/\r?\n/);
        var findings = [];
        var notParsed = [];
        function add(sev, check, line, msg){ findings.push({severity:sev, check:check, line:line, message:msg}); }

        var stack = []; // {indent, key(lower)}
        function ancKeys(){ var a=[]; for(var i=0;i<stack.length;i++) a.push(stack[i].key); return a; }
        function inAnc(a,k){ return a.indexOf(k)!==-1; }

        var recognized = {};
        var binds = []; // {kind, value, line}
        var httpPortVal = null, httpPortLine = null, httpsPortVal = null, httpsPortLine = null;
        var portsSeen = false;
        var upstreamEntries = []; // {value, line}
        var blockingSeen = false, blockingLine = null, blockingDisabledLine = null;
        var blackSeen = false, whiteSeen = false, blackItems = 0, whiteItems = 0, blackLine = null, whiteLine = null;
        var querySeen = false, queryType = null, queryTypeLine = null, queryRetention = null, queryRetentionLine = null, queryFields = [], queryFieldsLine = null;
        var promSeen = false, promEnable = null, promEnableLine = null, promPath = null;
        var cacheSeen = false, cacheMin = null, cacheMinLine = null, cacheMax = null, cacheMaxLine = null, cachePref = null, cachePrefLine = null;
        var condSeen = false, condEntries = [];
        var hostsSeen = false, hostsSources = [];
        var secrets = []; // {key, line, length, isEnv, isPlaceholder} — value itself is never stored

        for(var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var raw = lines[i];
          var trimmed = raw.trim();
          if(trimmed==="" || trimmed.charAt(0)==="#"){ continue; }

          // --- parseability (heuristic) ---
          var bad = false;
          if(raw.indexOf("\t")!==-1) bad = true;
          var dq = (trimmed.match(/"/g)||[]).length;
          if(dq % 2 === 1) bad = true;
          var ob = (trimmed.match(/\[/g)||[]).length, cb = (trimmed.match(/\]/g)||[]).length;
          if(ob !== cb) bad = true;

          var isItem = trimmed.indexOf("- ")===0 || trimmed==="-";
          var keyMatch = null;
          if(!isItem){
            keyMatch = trimmed.match(/^([^:#][^:]*?):(\s+(.*))?$/);
            if(!keyMatch && !/^[|>][+-]?$/.test(trimmed)) bad = true;
          }
          if(bad){ notParsed.push(lineNo); continue; }

          var indent = raw.match(/^\s*/)[0].length;

          if(isItem){
            var itemVal = stripQuotes(trimmed.replace(/^-\s*/,"").trim());
            var anc = ancKeys();
            if(inAnc(anc,"ports")){
              var topKey = stack.length? stack[stack.length-1].key : "";
              if(BIND_KEYS.indexOf(topKey)!==-1) binds.push({kind:topKey, value:itemVal, line:lineNo});
            }
            if(inAnc(anc,"upstreams")) upstreamEntries.push({value:itemVal, line:lineNo});
            if(inAnc(anc,"blacklists")) blackItems++;
            if(inAnc(anc,"whitelists")) whiteItems++;
            if(inAnc(anc,"querylog") && inAnc(anc,"fields")){ queryFields.push(itemVal); if(!queryFieldsLine) queryFieldsLine = lineNo; }
            if(inAnc(anc,"hostsfile")) hostsSources.push({value:itemVal, line:lineNo});
            continue;
          }

          // key line
          var keyRaw = keyMatch[1].trim();
          var key = keyRaw.toLowerCase();
          var value = (keyMatch[3]!=null ? keyMatch[3].trim() : "");
          while(stack.length && stack[stack.length-1].indent >= indent) stack.pop();
          var parent = ancKeys();

          if(indent===0 && KNOWN_TOP.indexOf(key)!==-1) recognized[key]=true;
          if(indent===0 && key==="ports") portsSeen = true;

          // secrets — record key name, line, length only; value is never stored or rendered
          if(SECRET_RE.test(keyRaw) && value!==""){
            var sv = stripQuotes(value);
            secrets.push({
              key:keyRaw, line:lineNo, length:sv.length,
              isEnv: sv.charAt(0)==="$",
              isPlaceholder: /^(\*+|x+|<[^>]*>|\[[^\]]*\]|changeme|redacted|none|null|~)$/i.test(sv)
            });
          }

          if(inAnc(parent,"ports") && BIND_KEYS.indexOf(key)!==-1 && value!==""){
            binds.push({kind:key, value:value, line:lineNo});
          }
          if(indent===0 && key==="httpport"){ httpPortVal = value; httpPortLine = lineNo; }
          if(indent===0 && key==="httpsport"){ httpsPortVal = value; httpsPortLine = lineNo; }

          if(key==="blocking" && indent===0){ blockingSeen = true; blockingLine = lineNo; }
          if(inAnc(parent,"blocking")){
            if(key==="blacklists"){ blackSeen = true; blackLine = lineNo; }
            if(key==="whitelists"){ whiteSeen = true; whiteLine = lineNo; }
            if((key==="enable"||key==="enabled") && /^(false|no|off)$/i.test(value)) blockingDisabledLine = lineNo;
            if((key==="disable"||key==="disabled") && /^(true|yes|on)$/i.test(value)) blockingDisabledLine = lineNo;
          }
          if(key==="querylog" && indent===0) querySeen = true;
          if(inAnc(parent,"querylog")){
            if(key==="type"){ queryType = stripQuotes(value).toLowerCase(); queryTypeLine = lineNo; }
            if(key==="retentiondays"||key==="retention"){ queryRetention = value; queryRetentionLine = lineNo; }
            if(key==="fields"){
              if(!queryFieldsLine) queryFieldsLine = lineNo;
              var fv = value.replace(/^\[|\]$/g,"");
              if(fv){ var parts = fv.split(","); for(var p=0;p<parts.length;p++){ var f=stripQuotes(parts[p].trim()); if(f) queryFields.push(f); } }
            }
          }
          if(key==="prometheus" && indent===0) promSeen = true;
          if(inAnc(parent,"prometheus")){
            if(key==="enable"||key==="enabled"){ promEnable = /^(true|yes|on)$/i.test(value); promEnableLine = lineNo; }
            if(key==="path") promPath = stripQuotes(value);
          }
          if(key==="caching" && indent===0) cacheSeen = true;
          if(inAnc(parent,"caching")){
            if(key==="mintime"){ cacheMin = value; cacheMinLine = lineNo; }
            if(key==="maxtime"){ cacheMax = value; cacheMaxLine = lineNo; }
            if(key==="prefetching"){ cachePref = /^(true|yes|on)$/i.test(value); cachePrefLine = lineNo; }
          }
          if(key==="conditional" && indent===0) condSeen = true;
          if(inAnc(parent,"conditional") && inAnc(parent,"mapping") && value!==""){
            condEntries.push({name:keyRaw, target:stripQuotes(value), line:lineNo});
          }
          if(key==="hostsfile" && indent===0){ hostsSeen = true; if(value!=="") hostsSources.push({value:stripQuotes(value), line:lineNo}); }

          stack.push({indent:indent, key:key});
        }

        /* ---------- evaluation ---------- */
        var httpExposed = false;

        // Ports & binds
        var dnsBinds = binds.filter(function(b){return b.kind==="dns";});
        if(!portsSeen && dnsBinds.length===0 && httpPortVal===null){
          add("HIGH","Ports & binds",null,"No ports section found — Blocky defaults apply and the DNS listener binds all interfaces. Pin listeners to loopback or a specific LAN address.");
        }
        binds.forEach(function(b){
          var parts = splitBind(b.value);
          var all = isAllInterfaces(parts.host), loop = isLoopback(parts.host);
          if(b.kind==="dns"){
            if(all) add("HIGH","Ports & binds",b.line,"DNS listener is bound to all interfaces (value \""+b.value+"\") — an open resolver exposed to the network invites abuse and amplification attacks. Bind it to 127.0.0.1 or a specific LAN address.");
            else if(loop) add("PASS","Ports & binds",b.line,"DNS listener is bound to loopback only.");
            else add("LOW","Ports & binds",b.line,"DNS listener is bound to a specific address ("+parts.host+") — confirm that interface is trusted.");
          } else if(b.kind==="http"){
            if(all){ httpExposed = true; add("HIGH","Ports & binds",b.line,"HTTP listener is bound to all interfaces (value \""+b.value+"\") — the API, UI, and metrics endpoints are reachable from the whole network. Bind it to 127.0.0.1."); }
            else if(loop) add("PASS","Ports & binds",b.line,"HTTP listener is bound to loopback only.");
            else add("LOW","Ports & binds",b.line,"HTTP listener is bound to a specific address ("+parts.host+") — confirm that interface is trusted.");
          } else if(b.kind==="https"){
            if(all){ httpExposed = true; add("HIGH","Ports & binds",b.line,"HTTPS listener is bound to all interfaces (value \""+b.value+"\") — confirm this DoH endpoint is meant to be public and sits behind proper TLS and access control."); }
            else if(loop) add("PASS","Ports & binds",b.line,"HTTPS listener is bound to loopback only.");
            else add("LOW","Ports & binds",b.line,"HTTPS listener is bound to a specific address ("+parts.host+").");
          } else if(b.kind==="tls"){
            if(all) add("MEDIUM","Ports & binds",b.line,"TLS (DoT) listener is bound to all interfaces (value \""+b.value+"\") — fine if a public DoT service is intended, otherwise restrict it.");
            else if(loop) add("PASS","Ports & binds",b.line,"TLS listener is bound to loopback only.");
            else add("LOW","Ports & binds",b.line,"TLS listener is bound to a specific address ("+parts.host+").");
          }
        });
        if(portsSeen){
          var kinds = {};
          binds.forEach(function(b){ kinds[b.kind]=true; });
          if(!kinds.https) add("INFO","Ports & binds",null,"No HTTPS (DoH) listener configured in ports.");
          if(!kinds.tls) add("INFO","Ports & binds",null,"No TLS (DoT) listener configured in ports.");
        }

        // Legacy httpPort / httpsPort
        if(httpPortVal!==null && httpPortVal!==""){
          var hp = splitBind(httpPortVal);
          if(isAllInterfaces(hp.host)){ httpExposed = true; add("HIGH","HTTP listeners",httpPortLine,"Legacy httpPort \""+httpPortVal+"\" listens on all interfaces — the HTTP API/metrics surface is network-exposed. Use ports.http bound to 127.0.0.1 instead."); }
          else if(isLoopback(hp.host)) add("LOW","HTTP listeners",httpPortLine,"Legacy httpPort is bound to loopback — acceptable, but prefer the ports.http form.");
          else add("MEDIUM","HTTP listeners",httpPortLine,"Legacy httpPort is bound to "+hp.host+" — confirm that interface is trusted.");
        }
        if(httpsPortVal!==null && httpsPortVal!==""){
          var hsp = splitBind(httpsPortVal);
          if(isAllInterfaces(hsp.host)){ httpExposed = true; add("HIGH","HTTP listeners",httpsPortLine,"Legacy httpsPort \""+httpsPortVal+"\" listens on all interfaces — confirm this exposure is intended."); }
          else if(isLoopback(hsp.host)) add("LOW","HTTP listeners",httpsPortLine,"Legacy httpsPort is bound to loopback — acceptable, but prefer the ports.https form.");
          else add("MEDIUM","HTTP listeners",httpsPortLine,"Legacy httpsPort is bound to "+hsp.host+" — confirm that interface is trusted.");
        }
        if(httpPortVal===null && httpsPortVal===null){
          add("INFO","HTTP listeners",null,"No legacy httpPort/httpsPort keys — listeners are governed by the ports section.");
        }

        // Upstreams
        if(upstreamEntries.length===0){
          add("HIGH","Upstreams",null,"No upstream resolvers found under upstreams.groups — the proxy has nothing to forward queries to, or the section could not be read.");
        } else {
          var plain = [], enc = [];
          upstreamEntries.forEach(function(e){
            var v = e.value.toLowerCase();
            if(v.indexOf("https://")===0 || v.indexOf("tcp-tls:")===0 || v.indexOf("tcp-tls://")===0) enc.push(e);
            else plain.push(e);
          });
          if(enc.length===0){
            add("CRITICAL","Upstreams",plain[0].line,"Every upstream ("+plain.length+" of "+upstreamEntries.length+") uses plain UDP/TCP DNS with no DoH/DoT — all queries leave this host in cleartext and can be logged, spoofed, or rewritten upstream. Switch to https:// (DoH) or tcp-tls: (DoT) upstreams.");
          } else if(plain.length>0){
            add("HIGH","Upstreams",plain[0].line,plain.length+" of "+upstreamEntries.length+" upstreams still use plain UDP/TCP DNS (first at line "+plain[0].line+") — those queries leave in cleartext. Move them to https:// or tcp-tls:.");
          } else {
            add("PASS","Upstreams",enc[0].line,"All "+enc.length+" upstreams use encrypted transport (https / tcp-tls).");
          }
        }

        // Blocking
        if(!blockingSeen){
          add("CRITICAL","Blocking",null,"No blocking section found — ad/malware blocking is off and every query resolves. Add a blocking section with blackLists.");
        } else if(blockingDisabledLine){
          add("CRITICAL","Blocking",blockingDisabledLine,"Blocking is explicitly disabled at line "+blockingDisabledLine+" — the blocklists will never be applied.");
        } else {
          if(!blackSeen) add("HIGH","Blocking",blockingLine,"Blocking section has no blackLists — no denylist is configured, so nothing will actually be blocked.");
          else if(blackItems===0) add("HIGH","Blocking",blackLine,"blackLists is present but empty — no list sources are configured, so nothing will actually be blocked.");
          else add("PASS","Blocking",blackLine,"Blocking is on and blackLists has "+blackItems+" list source(s).");
          if(!whiteSeen) add("LOW","Blocking",blockingLine,"No whiteLists configured — there is no allowlist escape hatch for false positives.");
          else if(whiteItems===0) add("LOW","Blocking",whiteLine,"whiteLists is present but empty — no allowlist entries for false positives.");
          else add("PASS","Blocking",whiteLine,"whiteLists has "+whiteItems+" allowlist entr(ies).");
        }

        // Query log
        if(!querySeen){
          add("INFO","Query log",null,"No queryLog section — query logging stays off, which is the privacy-friendly default.");
        } else if(queryType==="none"||queryType==="off"||queryType===""){
          add("PASS","Query log",queryTypeLine,"Query logging is disabled (type: "+(queryType||"unset")+").");
        } else {
          var rDays = null;
          if(queryRetention!=null){ var rm = String(queryRetention).match(/-?\d+/); if(rm) rDays = parseInt(rm[0],10); }
          if(rDays===null){
            add("MEDIUM","Query log",queryTypeLine,"Query logging is on (type: "+queryType+") with no retention limit set — logs of who resolved what can grow and persist indefinitely. Set retentionDays.");
          } else if(rDays>=90){
            add("CRITICAL","Query log",queryRetentionLine,"Query log retention is "+rDays+" days — a long-lived record of client DNS history. Cut retention to days, not months, or turn query logging off.");
          } else if(rDays>=30){
            add("HIGH","Query log",queryRetentionLine,"Query log retention is "+rDays+" days — a month or more of client DNS history at rest. Shorten it unless a real audit need exists.");
          } else if(rDays>=8){
            add("MEDIUM","Query log",queryRetentionLine,"Query log retention is "+rDays+" days — keep only what you actually review.");
          } else {
            add("PASS","Query log",queryRetentionLine,"Query log retention is short ("+rDays+" day(s)).");
          }
          var hasClient = false;
          queryFields.forEach(function(f){ if(/client/i.test(f)) hasClient = true; });
          if(hasClient){
            add("HIGH","Query log",queryFieldsLine,"Query log fields include client identifiers (clientIP) — combined with the retention above, this is a per-client browsing record. Drop client fields or shorten retention.");
          } else if(queryFields.length===0){
            add("MEDIUM","Query log",queryTypeLine,"Query logging is on (type: "+queryType+") and no fields restriction is set — Blocky logs client IPs by default. Restrict fields or accept and document the exposure.");
          } else {
            add("INFO","Query log",queryFieldsLine,"Query log fields are restricted to: "+queryFields.join(", ")+".");
          }
        }

        // Prometheus
        if(!promSeen){
          add("INFO","Prometheus",null,"No prometheus section — metrics endpoint is not configured.");
        } else if(promEnable===true){
          if(httpExposed) add("HIGH","Prometheus",promEnableLine,"Prometheus metrics are enabled (path "+(promPath||"/metrics")+") while an HTTP listener is bound to all interfaces — query and client metrics are readable by anyone on the network. Disable metrics, bind HTTP to loopback, or protect the path.");
          else add("MEDIUM","Prometheus",promEnableLine,"Prometheus metrics are enabled (path "+(promPath||"/metrics")+") — make sure that path is not reachable from untrusted networks.");
        } else if(promEnable===false){
          add("PASS","Prometheus",promEnableLine,"Prometheus metrics are disabled.");
        } else {
          add("INFO","Prometheus",null,"Prometheus section present but no enable flag was read.");
        }

        // Caching
        if(!cacheSeen){
          add("LOW","Caching",null,"No caching section — Blocky cache defaults apply. Set minTime/maxTime explicitly so staleness is a choice, not a default.");
        } else {
          var minM = parseDurationMinutes(cacheMin), maxM = parseDurationMinutes(cacheMax);
          if(minM!==null && maxM!==null && maxM < minM){
            add("HIGH","Caching",cacheMaxLine,"caching maxTime ("+cacheMax+") is below minTime ("+cacheMin+") — the cache window contradicts itself and answers can be held stale or evicted unpredictably. Make maxTime greater than minTime.");
          } else if(minM!==null && maxM!==null){
            add("PASS","Caching",cacheMinLine,"Caching window is consistent (minTime "+cacheMin+", maxTime "+cacheMax+").");
          }
          if(minM!==null && minM>60) add("MEDIUM","Caching",cacheMinLine,"caching minTime is "+cacheMin+" — records are held at least that long even if the authoritative TTL is shorter, so changes propagate slowly.");
          if(maxM!==null && maxM>10080) add("MEDIUM","Caching",cacheMaxLine,"caching maxTime is "+cacheMax+" — records can be served stale for over a week.");
          if(cachePref===true) add("PASS","Caching",cachePrefLine,"Cache prefetching is on — popular names are refreshed before expiry.");
          else if(cachePref===false) add("LOW","Caching",cachePrefLine,"Cache prefetching is off — popular names pay a full upstream lookup at expiry.");
        }

        // Conditional mapping
        if(!condSeen){
          add("INFO","Conditional mapping",null,"No conditional mapping — internal/split-horizon names resolve through the default upstreams.");
        } else if(condEntries.length===0){
          add("INFO","Conditional mapping",null,"Conditional section present but no mapping entries were read.");
        } else {
          condEntries.forEach(function(e){
            var t = e.target.toLowerCase();
            if(t.indexOf("https://")===0 || t.indexOf("tcp-tls:")===0){
              add("PASS","Conditional mapping",e.line,"Conditional mapping for \""+e.name+"\" uses an encrypted upstream.");
            } else if(isPrivateTarget(t)){
              add("INFO","Conditional mapping",e.line,"Conditional mapping for \""+e.name+"\" forwards to a loopback/private resolver ("+e.target+") over plain DNS — normal inside a trusted LAN.");
            } else {
              add("MEDIUM","Conditional mapping",e.line,"Conditional mapping for \""+e.name+"\" forwards to "+e.target+" over plain DNS — an internal name's queries leave in cleartext to a public resolver. Point it at a private resolver or an encrypted upstream.");
            }
          });
        }

        // Hosts file
        if(!hostsSeen){
          add("INFO","Hosts file",null,"No hostsFile section — no static hosts overrides are loaded.");
        } else {
          var httpSources = hostsSources.filter(function(s){ return s.value.toLowerCase().indexOf("http://")===0; });
          if(httpSources.length>0){
            httpSources.forEach(function(s){
              add("HIGH","Hosts file",s.line,"Hosts file source is fetched over plain HTTP ("+s.value+") — anyone on the path can rewrite your static name overrides. Use a local file or an https:// source.");
            });
          } else if(hostsSources.length>0){
            add("PASS","Hosts file",hostsSources[0].line,"hostsFile uses local or HTTPS source(s) only.");
          } else {
            add("INFO","Hosts file",null,"hostsFile section present but no sources were read.");
          }
        }

        // Secrets — key name, line, length only
        if(secrets.length===0){
          add("PASS","Secrets",null,"No password/token/secret keys found in the config.");
        } else {
          secrets.forEach(function(s){
            if(s.isEnv) add("INFO","Secrets",s.line,"Key \""+s.key+"\" at line "+s.line+" (value length "+s.length+") references an environment variable rather than a literal value — good practice; the value itself is not shown here.");
            else if(s.isPlaceholder) add("INFO","Secrets",s.line,"Key \""+s.key+"\" at line "+s.line+" (value length "+s.length+") holds a placeholder, not a live credential. The value itself is not shown here.");
            else add("CRITICAL","Secrets",s.line,"Plaintext credential in config: key \""+s.key+"\" at line "+s.line+", value length "+s.length+" (value never shown). Anyone who can read this file owns the credential — move it to an environment variable or secret store and rotate it.");
          });
        }

        // Parse
        if(notParsed.length>0){
          add("MEDIUM","Parse",notParsed[0]," "+notParsed.length+" line(s) could not be parsed by this heuristic audit (lines "+notParsed.join(", ")+") — findings may be incomplete for those sections. See the NOT PARSED list.");
        }

        findings.sort(function(a,b){
          var d = SEV_RANK[a.severity]-SEV_RANK[b.severity];
          if(d!==0) return d;
          var la = a.line==null?99999:a.line, lb = b.line==null?99999:b.line;
          return la-lb;
        });

        var counts = {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,PASS:0};
        findings.forEach(function(f){ counts[f.severity]++; });

        var recCount = Object.keys(recognized).length;
        var verdict;
        if(String(text||"").trim().length < 30 || recCount===0){
          verdict = "NOT ENOUGH TO GRADE";
        } else if(counts.CRITICAL>0){
          verdict = "DO NOT DEPLOY";
        } else if(counts.HIGH>0 || counts.MEDIUM>0){
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        return {verdict:verdict, findings:findings, notParsed:notParsed, counts:counts, lineCount:lines.length, recognized:recCount};
      }

      function buildReport(r){
        var out = [];
        out.push("J-Dawgs Blocky DNS Server Config Safety Auditor — Audit Report");
        out.push("Generated: "+new Date().toLocaleString());
        out.push("Verdict: "+r.verdict);
        out.push("Lines audited: "+r.lineCount+" | Recognized Blocky sections: "+r.recognized+" | NOT PARSED lines: "+(r.notParsed.length? r.notParsed.join(", ") : "none"));
        out.push("Counts: CRITICAL "+r.counts.CRITICAL+" | HIGH "+r.counts.HIGH+" | MEDIUM "+r.counts.MEDIUM+" | LOW "+r.counts.LOW+" | INFO "+r.counts.INFO+" | PASS "+r.counts.PASS);
        out.push("");
        out.push("Findings:");
        if(r.findings.length===0) out.push("  (none)");
        r.findings.forEach(function(f){
          out.push("  ["+f.severity+"] "+(f.line? "Line "+f.line+" · " : "Config-wide · ")+f.check+" — "+f.message);
        });
        out.push("");
        out.push("Notes: Heuristic text audit only — not a real YAML parser, and no server was started. Secret values are never shown; credentials are reported by key name, line, and value length only.");
        return out.join("\n");
      }
      function buildJson(r){
        return JSON.stringify({
          tool:"J-Dawgs Blocky DNS Server Config Safety Auditor",
          generatedAt:new Date().toISOString(),
          verdict:r.verdict,
          linesAudited:r.lineCount,
          recognizedSections:r.recognized,
          notParsedLines:r.notParsed,
          counts:r.counts,
          findings:r.findings.map(function(f){ return {severity:f.severity, check:f.check, line:f.line, message:f.message}; }),
          note:"Heuristic text audit, not a real YAML parser. No server was started. Secret values are never included; credentials appear as key name, line, and value length only."
        }, null, 2);
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-blocky-dns-server-config-safety-auditortm',
  name: 'J-Dawgs Blocky DNS Server Config Safety Auditor',
  description: 'Grades a pasted Blocky DNS proxy YAML config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — listening ports and bind posture, upstream and blocking configuration, and plaintext secrets, with secrets shown by key name, line, and leng',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
