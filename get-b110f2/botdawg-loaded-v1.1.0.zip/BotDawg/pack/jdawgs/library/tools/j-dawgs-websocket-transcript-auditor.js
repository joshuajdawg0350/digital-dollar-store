'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs WebSocket Transcript Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var EXAMPLE = [
  "# Worked example — one broken WebSocket session",
  "2026-11-04T10:00:00Z | C2S | text | {\"type\":\"hello\",\"client\":\"auditor-demo\"}",
  "2026-11-04T10:00:02Z | S2C | text | {\"type\":\"welcome\",\"session\":\"s-1042\"}",
  "2026-11-04T10:00:05Z | C2S | ping | heartbeat-1",
  "2026-11-04T10:00:40Z | C2S | text | {\"type\":\"update\",\"value\": ,}",
  "2026-11-04T10:00:42Z | S2C | close | 1000 normal closure",
  "2026-11-04T10:00:45Z | C2S | text | {\"type\":\"late-message\"}"
].join("\n");

var PITCHES = {
  pitch1: "WebSocket Transcript Auditor\u2122 \u2014 paste a session transcript, get one verdict (CLEAN / ISSUES / BROKEN) with line-numbered findings: messages after close, unanswered pings, malformed JSON, oversized payloads, retry duplicates. Runs entirely in the browser; opens no socket, saves nothing. Find it in the AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
  pitch2: "Own It, Rotate It, Stream It Stack \u2014 CODEOWNERS Coverage Auditor + Secret Rotation Overdue Auditor + WebSocket Transcript Auditor (own the files, rotate the secrets, vet the stream) \u2014 $2.25 full pass.",
  store: "AI Tool Store \u2014 https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
  exchange: "J-Dawgs Agent Exchange \u2014 https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY"
};

var VALID_DIRS = { "C2S": true, "S2C": true };
var VALID_TYPES = { "text": true, "binary": true, "ping": true, "pong": true, "close": true };
var encoder = (typeof TextEncoder !== "undefined") ? new TextEncoder() : null;

function byteLen(s) {
  if (encoder) return encoder.encode(s).length;
  var n = 0;
  for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); n += c < 128 ? 1 : (c < 2048 ? 2 : 3); }
  return n;
}

function fmtSec(x) {
  if (x === null || x === undefined || !isFinite(x)) return "\u2014";
  var r = Math.round(x * 1000) / 1000;
  return (r % 1 === 0) ? String(r) : String(r);
}

function parseTimestamp(raw) {
  var t = raw.trim();
  if (/^-?\d+(\.\d+)?$/.test(t)) {
    var v = parseFloat(t);
    return isFinite(v) ? v : null; // epoch seconds
  }
  var ms = Date.parse(t);
  return isNaN(ms) ? null : ms / 1000;
}

function audit(text, hbWindow, maxBytes) {
  var findings = [];
  function add(sev, line, title, detail) { findings.push({ sev: sev, line: line, title: title, detail: detail || "" }); }

  var rawLines = text.split(/\r?\n/);
  var msgs = [];       // parsed messages
  var excluded = [];   // {line, raw, reason}

  for (var i = 0; i < rawLines.length; i++) {
    var lineNo = i + 1;
    var raw = rawLines[i];
    var trimmed = raw.trim();
    if (trimmed === "" || trimmed.charAt(0) === "#") continue;

    var parts = raw.split("|");
    if (parts.length < 4) {
      excluded.push({ line: lineNo, raw: raw, reason: "expected 4 pipe-separated fields (timestamp | direction | type | payload-or-note), found " + parts.length });
      add("WARNING", lineNo, "Unparsable line \u2014 excluded from the audit", "Expected 4 pipe-separated fields, found " + parts.length + ". The line was not guessed at.");
      continue;
    }
    var tsRaw = parts[0].trim();
    var dirRaw = parts[1].trim();
    var typeRaw = parts[2].trim();
    var payload = parts.slice(3).join("|").trim();

    var ts = parseTimestamp(tsRaw);
    if (ts === null) {
      excluded.push({ line: lineNo, raw: raw, reason: "timestamp \"" + tsRaw + "\" is neither ISO 8601 nor epoch seconds" });
      add("WARNING", lineNo, "Unparsable timestamp \u2014 line excluded from the audit", "\"" + tsRaw + "\" is neither ISO 8601 nor epoch seconds. The line was not guessed at.");
      continue;
    }

    var dir = dirRaw.toUpperCase();
    var type = typeRaw.toLowerCase();
    var dirOk = !!VALID_DIRS[dir];
    var typeOk = !!VALID_TYPES[type];
    if (!dirOk) add("WARNING", lineNo, "Invalid direction token \"" + dirRaw + "\"", "Direction must be C2S or S2C.");
    if (!typeOk) add("WARNING", lineNo, "Invalid type token \"" + typeRaw + "\"", "Type must be one of: text, binary, ping, pong, close.");

    msgs.push({ line: lineNo, ts: ts, tsRaw: tsRaw, dir: dir, dirOk: dirOk, type: type, typeOk: typeOk, payload: payload });
  }

  // Longest silent gap between consecutive parsed messages (in transcript order)
  var longestGap = null, gapFrom = null, gapTo = null;
  for (var g = 1; g < msgs.length; g++) {
    var gap = Math.abs(msgs[g].ts - msgs[g - 1].ts);
    if (longestGap === null || gap > longestGap) { longestGap = gap; gapFrom = msgs[g - 1]; gapTo = msgs[g]; }
  }
  if (msgs.length >= 2 && longestGap !== null) {
    add("INFO", gapTo.line, "Longest silent gap: " + fmtSec(longestGap) + "s", "Between line " + gapFrom.line + " (" + gapFrom.tsRaw + ") and line " + gapTo.line + " (" + gapTo.tsRaw + ").");
  }

  // Close-frame checks
  var firstCloseIdx = -1;
  for (var c = 0; c < msgs.length; c++) { if (msgs[c].typeOk && msgs[c].type === "close") { firstCloseIdx = c; break; } }
  if (firstCloseIdx >= 0) {
    var fc = msgs[firstCloseIdx];
    for (var a = firstCloseIdx + 1; a < msgs.length; a++) {
      // An answering close frame is the closing handshake itself, not a violation.
      if (msgs[a].typeOk && msgs[a].type === "close") continue;
      add("BLOCKER", msgs[a].line, "Message after a close frame", "Close frame was on line " + fc.line + " (" + fc.dir + "). Nothing but the answering close frame may follow a close \u2014 this " + msgs[a].type + " message from " + msgs[a].dir + " breaks the session.");
    }
    // Closing handshake: an answering close from the opposite direction
    var answered = false;
    for (var h = 0; h < msgs.length; h++) {
      if (h !== firstCloseIdx && msgs[h].typeOk && msgs[h].type === "close" && msgs[h].dirOk && msgs[h].dir !== fc.dir) answered = true;
    }
    if (!answered) {
      add("WARNING", fc.line, "Close with no handshake noted", "Only one close frame appears, from " + fc.dir + ", with no answering close frame from the other side noted in the transcript.");
    }
  }

  // Ping / pong within heartbeat window
  for (var p = 0; p < msgs.length; p++) {
    var m = msgs[p];
    if (!(m.typeOk && m.type === "ping")) continue;
    var got = false;
    for (var q = p + 1; q < msgs.length; q++) {
      var n = msgs[q];
      if (n.typeOk && n.type === "pong") {
        var dt = n.ts - m.ts;
        if (dt >= 0 && dt <= hbWindow) { got = true; break; }
        if (dt > hbWindow) break;
      }
    }
    if (!got) add("WARNING", m.line, "Ping with no pong within " + fmtSec(hbWindow) + "s", "No pong follows this " + m.dir + " ping inside the heartbeat window you set (" + fmtSec(hbWindow) + "s).");
  }

  // Per-message payload checks
  for (var k = 0; k < msgs.length; k++) {
    var msg = msgs[k];
    if (!msg.typeOk) continue;
    var size = byteLen(msg.payload);
    if (size > maxBytes) {
      add("WARNING", msg.line, "Payload over size limit: " + size + " bytes", "Limit is " + maxBytes + " bytes. Payload measured as UTF-8 bytes; binary contents are never inspected beyond size.");
    }
    if (msg.type === "text") {
      var t = msg.payload.replace(/^\s+/, "");
      if (t.charAt(0) === "{" || t.charAt(0) === "[") {
        try { JSON.parse(msg.payload); }
        catch (e) { add("WARNING", msg.line, "Malformed JSON in text payload", "JSON.parse failed: " + e.message); }
      }
    }
  }

  // Duplicate consecutive identical C2S text messages
  var dupCount = 0;
  for (var d = 1; d < msgs.length; d++) {
    var prev = msgs[d - 1], cur = msgs[d];
    if (prev.typeOk && cur.typeOk && prev.type === "text" && cur.type === "text" &&
        prev.dirOk && cur.dirOk && prev.dir === "C2S" && cur.dir === "C2S" &&
        prev.payload === cur.payload && cur.payload !== "") {
      dupCount++;
      add("INFO", cur.line, "Duplicate consecutive C2S text message \u2014 possible retry duplicate", "Identical to line " + prev.line + ". Duplicate #" + dupCount + " in this transcript.");
    }
  }

  var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
  for (var f = 0; f < findings.length; f++) counts[findings[f].sev]++;

  var verdict, cls;
  if (counts.BLOCKER > 0) { verdict = "BROKEN SESSION"; cls = "broken"; }
  else if (counts.WARNING > 0) { verdict = "SESSION WITH ISSUES"; cls = "issues"; }
  else { verdict = "CLEAN SESSION"; cls = "clean"; }

  findings.sort(function (x, y) {
    var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
    if (rank[x.sev] !== rank[y.sev]) return rank[x.sev] - rank[y.sev];
    return x.line - y.line;
  });

  return { findings: findings, counts: counts, verdict: verdict, cls: cls, parsed: msgs.length, excluded: excluded, longestGap: longestGap, dupCount: dupCount };
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE": (typeof EXAMPLE !== 'undefined' ? EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-websocket-transcript-auditor',
  name: 'J-Dawgs WebSocket Transcript Auditor',
  description: 'Audits a pasted WebSocket transcript: messages sent after close, unanswered pings, heartbeat gaps, malformed JSON frames, and oversized payloads are all flagged, and the audit returns one verdict — CLEAN SESSION / SESSION WITH ISSUES / BROKEN SESSION.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE": __core["EXAMPLE"] }
};
