'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Shlink Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var KNOWN = {
        DB_HOST:1, DB_PORT:1, DB_USER:1, DB_PASSWORD:1, DB_NAME:1, DB_DRIVER:1, DB_UNIX_SOCKET:1,
        GEOLITE_LICENSE_KEY:1, ANONYMIZE_REMOTE_ADDR:1,
        REDIRECT_STATUS_CODE:1, REDIRECT_CACHE_LIFETIME:1,
        DISABLE_TRACKING:1, DISABLE_IP_TRACKING:1, DISABLE_REFERRER_TRACKING:1, DISABLE_UA_TRACKING:1,
        TRACK_ORPHAN_VISITS:1, DEFAULT_DOMAIN:1, IS_HTTPS_ENABLED:1,
        VISITS_WEBHOOKS:1, NOTIFY_ORPHAN_VISITS_TO_WEBHOOKS:1, BASE_PATH:1, WORKER_TASK_PRIORITY:1,
        REDIS_SERVERS:1, REDIS_SENTINEL_SERVICE:1, MERCURE_PUBLIC_URL:1, MERCURE_JWT_SECRET:1,
        RABBITMQ_HOST:1, RABBITMQ_USER:1, RABBITMQ_PASSWORD:1, MEMCACHED_SERVERS:1,
        API_KEY:1, SHLINK_API_KEY:1, JWT_SECRET:1, SECRET:1, SECRET_KEY:1, APP_SECRET:1,
        DELETE_SHORT_URL_THRESHOLD:1, QR_CODE_ENABLED:1, ROBOTS_ALLOW_ALL_DOMAINS:1
      };
      var SECRET_NAME = /(PASSWORD|PASSWD|PWD|SECRET|TOKEN|API_?KEY|LICENSE_?KEY|PRIVATE_?KEY|CREDENTIAL|AUTH_?KEY)/;
      var EXAMPLE_BITS = ["changeme","change-me","change_me","example","password","secret","test","dummy",
        "placeholder","your-","your_","xxxxx","123456","letmein","default","sample","demo","abc123","todo","fixme"];
      var REDIRECT_CODES = {301:1,302:1,303:1,307:1,308:1};

      var RISKY = [
        "# Risky worked example - a config that starts fine and should not ship",
        "DB_HOST=localhost",
        "DB_USER=shlink",
        "DB_PASSWORD=short123",
        "DB_NAME=shlink",
        "GEOLITE_LICENSE_KEY=abc123examplekey",
        "DEFAULT_DOMAIN=http://sho.rt",
        "IS_HTTPS_ENABLED=false",
        "ANONYMIZE_REMOTE_ADDR=false",
        "DISABLE_TRACKING=false",
        "TRACK_ORPHAN_VISITS=true",
        "API_KEY=plaintext-api-key-value-001",
        "JWT_SECRET=changeme",
        "REDIRECT_STATUS_CODE=302",
        "REDIRECT_CACHE_LIFETIME=30",
        "# DISABLE_UA_TRACKING=true"
      ].join("\n");

      var HARDENED = [
        "# Hardened worked example - secrets injected at deploy time, never in the file",
        "DB_HOST=db",
        "DB_USER=shlink",
        "DB_PASSWORD=${DB_PASSWORD}",
        "DB_NAME=shlink",
        "GEOLITE_LICENSE_KEY=${GEOLITE_LICENSE_KEY}",
        "DEFAULT_DOMAIN=https://sho.rt",
        "IS_HTTPS_ENABLED=true",
        "ANONYMIZE_REMOTE_ADDR=true",
        "DISABLE_TRACKING=false",
        "DISABLE_IP_TRACKING=false",
        "DISABLE_REFERRER_TRACKING=false",
        "DISABLE_UA_TRACKING=false",
        "TRACK_ORPHAN_VISITS=false",
        "API_KEY=${SHLINK_API_KEY}",
        "JWT_SECRET=${JWT_SECRET}",
        "REDIRECT_STATUS_CODE=302",
        "REDIRECT_CACHE_LIFETIME=3600"
      ].join("\n");

      var lastReport = null;   // {text, json} built from findings only - never holds raw values

      function el(id){ return document.getElementById(id); }
      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

      function parseBool(v){
        var s = String(v).trim().toLowerCase();
        if (s==="true"||s==="1"||s==="yes"||s==="on") return true;
        if (s==="false"||s==="0"||s==="no"||s==="off") return false;
        return null;
      }
      function isReference(v){
        return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) ||
               /^file:/i.test(v) || /^vault:/i.test(v) || /^secret:/i.test(v);
      }
      function cleanValue(raw){
        var v = raw.trim();
        if (v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
          return v.slice(1,-1);
        }
        var hash = v.indexOf(" #");
        if (hash>0) v = v.slice(0,hash).trim();
        return v;
      }

      function audit(text){
        var findings = [];
        function add(sev, code, key, line, len, msg){
          var f = { severity:sev, code:code, key:key||null, line:(line==null?null:line), message:msg };
          if (len!=null) f.secretLength = len;
          findings.push(f);
        }

        var lines = String(text||"").split(/\r?\n/);
        var entries = [];        // active {key, value, line}
        var byKey = {};          // UPPER key -> [entries]
        var commented = [];      // {key, line}
        var parsedCount = 0;

        var keyLineRe = /^([A-Za-z_][A-Za-z0-9_.]*)\s*[:=]\s*(.*)$/;

        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var raw = lines[i];
          var t = raw.trim();
          if (!t) continue;
          if (t.charAt(0)==="#" || t.indexOf("//")===0){
            var cm = t.replace(/^[#\/\s]+/,"").match(keyLineRe);
            if (cm && (KNOWN[cm[1].toUpperCase()] || SECRET_NAME.test(cm[1].toUpperCase()))){
              commented.push({ key:cm[1].toUpperCase(), line:lineNo });
            }
            continue;
          }
          var body = t;
          if (body.indexOf("- ")===0) body = body.slice(2).trim();
          if (body.indexOf("export ")===0) body = body.slice(7).trim();
          var m = body.match(keyLineRe);
          if (!m){
            add("LOW","NOT_PARSED",null,lineNo,null,
              "Line " + lineNo + ": NOT PARSED - it is not blank, not a comment, and not in KEY=value or KEY: value form, so this audit cannot grade it and a strict loader may choke on it.");
            continue;
          }
          var key = m[1].toUpperCase();
          var value = cleanValue(m[2]);
          var entry = { key:key, value:value, line:lineNo };
          entries.push(entry);
          if (!byKey[key]) byKey[key]=[];
          byKey[key].push(entry);
          parsedCount++;
        }

        function eff(key){
          var arr = byKey[key];
          return arr && arr.length ? arr[arr.length-1] : null;
        }

        // Duplicate keys
        Object.keys(byKey).forEach(function(k){
          if (byKey[k].length>1){
            var ls = byKey[k].map(function(e){return e.line;}).join(", ");
            add("MEDIUM","DUPLICATE_KEY",k,byKey[k][0].line,null,
              k + " is defined " + byKey[k].length + " times (lines " + ls + "). Only one value wins when the server loads this, and which one wins depends on the loader - remove the extras so the graded value is the running value.");
          }
        });

        // Commented keys
        commented.forEach(function(c){
          add("INFO","COMMENTED_NOT_ACTIVE",c.key,c.line,null,
            c.key + " on line " + c.line + " is COMMENTED / NOT ACTIVE. A commented line changes nothing on a running server - if you were counting on it, uncomment it and re-audit.");
        });

        // Secrets
        var plaintextSecrets = 0;
        entries.forEach(function(e){
          if (!SECRET_NAME.test(e.key)) return;
          if (e.value === ""){
            add("LOW","SECRET_EMPTY",e.key,e.line,0,
              e.key + " (line " + e.line + ") is present but empty. If the real value is injected another way, fine - if not, the server may fall back to a default or fail open.");
            return;
          }
          if (isReference(e.value)){
            add("INFO","SECRET_BY_REFERENCE",e.key,e.line,null,
              e.key + " (line " + e.line + ") is supplied by reference, not written in the config - no plaintext secret in the pasted text for this key.");
            return;
          }
          plaintextSecrets++;
          var len = e.value.length;
          var lower = e.value.toLowerCase();
          var example = false;
          for (var j=0;j<EXAMPLE_BITS.length;j++){ if (lower.indexOf(EXAMPLE_BITS[j])>=0){ example=true; break; } }
          if (example){
            add("CRITICAL","SECRET_EXAMPLE",e.key,e.line,len,
              e.key + " (line " + e.line + ", length " + len + ") is a plaintext secret whose value looks like an example, default, or placeholder value. Anyone who has seen the docs has seen this secret. Replace it with a long random value injected at deploy time. (Value never shown.)");
          } else if (len < 8){
            add("CRITICAL","SECRET_VERY_SHORT",e.key,e.line,len,
              e.key + " (line " + e.line + ", length " + len + ") is a plaintext secret and very short - short enough to guess or brute-force. Replace it with a long random value injected at deploy time. (Value never shown.)");
          } else if (len < 16){
            add("HIGH","SECRET_PLAINTEXT_SHORT",e.key,e.line,len,
              e.key + " (line " + e.line + ", length " + len + ") is written in plaintext and is short for a secret. Move it out of the file (environment injection or a secrets file) and make it long and random. (Value never shown.)");
          } else {
            add("HIGH","SECRET_PLAINTEXT",e.key,e.line,len,
              e.key + " (line " + e.line + ", length " + len + ") is written in plaintext in the config. Config files get committed, copied, and screenshotted - inject this value at deploy time instead of storing it here. (Value never shown.)");
          }
        });

        // Tracking posture
        var dTrack = eff("DISABLE_TRACKING"), dIp = eff("DISABLE_IP_TRACKING"),
            dRef = eff("DISABLE_REFERRER_TRACKING"), dUa = eff("DISABLE_UA_TRACKING"),
            anon = eff("ANONYMIZE_REMOTE_ADDR"), orphan = eff("TRACK_ORPHAN_VISITS");
        var trackingOff = dTrack && parseBool(dTrack.value)===true;
        var anonVal = anon ? parseBool(anon.value) : null;

        var posture = {
          trackingMaster: trackingOff ? "DISABLE_TRACKING=true - all visit tracking is off" :
            (dTrack ? "DISABLE_TRACKING is not true - visit tracking is on" : "DISABLE_TRACKING not set in the pasted text - visit tracking is on unless set elsewhere"),
          ipTracking: trackingOff ? "off (master switch)" : (dIp && parseBool(dIp.value)===true ? "DISABLE_IP_TRACKING=true - IP tracking off" : "IP tracking on"),
          referrerTracking: trackingOff ? "off (master switch)" : (dRef && parseBool(dRef.value)===true ? "DISABLE_REFERRER_TRACKING=true - referrer tracking off" : "referrer tracking on"),
          uaTracking: trackingOff ? "off (master switch)" : (dUa && parseBool(dUa.value)===true ? "DISABLE_UA_TRACKING=true - user-agent tracking off" : "user-agent tracking on"),
          anonymizeRemoteAddr: !anon ? "ANONYMIZE_REMOTE_ADDR not set in the pasted text - not confirmed" :
            (anonVal===true ? "ANONYMIZE_REMOTE_ADDR=true - visitor IPs are anonymized" :
             anonVal===false ? "ANONYMIZE_REMOTE_ADDR=false - full visitor IPs are kept" : "ANONYMIZE_REMOTE_ADDR has an unreadable value - not confirmed"),
          orphanVisits: !orphan ? "TRACK_ORPHAN_VISITS not set in the pasted text - not confirmed" :
            (parseBool(orphan.value)===true ? "TRACK_ORPHAN_VISITS=true - orphan visits are tracked" : "TRACK_ORPHAN_VISITS is not true - orphan visits are not tracked")
        };

        if (!trackingOff && anonVal===false){
          add("HIGH","PRIVACY_ANON_OFF", "ANONYMIZE_REMOTE_ADDR", anon.line, null,
            "Privacy HIGH: ANONYMIZE_REMOTE_ADDR=false (line " + anon.line + ") while visit tracking is enabled. Every short-link visit is recorded with the visitor's full IP address - that is personal data in most privacy regimes, stored forever by default. Set ANONYMIZE_REMOTE_ADDR=true, or turn tracking off.");
        } else if (!trackingOff && anonVal===true){
          add("INFO","PRIVACY_ANON_ON","ANONYMIZE_REMOTE_ADDR",anon.line,null,
            "ANONYMIZE_REMOTE_ADDR=true (line " + anon.line + ") with tracking enabled - visitor IPs are anonymized before storage. Good posture.");
        } else if (trackingOff){
          add("INFO","TRACKING_OFF", "DISABLE_TRACKING", dTrack.line, null,
            "DISABLE_TRACKING=true (line " + dTrack.line + ") - visit tracking is fully off, so anonymization and the per-type tracking switches do not come into play.");
        } else if (!anon){
          add("LOW","ANON_NOT_SET","ANONYMIZE_REMOTE_ADDR",null,null,
            "ANONYMIZE_REMOTE_ADDR does not appear in the pasted text, so this audit cannot confirm visitor IPs are anonymized while tracking is on. Set it explicitly to true.");
        } else if (anonVal===false && trackingOff){
          add("LOW","ANON_OFF_TRACKING_OFF","ANONYMIZE_REMOTE_ADDR",anon.line,null,
            "ANONYMIZE_REMOTE_ADDR=false (line " + anon.line + "), but tracking is disabled, so no IPs are being collected right now. If tracking is ever re-enabled, anonymization will still be off.");
        }

        if (orphan && parseBool(orphan.value)===true){
          add("HIGH","ORPHAN_TRACKING_ON","TRACK_ORPHAN_VISITS",orphan.line,null,
            "TRACK_ORPHAN_VISITS=true (line " + orphan.line + ") - visits to short URLs that do not exist are tracked too. That records probes, typos, and scanner traffic against visitor IPs, and most deployments get no value from it. Set it to false unless you specifically study orphan traffic.");
        }

        // Transport
        var https = eff("IS_HTTPS_ENABLED"), domain = eff("DEFAULT_DOMAIN");
        if (https && parseBool(https.value)===false){
          add("HIGH","HTTPS_DISABLED","IS_HTTPS_ENABLED",https.line,null,
            "IS_HTTPS_ENABLED=false (line " + https.line + ") - Shlink will build short URLs and serve its interfaces as http. API keys and credentials can cross the network in the clear wherever a proxy is not terminating TLS for you. Enable HTTPS or put the service behind a TLS-terminating proxy and say so in the config.");
        }
        if (domain){
          if (/^http:\/\//i.test(domain.value)){
            add("HIGH","DOMAIN_HTTP","DEFAULT_DOMAIN",domain.line,null,
              "DEFAULT_DOMAIN (line " + domain.line + ") starts with http:// - every short link this server hands out points at a plain-http address. Use the https:// address as the default domain.");
          } else if (/^https:\/\//i.test(domain.value)){
            add("INFO","DOMAIN_HTTPS","DEFAULT_DOMAIN",domain.line,null,
              "DEFAULT_DOMAIN (line " + domain.line + ") uses https://. Good.");
          } else {
            add("LOW","DOMAIN_NO_SCHEME","DEFAULT_DOMAIN",domain.line,null,
              "DEFAULT_DOMAIN (line " + domain.line + ") carries no http:// or https:// scheme in the pasted text, so this audit cannot confirm the transport from the domain alone - check it against IS_HTTPS_ENABLED.");
          }
        } else {
          add("LOW","DOMAIN_MISSING","DEFAULT_DOMAIN",null,null,
            "No DEFAULT_DOMAIN line in the pasted text - this audit cannot grade the transport your short links will use.");
        }

        // Redirect sanity
        var rsc = eff("REDIRECT_STATUS_CODE"), rcl = eff("REDIRECT_CACHE_LIFETIME");
        if (rsc){
          var code = parseInt(rsc.value,10);
          if (isNaN(code) || !REDIRECT_CODES[code]){
            add("MEDIUM","REDIRECT_CODE_ODD","REDIRECT_STATUS_CODE",rsc.line,null,
              "REDIRECT_STATUS_CODE (line " + rsc.line + ") is not one of the standard redirect codes (301, 302, 303, 307, 308). Browsers and crawlers may treat the redirects unexpectedly.");
          } else if ((code===301||code===308) && rcl && !isNaN(parseInt(rcl.value,10)) && parseInt(rcl.value,10)>86400){
            add("LOW","REDIRECT_PERMANENT_LONG_CACHE","REDIRECT_STATUS_CODE",rsc.line,null,
              "A permanent redirect code (301/308) is paired with a cache lifetime over a day. Browsers will remember these redirects for a long time - a wrong target is hard to take back.");
          }
        }
        if (rcl){
          var life = parseInt(rcl.value,10);
          if (isNaN(life)){
            add("LOW","CACHE_LIFETIME_UNREADABLE","REDIRECT_CACHE_LIFETIME",rcl.line,null,
              "REDIRECT_CACHE_LIFETIME (line " + rcl.line + ") is not a plain number of seconds in the pasted text - check it before deploying.");
          } else if (life<0){
            add("MEDIUM","CACHE_LIFETIME_NEGATIVE","REDIRECT_CACHE_LIFETIME",rcl.line,null,
              "REDIRECT_CACHE_LIFETIME (line " + rcl.line + ") is negative, which is not a meaningful cache duration.");
          }
        }

        // Database basics
        var dbPass = eff("DB_PASSWORD");
        if (!dbPass){
          add("MEDIUM","DB_PASSWORD_ABSENT","DB_PASSWORD",null,null,
            "No DB_PASSWORD line in the pasted text. If the password is injected at deploy time, that is the right pattern - but this audit cannot confirm the database credential posture without seeing how it is supplied.");
        }
        var dbUser = eff("DB_USER");
        if (dbUser && dbUser.value.toLowerCase()==="root"){
          add("MEDIUM","DB_USER_ROOT","DB_USER",dbUser.line,null,
            "DB_USER (line " + dbUser.line + ") is the database root account. Give Shlink its own least-privilege database user so a shortener compromise is not a database compromise.");
        }
        if (!eff("DB_HOST")){
          add("LOW","DB_HOST_ABSENT","DB_HOST",null,null,
            "No DB_HOST line in the pasted text - the database target is set somewhere this audit cannot see.");
        }

        // Recognized-key count for gradability
        var recognized = 0;
        entries.forEach(function(e){ if (KNOWN[e.key] || SECRET_NAME.test(e.key)) recognized++; });

        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict;
        if (parsedCount===0 || recognized===0){
          verdict = "NOT ENOUGH TO GRADE";
        } else if (counts.CRITICAL>0 || counts.HIGH>=2 || (counts.HIGH>=1 && plaintextSecrets>0)){
          verdict = "DO NOT DEPLOY";
        } else if (counts.HIGH>0 || counts.MEDIUM>0 || counts.LOW>0){
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        var order = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4 };
        findings.sort(function(a,b){
          if (order[a.severity]!==order[b.severity]) return order[a.severity]-order[b.severity];
          return (a.line||0)-(b.line||0);
        });

        return {
          verdict:verdict, findings:findings, counts:counts, posture:posture,
          parsedLines:parsedCount, recognizedKeys:recognized,
          totalLines:lines.length, commentedCount:commented.length, plaintextSecrets:plaintextSecrets
        };
      }

      function verdictClass(v){
        if (v==="SAFE TO DEPLOY") return "safe";
        if (v==="DEPLOY WITH FIXES") return "fixes";
        if (v==="DO NOT DEPLOY") return "donot";
        return "notenough";
      }

      function render(result){
        var box = el("results");
        var html = "";
        html += '<div class="verdict ' + verdictClass(result.verdict) + '">' + esc(result.verdict) + "</div>";
        html += '<div class="counts">' +
          '<span class="chip">Parsed key lines: ' + result.parsedLines + "</span>" +
          '<span class="chip">Critical: ' + result.counts.CRITICAL + "</span>" +
          '<span class="chip">High: ' + result.counts.HIGH + "</span>" +
          '<span class="chip">Medium: ' + result.counts.MEDIUM + "</span>" +
          '<span class="chip">Low: ' + result.counts.LOW + "</span>" +
          '<span class="chip">Info: ' + result.counts.INFO + "</span>" +
          '<span class="chip">Plaintext secrets: ' + result.plaintextSecrets + "</span></div>";

        html += "<h3>Tracking posture summary</h3><table><tbody>" +
          "<tr><th scope=\"row\">Master switch</th><td>" + esc(result.posture.trackingMaster) + "</td></tr>" +
          "<tr><th scope=\"row\">IP tracking</th><td>" + esc(result.posture.ipTracking) + "</td></tr>" +
          "<tr><th scope=\"row\">Referrer tracking</th><td>" + esc(result.posture.referrerTracking) + "</td></tr>" +
          "<tr><th scope=\"row\">User-agent tracking</th><td>" + esc(result.posture.uaTracking) + "</td></tr>" +
          "<tr><th scope=\"row\">IP anonymization</th><td>" + esc(result.posture.anonymizeRemoteAddr) + "</td></tr>" +
          "<tr><th scope=\"row\">Orphan visits</th><td>" + esc(result.posture.orphanVisits) + "</td></tr>" +
          "</tbody></table>";

        if (result.findings.length){
          html += "<h3>Findings</h3><ul class=\"findings\">";
          result.findings.forEach(function(f){
            html += "<li><span class=\"sev " + f.severity + "\">" + f.severity + "</span>" +
              esc(f.message) +
              (f.key ? ' <span class="meta">[' + esc(f.code) + (f.line ? " · line " + f.line : "") + "]</span>" : ' <span class="meta">[' + esc(f.code) + "]</span>") +
              "</li>";
          });
          html += "</ul>";
        } else {
          html += "<p>No findings. Nothing in the pasted text tripped a check.</p>";
        }
        box.innerHTML = html;
      }

      function buildReport(result){
        var L = [];
        L.push("J-Dawgs Shlink Server Config Safety Auditor - text report");
        L.push("Verdict: " + result.verdict);
        L.push("Parsed key lines: " + result.parsedLines + " | Recognized Shlink keys: " + result.recognizedKeys +
               " | Commented key lines: " + result.commentedCount);
        L.push("Counts - Critical: " + result.counts.CRITICAL + ", High: " + result.counts.HIGH +
               ", Medium: " + result.counts.MEDIUM + ", Low: " + result.counts.LOW + ", Info: " + result.counts.INFO);
        L.push("Plaintext secrets found: " + result.plaintextSecrets + " (reported by key, line, and length only - values are never included)");
        L.push("");
        L.push("Tracking posture:");
        L.push("  Master switch: " + result.posture.trackingMaster);
        L.push("  IP tracking: " + result.posture.ipTracking);
        L.push("  Referrer tracking: " + result.posture.referrerTracking);
        L.push("  User-agent tracking: " + result.posture.uaTracking);
        L.push("  IP anonymization: " + result.posture.anonymizeRemoteAddr);
        L.push("  Orphan visits: " + result.posture.orphanVisits);
        L.push("");
        L.push("Findings:");
        if (!result.findings.length) L.push("  (none)");
        result.findings.forEach(function(f){
          var head = "  [" + f.severity + "] " + f.code +
            (f.key ? " | key: " + f.key : "") +
            (f.line ? " | line: " + f.line : "") +
            (f.secretLength!=null ? " | secret length: " + f.secretLength : "");
          L.push(head);
          L.push("      " + f.message);
        });
        L.push("");
        L.push("Scope: offline text audit in the browser. No server connection, no live URL checks, nothing saved or uploaded.");
        var text = L.join("\n");
        var json = JSON.stringify({
          tool: "J-Dawgs Shlink Server Config Safety Auditor",
          verdict: result.verdict,
          parsedLines: result.parsedLines,
          recognizedKeys: result.recognizedKeys,
          commentedKeyLines: result.commentedCount,
          plaintextSecrets: result.plaintextSecrets,
          counts: result.counts,
          trackingPosture: result.posture,
          findings: result.findings,
          scope: "Offline text audit. Findings carry key names, line numbers, and secret lengths only - never secret values or the pasted config."
        }, null, 2);
        return { text:text, json:json };
      }

      function runAudit(){
        var result = audit(el("cfg").value);
        render(result);
        lastReport = buildReport(result);
        el("report-text").textContent = lastReport.text;
        el("copy-status").textContent = "";
        el("input-status").textContent = "Audit complete: " + result.verdict + " (" + result.parsedLines + " key lines parsed).";
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BITS": (typeof EXAMPLE_BITS !== 'undefined' ? EXAMPLE_BITS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-shlink-server-config-safety-auditortm',
  name: 'J-Dawgs Shlink Server Config Safety Auditor',
  description: 'Grades a pasted Shlink URL-shortener server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — plaintext secrets, the tracking and anonymization privacy posture, and HTTPS enforcement, with secrets shown by key name, line, and le',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BITS": __core["EXAMPLE_BITS"] }
};
