'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs syslog-ng Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples ---------- */
var RISKY = [
'# Risky example — review before deploying',
'@version: 3.38',
'',
'options {',
'    chain-hostnames(yes);',
'    keep-hostname(yes);',
'};',
'',
'source s_remote {',
'    network(',
'        ip(0.0.0.0)',
'        transport("udp")',
'        port(514)',
'    );',
'    network(',
'        ip(0.0.0.0)',
'        transport("tcp")',
'        port(514)',
'    );',
'};',
'',
'source s_local {',
'    internal();',
'    unix-stream("/run/systemd/journal/syslog");',
'};',
'',
'destination d_forward {',
'    tcp("logs.example.net" port(514));',
'};',
'',
'destination d_archive {',
'    file("/var/log/remote/${HOST}.log" perm(0666));',
'};',
'',
'destination d_cloud {',
'    http(',
'        url("http://ingest.example.net/v1/logs")',
'        user("logshipper")',
'        password("example-password-do-not-use")',
'    );',
'};',
'',
'filter f_warn { level(warning..emerg); };',
'',
'log {',
'    source(s_remote);',
'    source(s_local);',
'    filter(f_warn);',
'    destination(d_forward);',
'    destination(d_archive);',
'    destination(d_cloud);',
'};'
].join('\n');

var HARDENED = [
'# Hardened example',
'@version: 4.1',
'',
'options {',
'    chain-hostnames(no);',
'    keep-hostname(no);',
'    use-dns(no);',
'};',
'',
'source s_tls_remote {',
'    network(',
'        ip(192.0.2.10)',
'        transport("tcp")',
'        port(6514)',
'        tls(',
'            cert-file("/etc/syslog-ng/tls/server.crt")',
'            key-file("/etc/syslog-ng/tls/server.key")',
'            ca-dir("/etc/syslog-ng/tls/ca")',
'            peer-verify(required-trusted)',
'        )',
'        max-connections(50)',
'    );',
'};',
'',
'source s_local {',
'    internal();',
'    unix-stream("/run/systemd/journal/syslog");',
'};',
'',
'destination d_relay {',
'    network(',
'        "relay.example.net"',
'        port(6514)',
'        transport("tls")',
'        tls(',
'            ca-dir("/etc/syslog-ng/tls/ca")',
'            peer-verify(required-trusted)',
'        )',
'        disk-buffer(dir("/var/lib/syslog-ng/buffer") reliable(yes))',
'    );',
'};',
'',
'destination d_archive {',
'    file(',
'        "/var/log/remote/${HOST}.log"',
'        perm(0640)',
'        dir_perm(0750)',
'        create_dirs(yes)',
'    );',
'};',
'',
'log {',
'    source(s_tls_remote);',
'    source(s_local);',
'    destination(d_relay);',
'    destination(d_archive);',
'};'
].join('\n');

/* ---------- Small helpers ---------- */
function $(id){ return document.getElementById(id); }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

/* Remove a trailing # comment, respecting double quotes and backslash escapes. */
function stripComment(line){
  var inQ=false;
  for (var i=0;i<line.length;i++){
    var c=line.charAt(i);
    if (c==='\\' && inQ){ i++; continue; }
    if (c==='"'){ inQ=!inQ; continue; }
    if (c==='#' && !inQ){ return line.slice(0,i); }
  }
  return line;
}

/* Quote-aware brace balance over cleaned lines.
   Returns { ok:true } or { ok:false, errors:[{line,message,fix}] }. */
function braceScan(lines){
  var stack=[], errors=[], i, j;
  for (i=0;i<lines.length;i++){
    var line=lines[i], inQ=false;
    for (j=0;j<line.length;j++){
      var c=line.charAt(j);
      if (c==='\\' && inQ){ j++; continue; }
      if (c==='"'){ inQ=!inQ; continue; }
      if (inQ) continue;
      if (c==='{'){ stack.push(i+1); }
      else if (c==='}'){
        if (stack.length===0){
          errors.push({ line:i+1, message:'Closing brace on line '+(i+1)+' has no matching opening brace.',
            fix:'Remove the stray closing brace, or add the missing block opening above it.' });
        } else { stack.pop(); }
      }
    }
  }
  for (i=0;i<stack.length;i++){
    errors.push({ line:stack[i], message:'Block opened on line '+stack[i]+' is never closed.',
      fix:'Add the closing "};" for the block that starts on line '+stack[i]+'.' });
  }
  return { ok: errors.length===0, errors: errors };
}

/* Find top-level named blocks (source/destination/filter/log/options/...).
   Assumes braces are balanced. */
var BLOCK_HEAD = /^\s*(source|destination|filter|log|options|template|parser|rewrite)\s+([A-Za-z0-9_.\-]+)?\s*\{/;
function findBlocks(lines){
  var blocks=[], i, j;
  for (i=0;i<lines.length;i++){
    var m = lines[i].match(BLOCK_HEAD);
    if (!m) continue;
    var depth=0, end=-1;
    for (j=i;j<lines.length;j++){
      var line=lines[j], inQ=false, k;
      for (k=0;k<line.length;k++){
        var c=line.charAt(k);
        if (c==='\\' && inQ){ k++; continue; }
        if (c==='"'){ inQ=!inQ; continue; }
        if (inQ) continue;
        if (c==='{') depth++;
        else if (c==='}'){ depth--; if (depth===0){ end=j; break; } }
      }
      if (end>=0) break;
    }
    if (end<0) end=lines.length-1;
    blocks.push({ type:m[1], name:(m[2]||''), start:i+1, end:end+1,
      text: lines.slice(i, end+1).join('\n') });
    i=end;
  }
  return blocks;
}

/* Extract driver calls (name + full parenthesised span + line) from a block. */
function driversIn(block, names){
  var res=[], re=new RegExp('\\b(' + names.join('|') + ')\\s*\\(', 'g'), m;
  while ((m = re.exec(block.text)) !== null){
    var openIdx = block.text.indexOf('(', m.index);
    var depth=0, inQ=false, end=-1, j;
    for (j=openIdx;j<block.text.length;j++){
      var c=block.text.charAt(j);
      if (c==='\\' && inQ){ j++; continue; }
      if (c==='"'){ inQ=!inQ; continue; }
      if (inQ) continue;
      if (c==='(') depth++;
      else if (c===')'){ depth--; if (depth===0){ end=j; break; } }
    }
    if (end<0) end=block.text.length-1;
    var lineNo = block.start + block.text.slice(0, m.index).split('\n').length - 1;
    res.push({ driver:m[1].toLowerCase(), line:lineNo, text:block.text.slice(openIdx, end+1) });
    re.lastIndex = end+1;
  }
  return res;
}

function optValue(span, name){
  var m = span.match(new RegExp('\\b' + name + '\\s*\\(\\s*"?([^"\\s\\)]+)"?\\s*\\)', 'i'));
  return m ? m[1] : null;
}
function hasPeerVerifyRequired(span){
  return /peer-verify\s*\(\s*"?required/i.test(span);
}
function bindClass(ip){
  if (ip===null || ip==='' || ip==='0.0.0.0' || ip==='::' || ip==='*') return 'all';
  if (ip==='127.0.0.1' || ip==='::1' || ip.toLowerCase()==='localhost') return 'loopback';
  return 'specific';
}

/* ---------- The audit ---------- */
var CRED_RE = /\b(password|passwd|api[-_]?key|client[-_]?secret|secret|auth[-_]?token)\s*\(\s*(?:"([^"]*)"|([^\s\)"]+))\s*\)/gi;

function audit(raw){
  var findings=[], parseIssues=[];
  var result = { verdict:'NOT ENOUGH TO GRADE', parseStatus:'NOT PARSED', parsed:false,
    lines:0, counts:{blocker:0,warning:0,info:0}, findings:findings, parseIssues:parseIssues, notes:[] };

  var text = (raw === null || raw === undefined) ? '' : String(raw);
  var rawLines = text.split('\n');
  result.lines = rawLines.length;
  var lines = rawLines.map(stripComment);

  if (text.replace(/\s/g,'') === ''){
    parseIssues.push({ line:1, message:'Nothing to audit — the input is empty.',
      fix:'Paste a syslog-ng.conf, or load one of the built-in worked examples.' });
    result.notes.push('Empty input: no verdict can be graded.');
    return finish(result);
  }

  var scan = braceScan(lines);
  if (!scan.ok){
    for (var e=0;e<scan.errors.length;e++) parseIssues.push(scan.errors[e]);
    result.notes.push('Unbalanced braces: the text does not parse as a syslog-ng config, so no safety grade was given.');
    return finish(result);
  }

  var blocks = findBlocks(lines);
  var hasVersion = /@version\s*:/.test(text);
  var hasDriverWord = /\b(unix-stream|unix-dgram|internal|network|syslog)\s*\(/.test(text);
  if (blocks.length===0 && !hasVersion && !hasDriverWord){
    var hint='No syslog-ng structure was found in lines 1–'+result.lines+': no @version header and no source, destination, filter, or log blocks.';
    if (/\$[A-Za-z]+/.test(text) || /rsyslog/i.test(text)) hint += ' This text looks like rsyslog configuration, which is a different product with different syntax — the store covers it in a separate auditor.';
    else if (/<(source|match|filter)\b/.test(text)) hint += ' This text looks like Fluentd configuration (angle-bracket sections), which is a different product — the store covers it in a separate auditor.';
    else if (/^\s*\[[^\]]+\]\s*$/m.test(text) && /=/.test(text)) hint += ' This text looks like an INI / key-value file (the Fluent Bit classic-mode shape), which is a different product — the store covers it in a separate auditor.';
    else if (/=/.test(text)) hint += ' This text looks like key-value configuration, not syslog-ng block syntax.';
    else if (/\{/.test(text) && /\}/.test(text)) hint += ' Braces are balanced, but no syslog-ng block headers were recognised.';
    parseIssues.push({ line:1, message:hint,
      fix:'Paste a syslog-ng.conf (starting with an @version header, then source / destination / filter / log blocks).' });
    result.notes.push('Input was not recognised as syslog-ng configuration: no verdict was fabricated.');
    return finish(result);
  }

  result.parsed = true;
  result.parseStatus = 'PARSED';

  function add(sev, line, block, check, message, fix, cred){
    var f = { severity:sev, line:line, block:block, check:check, message:message, fix:fix };
    if (cred) f.credential = cred;
    findings.push(f);
  }
  function blockLabel(b){ return b.name ? (b.type+' '+b.name) : b.type; }

  /* @version header */
  var verMatch = text.match(/@version\s*:\s*([0-9]+(?:\.[0-9]+)?)/);
  if (!hasVersion){
    add('WARNING', 1, '(global)', 'version-header',
      'No @version header found. syslog-ng starts with a warning and falls back to defaults for the oldest supported syntax, so option meanings can drift from what the file appears to say.',
      'Add an @version header as the first line, matching the syslog-ng version that will run this file (for example: @version: 4.1).');
  } else if (verMatch && parseFloat(verMatch[1]) < 3){
    add('INFO', 1, '(global)', 'version-header',
      'The @version header pins an old syslog-ng release ('+verMatch[1]+'). Some current TLS and driver options may not exist in that syntax level.',
      'Plan an upgrade and raise @version to the release actually deployed, then re-check option names against that release.');
  }

  /* @include lines — contents cannot be seen */
  lines.forEach(function(ln, idx){
    var im = ln.match(/@include\s+"([^"]+)"/);
    if (im){
      add('INFO', idx+1, '(global)', 'include-not-checked',
        '@include "'+im[1]+'" — NOT CHECKED. This audit only sees the pasted text; anything defined in the included file is invisible to it.',
        'Paste the included file as well, or audit it separately, before treating this verdict as covering it.');
    }
  });

  /* Defined names + log references */
  var defined = { source:{}, destination:{}, filter:{}, parser:{}, rewrite:{} };
  var srcBlocks=[], dstBlocks=[], logBlocks=[];
  blocks.forEach(function(b){
    if (defined[b.type] && b.name) defined[b.type][b.name]=b;
    if (b.type==='source') srcBlocks.push(b);
    if (b.type==='destination') dstBlocks.push(b);
    if (b.type==='log') logBlocks.push(b);
  });
  var used = { source:{}, destination:{}, filter:{}, parser:{}, rewrite:{} };
  logBlocks.forEach(function(b){
    var re=/\b(source|destination|filter|parser|rewrite)\s*\(\s*([A-Za-z0-9_.\-]+)\s*\)/g, m;
    while ((m = re.exec(b.text)) !== null){
      var kind=m[1], nm=m[2];
      used[kind][nm]=true;
      if (defined[kind] && !defined[kind][nm]){
        var refLine = b.start + b.text.slice(0, m.index).split('\n').length - 1;
        add('WARNING', refLine, blockLabel(b), 'undefined-reference',
          'This log path references '+kind+' "'+nm+'", which is not defined anywhere in the pasted text. syslog-ng would refuse to start with this file as-is.',
          'Define '+kind+' '+nm+' in the config, fix the spelling, or remove the reference.');
      }
    }
  });
  if (logBlocks.length===0){
    add('WARNING', Math.max(1,result.lines), '(global)', 'no-log-path',
      'No log { } block found. Sources and destinations may be defined, but nothing routes log data anywhere.',
      'Add a log { } block that wires each source to its destination (and filters where needed).');
  }
  srcBlocks.concat(dstBlocks).forEach(function(b){
    if (b.name && !used[b.type][b.name]){
      add('INFO', b.start, blockLabel(b), 'unused-block',
        'This '+b.type+' is defined but never referenced by any log { } block, so it does nothing.',
        'Wire it into a log path, or remove it so the file only describes what actually runs.');
    }
  });

  /* Hostname-trust flags (global scan) */
  var hasUdpListener=false;

  /* ---- Sources ---- */
  var LISTENERS=['network','syslog','tcp','udp','http'];
  srcBlocks.forEach(function(b){
    var label=blockLabel(b);
    driversIn(b, LISTENERS).forEach(function(d){
      var isUdp = (d.driver==='udp') || /transport\s*\(\s*"?udp/i.test(d.text);
      var transport = optValue(d.text,'transport');
      var ip = optValue(d.text,'ip') || optValue(d.text,'bind-address') || optValue(d.text,'localip');
      var bind = bindClass(ip);
      var hasTls = /\btls\s*\(/i.test(d.text) || (transport && transport.toLowerCase()==='tls');
      var hasCred = /\b(password|passwd)\s*\(/i.test(d.text) || /auth/i.test(d.text);
      if (isUdp) hasUdpListener=true;

      if (isUdp){
        add('WARNING', d.line, label, 'udp-source-spoofing',
          d.driver+'() source receives over UDP, which has no handshake and no sender authentication: any host that can reach the port can inject forged log lines with a spoofed source address and hostname.',
          'Prefer a TCP/TLS listener for remote logs. If UDP is unavoidable, restrict the port at the firewall to known sender addresses and treat hostnames in those messages as untrusted.');
        if (bind==='all' && !hasCred){
          add('BLOCKER', d.line, label, 'open-network-source',
            d.driver+'() source listens on all interfaces (ip '+(ip===null?'not pinned — syslog-ng binds every interface by default':ip)+') over UDP with no tls() and no access control. Anyone who can reach this port can write forged entries into your logs.',
            'Bind the listener to a specific interface with ip(), put the port behind a firewall allow-list of known senders, or move the feed to TCP with tls() and peer-verify(required-trusted).');
        }
        return;
      }
      if (!hasTls){
        if (bind==='all'){
          add('BLOCKER', d.line, label, 'open-network-source',
            d.driver+'() source listens on all interfaces (ip '+(ip===null?'not pinned — syslog-ng binds every interface by default':ip)+') with no tls() and no access control. Log data arrives in plaintext and anyone who can reach the port can inject messages.',
            'Bind a specific interface with ip(), require TLS with tls() and peer-verify(required-trusted), or restrict the listener to a trusted management network or firewall allow-list.');
        } else if (bind==='specific'){
          add('WARNING', d.line, label, 'plaintext-network-source',
            d.driver+'() source on '+ip+' has no tls(): messages arrive in plaintext and senders are not authenticated, so anything on the network path can read or inject log data.',
            'Add tls() with peer-verify(required-trusted) so only clients with trusted certificates can deliver logs.');
        } else {
          add('INFO', d.line, label, 'plaintext-network-source',
            d.driver+'() source is bound to loopback ('+ip+') with no tls(). Plaintext is contained on this host, but any tunnel or forwarder added later would expose it.',
            'No change needed for on-host use; add tls() before this listener is ever exposed beyond loopback.');
        }
      } else if (!hasPeerVerifyRequired(d.text)){
        add('WARNING', d.line, label, 'tls-without-peer-verify',
          d.driver+'() source uses tls() but does not require peer-verify(required-trusted): the stream is encrypted, yet any client — with any certificate, or none the server truly checks — can still deliver logs.',
          'Set peer-verify(required-trusted) inside tls() and issue client certificates to legitimate senders.');
      }
      if (!/max-connections\s*\(/i.test(d.text) && bind!=='loopback'){
        add('INFO', d.line, label, 'no-max-connections',
          d.driver+'() source sets no max-connections(): a flood of connections (accidental or hostile) can exhaust the daemon.',
          'Set max-connections() to a value sized for your known senders.');
      }
    });
  });

  /* keep-hostname / chain-hostnames trust */
  lines.forEach(function(ln, idx){
    var m = ln.match(/\b(keep-hostname|chain-hostnames|keep_hostname|chain_hostnames)\s*\(\s*(yes|on|true)\s*\)/i);
    if (m){
      if (hasUdpListener){
        add('WARNING', idx+1, '(global)', 'hostname-trust',
          m[1]+'(yes) trusts the hostname carried inside each message. Combined with the UDP source in this file, a forged message can plant a false hostname into your stored logs.',
          'Set '+m[1]+'(no) for untrusted feeds, or move those feeds to an authenticated TLS listener before trusting their hostnames.');
      } else {
        add('INFO', idx+1, '(global)', 'hostname-trust',
          m[1]+'(yes) trusts the hostname carried inside each message rather than the connection it arrived on.',
          'Keep this only for feeds from authenticated, trusted senders; otherwise set it to no.');
      }
    }
  });

  /* Stats / metrics exposure */
  lines.forEach(function(ln, idx){
    if (/\b(prometheus|stats[-_]?exporter|metrics[-_]?exporter|stats-exporter)\b/i.test(ln)){
      add('WARNING', idx+1, '(global)', 'stats-exposure',
        'A stats/metrics exporter is referenced here. Exposed syslog-ng statistics reveal hostnames, per-source volumes, and queue depths — a useful map for an attacker — and they pass a parse check clean.',
        'Bind the exporter to loopback or a management network, or put it behind authentication, and confirm it is not reachable from untrusted networks.');
    }
  });

  /* ---- Destinations ---- */
  var DEST_DRIVERS=['network','syslog','tcp','udp','http','file','program','kafka','mongodb','sql','smtp','amqp','redis','elasticsearch-http','riemann','pipe'];
  var NET_DEST=['network','syslog','tcp','udp','http','kafka','mongodb','sql','smtp','amqp','redis','elasticsearch-http','riemann'];
  function destDriverInfo(d){
    var transport = optValue(d.text,'transport');
    var isUdp = (d.driver==='udp') || (transport && transport.toLowerCase()==='udp');
    var hasTls = /\btls\s*\(/i.test(d.text) || /\bssl\s*\(/i.test(d.text) ||
                 (transport && transport.toLowerCase()==='tls') ||
                 (d.driver==='http' && /url\s*\(\s*"https:\/\//i.test(d.text));
    return { transport:transport, isUdp:isUdp, hasTls:hasTls, plaintext:!hasTls };
  }
  /* Pre-pass: drivers + plaintext per destination block, so the credential
     pass and the transport findings agree with each other. */
  dstBlocks.forEach(function(b){
    var drivers = driversIn(b, DEST_DRIVERS);
    b._drivers = drivers;
    var plain=false;
    drivers.forEach(function(d){
      d._info = destDriverInfo(d);
      if (d._info.plaintext && NET_DEST.indexOf(d.driver)>=0) plain=true;
    });
    b._plaintextAny = plain;
  });
  /* A block whose literal credential rides a plaintext transport gets one
     BLOCKER (from the credential pass), not a duplicate transport warning. */
  dstBlocks.forEach(function(b){
    if (!b._plaintextAny) return;
    var seg = rawLines.slice(b.start-1, b.end).join('\n');
    var re2 = new RegExp(CRED_RE.source, 'gi'), mm;
    while ((mm = re2.exec(seg)) !== null){
      var v = (mm[2] !== undefined) ? mm[2] : (mm[3] || '');
      if (v.length>0 && v.indexOf('$')<0){ b._hasPlainCred = true; break; }
    }
  });
  dstBlocks.forEach(function(b){
    var label=blockLabel(b);
    var drivers = b._drivers;
    drivers.forEach(function(d){
      var isNet = NET_DEST.indexOf(d.driver) >= 0;
      if (!isNet && d.driver!=='file' && d.driver!=='program') return;
      if (d.driver==='program'){
        add('WARNING', d.line, label, 'program-destination',
          'program() destination runs an external command for the log stream. If any template feeding it includes untrusted message content, that content reaches a shell command line.',
          'Prefer a file or network destination plus a separate reader; if program() is required, keep the command and its arguments fixed and free of message-derived data.');
        return;
      }
      if (d.driver==='file'){
        var perm = optValue(d.text,'perm');
        var dirPerm = optValue(d.text,'dir_perm') || optValue(d.text,'dir-perm');
        function otherDigit(v){ if (v===null) return null; var s=String(v).replace(/^0+/,''); if (s==='') s='0'; return parseInt(s.charAt(s.length-1),10); }
        var po = otherDigit(perm), dpo = otherDigit(dirPerm);
        if (perm!==null && po!==null && (po & 4 || po & 2)){
          var writable = (po & 2) ? true : false;
          if (dirPerm===null || (dpo!==null && (dpo & 5))){
            add('WARNING', d.line, label, 'world-accessible-logfile',
              'file() destination writes logs with perm('+perm+'), which makes them world-'+(writable?'writable':'readable')+', and there is '+(dirPerm===null?'no dir_perm() discipline':'also a permissive dir_perm('+dirPerm+')')+' to contain them. Log files routinely contain hostnames, user names, and internal addresses.',
              'Tighten perm() to 0640 or 0600, set dir_perm(0750) or stricter, and make sure the directory itself is not traversable by other users.');
          } else {
            add('INFO', d.line, label, 'world-accessible-logfile',
              'file() destination uses perm('+perm+') (world access at the file level), but dir_perm('+dirPerm+') restricts the containing directory, which limits exposure in practice.',
              'For defence in depth, tighten perm() to 0640 as well, so protection does not depend on the directory alone.');
          }
        }
        return;
      }
      /* network-class destinations */
      var isUdp = d._info.isUdp;
      var hasTls = d._info.hasTls;
      d._plaintext = d._info.plaintext;
      if (isUdp){
        add('WARNING', d.line, label, 'udp-destination',
          d.driver+'() destination sends logs over UDP: plaintext on the wire, trivially spoofable, and silently lossy — dropped datagrams leave no trace at either end.',
          'Forward over TCP with tls() instead; keep UDP only for feeds you can afford to lose.');
      } else if (!hasTls && !b._hasPlainCred){
        add('WARNING', d.line, label, 'plaintext-destination',
          d.driver+'() destination sends logs with no tls(): log data crosses the network in plaintext, readable and alterable by anything on the path.',
          'Enable TLS on this destination — transport("tls") with tls() and peer-verify(required-trusted) for network()/syslog(), or an https:// URL for http().');
      }
      if (hasTls && (d.driver==='network' || d.driver==='syslog') && !hasPeerVerifyRequired(d.text)){
        add('INFO', d.line, label, 'tls-peer-verify-destination',
          d.driver+'() destination uses TLS but does not pin peer-verify(required-trusted): the stream is encrypted, but the receiving server’s identity is not strictly verified.',
          'Set peer-verify(required-trusted) inside tls() with the CA that signs the receiving server’s certificate.');
      }
      if (!/disk-buffer\s*\(/i.test(b.text) && !isUdp && d.driver!=='http'){
        add('INFO', d.line, label, 'no-disk-buffer',
          'This network destination has no disk-buffer(): if the receiver or the network is down, queued messages are held only in memory and are lost on restart or overflow.',
          'Add a disk-buffer() (reliable(yes) for logs you cannot afford to lose) sized for your outage window.');
      }
    });
  });

  /* ---- Credentials (values are NEVER stored or rendered) ---- */
  var credMatch, credCount=0;
  CRED_RE.lastIndex = 0;
  while ((credMatch = CRED_RE.exec(text)) !== null){
    var directive = credMatch[1].toLowerCase();
    var val = (credMatch[2] !== undefined) ? credMatch[2] : (credMatch[3] || '');
    var vlen = val.length;
    var lineNo = text.slice(0, credMatch.index).split('\n').length;
    var isRef = val.indexOf('$') >= 0; /* macro / environment reference, not a literal */
    var owner = null;
    blocks.forEach(function(b){ if (lineNo>=b.start && lineNo<=b.end) owner=b; });
    var ownerLabel = owner ? blockLabel(owner) : '(global)';
    var credInfo = { directive:directive, line:lineNo, value_length:vlen };
    credCount++;
    if (isRef){
      add('INFO', lineNo, ownerLabel, 'credential-reference',
        'Directive '+directive+'() on line '+lineNo+' takes its value from a macro or environment reference rather than a literal typed into the file — the safer pattern.',
        'Keep the referenced secret out of the config file, in the environment or a secrets store with tight file permissions.',
        credInfo);
      continue;
    }
    if (vlen===0){
      add('WARNING', lineNo, ownerLabel, 'empty-credential',
        'Directive '+directive+'() on line '+lineNo+' is present but empty (value length 0). The destination will likely fail authentication at runtime even though the file parses.',
        'Supply the credential from a secrets file or environment reference, or remove the directive if the endpoint needs no authentication.',
        credInfo);
      continue;
    }
    var destPlain = !!(owner && owner.type==='destination' && owner._plaintextAny);
    if (owner && owner.type==='destination' && destPlain){
      add('BLOCKER', lineNo, ownerLabel, 'plaintext-credential',
        'Hardcoded credential in a plaintext destination: directive '+directive+'(), line '+lineNo+', value length '+vlen+' characters (value never shown). The destination it belongs to sends without TLS, so this credential crosses the network readable by anything on the path — and it also sits in plaintext in this file.',
        'Move the credential out of the config into a secrets file or environment reference, rotate it (treat the current one as exposed), and enable TLS on the destination.',
        credInfo);
    } else if (owner && owner.type==='destination'){
      add('WARNING', lineNo, ownerLabel, 'hardcoded-credential',
        'Hardcoded credential in destination: directive '+directive+'(), line '+lineNo+', value length '+vlen+' characters (value never shown). Anyone who can read this config file has the credential.',
        'Move the credential into a secrets file or environment reference, restrict the config file’s permissions, and rotate the credential if the file has been shared.',
        credInfo);
    } else {
      add('WARNING', lineNo, ownerLabel, 'hardcoded-credential',
        'Hardcoded credential: directive '+directive+'(), line '+lineNo+', value length '+vlen+' characters (value never shown). Credentials typed into config files tend to end up in backups, tickets, and version control.',
        'Move the credential into a secrets file or environment reference and rotate it if this file has been shared.',
        credInfo);
    }
  }
  result.credCount = credCount;

  return finish(result);
}

function finish(result){
  var f=result.findings;
  f.sort(function(a,b){ return (a.line-b.line) || (a.severity<b.severity?-1:1); });
  result.counts = { blocker:0, warning:0, info:0 };
  f.forEach(function(x){
    if (x.severity==='BLOCKER') result.counts.blocker++;
    else if (x.severity==='WARNING') result.counts.warning++;
    else result.counts.info++;
  });
  if (!result.parsed){ result.verdict='NOT ENOUGH TO GRADE'; }
  else if (result.counts.blocker>0){ result.verdict='DO NOT DEPLOY'; }
  else if (result.counts.warning>0){ result.verdict='DEPLOY WITH FIXES'; }
  else { result.verdict='SAFE TO DEPLOY'; }
  return result;
}

/* ---------- Rendering ---------- */
var lastResult=null, lastReport='', lastJson='';

function verdictClass(v){
  if (v==='SAFE TO DEPLOY') return 'verdict safe';
  if (v==='DEPLOY WITH FIXES') return 'verdict warn';
  if (v==='DO NOT DEPLOY') return 'verdict block';
  return 'verdict unknown';
}
function verdictSub(r){
  if (!r.parsed) return 'The pasted text did not parse as a syslog-ng config, so no safety grade was given. Fix the parse problems below and run it again.';
  if (r.verdict==='SAFE TO DEPLOY') return 'No BLOCKER or WARNING findings. Any INFO notes below are optional hardening.';
  if (r.verdict==='DEPLOY WITH FIXES') return 'No blockers, but warnings were found — work through the fix list before this config carries real traffic.';
  if (r.verdict==='DO NOT DEPLOY') return 'Blockers were found. Do not deploy this config as pasted — fix every BLOCKER first.';
  return '';
}

function buildReport(r){
  var out=[];
  out.push('J-Dawgs syslog-ng Config Safety Auditor — Audit Report');
  out.push('Verdict: '+r.verdict);
  out.push('Parse: '+r.parseStatus+' · Lines audited: '+r.lines);
  out.push('Counts: '+r.counts.blocker+' BLOCKER · '+r.counts.warning+' WARNING · '+r.counts.info+' INFO');
  out.push('');
  if (!r.parsed){
    out.push('Parse problems (no safety grade was given):');
    r.parseIssues.forEach(function(p,i){
      out.push((i+1)+'. [NOT PARSED] Line '+p.line+' — '+p.message);
      out.push('   Fix: '+p.fix);
    });
  } else if (r.findings.length===0){
    out.push('Findings: none. Nothing to fix.');
  } else {
    out.push('Findings — the fix list:');
    r.findings.forEach(function(fd,i){
      var credNote = fd.credential ? ' [credential: directive '+fd.credential.directive+'(), line '+fd.credential.line+', value length '+fd.credential.value_length+' — value never shown]' : '';
      out.push((i+1)+'. ['+fd.severity+'] Line '+fd.line+' · '+fd.block+' — '+fd.message+credNote);
      out.push('   Fix: '+fd.fix);
    });
  }
  out.push('');
  out.push('Notes: heuristic text audit of pasted text only. It starts no daemon and is not a replacement for a live check on the host. Credential values are never shown anywhere in this report — directive name, line, and value length only.');
  return out.join('\n');
}

function buildJson(r){
  var obj = {
    tool: 'J-Dawgs syslog-ng Config Safety Auditor',
    verdict: r.verdict,
    parse_status: r.parseStatus,
    parsed: r.parsed,
    lines_audited: r.lines,
    counts: r.counts,
    parse_issues: r.parseIssues.map(function(p){ return { line:p.line, message:p.message, fix:p.fix }; }),
    findings: r.findings.map(function(fd){
      var o = { severity:fd.severity, line:fd.line, block:fd.block, check:fd.check, message:fd.message, fix:fd.fix };
      if (fd.credential) o.credential = { directive:fd.credential.directive, line:fd.credential.line, value_length:fd.credential.value_length, value_shown:false };
      return o;
    }),
    notes: ['Heuristic text audit of pasted text only; starts no daemon; not a replacement for a live check on the host.',
            'Credential values are never included — directive name, line, and value length only.']
  };
  return JSON.stringify(obj, null, 2);
}

function render(r){
  lastResult=r;
  $('verdictBox').className = verdictClass(r.verdict);
  $('verdictLabel').textContent = r.verdict;
  $('verdictSub').textContent = verdictSub(r);
  $('counts').textContent = r.parsed
    ? (r.counts.blocker+' BLOCKER · '+r.counts.warning+' WARNING · '+r.counts.info+' INFO · '+r.lines+' lines audited')
    : ('NOT PARSED · '+r.parseIssues.length+' parse problem'+(r.parseIssues.length===1?'':'s')+' · '+r.lines+' lines read');
  var host=$('findings'), html='';
  if (!r.parsed){
    r.parseIssues.forEach(function(p){
      html += '<div class="finding"><div class="fhead"><span class="sev parse">Not parsed</span><span class="linechip">Line '+p.line+'</span></div><p>'+esc(p.message)+'</p><p class="fix"><strong>Fix:</strong> '+esc(p.fix)+'</p></div>';
    });
  } else if (r.findings.length===0){
    html = '<p class="small">No findings — nothing to fix. The checks that ran clean: listener binding and TLS, hostname trust, destination transport, credential handling, file permissions, stats exposure, and log-path wiring.</p>';
  } else {
    r.findings.forEach(function(fd){
      html += '<div class="finding"><div class="fhead"><span class="sev '+fd.severity.toLowerCase()+'">'+fd.severity+'</span><span class="linechip">Line '+fd.line+'</span><span class="blockname">'+esc(fd.block)+'</span></div><p>'+esc(fd.message)+'</p><p class="fix"><strong>Fix:</strong> '+esc(fd.fix)+'</p></div>';
    });
  }
  host.innerHTML = html;
  lastReport = buildReport(r);
  lastJson = buildJson(r);
  $('report').value = lastReport;
  $('jsonout').value = lastJson;
}

function run(){
  var r = audit($('cfg').value);
  render(r);
  $('status').textContent = 'Audited locally in your browser. Nothing was saved or sent.';
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-syslog-ng-config-safety-auditor',
  name: 'J-Dawgs syslog-ng Config Safety Auditor',
  description: 'Grades a pasted syslog-ng.conf anywhere, offline, into one deploy verdict: unauthenticated all-interface sources and plaintext credential destinations graded, with credential values never rendered. syslog-ng\'s own checks only answer will-it-parse, and only on an installed host.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
