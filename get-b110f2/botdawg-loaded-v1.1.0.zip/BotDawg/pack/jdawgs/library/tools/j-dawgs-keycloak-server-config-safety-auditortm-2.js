'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Keycloak Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"KC_DB=postgres",
"KC_DB_URL=jdbc:postgresql://db.internal:5432/keycloak?password=dbpass123",
"KC_DB_USERNAME=keycloak",
"KC_DB_PASSWORD=changeme",
"KC_HOSTNAME=http://auth.example.com",
"KC_HOSTNAME_STRICT=false",
"KC_HTTP_ENABLED=true",
"KC_LOG_LEVEL=debug",
"KC_BOOTSTRAP_ADMIN_PASSWORD=admin123",
"KC_METRICS_ENABLED=true"
].join("\n");

var HARDENED = [
"KC_DB=postgres",
"KC_DB_URL=jdbc:postgresql://db.internal:5432/keycloak",
"KC_DB_USERNAME=kc_service_account",
"KC_DB_PASSWORD=a-very-long-unique-database-password-9f3k",
"KC_HOSTNAME=https://auth.example.com",
"KC_HOSTNAME_STRICT=true",
"KC_HTTP_ENABLED=false",
"KC_PROXY=edge",
"KC_LOG_LEVEL=info",
"KC_BOOTSTRAP_ADMIN_PASSWORD=a-very-long-unique-bootstrap-admin-password-7q2m",
"KC_HEALTH_ENABLED=true"
].join("\n");

var WEAK = ["password","changeme","admin","keycloak","example","test","letmein","secret","12345"];
var DEFAULT_USERS = ["keycloak","admin","postgres","root"];

var SUFFIX_MAP = {
  "DB":"KC_DB","DB_URL":"KC_DB_URL","DB_USERNAME":"KC_DB_USERNAME","DB_PASSWORD":"KC_DB_PASSWORD",
  "HOSTNAME":"KC_HOSTNAME","HOSTNAME_STRICT":"KC_HOSTNAME_STRICT","HOSTNAME_STRICT_HTTPS":"KC_HOSTNAME_STRICT_HTTPS",
  "HTTP_ENABLED":"KC_HTTP_ENABLED","PROXY":"KC_PROXY","LOG_LEVEL":"KC_LOG_LEVEL",
  "BOOTSTRAP_ADMIN_PASSWORD":"KC_BOOTSTRAP_ADMIN_PASSWORD","BOOTSTRAP_ADMIN_USERNAME":"KC_BOOTSTRAP_ADMIN_USERNAME",
  "METRICS_ENABLED":"KC_METRICS_ENABLED","HEALTH_ENABLED":"KC_HEALTH_ENABLED",
  "HTTPS_ENABLED":"KC_HTTPS_ENABLED","CACHE":"KC_CACHE","FEATURES":"KC_FEATURES"
};
var RECOGNIZED = {};
["KC_DB","KC_DB_URL","KC_DB_USERNAME","KC_DB_PASSWORD","KC_HOSTNAME","KC_HOSTNAME_STRICT",
 "KC_HTTP_ENABLED","KC_PROXY","KC_LOG_LEVEL","KC_BOOTSTRAP_ADMIN_PASSWORD","KEYCLOAK_ADMIN_PASSWORD",
 "KEYCLOAK_ADMIN","KC_METRICS_ENABLED","KC_HEALTH_ENABLED","KC_HTTPS_ENABLED","KC_CACHE","KC_FEATURES",
 "KC_BOOTSTRAP_ADMIN_USERNAME"].forEach(function(k){ RECOGNIZED[k]=true; });

function normalizeKey(raw){
  var k = String(raw).trim().replace(/-/g,"_").toUpperCase();
  if(RECOGNIZED[k]) return k;
  if(k.indexOf("KC_")===0) return k;
  if(k.indexOf("KEYCLOAK_")===0) return k;
  if(SUFFIX_MAP[k]) return SUFFIX_MAP[k];
  return k;
}
function isRecognized(norm){ return !!RECOGNIZED[norm]; }

function parseConfig(text){
  var entries = []; // {key (normalized), rawKey, value, line}
  var trimmed = String(text||"").replace(/^\s+/,"");
  if(trimmed.charAt(0)==="{"){
    try{
      var obj = JSON.parse(text);
      var i = 0;
      for(var rawKey in obj){
        if(!Object.prototype.hasOwnProperty.call(obj, rawKey)) continue;
        i++;
        entries.push({key: normalizeKey(rawKey), rawKey: rawKey, value: String(obj[rawKey]), line: i});
      }
      return entries;
    }catch(e){ /* fall through to line parsing */ }
  }
  var lines = String(text||"").split(/\r?\n/);
  for(var n=0;n<lines.length;n++){
    var line = lines[n].trim();
    if(!line || line.charAt(0)==="#" || line.charAt(0)===";") continue;
    var eq = line.indexOf("=");
    if(eq<1) continue;
    var k = line.slice(0,eq).trim();
    var v = line.slice(eq+1).trim();
    if(v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
      v = v.slice(1,-1);
    }
    entries.push({key: normalizeKey(k), rawKey: k, value: v, line: n+1});
  }
  return entries;
}

function isWeakSecret(value){
  var lower = String(value).toLowerCase();
  // A long, unique passphrase that merely contains a common word (e.g. the
  // word "password" inside a 40-char passphrase) is not an example secret.
  // Weak grading applies to short values built from example words.
  if(lower.length >= 16) return false;
  for(var i=0;i<WEAK.length;i++){
    if(lower.indexOf(WEAK[i]) !== -1) return true;
  }
  return false;
}
function truthy(v){ return String(v).trim().toLowerCase()==="true"; }
function falsy(v){ return String(v).trim().toLowerCase()==="false"; }

var SEV_ORDER = {"Critical":0,"High":1,"Medium":2,"Low":3,"Info":4};

function audit(text){
  var entries = parseConfig(text);
  var map = {};
  var recognizedCount = 0;
  entries.forEach(function(e){
    map[e.key] = e;
    if(isRecognized(e.key)) recognizedCount++;
  });
  var findings = [];
  function add(line, key, severity, check, message, fix){
    findings.push({line: line, key: key, severity: severity, check: check, message: message, fix: fix});
  }
  function get(k){ return map[k] || null; }

  var enough = String(text||"").trim().length>0 && recognizedCount>=3;

  if(enough){
    var db = get("KC_DB");
    var dbUrl = get("KC_DB_URL");
    var dbUser = get("KC_DB_USERNAME");
    var dbPass = get("KC_DB_PASSWORD");
    var hostname = get("KC_HOSTNAME");
    var hostnameStrict = get("KC_HOSTNAME_STRICT");
    var httpEnabled = get("KC_HTTP_ENABLED");
    var proxy = get("KC_PROXY");
    var logLevel = get("KC_LOG_LEVEL");
    var bootstrap = get("KC_BOOTSTRAP_ADMIN_PASSWORD") || get("KEYCLOAK_ADMIN_PASSWORD");
    var metrics = get("KC_METRICS_ENABLED");
    var health = get("KC_HEALTH_ENABLED");

    // Check 10: missing KC_DB
    if(!db){
      add(0,"KC_DB","High","missing-database",
        "KC_DB is not set. Without it Keycloak falls back to the built-in dev-file / dev-mem database, which is not a production database and can lose data on restart.",
        "Set KC_DB to your production database (for example KC_DB=postgres) together with KC_DB_URL, KC_DB_USERNAME, and KC_DB_PASSWORD.");
    }

    // Check 3: KC_DB_PASSWORD
    if(db && !dbPass){
      add(0,"KC_DB_PASSWORD","Critical","db-password-missing",
        "KC_DB is set but KC_DB_PASSWORD is missing (key name: KC_DB_PASSWORD, length: 0). The server cannot authenticate to its production database, or is relying on an unsafe default somewhere else.",
        "Set KC_DB_PASSWORD to a long, unique secret (16+ characters) supplied through your secret manager or environment, never committed to the config file.");
    } else if(dbPass){
      var weakDb = isWeakSecret(dbPass.value);
      if(weakDb){
        add(dbPass.line,"KC_DB_PASSWORD","Critical","db-password-weak",
          "KC_DB_PASSWORD (line " + dbPass.line + ", length " + dbPass.value.length + ") matches a known example/weak password pattern. The value itself is never shown here. Example passwords are the first thing an attacker tries.",
          "Replace KC_DB_PASSWORD with a long, unique, randomly generated secret of 16+ characters and rotate the database credential.");
      } else if(dbPass.value.length < 16){
        add(dbPass.line,"KC_DB_PASSWORD","High","db-password-short",
          "KC_DB_PASSWORD (line " + dbPass.line + ", length " + dbPass.value.length + ") is shorter than 16 characters. The value itself is never shown here. Short database passwords are practical to brute-force if the database port or a backup is exposed.",
          "Use a unique database password of at least 16 characters (longer is better), generated randomly and stored in a secret manager.");
      }
    }

    // Check 4: bootstrap admin password
    if(bootstrap){
      var bKey = bootstrap.key;
      var weakB = isWeakSecret(bootstrap.value);
      if(weakB){
        add(bootstrap.line,bKey,"Critical","bootstrap-password-weak",
          bKey + " (line " + bootstrap.line + ", length " + bootstrap.value.length + ") matches a known example/weak password pattern. The value itself is never shown here. This password guards the master admin account that controls every realm.",
          "Replace the bootstrap admin password with a long, unique, randomly generated secret of 16+ characters, and remove it from the config once the admin account exists where your process allows.");
      } else if(bootstrap.value.length < 16){
        add(bootstrap.line,bKey,"High","bootstrap-password-short",
          bKey + " (line " + bootstrap.line + ", length " + bootstrap.value.length + ") is shorter than 16 characters. The value itself is never shown here. This is the master admin credential for the whole server.",
          "Use a unique bootstrap admin password of at least 16 characters, generated randomly and stored in a secret manager.");
      }
    }

    // Check 7: plaintext password in KC_DB_URL
    if(dbUrl){
      var url = dbUrl.value;
      var hasPwParam = /[?&]password=[^&\s]+/i.test(url);
      var hasUserPass = /:\/\/[^\/:@\s]+:[^\/@\s]+@/.test(url);
      if(hasPwParam || hasUserPass){
        add(dbUrl.line,"KC_DB_URL","Critical","db-url-plaintext-password",
          "KC_DB_URL (line " + dbUrl.line + ") embeds a plaintext password in the JDBC URL. The password portion is never shown here. URLs get copied into logs, tickets, screenshots, and shell history, so a secret inside one leaks far beyond the config file.",
          "Remove the password from KC_DB_URL and supply it only through KC_DB_PASSWORD (or your secret manager) so the URL itself is safe to log and share.");
      }
    }

    // Check 8: default DB username
    if(dbUser && DEFAULT_USERS.indexOf(dbUser.value.trim().toLowerCase()) !== -1){
      add(dbUser.line,"KC_DB_USERNAME","Info","db-username-default",
        "KC_DB_USERNAME (line " + dbUser.line + ") uses a well-known default/example database username. That is not automatically unsafe, but default usernames are the first half of every credential-guessing attempt.",
        "Confirm this is intentional. Prefer a dedicated, non-default service account (for example kc_service_account) with only the permissions Keycloak needs.");
    }

    // Check 2: hostname
    if(!hostname){
      add(0,"KC_HOSTNAME","High","hostname-missing",
        "KC_HOSTNAME is not set. Keycloak then derives issuer URLs and redirects from incoming request headers, which can produce wrong or spoofable URLs behind proxies and load balancers.",
        "Set KC_HOSTNAME to the public HTTPS address of the server, for example KC_HOSTNAME=https://auth.example.com.");
    } else if(/^http:\/\//i.test(hostname.value.trim())){
      add(hostname.line,"KC_HOSTNAME","High","hostname-not-https",
        "KC_HOSTNAME (line " + hostname.line + ") starts with http:// instead of https://. Tokens, login pages, and redirects would be tied to a plain-HTTP address that can be intercepted or downgraded.",
        "Serve Keycloak over HTTPS and set KC_HOSTNAME to the https:// address.");
    }

    // Check 5: hostname-strict
    if(hostnameStrict && falsy(hostnameStrict.value)){
      add(hostnameStrict.line,"KC_HOSTNAME_STRICT","High","hostname-strict-off",
        "KC_HOSTNAME_STRICT is false (line " + hostnameStrict.line + "). With strict hostname checking off, Keycloak accepts requests for other hostnames, weakening the binding between tokens, cookies, and your real domain.",
        "Set KC_HOSTNAME_STRICT=true and set KC_HOSTNAME to the one public hostname the server answers to.");
    }

    // Checks 1 + 11: HTTP enabled without proxy/TLS posture
    if(httpEnabled && truthy(httpEnabled.value)){
      var proxyVal = proxy ? proxy.value.trim().toLowerCase() : "";
      var proxyOk = (proxyVal==="edge" || proxyVal==="reencrypt");
      var httpsHost = hostname && /^https:\/\//i.test(hostname.value.trim());
      if(!proxyOk && !httpsHost){
        if(!proxy){
          add(httpEnabled.line,"KC_HTTP_ENABLED","Critical","http-without-proxy",
            "KC_HTTP_ENABLED is true (line " + httpEnabled.line + ") and KC_PROXY is not set, and there is no HTTPS hostname posture. Plain HTTP is switched on with nothing in front of it terminating TLS, so logins and tokens can cross the network unencrypted.",
            "Either turn KC_HTTP_ENABLED off and serve HTTPS from Keycloak itself, or put a TLS-terminating proxy in front and set KC_PROXY=edge (or reencrypt), with KC_HOSTNAME set to the https:// address.");
        } else {
          add(httpEnabled.line,"KC_HTTP_ENABLED","High","http-without-proxy",
            "KC_HTTP_ENABLED is true (line " + httpEnabled.line + ") but KC_PROXY is not set to edge or reencrypt, and KC_HOSTNAME does not provide an HTTPS posture. The proxy/TLS story for this server is incomplete.",
            "Set KC_PROXY=edge (or reencrypt) when a proxy terminates TLS, or disable KC_HTTP_ENABLED and serve HTTPS directly.");
        }
      }
    }

    // Check 6: debug logging
    if(logLevel && logLevel.value.toLowerCase().indexOf("debug") !== -1){
      var exact = logLevel.value.trim().toLowerCase()==="debug";
      add(logLevel.line,"KC_LOG_LEVEL", exact ? "High" : "Medium","debug-logging",
        "KC_LOG_LEVEL (line " + logLevel.line + ") enables debug logging. Debug logs are verbose and can capture request details, headers, and other sensitive material, and they grow fast enough to fill disks.",
        "Set KC_LOG_LEVEL=info for production (warn if you need it quieter) and raise it to debug only temporarily while diagnosing a problem.");
    }

    // Check 9: metrics / health posture
    var mgmtOn = [];
    if(metrics && truthy(metrics.value)) mgmtOn.push({e:metrics,k:"KC_METRICS_ENABLED"});
    if(health && truthy(health.value)) mgmtOn.push({e:health,k:"KC_HEALTH_ENABLED"});
    if(mgmtOn.length){
      mgmtOn.forEach(function(m){
        add(m.e.line, m.k, "Info","management-endpoints",
          m.k + " is true (line " + m.e.line + "). Metrics and health endpoints are useful for monitoring, but they describe your server's internals and should not be open to the public internet.",
          "Keep the management endpoints reachable only from your monitoring network or localhost, and block them at the proxy/firewall for everyone else.");
      });
    } else {
      add(0,"KC_METRICS_ENABLED / KC_HEALTH_ENABLED","Info","management-endpoints-absent",
        "Neither KC_METRICS_ENABLED nor KC_HEALTH_ENABLED is set. That is the safer default for exposure, but you will have no built-in health or metrics signal for monitoring and load-balancer checks.",
        "If you need health checks or metrics, enable them deliberately and restrict the management endpoints to your monitoring network.");
    }
  }

  findings.sort(function(a,b){
    var s = SEV_ORDER[a.severity]-SEV_ORDER[b.severity];
    if(s!==0) return s;
    return (a.line||0)-(b.line||0);
  });

  var counts = {"Critical":0,"High":0,"Medium":0,"Low":0,"Info":0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict;
  if(!enough) verdict = "NOT ENOUGH TO GRADE";
  else if(counts.Critical>0) verdict = "DO NOT DEPLOY";
  else if(counts.High>0 || counts.Medium>0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict: verdict, counts: counts, findings: findings, recognizedCount: recognizedCount};
}

function buildTextReport(r){
  var lines = [];
  lines.push("J-Dawgs Keycloak Server Config Safety Auditor - Report");
  lines.push("Verdict: " + r.verdict);
  lines.push("Counts: Critical " + r.counts.Critical + " | High " + r.counts.High + " | Medium " + r.counts.Medium + " | Low " + r.counts.Low + " | Info " + r.counts.Info);
  lines.push("Recognized Keycloak keys: " + r.recognizedCount);
  lines.push("Note: secret values are never included - key name, line, and length only.");
  lines.push("");
  if(!r.findings.length){
    lines.push("No findings.");
  } else {
    r.findings.forEach(function(f,i){
      lines.push((i+1) + ". [" + f.severity + "] " + f.key + " (line " + (f.line>0?f.line:"-") + ") - " + f.check);
      lines.push("   " + f.message);
      lines.push("   Fix: " + f.fix);
    });
  }
  return lines.join("\n");
}
function buildJsonReport(r){
  return JSON.stringify({
    tool: "J-Dawgs Keycloak Server Config Safety Auditor",
    verdict: r.verdict,
    counts: r.counts,
    recognizedKeys: r.recognizedCount,
    findings: r.findings.map(function(f){
      return {line: f.line, key: f.key, severity: f.severity, check: f.check, message: f.message, fix: f.fix};
    })
  }, null, 2);
}

/* ---------- UI ---------- */
var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-keycloak-server-config-safety-auditortm-2',
  name: 'J-Dawgs Keycloak Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
