'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Pinot Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky Pinot cluster config - training example only",
    "controller.host=0.0.0.0",
    "controller.port=9000",
    "controller.helix.cluster.name=PinotCluster",
    "controller.zk.str=localhost:2181",
    "controller.data.dir=/var/pinot/controller/data",
    "controller.tls.enabled=false",
    "broker.tls.enabled=false",
    "pinot.broker.netty.host=0.0.0.0",
    "pinot.broker.netty.port=8099",
    "pinot.server.netty.host=0.0.0.0",
    "pinot.server.netty.port=8098",
    "pinot.controller.access.control.enabled=false",
    "auth.enabled=false",
    "zookeeper.password=ExampleZKPassw0rd!",
    "pinot.controller.segment.fetcher.auth.token=example-token-9f27c1",
    "pinot.server.segment.fetcher.s3.access.key=AKIAEXAMPLE00000001",
    "pinot.server.segment.fetcher.s3.secret.key=examplePlaintextSecretValue0123456789"
  ].join("\n");

  var HARDENED = [
    "# Hardened Pinot cluster config - training example",
    "controller.host=10.0.1.20",
    "controller.port=9443",
    "controller.helix.cluster.name=PinotCluster",
    "controller.zk.str=zk1.internal.example:2181,zk2.internal.example:2181",
    "controller.data.dir=/var/pinot/controller/data",
    "controller.tls.enabled=true",
    "controller.admin.protocol.https.enabled=true",
    "broker.tls.enabled=true",
    "pinot.broker.netty.host=10.0.1.21",
    "pinot.broker.netty.port=8099",
    "pinot.server.netty.host=10.0.1.22",
    "pinot.server.netty.port=8098",
    "pinot.controller.access.control.enabled=true",
    "auth.enabled=true",
    "auth.type=basic",
    "zookeeper.password=${env:ZK_PASSWORD}",
    "pinot.server.segment.fetcher.s3.access.key=${env:S3_ACCESS_KEY}",
    "pinot.server.segment.fetcher.s3.secret.key=${env:S3_SECRET_KEY}",
    "broker.query.max.rows=10000",
    "broker.timeout.ms=10000",
    "pinot.server.query.executor.timeout.ms=15000",
    "controller.query.timeout.ms=10000"
  ].join("\n");

  var cfgEl = document.getElementById("cfg");
  var verdictEl = document.getElementById("verdict");
  var verdictText = document.getElementById("verdict-text");
  var verdictDetail = document.getElementById("verdict-detail");
  var countsEl = document.getElementById("counts");
  var findingsEl = document.getElementById("findings");
  var reportEl = document.getElementById("report");
  var copyStatus = document.getElementById("copy-status");
  var lastResult = null;

  function isFalsey(v){
    var s = String(v).trim().toLowerCase();
    return s === "false" || s === "disabled" || s === "disable" || s === "no" || s === "off" || s === "none";
  }
  function isTruthy(v){
    var s = String(v).trim().toLowerCase();
    return s === "true" || s === "enabled" || s === "enable" || s === "yes" || s === "on";
  }
  function isEnvRef(v){
    return /\$\{\s*env\s*:/i.test(v) || /^\$\{[^}]+\}$/.test(String(v).trim());
  }

  // ---------- Parsing ----------
  function flattenJson(obj, prefix, out){
    Object.keys(obj).forEach(function(k){
      var key = prefix ? prefix + "." + k : k;
      var val = obj[k];
      if (val !== null && typeof val === "object" && !Array.isArray(val)){
        flattenJson(val, key, out);
      } else if (Array.isArray(val)){
        out.push({ key: key, value: val.join(",") });
      } else {
        out.push({ key: key, value: val === null ? "" : String(val) });
      }
    });
  }
  function findJsonLine(lines, leafKey, startAt){
    var needle = '"' + leafKey + '"';
    for (var i = startAt; i < lines.length; i++){
      if (lines[i].indexOf(needle) !== -1) return i;
    }
    for (var j = 0; j < lines.length; j++){
      if (lines[j].indexOf(needle) !== -1) return j;
    }
    return 0;
  }

  function parseConfig(text){
    var lines = text.split(/\r?\n/);
    var entries = [];      // {key, value, line}
    var notParsed = [];    // line numbers
    var commentLines = 0;
    var trimmed = text.trim();
    var isJson = trimmed.charAt(0) === "{";

    if (isJson){
      var parsed = null, parseOk = true;
      try { parsed = JSON.parse(trimmed); } catch(e){ parseOk = false; }
      if (parseOk && parsed && typeof parsed === "object"){
        var flat = [];
        flattenJson(parsed, "", flat);
        var cursor = 0;
        flat.forEach(function(e){
          var parts = e.key.split(".");
          var leaf = parts[parts.length - 1];
          var li = findJsonLine(lines, leaf, cursor);
          cursor = li;
          entries.push({ key: e.key, value: e.value, line: li + 1 });
        });
        // Count comment-style lines in JSON-ish text (non-standard, ignored)
        lines.forEach(function(raw){
          var t = raw.trim();
          if (t.indexOf("//") === 0 || t.indexOf("#") === 0) commentLines++;
        });
        return { entries: entries, notParsed: notParsed, lines: lines, format: "JSON", commentLines: commentLines };
      }
      // JSON that does not parse: grade line by line, mark the rest NOT PARSED.
      var inComment = false;
      lines.forEach(function(raw, idx){
        var t = raw.trim();
        if (!t) return;
        if (t.indexOf("//") === 0 || t.indexOf("#") === 0){ commentLines++; return; }
        if (t === "{" || t === "}" || t === "}," || t === "]" || t === "],") return;
        var m = t.match(/^"([^"]+)"\s*:\s*("([^"]*)"|true|false|null|-?[0-9][0-9.]*(?:[eE][+-]?[0-9]+)?)\s*,?$/);
        if (m){
          entries.push({ key: m[1], value: m[3] !== undefined ? m[3] : m[2], line: idx + 1 });
        } else if (/^"[^"]+"\s*:\s*(\{|\[)$/.test(t)){
          return; // structural parent key
        } else {
          notParsed.push(idx + 1);
        }
      });
      return { entries: entries, notParsed: notParsed, lines: lines, format: "JSON (unparseable as a whole)", commentLines: commentLines };
    }

    // Properties format
    var inBlock = false;
    lines.forEach(function(raw, idx){
      var t = raw.trim();
      if (inBlock){
        if (t.indexOf("*/") !== -1) inBlock = false;
        commentLines++;
        return;
      }
      if (!t) return;
      if (t.charAt(0) === "#" || t.charAt(0) === "!" || t.indexOf("//") === 0){ commentLines++; return; }
      if (t.indexOf("/*") === 0){ inBlock = t.indexOf("*/") === -1; commentLines++; return; }
      var m = t.match(/^([^=:\s][^=:]*?)\s*[=:]\s*(.*)$/);
      if (m){
        entries.push({ key: m[1].trim(), value: m[2].trim(), line: idx + 1 });
      } else {
        notParsed.push(idx + 1);
      }
    });
    return { entries: entries, notParsed: notParsed, lines: lines, format: "properties", commentLines: commentLines };
  }

  // ---------- Audit ----------
  var PINOT_HINT = /(pinot|controller\.|broker\.|helix|segment|tenant|zookeeper|zk\.str|cluster\.name)/i;
  var SECRET_KEY = /(password|passwd|pwd|secret|access[-_.]?key|private[-_.]?key|api[-_.]?key|auth[-_.]?token|token|credential)/i;
  var ENABLE_KEY = /(enabled|enable)$/i;

  function audit(text){
    var findings = [];
    function add(sev, line, key, title, detail, fix){
      findings.push({ severity: sev, line: (line === null || line === undefined) ? null : line, key: key || null, title: title, detail: detail, fix: fix || "" });
    }

    if (!text || !text.trim()){
      return finish("NOT ENOUGH TO GRADE", findings, { entries: 0, format: "none", notParsed: 0 },
        "Nothing was pasted. Paste a Pinot controller, broker, or server configuration to grade it.");
    }

    var parsed = parseConfig(text);
    var entries = parsed.entries;

    parsed.notParsed.forEach(function(ln){
      add("WARNING", ln, null, "Line NOT PARSED",
        "Line " + ln + " is not a comment, not blank, and not a readable key = value setting, so it was not graded. Its contents are not shown here.",
        "Fix the line into a valid setting, comment it out, or remove it — then re-run the audit.");
    });

    var pinotHits = entries.filter(function(e){ return PINOT_HINT.test(e.key); }).length;
    if (entries.length === 0 || pinotHits < 2){
      add("INFO", null, null, "Not recognizably a Pinot configuration",
        "Only " + pinotHits + " recognizable Pinot setting(s) were found in " + entries.length + " parsed setting(s). A gradeable file normally carries several controller.*, broker.*, pinot.*, or helix keys.",
        "Paste a full Pinot controller, broker, or server config file (properties or JSON).");
      return finish("NOT ENOUGH TO GRADE", findings,
        { entries: entries.length, format: parsed.format, notParsed: parsed.notParsed.length },
        "This text does not look like an Apache Pinot configuration, so no deploy grade was given.");
    }

    var tlsSeen = false, tlsEnabledSeen = false;
    var authSeen = false, authEnabledSeen = false;
    var limitSeen = false;

    entries.forEach(function(e){
      var key = e.key, lk = key.toLowerCase(), val = e.value, lv = String(val).trim().toLowerCase();

      // --- Wildcard binds ---
      if (/(host|hostname|listen|bind|address)/i.test(key)){
        var hostVal = lv.split(":")[0];
        if (hostVal === "0.0.0.0" || hostVal === "*" || hostVal === "::" || hostVal === "[::]" || hostVal === ""){
          if (hostVal !== "" || lv === ""){
            add("BLOCKER", e.line, key, "Wildcard bind — listener on all interfaces",
              "Line " + e.line + ": " + key + " binds to every network interface. A Pinot listener on all interfaces is reachable from any network that can route to this host.",
              "Bind to one specific internal interface IP or hostname that only your cluster and operators can reach.");
          }
        }
      }

      // --- TLS ---
      if (/(tls|ssl|https)/i.test(key)){
        tlsSeen = true;
        if (ENABLE_KEY.test(key) || /(tls|ssl)/i.test(key)){
          if (isFalsey(val)){
            var tlsSev = /(controller|broker)/i.test(key) ? "BLOCKER" : "HIGH";
            add(tlsSev, e.line, key, "TLS disabled",
              "Line " + e.line + ": " + key + " turns TLS off. Controller and broker traffic — including admin calls — travels unencrypted.",
              "Enable TLS with a real certificate for controller and broker listeners before deploying.");
          } else if (isTruthy(val)){
            tlsEnabledSeen = true;
          }
        }
        if (isTruthy(val)) tlsEnabledSeen = true;
      }
      if (/protocol/i.test(key) && lv === "http"){
        add("WARNING", e.line, key, "Plain HTTP protocol configured",
          "Line " + e.line + ": " + key + " selects plain HTTP.",
          "Prefer HTTPS with TLS enabled for controller and broker protocols.");
      }

      // --- Auth / access control ---
      if (/(auth|access[-_.]?control|acl|authentication|authorization)/i.test(key)){
        if (!SECRET_KEY.test(key) || /enabled|type|factory|class/i.test(key)){
          authSeen = true;
        }
        if (isFalsey(val) && (ENABLE_KEY.test(key) || /auth/i.test(key))){
          add("BLOCKER", e.line, key, "Authentication / access control disabled",
            "Line " + e.line + ": " + key + " disables authentication or access control. Anyone who can reach the port can query and administer the cluster.",
            "Enable access control and authentication, and issue credentials per operator and per application.");
        }
        if (/type/i.test(key) && (lv === "none" || lv === "noop" || lv === "allowall")){
          add("BLOCKER", e.line, key, "Authentication type allows everyone",
            "Line " + e.line + ": " + key + " is set to a no-check mode.",
            "Use a real authentication type (for example basic auth with strong credentials, or your identity provider).");
        }
        if (isTruthy(val)) authEnabledSeen = true;
      }

      // --- Secrets (value NEVER recorded) ---
      if (SECRET_KEY.test(key) && !ENABLE_KEY.test(key) && !/(file|path|factory|class|provider|type)/i.test(key)){
        var v = String(val).trim();
        if (v.length > 0 && !/^(true|false)$/i.test(v)){
          if (isEnvRef(v)){
            add("INFO", e.line, key, "Secret supplied by reference — safe pattern",
              "Line " + e.line + ": " + key + " uses an environment / external reference instead of a literal value (reference length " + v.length + " characters). The reference itself is not printed in this report.",
              "No change needed — keep secrets in the environment or a secret store, never in the config file.");
          } else {
            add("BLOCKER", e.line, key, "Plaintext secret in config file",
              "Line " + e.line + ": " + key + " holds a literal secret value of " + v.length + " characters. The value is deliberately not shown here or in any export. Anyone with this file — or its git history — has the credential.",
              "Move this value to an environment reference such as an env-variable placeholder or your secret store, and rotate the exposed credential.");
          }
        }
      }

      // --- Query / timeout limits ---
      if (/(query|broker|executor|scan)/i.test(key) && /(max|limit|timeout)/i.test(key)){
        limitSeen = true;
        if (lv === "0" || lv === "-1" || lv === "unlimited" || lv === "none"){
          add("WARNING", e.line, key, "Query limit present but effectively unlimited",
            "Line " + e.line + ": " + key + " is set to a value that disables the limit.",
            "Set a real row limit and a real timeout sized to your workload.");
        }
      }
      if (/timeout/i.test(key)) limitSeen = true;
    });

    if (!tlsSeen){
      add("HIGH", null, null, "No TLS configured anywhere",
        "No TLS, SSL, or HTTPS setting appears in the active (non-commented) lines. By default, controller and broker traffic is unencrypted.",
        "Configure TLS for the controller and broker listeners and enable it explicitly.");
    } else if (tlsEnabledSeen){
      add("INFO", null, null, "TLS enabled setting found",
        "At least one TLS / HTTPS setting is switched on in the active lines.",
        "No change needed for this check.");
    }
    if (!authSeen){
      add("HIGH", null, null, "No authentication / access control configured",
        "No auth or access-control setting appears in the active (non-commented) lines. An unauthenticated Pinot endpoint trusts every caller that can reach it.",
        "Add access control and authentication settings for controller, broker, and server, and enable them explicitly.");
    } else if (authEnabledSeen){
      add("INFO", null, null, "Authentication / access control enabled setting found",
        "At least one auth or access-control setting is switched on in the active lines.",
        "No change needed for this check.");
    }
    if (!limitSeen){
      add("WARNING", null, null, "No query or timeout limits set",
        "No query row limit and no query, broker, or executor timeout appears in the active lines. One runaway query can consume broker and server resources until it finishes on its own.",
        "Set a broker query row limit (for example a max-rows setting) and query / broker timeouts sized to your workload.");
    } else {
      add("INFO", null, null, "Query / timeout limit setting found",
        "At least one query limit or timeout setting is present in the active lines.",
        "No change needed for this check — confirm the values fit your workload.");
    }

    var counts = countSev(findings);
    var verdict, detail;
    if (counts.BLOCKER > 0){
      verdict = "DO NOT DEPLOY";
      detail = counts.BLOCKER + " blocker finding(s) must be fixed before this configuration goes anywhere near production.";
    } else if (counts.HIGH > 0 || counts.WARNING > 0){
      verdict = "DEPLOY WITH FIXES";
      detail = "No blockers, but " + (counts.HIGH + counts.WARNING) + " high / warning finding(s) should be fixed first.";
    } else {
      verdict = "SAFE TO DEPLOY";
      detail = "No blocker, high, or warning patterns were found in the active lines of this configuration.";
    }
    return finish(verdict, findings, { entries: entries.length, format: parsed.format, notParsed: parsed.notParsed.length }, detail);
  }

  function countSev(findings){
    var c = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
    findings.forEach(function(f){ c[f.severity]++; });
    return c;
  }
  var SEV_ORDER = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
  function finish(verdict, findings, meta, detail){
    findings.sort(function(a, b){
      var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
      if (d !== 0) return d;
      var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
      return la - lb;
    });
    return { verdict: verdict, detail: detail, findings: findings, counts: countSev(findings), meta: meta };
  }

  // ---------- Rendering ----------
  function esc(s){
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function render(result){
    lastResult = result;
    var cls = result.verdict === "SAFE TO DEPLOY" ? "safe"
      : result.verdict === "DEPLOY WITH FIXES" ? "fixes"
      : result.verdict === "DO NOT DEPLOY" ? "no" : "unknown";
    verdictEl.className = "verdict show " + cls;
    verdictText.textContent = result.verdict;
    verdictDetail.textContent = result.detail;

    countsEl.className = "counts show";
    countsEl.innerHTML =
      '<span class="count">Settings parsed: <b>' + result.meta.entries + '</b></span>' +
      '<span class="count">Format: <b>' + esc(result.meta.format) + '</b></span>' +
      '<span class="count">BLOCKER: <b>' + result.counts.BLOCKER + '</b></span>' +
      '<span class="count">HIGH: <b>' + result.counts.HIGH + '</b></span>' +
      '<span class="count">WARNING: <b>' + result.counts.WARNING + '</b></span>' +
      '<span class="count">INFO: <b>' + result.counts.INFO + '</b></span>';

    if (!result.findings.length){
      findingsEl.innerHTML = '<div class="empty-note">No findings.</div>';
    } else {
      findingsEl.innerHTML = result.findings.map(function(f){
        var meta = [];
        meta.push("Line: " + (f.line === null ? "— (whole file)" : f.line));
        if (f.key) meta.push("Key: " + f.key);
        return '<article class="finding">' +
          '<div class="fhead"><span class="sev ' + f.severity + '">' + f.severity + '</span>' +
          '<span class="ftitle">' + esc(f.title) + '</span>' +
          '<span class="fmeta">' + esc(meta.join(" · ")) + '</span></div>' +
          '<p>' + esc(f.detail) + '</p>' +
          (f.fix ? '<p class="fix"><b>Fix:</b> ' + esc(f.fix) + '</p>' : '') +
          '</article>';
      }).join("");
    }
    reportEl.value = buildReport(result);
  }

  function buildReport(r){
    var out = [];
    out.push("J-Dawgs Pinot Server Config Safety Auditor - Audit Report");
    out.push("==========================================================");
    out.push("Verdict: " + r.verdict);
    out.push(r.detail);
    out.push("Format detected: " + r.meta.format + " | Settings parsed: " + r.meta.entries + " | Lines not parsed: " + r.meta.notParsed);
    out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
    out.push("Note: secret values are never included - findings name the key, line, and value length only.");
    out.push("");
    out.push("Findings");
    out.push("--------");
    if (!r.findings.length) out.push("(none)");
    r.findings.forEach(function(f, i){
      out.push((i + 1) + ". [" + f.severity + "] " + f.title);
      out.push("   Line: " + (f.line === null ? "- (whole file)" : f.line) + (f.key ? " | Key: " + f.key : ""));
      out.push("   " + f.detail);
      if (f.fix) out.push("   Fix: " + f.fix);
    });
    out.push("");
    out.push("Limits: heuristic text audit only. This tool does not connect to a cluster and does not verify a running deployment.");
    out.push("Generated locally in your browser. Nothing was uploaded or saved.");
    return out.join("\n");
  }
  function buildJson(r){
    return JSON.stringify({
      tool: "J-Dawgs Pinot Server Config Safety Auditor",
      verdict: r.verdict,
      verdictDetail: r.detail,
      formatDetected: r.meta.format,
      settingsParsed: r.meta.entries,
      linesNotParsed: r.meta.notParsed,
      counts: r.counts,
      findings: r.findings.map(function(f){
        return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
      }),
      limits: "Heuristic text audit only. Does not connect to a cluster. Secret values are never included; secrets are reported by key name, line number, and value length only."
    }, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pinot-server-config-safety-auditor',
  name: 'J-Dawgs Pinot Server Config Safety Auditor',
  description: 'Grades a pasted Apache Pinot cluster configuration (controller, broker, and server) fully offline into one deploy verdict — authentication posture, listener exposure, and plaintext secrets reported by key name, line, and length only, never by value. Pinot only exercises a config by starting the clus',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
