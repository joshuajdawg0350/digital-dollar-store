'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Invoice Ninja Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Example configs ---------------- */

      var PLANTED_SECRET = "PLANTED-SECRET-9f3Kx-7741";

      var RISKY_LINES = [
        "# Risky example - a self-hosted Invoice Ninja config with problems planted on purpose.",
        "APP_NAME=Invoice Ninja",
        "APP_ENV=local",
        "APP_DEBUG=true",
        "APP_KEY=base64:EXAMPLE-KEY-replace-me-000000000000",
        "APP_URL=http://billing.example.net",
        "APP_TIMEZONE=UTC",
        "DB_CONNECTION=mysql",
        "DB_HOST=127.0.0.1",
        "DB_PORT=3306",
        "DB_DATABASE=ninja",
        "DB_USERNAME=ninja",
        "DB_PASSWORD=" + PLANTED_SECRET,
        "DB_PASSWORD1=short",
        "MAIL_MAILER=smtp",
        "MAIL_HOST=mail.example.net",
        "MAIL_PASSWORD=mailpw123",
        "REQUIRE_HTTPS=false",
        "SESSION_ENCRYPT=false",
        "ALLOW_REGISTRATION=true",
        "PHANTOMJS_CLOUD_KEY=abc123",
        "API_SECRET=letmein",
        "REDIS_PASSWORD=redis1",
        "this line is not a config line at all"
      ];
      var RISKY_TEXT = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hardened example - the same kind of config with the problems fixed.",
        "APP_NAME=Invoice Ninja",
        "APP_ENV=production",
        "APP_DEBUG=false",
        "APP_KEY=base64:kX9vQ2mZp7LwR4tBnHsY6dFcA1eGjU3iOlP8sNqWr5zM=",
        "APP_URL=https://billing.example.net",
        "APP_TIMEZONE=UTC",
        "DB_CONNECTION=mysql",
        "DB_HOST=127.0.0.1",
        "DB_PORT=3306",
        "DB_DATABASE=ninja",
        "DB_USERNAME=ninja",
        "DB_PASSWORD=Tr7!qZm9#xLp2$wKd8&vBn4",
        "DB_PASSWORD1=Hg4@fDs6!pQw9#zXc3&mNb7",
        "MAIL_MAILER=smtp",
        "MAIL_HOST=mail.example.net",
        "MAIL_PASSWORD=Qw8!zXc3#mNb6@pLk9&dFs2",
        "REQUIRE_HTTPS=true",
        "SESSION_ENCRYPT=true",
        "ALLOW_REGISTRATION=false",
        "PHANTOMJS_CLOUD_KEY=pk-9f8e7d6c5b4a39281706f5e4d3c2b1a0",
        "API_SECRET=aP1s3cr3t-5f6g7h8j9k0l2m4n6p8q",
        "REDIS_PASSWORD=Rd8!sPw3#kLm6@xQz9&vTy5"
      ];
      var HARDENED_TEXT = HARDENED_LINES.join("\n");

      /* ---------------- Parsing ---------------- */

      var KEY_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

      var RECOGNIZED_EXACT = {
        APP_NAME: 1, APP_ENV: 1, APP_KEY: 1, APP_DEBUG: 1, APP_URL: 1,
        APP_TIMEZONE: 1, APP_LOCALE: 1, REQUIRE_HTTPS: 1, SESSION_ENCRYPT: 1,
        API_SECRET: 1, NINJA_ENV: 1, ALLOW_REGISTRATION: 1
      };
      function isRecognized(key) {
        if (RECOGNIZED_EXACT[key]) return true;
        return /^(DB_|MAIL_|PHANTOMJS_|REDIS_|QUEUE_|CACHE_|SESSION_)/.test(key);
      }

      function unquote(v) {
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        return v;
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = {};   // key -> { value, line }  (last occurrence wins)
        var order = [];
        var notParsed = []; // { line }
        var parseable = 0;
        var recognized = 0;
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var trimmed = raw.replace(/^\s+|\s+$/g, "");
          if (trimmed === "") continue;
          if (trimmed.charAt(0) === "#" || trimmed.charAt(0) === ";") continue;
          var body = trimmed;
          if (body.indexOf("export ") === 0) body = body.slice(7);
          var eq = body.indexOf("=");
          if (eq <= 0) { notParsed.push({ line: lineNo }); continue; }
          var key = body.slice(0, eq).replace(/\s+$/g, "");
          if (!KEY_RE.test(key)) { notParsed.push({ line: lineNo }); continue; }
          var value = body.slice(eq + 1).replace(/^\s+|\s+$/g, "");
          // Strip an unquoted trailing " # comment".
          if (value.charAt(0) !== '"' && value.charAt(0) !== "'") {
            var hashIdx = value.indexOf(" #");
            if (hashIdx > -1) value = value.slice(0, hashIdx).replace(/\s+$/g, "");
          }
          value = unquote(value);
          if (!entries[key]) order.push(key);
          entries[key] = { value: value, line: lineNo };
          parseable++;
          if (isRecognized(key)) recognized++;
        }
        return { entries: entries, order: order, notParsed: notParsed, parseable: parseable, recognized: recognized, lineCount: lines.length };
      }

      /* ---------------- Check helpers ---------------- */

      var EXAMPLE_SUBSTRINGS = [
        "example", "changeme", "change-me", "change_me", "placeholder",
        "your-", "your_", "xxxx", "todo", "insert", "replace-me", "replace_me",
        "sample", "dummy", "fake-key", "test-key"
      ];
      var EXAMPLE_EXACT = [
        "password", "secret", "123456", "12345678", "123456789", "letmein",
        "admin", "root", "ninja", "invoiceninja", "qwerty", "changethis",
        "base64:", "base64:xxxx", "null", "none"
      ];
      function isExampleValue(v) {
        var s = v.toLowerCase();
        if (EXAMPLE_EXACT.indexOf(s) > -1) return true;
        for (var i = 0; i < EXAMPLE_SUBSTRINGS.length; i++) {
          if (s.indexOf(EXAMPLE_SUBSTRINGS[i]) > -1) return true;
        }
        return false;
      }

      function isTruthy(v) {
        var s = String(v).toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function isFalsy(v) {
        var s = String(v).toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off" || s === "";
      }

      function isSecretKey(key) {
        if (key === "APP_KEY") return false; // graded by its own stricter check
        if (/(PASSWORD|PASSWD|SECRET|API_KEY|PRIVATE_KEY|ACCESS_KEY)/.test(key)) return true;
        if (/_(KEY|TOKEN)\d*$/.test(key)) return true;
        if (/^(PASSWORD|PASSWD|SECRET|TOKEN)/.test(key)) return true;
        return false;
      }

      var REGISTRATION_KEYS = [
        "ALLOW_REGISTRATION", "ENABLE_REGISTRATION", "REGISTRATION_ENABLED",
        "OPEN_REGISTRATION", "APP_REGISTRATION", "ALLOW_SIGNUP", "ENABLE_SIGNUP"
      ];

      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      /* ---------------- The audit ---------------- */

      function audit(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, line, key, message, fix, valueLength) {
          var f = { severity: severity, line: line, key: key, message: message, fix: fix };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }

        var gradeable = parsed.parseable > 0 && parsed.recognized >= 3;

        if (!gradeable) {
          add("INFO", null, "(whole paste)",
            "This paste is not recognizably an Invoice Ninja server configuration. It needs at least a few known Invoice Ninja .env keys (such as APP_KEY, APP_ENV, DB_HOST, or MAIL_HOST) before it can be graded.",
            "Paste the full text of the Invoice Ninja .env file from the server — not a screenshot, a settings page, or a different app's config.",
            null);
        } else {
          var e = parsed.entries;

          /* APP_DEBUG */
          if (!e.APP_DEBUG) {
            add("WARNING", null, "APP_DEBUG",
              "APP_DEBUG is not set anywhere in this config, so the server falls back to its built-in default — and you cannot tell from this file whether debug output is on.",
              "Add an explicit line: APP_DEBUG=false");
          } else if (isTruthy(e.APP_DEBUG.value)) {
            add("BLOCKER", e.APP_DEBUG.line, "APP_DEBUG",
              "Debug mode is switched on. On a live server this can show full error pages — stack traces, file paths, and pieces of the configuration itself — to anyone who triggers an error.",
              "Set APP_DEBUG=false before this server faces the internet.");
          }

          /* APP_ENV */
          if (!e.APP_ENV) {
            add("HIGH", null, "APP_ENV",
              "APP_ENV is missing. Without it the server does not know it is in production, and production-only safeguards and behavior cannot be counted on.",
              "Add the line: APP_ENV=production");
          } else if (e.APP_ENV.value.toLowerCase() !== "production") {
            add("HIGH", e.APP_ENV.line, "APP_ENV",
              "APP_ENV is not set to production. A non-production environment name relaxes behavior that a live billing server should keep strict.",
              "Set APP_ENV=production on the live server.");
          }

          /* APP_KEY */
          if (!e.APP_KEY) {
            add("BLOCKER", null, "APP_KEY",
              "APP_KEY is missing entirely. Invoice Ninja encrypts sensitive data with this key; without a real one the install cannot protect stored data, and sessions and encrypted fields are unsafe.",
              "Generate a key on the server (php artisan key:generate) and put the result in APP_KEY. Never reuse a key from documentation or another install.");
          } else if (isExampleValue(e.APP_KEY.value)) {
            add("BLOCKER", e.APP_KEY.line, "APP_KEY",
              "APP_KEY is a known example or placeholder value (" + e.APP_KEY.value.length + " characters). Anyone who has seen the same example — which is everyone — effectively knows this server's encryption key.",
              "Generate a fresh key on the server (php artisan key:generate) and replace this value. The old value must never be used again.");
          } else if (e.APP_KEY.value.length < 32) {
            add("HIGH", e.APP_KEY.line, "APP_KEY",
              "APP_KEY is only " + e.APP_KEY.value.length + " characters long. A real generated key is longer than that; a short key is far easier to guess or brute-force.",
              "Generate a fresh key on the server (php artisan key:generate) and replace this value.");
          }

          /* APP_URL */
          if (!e.APP_URL) {
            add("WARNING", null, "APP_URL",
              "APP_URL is not set. Invoice Ninja builds links in invoices, emails, and payment pages from this value; leaving it unset invites wrong or insecure links.",
              "Set APP_URL to the server's full public address, starting with https://");
          } else if (/^http:\/\//i.test(e.APP_URL.value)) {
            add("HIGH", e.APP_URL.line, "APP_URL",
              "APP_URL uses http:// instead of https://. Links the server generates — including invoice and payment links sent to your customers — will point at the unencrypted address.",
              "Change APP_URL to the same address starting with https:// and make sure the server has a valid TLS certificate.");
          } else if (!/^https:\/\//i.test(e.APP_URL.value)) {
            add("WARNING", e.APP_URL.line, "APP_URL",
              "APP_URL does not start with https://, so generated links may be wrong or insecure.",
              "Set APP_URL to the server's full public https:// address.");
          }

          /* REQUIRE_HTTPS */
          if (!e.REQUIRE_HTTPS) {
            add("WARNING", null, "REQUIRE_HTTPS",
              "REQUIRE_HTTPS is not set, so the app is not told to force encrypted connections.",
              "Add the line: REQUIRE_HTTPS=true");
          } else if (!isTruthy(e.REQUIRE_HTTPS.value)) {
            add("HIGH", e.REQUIRE_HTTPS.line, "REQUIRE_HTTPS",
              "REQUIRE_HTTPS is not enabled. The app will happily serve logins and invoice data over plain http if it is reached that way.",
              "Set REQUIRE_HTTPS=true and make sure the server is reachable over https.");
          }

          /* SESSION_ENCRYPT */
          if (!e.SESSION_ENCRYPT) {
            add("WARNING", null, "SESSION_ENCRYPT",
              "SESSION_ENCRYPT is not set, so session data is not explicitly encrypted.",
              "Add the line: SESSION_ENCRYPT=true");
          } else if (!isTruthy(e.SESSION_ENCRYPT.value)) {
            add("HIGH", e.SESSION_ENCRYPT.line, "SESSION_ENCRYPT",
              "SESSION_ENCRYPT is not enabled. Session cookies carry who is logged in; unencrypted session handling makes them easier to abuse if they leak.",
              "Set SESSION_ENCRYPT=true.");
          }

          /* Open registration */
          for (var r = 0; r < REGISTRATION_KEYS.length; r++) {
            var rk = REGISTRATION_KEYS[r];
            if (e[rk] && isTruthy(e[rk].value)) {
              add("HIGH", e[rk].line, rk,
                "Open self-registration is switched on. Anyone on the internet can create an account on this billing server without an invitation.",
                "Set " + rk + "=false and invite users from inside the app instead.");
            }
          }

          /* Every password / secret / token / key value (generic sweep) */
          for (var i = 0; i < parsed.order.length; i++) {
            var key = parsed.order[i];
            if (!isSecretKey(key)) continue;
            var ent = parsed.entries[key];
            var v = ent.value;
            var isPdfKey = /PHANTOMJS|PDF/.test(key);
            var label = isPdfKey ? "PDF-generation key" : "Secret value";
            if (v === "") {
              add("WARNING", ent.line, key,
                label + " for " + key + " is empty. If the feature that uses it is on, it will fail — or worse, run unprotected.",
                "Set a real, unique value for " + key + ", or disable the feature that uses it.",
                0);
            } else if (isExampleValue(v)) {
              add("HIGH", ent.line, key,
                label + " for " + key + " is a known example or placeholder value (" + v.length + " characters). Example values are public knowledge. The value itself is never shown in this report.",
                "Replace " + key + " with a fresh, unique secret that appears nowhere else.",
                v.length);
            } else if (v.length < 12) {
              add("HIGH", ent.line, key,
                label + " for " + key + " is only " + v.length + " characters long — short enough to guess or brute-force. The value itself is never shown in this report.",
                "Replace " + key + " with a unique secret of at least 16 random characters.",
                v.length);
            } else {
              add("INFO", ent.line, key,
                label + " for " + key + " is present (" + v.length + " characters) and stored as plaintext in this file — anyone who can read this file holds the credential. The value itself is never shown in this report.",
                "Keep this file readable only by the server account (for example chmod 600), and rotate " + key + " if the file has ever been shared.",
                v.length);
            }
          }
        }

        /* NOT PARSED lines — reported, never guessed */
        for (var n = 0; n < parsed.notParsed.length; n++) {
          add("WARNING", parsed.notParsed[n].line, "(line " + parsed.notParsed[n].line + ")",
            "NOT PARSED: this line is not a KEY=VALUE setting, a comment, or a blank line, so it was ignored. Its contents are not shown and were not guessed at.",
            "Fix the line to the form KEY=VALUE, comment it out with a leading #, or delete it.");
        }

        findings.sort(function (a, b) {
          var d = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (d !== 0) return d;
          var la = a.line === null ? 9999 : a.line;
          var lb = b.line === null ? 9999 : b.line;
          return la - lb;
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        for (var c = 0; c < findings.length; c++) counts[findings[c].severity]++;

        var verdict;
        if (!gradeable) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, findings: findings, counts: counts, gradeable: gradeable, parsed: parsed };
      }

      /* ---------------- Report builders ---------------- */

      function verdictWhy(result) {
        if (result.verdict === "SAFE TO DEPLOY") return "No blockers, no high-severity problems, and no warnings. The pasted settings pass every check in this audit. (INFO notes, if any, are observations, not problems.)";
        if (result.verdict === "DEPLOY WITH FIXES") return "Nothing here is an emergency, but there are warnings to fix before this goes live. Fix each one, then grade the updated config again.";
        if (result.verdict === "DO NOT DEPLOY") return "This config has blocker or high-severity problems. Do not put this server on the internet until every BLOCKER and HIGH finding is fixed and the updated config is graded again.";
        return "The paste does not contain enough recognizable Invoice Ninja settings to grade. Paste the full .env config text and try again.";
      }

      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs Invoice Ninja Server Config Safety Auditor(TM)");
        out.push("Verdict: " + result.verdict);
        out.push("Why: " + verdictWhy(result));
        out.push("Findings: " + result.findings.length + " total - " +
          result.counts.BLOCKER + " BLOCKER, " + result.counts.HIGH + " HIGH, " +
          result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO");
        out.push("Secret values are never printed in this report: key name, line number, and value length only.");
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings.");
        }
        for (var i = 0; i < result.findings.length; i++) {
          var f = result.findings[i];
          var where = f.line === null ? "not present in file" : "line " + f.line;
          var line = "[" + f.severity + "] " + where + " - " + f.key + ": " + f.message;
          if (typeof f.valueLength === "number") line += " (value length: " + f.valueLength + " characters; value not shown)";
          out.push(line);
          out.push("    Fix: " + f.fix);
        }
        out.push("");
        out.push("This report grades the pasted text only. It does not start a server, connect to anything, or verify the config will run.");
        return out.join("\n");
      }

      function buildJson(result) {
        var data = {
          tool: "J-Dawgs Invoice Ninja Server Config Safety Auditor\u2122",
          verdict: result.verdict,
          why: verdictWhy(result),
          counts: result.counts,
          note: "Secret values are never included in this export: key name, line number, and value length only.",
          findings: result.findings.map(function (f) {
            var o = {
              severity: f.severity,
              line: f.line,
              key: f.key,
              message: f.message,
              fix: f.fix
            };
            if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
            return o;
          })
        };
        return JSON.stringify(data, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SUBSTRINGS": (typeof EXAMPLE_SUBSTRINGS !== 'undefined' ? EXAMPLE_SUBSTRINGS : undefined), "EXAMPLE_EXACT": (typeof EXAMPLE_EXACT !== 'undefined' ? EXAMPLE_EXACT : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-invoice-ninja-server-config-safety-auditortm',
  name: 'J-Dawgs Invoice Ninja Server Config Safety Auditor',
  description: 'Grades a pasted self-hosted Invoice Ninja .env config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — with secrets shown by key name, line, and length only, never by value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SUBSTRINGS": __core["EXAMPLE_SUBSTRINGS"], "EXAMPLE_EXACT": __core["EXAMPLE_EXACT"] }
};
