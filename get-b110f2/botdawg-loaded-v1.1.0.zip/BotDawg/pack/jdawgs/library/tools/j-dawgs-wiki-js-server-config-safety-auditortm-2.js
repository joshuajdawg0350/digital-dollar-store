'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Wiki.js Server Config Safety Auditor 2".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configs (line numbers are load-bearing) ---------- */
      var RISKY_LINES = [
        "# Wiki.js server config — risky sample (audit me)",   /* line 1  */
        "port: 3000",                                          /* line 2  */
        "bindIP: 0.0.0.0",                                     /* line 3  */
        "",                                                    /* line 4  */
        "db:",                                                 /* line 5  */
        "  type: postgres",                                    /* line 6  */
        "  host: db.internal",                                 /* line 7  */
        "  port: 5432",                                        /* line 8  */
        "  user: wikijs",                                      /* line 9  */
        "  pass: Zq9PlantedWikiDbPass4471xX",                  /* line 10 */
        "  db: wikijs",                                        /* line 11 */
        "  ssl: false",                                        /* line 12 */
        "",                                                    /* line 13 */
        "ssl:",                                                /* line 14 */
        "  enabled: false",                                    /* line 15 */
        "  port: 3443",                                        /* line 16 */
        "",                                                    /* line 17 */
        "url: http://wiki.jdawgs.net",                         /* line 18 */
        "sessionSecret: shortsecret",                          /* line 19 */
        "jwtSecret: changeme-jwt-value",                       /* line 20 */
        "debug: true",                                         /* line 21 */
        "telemetry: true"                                      /* line 22 */
      ];
      var RISKY = RISKY_LINES.join("\n");
      var PLANTED_DB_PASS = "Zq9PlantedWikiDbPass4471xX";
      var PLANTED_JWT = "changeme-jwt-value";

      var HARDENED_LINES = [
        "# Wiki.js server config — hardened sample",
        "port: 3000",
        "bindIP: 127.0.0.1",
        "",
        "db:",
        "  type: postgres",
        "  host: db.internal",
        "  port: 5432",
        "  user: wikijs",
        "  pass: ${DB_PASSWORD}",
        "  db: wikijs",
        "  ssl: true",
        "",
        "ssl:",
        "  enabled: true",
        "  port: 3443",
        "  provider: custom",
        "  format: pem",
        "  key: /etc/ssl/private/wiki.key",
        "  cert: /etc/ssl/certs/wiki.crt",
        "",
        "url: https://wiki.jdawgs.net",
        "sessionSecret: Kx7fQ2mZ9pL4vN8sR1tW6yB3dH5jM0aVcXeGkPnSqU",
        "jwtSecret: Mw3zT8bN6rK1xQ9sD4fH7jL2pV5cX0gEaUySokmnhb",
        "debug: false",
        "telemetry: false"
      ];
      var HARDENED = HARDENED_LINES.join("\n");

      var PROSE = "The wiki team meets on Tuesdays to talk about backups, page naming, and the office plants. Nothing in this paragraph is a server configuration file, and none of it should grade as one.";

      /* ---------- Auditor ---------- */
      var KNOWN = {};
      ["port","bindip","bind","host","hostname","address","db","database","ssl","sslenabled","dbssl",
       "url","publicurl","siteurl","baseurl","origin","appurl","externalurl","pass","password","passwd","pwd","dbpass","dbpassword",
       "user","username","dbuser","dbhost","dbname","debug","telemetry","secret","sessionsecret","jwtsecret","jwt","token",
       "apikey","datapath","type","enabled","provider","format","key","cert","nodeenv","session","auth","data","bodyparserlimit"
      ].forEach(function(k){ KNOWN[k]=1; });

      var URL_KEYS = { url:1, publicurl:1, siteurl:1, baseurl:1, origin:1, appurl:1, externalurl:1 };
      var BIND_KEYS = { bindip:1, bind:1, host:1, hostname:1, address:1, listen:1 };
      var PLACEHOLDER_WORDS = ["changeme","change-me","change_me","example","secret","password","passwd","test","default","placeholder","letmein","123456","qwerty","your-","your_","xxx"];

      var FIX = {
        "db-ssl-disabled": "Turn database SSL on (ssl: true in the db block, or DB_SSL=true) so traffic between Wiki.js and the database is encrypted.",
        "db-password-plaintext": "Move the database password out of the config file into an environment variable or a secret manager, and reference it there instead of pasting the real password into the file.",
        "public-url-http": "Change the public URL to https:// so logins, session cookies, and page content are not sent in the clear.",
        "bind-all-interfaces": "Bind to 127.0.0.1 (or a private interface) and put a reverse proxy in front, instead of listening on every network interface.",
        "bind-unrestricted": "Add an explicit bind/host restriction (for example bindIP: 127.0.0.1 behind a reverse proxy). A config that sets a port with no host restriction can end up listening on every interface.",
        "server-ssl-disabled": "Enable SSL (ssl.enabled: true) with a valid certificate, or terminate TLS at a reverse proxy and lock the app port down to local traffic.",
        "secret-placeholder": "Replace this value with a fresh random secret of at least 32 characters. Example and placeholder secrets are public knowledge and protect nothing.",
        "secret-short": "Use a random secret of at least 32 characters. Short secrets can be guessed or brute-forced.",
        "debug-enabled": "Set debug to false in production. Debug output can leak internals, paths, and request data.",
        "dev-env": "Set NODE_ENV=production for a deployed server; a development setting can enable verbose errors and relaxed behavior.",
        "telemetry-enabled": "Set telemetry to false if you do not want a production server sending usage data out.",
        "example-value": "Replace the example or default value with your real production value before deploying."
      };
      var RULE_NAME = {
        "db-ssl-disabled": "Database SSL disabled",
        "db-password-plaintext": "Plaintext database password",
        "public-url-http": "Public URL uses http",
        "bind-all-interfaces": "Bound to all interfaces (0.0.0.0)",
        "bind-unrestricted": "No bind/host restriction",
        "server-ssl-disabled": "Server SSL disabled",
        "secret-placeholder": "Placeholder / example secret",
        "secret-short": "Short secret (under 32 characters)",
        "debug-enabled": "Debug mode enabled",
        "dev-env": "Development environment",
        "telemetry-enabled": "Telemetry enabled",
        "example-value": "Example / default value"
      };

      function normKey(k){ return k.toLowerCase().replace(/[^a-z0-9]/g, ""); }
      function parseBool(v){
        var s = v.trim().toLowerCase();
        if (s === "true" || s === "yes" || s === "on" || s === "1") return true;
        if (s === "false" || s === "no" || s === "off" || s === "0") return false;
        return null;
      }
      function cleanValue(v){
        v = v.trim();
        if (v.charAt(0) !== '"' && v.charAt(0) !== "'") {
          var hash = v.indexOf(" #");
          if (hash > -1) v = v.slice(0, hash).trim();
        }
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1, -1);
        }
        return v.trim();
      }
      function isEnvRef(v){ return /^\$\{?[A-Za-z_][A-Za-z0-9_]*\}?$/.test(v) || v.indexOf("process.env") === 0; }

      function auditConfig(text){
        var findings = [], secrets = [], secretLines = {};
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var section = "";
        var assignments = 0, recognized = 0;
        var hasTopPort = false, topPortLine = 0, hasBind = false;

        function addFinding(sev, id, line){
          findings.push({ severity: sev, rule: RULE_NAME[id], ruleId: id, line: line, fix: FIX[id] });
        }
        function addSecret(key, line, len){
          if (!secretLines[line]) { secretLines[line] = 1; secrets.push({ key: key, line: line, length: len }); }
        }
        function secretChecks(key, value, line){
          var lv = value.toLowerCase(), i;
          for (i = 0; i < PLACEHOLDER_WORDS.length; i++) {
            if (lv.indexOf(PLACEHOLDER_WORDS[i]) > -1) { addFinding("CRITICAL", "secret-placeholder", line); return; }
          }
          if (value.length < 32) addFinding("WARNING", "secret-short", line);
        }

        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i], lineNo = i + 1, trimmed = raw.trim();
          if (!trimmed || trimmed.charAt(0) === "#") continue;

          var key = null, value = "", indent = 0, isEnv = false;
          var eqIdx = raw.indexOf("="), colonIdx = raw.indexOf(":");
          var envM = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (envM && eqIdx > -1 && (colonIdx === -1 || eqIdx < colonIdx)) {
            isEnv = true; key = envM[1]; value = cleanValue(envM[2]); section = "";
          } else {
            var ym = raw.match(/^(\s*)([A-Za-z][A-Za-z0-9_.\-]*)\s*:\s?(.*)$/);
            if (!ym) continue;
            indent = ym[1].length; key = ym[2]; value = cleanValue(ym[3]);
            if (indent === 0) section = (value === "") ? key.toLowerCase() : "";
          }

          assignments++;
          var nkey = normKey(key);
          if (KNOWN[nkey]) recognized++;

          var boolVal = parseBool(value);
          var topLevel = isEnv || (indent === 0 && section === "") || (indent === 0 && section === key.toLowerCase() && value !== "");
          var isDbContext = section === "db" || nkey === "dbpass" || nkey === "dbpassword" || nkey === "databasepassword" || (isEnv && /^DB_?PASS/i.test(key));
          var isPasswordKey = (nkey === "pass" || nkey === "password" || nkey === "passwd" || nkey === "pwd" || nkey === "dbpass" || nkey === "dbpassword" || nkey === "databasepassword");
          var isSecretKey = !isPasswordKey && /(secret|jwt|token|apikey|accesskey|privatekey|sessionkey|authkey)/.test(nkey);

          /* Secrets: register + grade. Values are used only for length/pattern tests, never output. */
          if (isPasswordKey) {
            if (value && !isEnvRef(value)) {
              addSecret(key, lineNo, value.length);
              if (isDbContext) addFinding("WARNING", "db-password-plaintext", lineNo);
              else secretChecks(key, value, lineNo);
            }
          } else if (isSecretKey) {
            if (value && !isEnvRef(value)) {
              addSecret(key, lineNo, value.length);
              secretChecks(key, value, lineNo);
            }
          }

          /* Database SSL */
          if (((section === "db" && nkey === "ssl") || nkey === "dbssl") && boolVal === false) {
            addFinding("CRITICAL", "db-ssl-disabled", lineNo);
          }
          /* Server SSL */
          if (section === "ssl" && nkey === "enabled" && boolVal === false) addFinding("CRITICAL", "server-ssl-disabled", lineNo);
          if (!isEnv && indent === 0 && section === "" && nkey === "ssl" && boolVal === false) addFinding("CRITICAL", "server-ssl-disabled", lineNo);
          if (nkey === "sslenabled" && boolVal === false) addFinding("CRITICAL", "server-ssl-disabled", lineNo);

          /* Public URL over http */
          if (URL_KEYS[nkey] && /^http:\/\//i.test(value)) addFinding("CRITICAL", "public-url-http", lineNo);

          /* Binding */
          if ((isEnv || topLevel) && BIND_KEYS[nkey]) {
            hasBind = true;
            if (value === "0.0.0.0" || value === "::" || value === "*") addFinding("CRITICAL", "bind-all-interfaces", lineNo);
          }
          if ((isEnv || topLevel) && nkey === "port" && value !== "") { hasTopPort = true; topPortLine = lineNo; }

          /* Debug / dev / telemetry */
          if (nkey === "debug" && boolVal === true) addFinding("WARNING", "debug-enabled", lineNo);
          if (nkey === "nodeenv" && value.toLowerCase() === "development") addFinding("WARNING", "dev-env", lineNo);
          if (nkey === "telemetry" && boolVal === true) addFinding("WARNING", "telemetry-enabled", lineNo);

          /* Example / default values (non-secret lines; secrets handled above) */
          if (!isPasswordKey && !isSecretKey && /(example\.(com|org|net)|your[-_](domain|site|url|host))/i.test(value)) {
            addFinding("WARNING", "example-value", lineNo);
          }
        }

        if (hasTopPort && !hasBind) addFinding("WARNING", "bind-unrestricted", topPortLine);

        findings.sort(function(a, b){
          if (a.line !== b.line) return a.line - b.line;
          if (a.severity === b.severity) return 0;
          return a.severity === "CRITICAL" ? -1 : 1;
        });
        secrets.sort(function(a, b){ return a.line - b.line; });

        var crit = 0, warn = 0;
        findings.forEach(function(f){ if (f.severity === "CRITICAL") crit++; else warn++; });

        var isRecognizable = recognized >= 1 || assignments >= 4;
        var verdict;
        if (!isRecognizable) verdict = "NOT ENOUGH TO GRADE";
        else if (crit > 0) verdict = "DO NOT DEPLOY";
        else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          findings: findings,
          secrets: secrets,
          counts: { critical: crit, warning: warn },
          recognized: isRecognizable
        };
      }

      function buildReport(result){
        var out = [];
        out.push("J-Dawgs Wiki.js Server Config Safety Auditor — audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Critical findings: " + result.counts.critical + " · Warnings: " + result.counts.warning);
        out.push("");
        if (result.findings.length) {
          out.push("Findings:");
          result.findings.forEach(function(f){
            out.push("- [" + f.severity + "] " + f.rule + " — line " + f.line + " — Fix: " + f.fix);
          });
        } else {
          out.push("Findings: none.");
        }
        out.push("");
        if (result.secrets.length) {
          out.push("Secrets seen (key, line, and length only — values never shown):");
          result.secrets.forEach(function(s){
            out.push("- key \"" + s.key + "\" — line " + s.line + " — " + s.length + " characters");
          });
        } else {
          out.push("Secrets seen: none.");
        }
        return out.join("\n");
      }

      function buildJson(result){
        return JSON.stringify({
          tool: "J-Dawgs Wiki.js Server Config Safety Auditor",
          verdict: result.verdict,
          counts: result.counts,
          findings: result.findings.map(function(f){
            return { severity: f.severity, rule: f.rule, line: f.line, fix: f.fix };
          }),
          secrets: result.secrets.map(function(s){
            return { key: s.key, line: s.line, length: s.length };
          })
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wiki-js-server-config-safety-auditortm-2',
  name: 'J-Dawgs Wiki.js Server Config Safety Auditor 2',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
