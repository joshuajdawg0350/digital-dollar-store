'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Warp Drive".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      /* ================= Pure core (no DOM) ================= */
      var DEFAULT_ITEM_MIN = 30;
      var DEFAULT_PRIO_MIN = 60;

      var STOPWORDS = {
        the: 1, a: 1, an: 1, and: 1, or: 1, to: 1, for: 1, of: 1, on: 1, in: 1,
        at: 1, by: 1, with: 1, from: 1, into: 1, about: 1, my: 1, our: 1, your: 1,
        it: 1, its: 1, this: 1, that: 1, up: 1, out: 1, off: 1, over: 1, new: 1
      };
      var HIS_KEYWORDS = [
        "sign", "signing", "signature", "pay", "payment", "captcha", "identity",
        "liveness", "ssn", "2fa", "two-factor", "notarize", "notary",
        "fingerprint", "id check", "verify identity", "in person", "in-person"
      ];

      function stem(w) {
        if (w.length > 4 && w.slice(-3) === "ing") return w.slice(0, -3);
        if (w.length > 3 && w.slice(-2) === "es") return w.slice(0, -2);
        if (w.length > 3 && w.slice(-1) === "s") return w.slice(0, -1);
        return w;
      }
      function rawWords(text) {
        var parts = String(text || "").toLowerCase().split(/[^a-z0-9]+/);
        var out = [];
        for (var i = 0; i < parts.length; i++) {
          var w = parts[i];
          if (w.length < 3 || STOPWORDS[w]) continue;
          out.push(w);
        }
        return out;
      }
      function parseEffort(text) {
        var t = " " + String(text) + " ";
        var mins = null;
        var both = t.match(/(\d+(?:\.\d+)?)\s*h(?:ours?|rs?)?\s*(\d+)\s*m(?:in(?:ute)?s?)?\b/);
        if (both) {
          mins = Math.round(parseFloat(both[1]) * 60) + parseInt(both[2], 10);
          t = t.replace(both[0], " ");
        } else {
          var hm = t.match(/(\d+(?:\.\d+)?)\s*h(?:ours?|rs?)?\b/);
          var mm = t.match(/(\d+)\s*m(?:in(?:ute)?s?)?\b/);
          if (hm || mm) {
            mins = (hm ? Math.round(parseFloat(hm[1]) * 60) : 0) + (mm ? parseInt(mm[1], 10) : 0);
            if (hm) t = t.replace(hm[0], " ");
            if (mm) t = t.replace(mm[0], " ");
          }
        }
        return { minutes: mins, text: t.replace(/\s+/g, " ").trim() };
      }
      function isHisStepText(text) {
        var t = " " + String(text).toLowerCase() + " ";
        for (var i = 0; i < HIS_KEYWORDS.length; i++) {
          var k = HIS_KEYWORDS[i];
          var re = new RegExp("[^a-z0-9]" + k.replace(/[-]/g, "[- ]") + "[^a-z0-9]");
          if (re.test(t)) return k;
        }
        return null;
      }
      function parseLine(raw) {
        var t = String(raw || "").trim();
        if (!t) return null;
        var owner = "UNKNOWN";
        var ownerMarker = null;
        var m = t.match(/\[([^\]]+)\]/);
        while (m) {
          var tag = m[1].trim().toLowerCase();
          if (tag === "mine" || tag === "me" || tag === "self") { owner = "SELF"; ownerMarker = m[0]; }
          else if (tag === "agent" || tag === "delegate" || tag === "crew") { owner = "DELEGATE"; ownerMarker = m[0]; }
          else if (tag === "his step" || tag === "his-step" || tag === "human" || tag === "joshua") { owner = "HIS-STEP"; ownerMarker = m[0]; }
          t = t.replace(m[0], " ");
          m = t.match(/\[([^\]]+)\]/);
        }
        var deadline = null;
        var dm = t.match(/\b(?:due|by)\s+([A-Za-z]{3,9}(?:\s+\d{1,2})?)/i);
        if (dm) deadline = dm[0].trim();
        var ef = parseEffort(t);
        var title = ef.text.replace(/\s+[-–—:]\s*$/, "").trim();
        if (!title) title = String(raw).trim();
        var hisKw = owner === "HIS-STEP" ? null : isHisStepText(title);
        return {
          raw: String(raw),
          title: title,
          minutes: ef.minutes,
          assumed: ef.minutes === null,
          owner: owner,
          ownerMarker: ownerMarker,
          deadline: deadline,
          hisKeyword: hisKw
        };
      }
      function analyze(priorityRaw, pileText, budget, crews) {
        budget = Math.max(1, parseInt(budget, 10) || 0);
        crews = Math.max(1, Math.min(12, parseInt(crews, 10) || 1));
        var pef = parseEffort(String(priorityRaw || ""));
        var prioTitle = pef.text || String(priorityRaw || "").trim() || "(no priority set)";
        var prio = {
          title: prioTitle,
          minutes: pef.minutes === null ? DEFAULT_PRIO_MIN : pef.minutes,
          assumed: pef.minutes === null,
          owner: "SELF",
          isPriority: true
        };
        var prioStems = {};
        var pw = rawWords(prioTitle);
        for (var pi = 0; pi < pw.length; pi++) prioStems[stem(pw[pi])] = true;
        var lines = String(pileText || "").split(/\r?\n/);
        var supports = [], parked = [], hisSteps = [];
        for (var i = 0; i < lines.length; i++) {
          var item = parseLine(lines[i]);
          if (!item) continue;
          if (item.minutes === null) { item.minutes = DEFAULT_ITEM_MIN; item.assumed = true; }
          if (item.owner === "HIS-STEP" || item.hisKeyword) {
            item.class = "HIS-STEP";
            item.reason = item.owner === "HIS-STEP"
              ? "marked as a step only he can do"
              : "human-only step (matched \u201C" + item.hisKeyword + "\u201D) — pulled out so it never blocks the sprint silently";
            hisSteps.push(item);
            continue;
          }
          var iwords = rawWords(item.title);
          var shared = [], seenStem = {};
          for (var j = 0; j < iwords.length; j++) {
            var st = stem(iwords[j]);
            if (prioStems[st] && !seenStem[st]) { seenStem[st] = true; shared.push(iwords[j]); }
          }
          if (shared.length > 0) {
            item.class = "SUPPORTS";
            item.shared = shared;
            item.reason = "supports the priority — shares \u201C" + shared.join("\u201D, \u201C") + "\u201D with it";
            supports.push(item);
          } else {
            item.class = "PARKS";
            item.reason = "does not move the priority";
            parked.push(item);
          }
        }
        /* ---- Schedule FIRE NOW across crews (priority pinned to Crew 1, rest longest-first) ---- */
        var fire = [prio].concat(supports);
        var avail = [], counts = [];
        for (var c = 0; c < crews; c++) { avail.push(0); counts.push(0); }
        var order = fire.slice();
        var rest = order.slice(1).sort(function (a, b) { return b.minutes - a.minutes; });
        var seq = [order[0]].concat(rest);
        for (var k = 0; k < seq.length; k++) {
          var it = seq[k];
          var best = 0;
          for (var q = 1; q < crews; q++) if (avail[q] < avail[best]) best = q;
          it.crew = best + 1;
          it.wave = counts[best] + 1;
          it.start = avail[best];
          it.end = avail[best] + it.minutes;
          avail[best] = it.end;
          counts[best]++;
        }
        var totalWork = 0, wall = 0;
        for (var s = 0; s < fire.length; s++) { totalWork += fire[s].minutes; if (fire[s].end > wall) wall = fire[s].end; }
        var overflow = fire.filter(function (x) { return x.end > budget; });
        overflow.sort(function (a, b) { return a.end - b.end; });
        return {
          priority: prio,
          fireNow: seq,
          parked: parked,
          hisSteps: hisSteps,
          budget: budget,
          crews: crews,
          totalWork: totalWork,
          wallClock: wall,
          fits: wall <= budget,
          overflow: overflow,
          pileCount: supports.length + parked.length + hisSteps.length
        };
      }
      function fmtMin(m) {
        if (m < 60) return m + "m";
        var h = Math.floor(m / 60), r = m % 60;
        return r ? h + "h " + r + "m" : h + "h";
      }
      function buildBrief(r) {
        var L = [];
        L.push("WARP DRIVE SPRINT — " + r.priority.title);
        L.push(r.fits
          ? "Verdict: FITS — " + fmtMin(r.wallClock) + " wall clock across " + r.crews + (r.crews === 1 ? " crew" : " crews") + " inside a " + fmtMin(r.budget) + " budget (" + fmtMin(r.totalWork) + " of work)."
          : "Verdict: DOES NOT FIT — " + fmtMin(r.wallClock) + " wall clock needed, budget is " + fmtMin(r.budget) + ". Overflow: " + r.overflow.map(function (x) { return x.title; }).join("; ") + ".");
        L.push("");
        L.push("FIRE NOW:");
        for (var i = 0; i < r.fireNow.length; i++) {
          var f = r.fireNow[i];
          L.push((i + 1) + ". " + f.title + " — Crew " + f.crew + ", wave " + f.wave + " — " + fmtMin(f.minutes) + (f.assumed ? " (assumed)" : ""));
        }
        L.push("");
        if (r.hisSteps.length) {
          L.push("HIS ONE STEP: " + r.hisSteps[0].title);
          for (var h = 1; h < r.hisSteps.length; h++) L.push("Also his, pulled out of the sprint: " + r.hisSteps[h].title);
        } else {
          L.push("HIS ONE STEP: none — full speed, no human step needed");
        }
        L.push("");
        L.push("PARKED (" + r.parked.length + ") — nothing dropped, everything waits:");
        if (!r.parked.length) L.push("- (nothing parked)");
        for (var p = 0; p < r.parked.length; p++) {
          L.push("- " + r.parked[p].title + " — " + r.parked[p].reason);
        }
        return L.join("\n");
      }
      function buildReport(r) {
        var L = [buildBrief(r), ""];
        L.push("DETAIL:");
        L.push("Priority effort: " + fmtMin(r.priority.minutes) + (r.priority.assumed ? " (assumed default " + DEFAULT_PRIO_MIN + "m — no estimate given)" : ""));
        L.push("Pile lines parsed: " + r.pileCount + " → " + (r.fireNow.length - 1) + " supporting, " + r.parked.length + " parked, " + r.hisSteps.length + " his-step.");
        for (var i = 0; i < r.fireNow.length; i++) {
          var f = r.fireNow[i];
          if (f.isPriority) continue;
          L.push("- FIRE: " + f.title + " — " + f.reason + " — owner " + f.owner + (f.deadline ? " — " + f.deadline : ""));
        }
        for (var p = 0; p < r.parked.length; p++) {
          L.push("- PARKED: " + r.parked[p].title + " — owner " + r.parked[p].owner + " — " + fmtMin(r.parked[p].minutes) + (r.parked[p].assumed ? " (assumed)" : "") + (r.parked[p].deadline ? " — " + r.parked[p].deadline : ""));
        }
        for (var h = 0; h < r.hisSteps.length; h++) {
          L.push("- HIS STEP: " + r.hisSteps[h].title + " — " + r.hisSteps[h].reason);
        }
        L.push("");
        L.push("Outcome-only check-off (as each lands, report it Joshua's way):");
        for (var k = 0; k < r.fireNow.length; k++) L.push(r.fireNow[k].title + " — it's handled");
        return L.join("\n");
      }

      /* ================= Worked example ================= */
      var EXAMPLE_PRIO = "Finish the Contra services page 90m";
      var EXAMPLE_PILE = [
        "Draft the services list for the Contra page 45m [agent]",
        "Grab screenshots of finished jobs for the services page 30m [agent]",
        "Write the Contra page headline and pricing blurb 40m [agent]",
        "Sign in to Contra and publish the services page [his step]",
        "Order more deck screws for the Miller job 20m",
        "Call the lumber yard about Friday delivery 15m [mine]",
        "Fix the squeaky hinge on the shop door 25m",
        "Renew the truck registration due Fri"
      ].join("\n");
      var EXAMPLE_BUDGET = 240;
      var EXAMPLE_CREWS = 2;
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_PRIO": (typeof EXAMPLE_PRIO !== 'undefined' ? EXAMPLE_PRIO : undefined), "EXAMPLE_PILE": (typeof EXAMPLE_PILE !== 'undefined' ? EXAMPLE_PILE : undefined), "EXAMPLE_BUDGET": (typeof EXAMPLE_BUDGET !== 'undefined' ? EXAMPLE_BUDGET : undefined), "EXAMPLE_CREWS": (typeof EXAMPLE_CREWS !== 'undefined' ? EXAMPLE_CREWS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-warp-drive',
  name: 'J-Dawgs Warp Drive',
  description: 'Paste a priority plus a messy task pile; it sequences a FIRE NOW sprint with parallel crew assignments, parks everything else with reasons, isolates the one human-only step, and verdicts the time math (FITS / DOES NOT FIT with named overflow).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_PRIO": __core["EXAMPLE_PRIO"], "EXAMPLE_PILE": __core["EXAMPLE_PILE"], "EXAMPLE_BUDGET": __core["EXAMPLE_BUDGET"], "EXAMPLE_CREWS": __core["EXAMPLE_CREWS"] }
};
