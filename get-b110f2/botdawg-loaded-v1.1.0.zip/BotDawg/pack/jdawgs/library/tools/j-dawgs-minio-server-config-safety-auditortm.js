'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MinIO Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example — do not ship a server like this",
          "MINIO_ROOT_USER=minioadmin",
          "MINIO_ROOT_PASSWORD=minioadmin",
          "MINIO_SERVER_URL=http://storage.example.com:9000",
          "MINIO_BROWSER_REDIRECT_URL=http://storage.example.com:9001",
          "MINIO_CONSOLE_ADDRESS=:9001",
          "MINIO_ADDRESS=:9000",
          "MINIO_NOTIFY_WEBHOOK_ENDPOINT_PRIMARY=http://hooks.example.com:8080/events",
          "MINIO_NOTIFY_AMQP_URL_PRIMARY=amqp://minio:notifysecret99@rabbit.example.com:5672/",
          "MINIO_SERVER_URL=http://storage.example.com:9000",
          "# MINIO_CERTS_DIR=/etc/minio/certs",
          "MINIO_API_REQUESTS_MAX=1000",
          "this line is not a setting at all"
        ].join("\n");

        var HARDENED = [
          "# Hardened example — the shape of a careful setup",
          "MINIO_ROOT_USER=svc-storage-admin-01",
          "MINIO_ROOT_PASSWORD=N7$kQ2!vR9#mZ4xP8wL3sD6f",
          "MINIO_SERVER_URL=https://storage.example.com:9000",
          "MINIO_BROWSER_REDIRECT_URL=https://storage.example.com:9001",
          "MINIO_CONSOLE_ADDRESS=127.0.0.1:9001",
          "MINIO_ADDRESS=127.0.0.1:9000",
          "MINIO_CERTS_DIR=/etc/minio/certs",
          "MINIO_NOTIFY_WEBHOOK_ENDPOINT_PRIMARY=https://hooks.example.com/minio-events",
          "MINIO_API_REQUESTS_MAX=2000",
          "MINIO_BROWSER=on"
        ].join("\n");

        var input = document.getElementById("configInput");
        var verdictBox = document.getElementById("verdictBox");
        var verdictText = document.getElementById("verdictText");
        var verdictWhy = document.getElementById("verdictWhy");
        var verdictCounts = document.getElementById("verdictCounts");
        var findingsCard = document.getElementById("findingsCard");
        var findingsList = document.getElementById("findingsList");
        var reportCard = document.getElementById("reportCard");
        var reportOutput = document.getElementById("reportOutput");
        var copyStatus = document.getElementById("copyStatus");
        var pitchStatus = document.getElementById("pitchStatus");

        var WEAK_PASSWORDS = ["minioadmin", "password", "password1", "changeme", "letmein", "admin123", "minio123", "12345678"];
        var lastTextReport = "";
        var lastJsonReport = "";

        function unquote(v) {
          v = v.trim();
          if (v.length >= 2) {
            var a = v.charAt(0), b = v.charAt(v.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
          }
          return v;
        }

        function isSecretKey(key) {
          return /PASSWORD|SECRET|TOKEN|ACCESS_KEY|PRIVATE_KEY|CREDENTIAL/.test(key);
        }

        function parseUrlLoose(v) {
          var m = v.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/([^\/?#]*)([\s\S]*)$/);
          if (!m) return null;
          var authority = m[2];
          var userinfo = null;
          var hostport = authority;
          var at = authority.lastIndexOf("@");
          if (at >= 0) { userinfo = authority.slice(0, at); hostport = authority.slice(at + 1); }
          var host = hostport.replace(/:\d+$/, "").replace(/^\[|\]$/g, "");
          return { scheme: m[1].toLowerCase(), userinfo: userinfo, host: host, hostport: hostport };
        }

        function isLocalHost(host) {
          return host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "";
        }

        function bindsAllInterfaces(v) {
          var t = v.trim();
          return /^:\d+$/.test(t) || t.indexOf("0.0.0.0:") === 0 || t.indexOf("[::]:") === 0 || t === "0.0.0.0" || t === "::";
        }

        function bindsLocalhost(v) {
          var t = v.trim();
          return t.indexOf("127.0.0.1:") === 0 || t.indexOf("localhost:") === 0 || t.indexOf("[::1]:") === 0;
        }

        function audit(text) {
          var lines = text.split(/\r?\n/);
          var findings = [];
          var seen = {};           // key -> first line number (active only)
          var activeMinioKeys = 0;
          var tlsPresent = false;
          var serverUrlInfo = null; // {line, scheme, host, publicHost}
          var hasRootUser = false, hasRootPassword = false, rootUserValue = null;

          function add(line, key, severity, message, secretLength) {
            var f = { line: line, key: key, severity: severity, message: message };
            if (typeof secretLength === "number") f.secretLength = secretLength;
            findings.push(f);
          }

          lines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var trimmed = raw.trim();
            if (trimmed === "") return;

            /* ---- Commented lines: never graded as active ---- */
            if (trimmed.charAt(0) === "#") {
              var body = trimmed.replace(/^#+\s*/, "");
              var cm = body.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=/);
              if (cm) {
                add(lineNo, cm[1], "COMMENTED",
                  cm[1] + " is commented out on this line — COMMENTED / NOT ACTIVE. It has no effect on the server and was not graded as a live setting.");
              } else {
                add(lineNo, null, "COMMENTED",
                  "Comment line — COMMENTED / NOT ACTIVE. It has no effect on the server and was not graded.");
              }
              return;
            }

            /* ---- Parse KEY=value ---- */
            var m = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (!m) {
              add(lineNo, null, "NOT PARSED",
                "This line is NOT PARSED — it is not in KEY=value form, so the auditor cannot grade it. If it was meant to be a setting, rewrite it as KEY=value.");
              return;
            }
            var key = m[1].toUpperCase();
            var value = unquote(m[2]);

            if (key.indexOf("MINIO_") === 0) activeMinioKeys++;
            if (/TLS|CERT/.test(key) && value !== "") tlsPresent = true;

            /* ---- Duplicates ---- */
            var isDup = false;
            if (Object.prototype.hasOwnProperty.call(seen, key)) {
              isDup = true;
              add(lineNo, key, "WARNING",
                key + " is set more than once (first set on line " + seen[key] + "). Duplicate keys are confusing and error-prone — which value wins depends on how the config is loaded. Keep exactly one entry per key.");
            } else {
              seen[key] = lineNo;
            }

            /* ---- Per-key checks ---- */
            if (key === "MINIO_ROOT_USER") {
              hasRootUser = true;
              rootUserValue = value;
              if (value === "minioadmin") {
                add(lineNo, key, "BLOCKER",
                  "MINIO_ROOT_USER is still the documented default root user name, minioadmin. It is public knowledge and the first name any attacker tries. Set a unique root user name that is not published anywhere.");
              } else if (value.length < 3) {
                add(lineNo, key, "WARNING",
                  "MINIO_ROOT_USER is very short (" + value.length + " characters). Short root user names are easy to guess — use a longer, unique name.");
              } else if (!isDup) {
                add(lineNo, key, "PASS",
                  "MINIO_ROOT_USER is set to a non-default name. Good — the documented default is not in use.");
              }
              return;
            }

            if (key === "MINIO_ROOT_PASSWORD") {
              hasRootPassword = true;
              var len = value.length;
              if (WEAK_PASSWORDS.indexOf(value.toLowerCase()) >= 0 || (rootUserValue !== null && value !== "" && value === rootUserValue)) {
                add(lineNo, key, "BLOCKER",
                  "MINIO_ROOT_PASSWORD is a documented default or commonly guessed password (length only: " + len + " characters). The value is never printed here. Replace it with a long, unique password before this server stores anything real.", len);
              } else if (len < 8) {
                add(lineNo, key, "BLOCKER",
                  "MINIO_ROOT_PASSWORD is too short (length only: " + len + " characters). MinIO expects at least 8 characters, and a root password this short can be guessed or brute-forced. The value is never printed here.", len);
              } else if (len < 16) {
                add(lineNo, key, "WARNING",
                  "MINIO_ROOT_PASSWORD is " + len + " characters long (length only — the value is never printed). That clears the minimum, but the root account controls every bucket: 16 characters or more, unique to this server, is the safer bar.", len);
              } else if (!isDup) {
                add(lineNo, key, "PASS",
                  "MINIO_ROOT_PASSWORD is " + len + " characters long (length only — the value is never printed) and is not a known default. That is a healthy length for a root credential.", len);
              }
              return;
            }

            if (key === "MINIO_SERVER_URL" || key === "MINIO_BROWSER_REDIRECT_URL") {
              var u = parseUrlLoose(value);
              if (!u) {
                add(lineNo, key, "WARNING",
                  key + " does not look like a full URL with a scheme (such as https://host:port), so its transport safety cannot be confirmed.");
                return;
              }
              if (key === "MINIO_SERVER_URL") {
                serverUrlInfo = { line: lineNo, scheme: u.scheme, host: u.host, publicHost: !isLocalHost(u.host) };
              }
              if (u.userinfo) {
                add(lineNo, key, "HIGH",
                  key + " embeds credentials inside the URL itself. Anything that can read this config or the URL can reuse them. Move credentials out of URLs and into dedicated settings.");
              } else if (u.scheme === "http") {
                if (isLocalHost(u.host)) {
                  add(lineNo, key, "WARNING",
                    key + " uses plain http:// to a local address (" + (u.host || "this machine") + "). That stays on one machine, but switch to https:// before this address is ever exposed to a network.");
                } else {
                  add(lineNo, key, "HIGH",
                    key + " uses plain http:// to " + u.host + ". Logins, credentials, and object data cross the network unencrypted where anyone on the path can read them. Use https:// with a valid TLS certificate.");
                }
              } else if (u.scheme === "https") {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " uses https://, so traffic to " + (u.host || "the server") + " is encrypted in transit.");
              } else {
                add(lineNo, key, "WARNING",
                  key + " uses the " + u.scheme + ":// scheme, which this auditor cannot confirm as encrypted transport. https:// is the expected scheme here.");
              }
              return;
            }

            if (key === "MINIO_CONSOLE_ADDRESS" || key === "MINIO_BROWSER_ADDRESS" || key.indexOf("CONSOLE") >= 0) {
              if (bindsAllInterfaces(value)) {
                add(lineNo, key, "HIGH",
                  key + " binds the browser console to all network interfaces (" + value + "). The admin console is then reachable from anywhere that can route to this machine. Bind it to 127.0.0.1 and reach it through a tunnel or a protected reverse proxy instead.");
              } else if (bindsLocalhost(value)) {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " binds the browser console to localhost only (" + value + "). It is not reachable from other machines directly — the safe default posture.");
              } else {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " binds the browser console to a specific address (" + value + ") rather than all interfaces.");
              }
              return;
            }

            if (key === "MINIO_ADDRESS" || /_ADDRESS$/.test(key)) {
              if (bindsAllInterfaces(value)) {
                add(lineNo, key, "WARNING",
                  key + " binds the API listener to all network interfaces (" + value + "). That is normal for a storage server that other machines must reach — just make sure a firewall, not hope, decides who can connect.");
              } else if (bindsLocalhost(value)) {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " binds this listener to localhost only (" + value + "), so it is not reachable from other machines.");
              } else {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " binds this listener to a specific address (" + value + ") rather than all interfaces.");
              }
              return;
            }

            if (key.indexOf("MINIO_NOTIFY_") === 0) {
              var nu = parseUrlLoose(value);
              if (nu && nu.userinfo) {
                var pwLen = null;
                var colon = nu.userinfo.indexOf(":");
                if (colon >= 0) pwLen = nu.userinfo.length - colon - 1;
                var lenNote = pwLen !== null ? "password length only: " + pwLen + " characters" : "credential length only: " + nu.userinfo.length + " characters";
                add(lineNo, key, "HIGH",
                  key + " embeds plaintext credentials inside the endpoint URL (" + lenNote + "; the credentials themselves are never printed here). Anyone who can read this config owns that queue or webhook account. Use the dedicated auth settings for this target, or a secrets source, instead of credentials in the URL.", pwLen !== null ? pwLen : nu.userinfo.length);
              } else if (nu && nu.scheme === "http") {
                add(lineNo, key, "WARNING",
                  key + " sends event notifications over plain http:// to " + (nu.host || "a remote host") + ". Event payloads cross the network unencrypted. Prefer an https:// endpoint.");
              } else if (isSecretKey(key)) {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " is set (length only: " + value.length + " characters — the value is never printed).", value.length);
              } else {
                if (!isDup) add(lineNo, key, "PASS",
                  key + " is set without credentials embedded in a URL and without a plaintext http:// transport flag.");
              }
              return;
            }

            if (isSecretKey(key)) {
              if (value.length === 0) {
                add(lineNo, key, "WARNING",
                  key + " is present but empty. An empty secret usually means the feature silently falls back or fails later — set it properly or remove the line.");
              } else if (value.length < 8) {
                add(lineNo, key, "WARNING",
                  key + " is short (length only: " + value.length + " characters — the value is never printed). Short secrets are weak secrets.", value.length);
              } else if (!isDup) {
                add(lineNo, key, "PASS",
                  key + " is set (length only: " + value.length + " characters — the value is never printed).", value.length);
              }
              return;
            }

            if (/CORS/.test(key) && value.indexOf("*") >= 0) {
              add(lineNo, key, "WARNING",
                key + " allows any origin (wildcard). Wildcard cross-origin access on a storage API invites browser-based misuse — restrict it to the origins you actually run.");
              return;
            }

            if (key === "MINIO_BROWSER") {
              if (value.toLowerCase() === "off") {
                add(lineNo, key, "PASS", "MINIO_BROWSER is off, so the web console is disabled entirely — one less admin surface exposed.");
              } else if (!isDup) {
                add(lineNo, key, "PASS", "MINIO_BROWSER is on. That is fine as long as the console address above is not bound to all interfaces without protection.");
              }
              return;
            }

            if (/TLS|CERT/.test(key)) {
              if (!isDup) add(lineNo, key, "PASS",
                key + " is set, so TLS certificate configuration is present in this config. (This tool can see that it is set — it cannot verify the certificate itself.)");
              return;
            }

            if (key.indexOf("MINIO_API_") === 0) {
              if (!isDup) add(lineNo, key, "PASS",
                key + " is a recognized API tuning setting with no safety flag on its face.");
              return;
            }

            if (key.indexOf("MINIO_") === 0) {
              if (!isDup) add(lineNo, key, "PASS",
                key + " is a recognized MinIO setting with no specific safety flag in this audit.");
              return;
            }

            /* Non-MinIO key: parsed fine, just not graded */
            add(lineNo, key, "PASS",
              key + " parsed as a setting, but it is not a MINIO_ key, so it is outside what this auditor grades.");
          });

          /* ---- Whole-config checks ---- */
          if (activeMinioKeys > 0) {
            if (serverUrlInfo && serverUrlInfo.publicHost && !tlsPresent) {
              if (serverUrlInfo.scheme === "https") {
                add(serverUrlInfo.line, "MINIO_SERVER_URL", "WARNING",
                  "MINIO_SERVER_URL points at a public https:// address, but no TLS certificate setting (a key mentioning TLS or CERT, such as a certs directory) appears anywhere in this config. The certificate may well be configured outside the pasted text — but from this config alone, TLS cannot be confirmed.");
              } else if (serverUrlInfo.scheme === "http") {
                add(serverUrlInfo.line, "MINIO_SERVER_URL", "WARNING",
                  "No TLS certificate setting (a key mentioning TLS or CERT) appears anywhere in this config while a public server URL is set. Without TLS there is no encryption and no proof of the server's identity — add certificates and switch the URL to https://.");
              }
            }
            if (!hasRootUser) {
              add(null, "MINIO_ROOT_USER", "WARNING",
                "No active MINIO_ROOT_USER line was found. If the server falls back to a default or a value set elsewhere, this pasted config cannot show it — set the root user explicitly here so it can be graded.");
            }
            if (!hasRootPassword) {
              add(null, "MINIO_ROOT_PASSWORD", "HIGH",
                "No active MINIO_ROOT_PASSWORD line was found. A root password set outside this config cannot be graded here, and a missing one risks a default or an unstartable server being mistaken for a configured one. Set it explicitly in the config you audit.");
            }
          }

          /* ---- Verdict ---- */
          var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, PASS: 0, "NOT PARSED": 0, COMMENTED: 0 };
          findings.forEach(function (f) { if (counts.hasOwnProperty(f.severity)) counts[f.severity]++; });

          var verdict, why;
          if (activeMinioKeys === 0) {
            verdict = "NOT ENOUGH TO GRADE";
            why = "No active MINIO_ settings were recognized in the pasted text. Paste an env-style config with MINIO_ keys (one KEY=value per line), or load one of the built-in examples.";
          } else if (counts.BLOCKER > 0 || counts.HIGH > 0) {
            verdict = "DO NOT DEPLOY";
            why = "This config has " + counts.BLOCKER + " BLOCKER and " + counts.HIGH + " HIGH finding(s). Fix those first — they are the issues that hand an attacker the keys or expose the server.";
          } else if (counts.WARNING > 0) {
            verdict = "DEPLOY WITH FIXES";
            why = "No blockers or high findings, but " + counts.WARNING + " warning(s) need attention. Work through them before this config faces real data or a real network.";
          } else {
            verdict = "SAFE TO DEPLOY";
            why = "No blockers, highs, or warnings in the pasted config. Remember the limits above: bucket policies and identity-provider settings stored outside this text were not graded, because they were not pasted.";
          }

          return { findings: findings, counts: counts, verdict: verdict, why: why, activeMinioKeys: activeMinioKeys };
        }

        function buildTextReport(r) {
          var out = [];
          out.push("J-Dawgs MinIO Server Config Safety Auditor — Report");
          out.push("Verdict: " + r.verdict);
          out.push("Active MINIO_ settings graded: " + r.activeMinioKeys);
          out.push("Counts — BLOCKER: " + r.counts.BLOCKER + " | HIGH: " + r.counts.HIGH + " | WARNING: " + r.counts.WARNING + " | PASS: " + r.counts.PASS + " | NOT PARSED: " + r.counts["NOT PARSED"] + " | COMMENTED: " + r.counts.COMMENTED);
          out.push("Note: secrets are reported by key name, line, and length only. No secret value appears in this report.");
          out.push("");
          out.push("Findings:");
          if (r.findings.length === 0) out.push("(none — nothing was pasted)");
          r.findings.forEach(function (f) {
            var loc = f.line === null ? "Config-wide" : "Line " + f.line;
            var keyPart = f.key ? " [" + f.key + "]" : "";
            var lenPart = typeof f.secretLength === "number" ? " (secret length: " + f.secretLength + ")" : "";
            out.push("- " + loc + " — " + f.severity + keyPart + ": " + f.message + lenPart);
          });
          out.push("");
          out.push("Limits: this audit graded only the pasted text. It did not connect to any server, and it cannot confirm bucket policies or identity-provider settings stored outside the pasted config.");
          return out.join("\n");
        }

        function buildJsonReport(r) {
          var obj = {
            tool: "J-Dawgs MinIO Server Config Safety Auditor",
            verdict: r.verdict,
            verdictReason: r.why,
            activeMinioSettingsGraded: r.activeMinioKeys,
            counts: {
              BLOCKER: r.counts.BLOCKER, HIGH: r.counts.HIGH, WARNING: r.counts.WARNING,
              PASS: r.counts.PASS, NOT_PARSED: r.counts["NOT PARSED"], COMMENTED: r.counts.COMMENTED
            },
            secretsPolicy: "Secrets are reported by key name, line, and length only. No secret value is included in this report.",
            findings: r.findings.map(function (f) {
              var o = { line: f.line, key: f.key, severity: f.severity, message: f.message };
              if (typeof f.secretLength === "number") o.secretLength = f.secretLength;
              return o;
            }),
            limits: "Graded the pasted text only. No server connection was made. Bucket policies and identity-provider settings stored outside the pasted config cannot be confirmed."
          };
          return JSON.stringify(obj, null, 2);
        }

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-minio-server-config-safety-auditortm',
  name: 'J-Dawgs MinIO Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
