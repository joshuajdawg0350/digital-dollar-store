'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs S3 Bucket Policy Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Sid": "PublicRead",
              "Effect": "Allow",
              "Principal": "*",
              "Action": "s3:GetObject",
              "Resource": "arn:aws:s3:::example-assets/*"
            },
            {
              "Sid": "BroadWildcard",
              "Effect": "Allow",
              "Principal": { "AWS": "arn:aws:iam::123456789012:root" },
              "Action": ["s3:*"],
              "Resource": "*"
            }
          ]
        };

        var CLEAN = {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Sid": "ListOwnBucket",
              "Effect": "Allow",
              "Principal": { "AWS": "arn:aws:iam::210987654321:root" },
              "Action": "s3:ListBucket",
              "Resource": "arn:aws:s3:::clean-assets"
            },
            {
              "Sid": "ReadOwnObjects",
              "Effect": "Allow",
              "Principal": { "AWS": "arn:aws:iam::210987654321:root" },
              "Action": "s3:GetObject",
              "Resource": "arn:aws:s3:::clean-assets/*"
            }
          ]
        };

        var policyEl = document.getElementById("policy");
        var bucketEl = document.getElementById("expectedBucket");
        var intentEl = document.getElementById("intentionalPublic");
        var verdictBox = document.getElementById("verdictBox");
        var countsEl = document.getElementById("counts");
        var findingsEl = document.getElementById("findings");
        var reportEl = document.getElementById("report");
        var auditNote = document.getElementById("auditNote");
        var copyNote = document.getElementById("copyNote");
        var pitchNote = document.getElementById("pitchNote");

        /* ---------- helpers ---------- */

        function toArray(v) {
          if (v === undefined || v === null) return [];
          return Array.isArray(v) ? v : [v];
        }
        function asStrings(v) {
          return toArray(v).map(function (x) { return String(x); });
        }
        // Mask every 12-digit account ID: first 4 digits + "…"
        function mask(s) {
          return String(s).replace(/\d{12}/g, function (m) { return m.slice(0, 4) + "…"; });
        }
        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }
        function stmtLabel(stmt, idx) {
          var base = "Statement " + (idx + 1);
          if (stmt && typeof stmt.Sid === "string" && stmt.Sid) base += " (Sid: " + mask(stmt.Sid) + ")";
          return base;
        }
        function isPublicPrincipal(p) {
          if (p === "*") return true;
          if (p && typeof p === "object") {
            var keys = Object.keys(p);
            for (var i = 0; i < keys.length; i++) {
              var vals = asStrings(p[keys[i]]);
              for (var j = 0; j < vals.length; j++) if (vals[j] === "*") return true;
            }
          }
          return false;
        }
        function principalText(p) {
          if (p === undefined || p === null) return "(no Principal)";
          if (typeof p === "string") return mask(p);
          try { return mask(JSON.stringify(p)); } catch (e) { return mask(String(p)); }
        }
        function condEntries(cond) {
          var out = [];
          if (!cond || typeof cond !== "object") return out;
          Object.keys(cond).forEach(function (op) {
            var inner = cond[op];
            if (inner && typeof inner === "object") {
              Object.keys(inner).forEach(function (k) {
                out.push({ op: op, key: k, values: asStrings(inner[k]) });
              });
            }
          });
          return out;
        }
        var REAL_KEYS = { "aws:sourcevpc": 1, "aws:sourcevpce": 1, "aws:principalorgid": 1 };
        function analyzeConditions(entries) {
          var real = [], weak = [];
          entries.forEach(function (e) {
            var lk = e.key.toLowerCase();
            if (REAL_KEYS[lk]) real.push(e.key);
            else if (lk === "aws:sourcearn") {
              var specific = e.values.some(function (v) { return v.indexOf("arn:") === 0 && v.indexOf("*") === -1; });
              if (specific) real.push(e.key);
              else weak.push({ key: e.key, why: "its value contains a wildcard, so it can match any source and does not narrow who the grant reaches" });
            } else if (lk === "aws:referer") {
              weak.push({ key: e.key, why: "aws:Referer is a header any client can set for itself, so it does not limit who can reach the bucket" });
            }
          });
          return { real: real, weak: weak };
        }
        var OBJECT_ACTIONS = ["s3:getobject","s3:putobject","s3:deleteobject","s3:getobjectversion","s3:deleteobjectversion","s3:restoreobject","s3:getobjectacl","s3:putobjectacl","s3:getobjecttagging","s3:putobjecttagging"];
        var BUCKET_ACTIONS = ["s3:listbucket","s3:getbucketlocation","s3:listbucketversions","s3:getbucketacl","s3:getbucketpolicy","s3:getbucketcors"];
        function grantsWrite(actions) {
          return actions.some(function (a) {
            var l = a.toLowerCase();
            return l === "*" || l === "s3:*" || l.indexOf("s3:put") === 0 || l.indexOf("s3:delete") === 0 || l === "s3:createbucket";
          });
        }
        function parseBucket(res) {
          var prefix = "arn:aws:s3:::";
          if (typeof res !== "string" || res.indexOf(prefix) !== 0) return null;
          var rest = res.slice(prefix.length);
          var slash = rest.indexOf("/");
          return { bucket: slash === -1 ? rest : rest.slice(0, slash), isObject: slash !== -1, rest: rest };
        }

        /* ---------- audit ---------- */

        function audit(raw, expectedBucket, intentional) {
          var findings = [];
          function add(level, code, loc, msg) { findings.push({ level: level, code: code, loc: loc, msg: msg }); }

          var doc;
          try {
            doc = JSON.parse(raw);
          } catch (err) {
            var msg = err && err.message ? err.message : String(err);
            var posMatch = /position\s+(\d+)/i.exec(msg);
            return {
              verdict: "NOT PARSED", cls: "bad",
              sub: "The pasted text is not valid JSON, so nothing in it was audited. Fix the JSON and run the audit again.",
              findings: [{ level: "BLOCKER", code: "NOT PARSED", loc: "Whole input",
                msg: "JSON parser error: " + msg + (posMatch ? " (position " + posMatch[1] + ")" : " (the parser did not report a position)") + ". The auditor never guesses at broken input." }],
              parsed: false
            };
          }
          if (!doc || typeof doc !== "object" || Array.isArray(doc)) {
            return { verdict: "NOT PARSED", cls: "bad",
              sub: "The JSON parsed, but the top level is not a policy object, so nothing was audited.",
              findings: [{ level: "BLOCKER", code: "NOT PARSED", loc: "Whole input", msg: "Top-level JSON value is not an object with Version and Statement fields." }],
              parsed: false };
          }

          // (7) Version
          if (doc.Version === undefined) {
            add("WARNING", "VERSION", "Policy root", "The Version field is missing. Set \"Version\": \"2012-10-17\" — an older or absent version changes how some condition keys behave.");
          } else if (String(doc.Version) !== "2012-10-17") {
            add("WARNING", "VERSION", "Policy root", "Version is \"" + mask(doc.Version) + "\", not \"2012-10-17\". Use the current policy language version unless you have a specific reason not to.");
          }

          var stmts = doc.Statement;
          if (stmts === undefined) {
            add("WARNING", "STRUCTURE", "Policy root", "No Statement field found — this policy grants and denies nothing as written.");
            stmts = [];
          } else if (!Array.isArray(stmts)) {
            add("WARNING", "STRUCTURE", "Policy root", "Statement is a single object, not an array. S3 expects an array of statements; wrap it in [ ].");
            stmts = [stmts];
          }

          stmts.forEach(function (stmt, idx) {
            var loc = stmtLabel(stmt, idx);
            if (!stmt || typeof stmt !== "object") {
              add("WARNING", "STRUCTURE", loc, "This statement is not a JSON object and was not audited further.");
              return;
            }
            var effect = typeof stmt.Effect === "string" ? stmt.Effect : "";
            var isAllow = effect.toLowerCase() === "allow";
            var actions = asStrings(stmt.Action !== undefined ? stmt.Action : stmt.NotAction);
            var resources = asStrings(stmt.Resource !== undefined ? stmt.Resource : stmt.NotResource);
            var pub = isPublicPrincipal(stmt.Principal);
            var entries = condEntries(stmt.Condition);
            var cond = analyzeConditions(entries);
            var hasRealRestriction = cond.real.length > 0;

            /* (6) informational condition notes — any effect */
            entries.forEach(function (e) {
              var lk = e.key.toLowerCase();
              if (lk === "aws:principaltag" || lk.indexOf("principaltag") !== -1) {
                add("INFO", "CONDITION NOTE", loc, "Uses an aws:PrincipalTag condition (" + mask(e.key) + "). Tag-based scoping only bites if the tags are actually assigned and managed — worth a manual check, not a finding against the policy.");
              }
              if (lk === "aws:securetransport") {
                if (effect.toLowerCase() === "deny" && e.values.some(function (v) { return v.toLowerCase() === "false"; })) {
                  add("INFO", "POSITIVE", loc, "Deny with Bool aws:SecureTransport \"false\" is a good pattern: it blocks every non-TLS request to the bucket. Labelled INFO POSITIVE — this is protection, never a risk.");
                } else {
                  add("INFO", "CONDITION NOTE", loc, "An aws:SecureTransport condition is present (" + effect + ", values: " + mask(e.values.join(", ")) + "). Noted for the record.");
                }
              }
            });
            if (/requesterpays/i.test(JSON.stringify(stmt))) {
              add("INFO", "CONDITION NOTE", loc, "A requester-pays marker (s3:RequesterPays) is present in this statement. Requester-pays moves GET costs to the requester; it does not restrict who can read — noted as INFO only.");
            }

            if (!isAllow) return; // Deny statements are not exposure findings.

            var actionList = actions.length ? mask(actions.join(", ")) : "(no actions listed)";
            var resourceList = resources.length ? mask(resources.join(", ")) : "(no resources listed)";

            /* (1) + (3) + (8) public principal */
            var publicFindingMade = false;
            if (pub) {
              var weakNote = "";
              if (!hasRealRestriction && cond.weak.length) {
                weakNote = " The Condition present does not downgrade this: " + cond.weak.map(function (w) { return w.key + " — " + w.why; }).join("; ") + ".";
              }
              var onlyGet = actions.length > 0 && actions.every(function (a) { return a === "s3:GetObject"; });
              var allObjectResources = resources.length > 0 && resources.every(function (r) { var pb = parseBucket(r); return pb && pb.isObject; });
              if (hasRealRestriction) {
                add("WARNING", "RESTRICTED PUBLIC", loc,
                  "Effect Allow with a public Principal (" + principalText(stmt.Principal) + ") grants " + actionList + " on " + resourceList + ", but a Condition restricts it via " + cond.real.join(", ") + " — downgraded to WARNING RESTRICTED PUBLIC. The grant is only as tight as that condition; re-check it before applying.");
                publicFindingMade = true;
              } else if (intentional && onlyGet && allObjectResources && !grantsWrite(actions)) {
                add("WARNING", "INTENTIONAL PUBLIC", loc,
                  "Effect Allow with a public Principal (" + principalText(stmt.Principal) + ") grants " + actionList + " on " + resourceList + ", and you declared this bucket intentionally public. Read-only public access on object ARNs matches that declaration — graded WARNING INTENTIONAL PUBLIC instead of BLOCKER." + weakNote);
                publicFindingMade = true;
              } else {
                var writeNote = grantsWrite(actions)
                  ? " The granted actions include public WRITE access, which stays BLOCKER even for an intentional public website / asset bucket."
                  : "";
                add("BLOCKER", "PUBLIC PRINCIPAL", loc,
                  "Effect Allow with a public Principal (" + principalText(stmt.Principal) + ") grants " + actionList + " on " + resourceList + " to anyone on the internet, with no Condition that actually restricts it." + writeNote + weakNote);
                publicFindingMade = true;
              }
            }

            /* (2) wildcard actions */
            var fullWild = actions.some(function (a) { return a === "*" || a === "s3:*"; });
            var partialWild = !fullWild && actions.some(function (a) { return a.indexOf("*") !== -1; });
            var hasStarResource = resources.some(function (r) { return r === "*"; });
            if (fullWild) {
              if (pub && hasRealRestriction) {
                // already covered by the RESTRICTED PUBLIC warning above
              } else if (pub) {
                add("BLOCKER", "WILDCARD ACTION — PUBLIC", loc,
                  "Wildcard action (" + actionList + ") is granted to a public principal on " + resourceList + ". That is every S3 action, for everyone — BLOCKER.");
              } else if (hasStarResource) {
                add("BLOCKER", "WILDCARD ACTION — FULL SCOPE", loc,
                  "Wildcard action (" + actionList + ") granted to Principal " + principalText(stmt.Principal) + " on resource \"*\": every S3 action on every bucket and object in the account. The scope is total, so this is a BLOCKER even though the principal itself is specific.");
              } else {
                add("WARNING", "WILDCARD ACTION", loc,
                  "Wildcard action (" + actionList + ") granted to Principal " + principalText(stmt.Principal) + " on " + resourceList + ". The principal is specific, so this is not public — but it hands over every S3 action where a short list would do. Graded WARNING by scope.");
              }
            } else if (partialWild) {
              add("WARNING", "WILDCARD ACTION", loc,
                "Partial wildcard action in " + actionList + " granted to Principal " + principalText(stmt.Principal) + ". Wildcard prefixes quietly widen as AWS adds actions — name the actions you mean.");
            }

            /* (5a) wildcard resource */
            if (hasStarResource) {
              add("BLOCKER", "WILDCARD RESOURCE", loc,
                "Resource \"*\" on an Allow statement reaches every bucket and object, not just the one this policy is for. Principal: " + principalText(stmt.Principal) + "; actions: " + actionList + ". Name the bucket ARN and its /* object ARN instead.");
            }

            /* (5b) bucket mismatch + ineffective grants */
            resources.forEach(function (r) {
              var pb = parseBucket(r);
              if (!pb) return;
              if (expectedBucket && pb.bucket !== expectedBucket) {
                add("WARNING", "BUCKET MISMATCH", loc,
                  "Resource " + mask(r) + " names bucket \"" + mask(pb.bucket) + "\", but the expected bucket is \"" + mask(expectedBucket) + "\". Check for a copy-paste from another bucket's policy.");
              }
              var lowerActions = actions.map(function (a) { return a.toLowerCase(); });
              var objUsed = OBJECT_ACTIONS.filter(function (o) { return lowerActions.indexOf(o) !== -1; });
              var bucketUsed = BUCKET_ACTIONS.filter(function (b) { return lowerActions.indexOf(b) !== -1; });
              if (!pb.isObject && objUsed.length) {
                add("WARNING", "INEFFECTIVE GRANT", loc,
                  mask(objUsed.join(", ")) + " granted on the bare bucket ARN " + mask(r) + " (no /*) can never match an object — object actions only match object ARNs like " + mask("arn:aws:s3:::" + pb.bucket + "/*") + ". This grant silently does nothing.");
              }
              if (pb.isObject && bucketUsed.length) {
                add("WARNING", "INEFFECTIVE GRANT", loc,
                  mask(bucketUsed.join(", ")) + " granted on the object ARN " + mask(r) + " can never match — bucket-level actions only match the bare bucket ARN " + mask("arn:aws:s3:::" + pb.bucket) + ". This grant silently does nothing.");
              }
            });

            void publicFindingMade;
          });

          var blockers = findings.filter(function (f) { return f.level === "BLOCKER"; });
          var warnings = findings.filter(function (f) { return f.level === "WARNING"; });
          var publicBlocker = blockers.some(function (f) {
            return /PUBLIC|FULL SCOPE|WILDCARD RESOURCE/.test(f.code) || f.code === "PUBLIC PRINCIPAL";
          });

          var verdict, cls, sub;
          if (blockers.length) {
            verdict = publicBlocker ? "DO NOT APPLY — PUBLIC ACCESS" : "DO NOT APPLY";
            cls = "bad";
            sub = blockers.length + " blocker(s) must be fixed before this policy goes anywhere near a bucket.";
          } else if (warnings.length) {
            verdict = "APPLY WITH FIXES";
            cls = "warn";
            sub = "No blockers, but " + warnings.length + " warning(s) should be fixed or consciously accepted first.";
          } else {
            verdict = "SAFE TO APPLY";
            cls = "ok";
            sub = "No BLOCKER or WARNING findings in this policy. That means no structural public-access red flags in THIS policy — never proof the bucket is private.";
          }
          return { verdict: verdict, cls: cls, sub: sub, findings: findings, parsed: true };
        }

        /* ---------- rendering + report ---------- */

        function buildReport(result, expectedBucket, intentional) {
          var lines = [];
          lines.push("J-Dawgs S3 Bucket Policy Auditor — audit report");
          lines.push("Run locally in the browser on " + new Date().toLocaleString() + ". Nothing was uploaded.");
          lines.push("Expected bucket: " + (expectedBucket ? mask(expectedBucket) : "(not given)"));
          lines.push("Intentional public website / asset bucket: " + (intentional ? "yes" : "no"));
          lines.push("");
          lines.push("VERDICT: " + result.verdict);
          lines.push(result.sub);
          lines.push("");
          var b = result.findings.filter(function (f) { return f.level === "BLOCKER"; }).length;
          var w = result.findings.filter(function (f) { return f.level === "WARNING"; }).length;
          var i = result.findings.filter(function (f) { return f.level === "INFO"; }).length;
          lines.push("Findings: " + b + " BLOCKER, " + w + " WARNING, " + i + " INFO");
          lines.push("");
          if (!result.findings.length) {
            lines.push("No findings.");
          } else {
            result.findings.forEach(function (f, n) {
              lines.push((n + 1) + ". [" + f.level + " — " + f.code + "] " + f.loc);
              lines.push("   " + f.msg);
            });
          }
          lines.push("");
          lines.push("Scope: this report covers the pasted policy text only. It does not check bucket ACLs, Block Public Access settings, or other policies on the same bucket.");
          return lines.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-s3-bucket-policy-auditor',
  name: 'J-Dawgs S3 Bucket Policy Auditor',
  description: 'Audits a pasted S3 bucket policy anywhere — public principals, wildcard actions/resources, restricted-public downgrades, bucket/object ARN confusion — into one apply verdict (SAFE TO APPLY / APPLY WITH FIXES / DO NOT APPLY — PUBLIC ACCESS), account IDs masked. Console checks grade one setting inside',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
