'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Shaarli Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          '<?php /*',
          '{',
          '    "site_url": "http://links.example.net",',
          '    "login": "admin",',
          '    "password": "letmein",',
          '    "api_secret": "sk-12345",',
          '    "open_registration": true,',
          '    "public_links": true,',
          '    "debug": true,',
          '    "check_updates": true,',
          '    "data_dir_note": "chmod 777 the data folder if writes fail",',
          '    "timezone": "UTC",',
          '    this line is not a setting and will not parse',
          '}',
          '*/ ?>'
        ].join('\n');

        var HARDENED = [
          '<?php /*',
          '{',
          '    "site_url": "https://links.example.net",',
          '    "login": "jdawg",',
          '    "password_hash": "$2y$12$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy",',
          '    "api_secret": "a94f8c1e7b3d4902b6f5a8c0d1e2f3049586a7b8c9d0e1f2",',
          '    "open_registration": false,',
          '    "public_links": false,',
          '    "debug": false,',
          '    "check_updates": false,',
          '    "ban_after": 4,',
          '    "ban_duration": 1800,',
          '    "session_protection": true,',
          '    "timezone": "America/Chicago"',
          '}',
          '*/ ?>'
        ].join('\n');

        var input = document.getElementById('config-input');
        var verdictEl = document.getElementById('verdict');
        var countsEl = document.getElementById('counts');
        var findingsWrap = document.getElementById('findings-wrap');
        var findingsBody = document.getElementById('findings-body');
        var noFindings = document.getElementById('no-findings');
        var statusEl = document.getElementById('audit-status');
        var copyStatus = document.getElementById('copy-status');
        var reportTextEl = document.getElementById('report-text');
        var reportJsonEl = document.getElementById('report-json');

        document.getElementById('pre-risky').textContent = RISKY;
        document.getElementById('pre-hardened').textContent = HARDENED;

        var lastResult = null;

        function isTruthy(v){
          if (v === true) return true;
          if (typeof v === 'number') return v !== 0;
          if (typeof v === 'string'){
            var s = v.trim().toLowerCase();
            return s === 'true' || s === 'yes' || s === 'on' || s === '1' || s === 'enabled';
          }
          return false;
        }
        function isFalsySet(v){
          if (v === false) return true;
          if (typeof v === 'number') return v === 0;
          if (typeof v === 'string'){
            var s = v.trim().toLowerCase();
            return s === 'false' || s === 'no' || s === 'off' || s === '0' || s === 'disabled' || s === '';
          }
          return false;
        }

        function parseValue(raw){
          var v = raw.trim();
          if (v.charAt(v.length - 1) === ',' || v.charAt(v.length - 1) === ';') v = v.slice(0, -1).trim();
          if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))){
            return v.slice(1, -1);
          }
          var low = v.toLowerCase();
          if (low === 'true') return true;
          if (low === 'false') return false;
          if (low === 'null' || low === 'none') return null;
          if (/^-?\d+(\.\d+)?$/.test(v)) return parseFloat(v);
          return v;
        }

        function parseLine(line){
          var t = line.trim();
          if (t === '') return { kind: 'blank' };
          if (/^<\?php/.test(t) || /^\?>$/.test(t)) return { kind: 'structural' };
          if (/^\/\*.*\*\/\s*\?>?$/.test(t) || /^\/\*$/.test(t) || /^\*\/\s*\?>?$/.test(t)) return { kind: 'structural' };
          if (/^[\{\}\[\]],?$/.test(t)) return { kind: 'structural' };
          if (/^\/\//.test(t) || /^#/.test(t) || /^\*/.test(t)) return { kind: 'comment' };
          var m;
          m = t.match(/^define\s*\(\s*['"]([^'"]+)['"]\s*,\s*(.+)\)\s*;?$/);
          if (m) return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          m = t.match(/^\$[A-Za-z_]\w*\s*\[\s*['"]([^'"]+)['"]\s*\]\s*=\s*(.+)$/);
          if (m) return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          m = t.match(/^"([^"]+)"\s*:\s*(.+)$/);
          if (m){
            if (/^\{\s*,?$/.test(m[2].trim())) return { kind: 'section', key: m[1] };
            return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          }
          m = t.match(/^'([^']+)'\s*=>\s*(.+)$/);
          if (m){
            if (/^(array\s*\(|\{)/.test(m[2].trim())) return { kind: 'section', key: m[1] };
            return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          }
          m = t.match(/^\$([A-Za-z_]\w*)\s*=\s*(.+)$/);
          if (m) return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          m = t.match(/^([A-Za-z_][\w.\-]*)\s*[:=]\s*(.+)$/);
          if (m) return { kind: 'setting', key: m[1], value: parseValue(m[2]) };
          return { kind: 'unparsed' };
        }

        var COMMON_SECRETS = ['password','password123','password1','admin','admin123','letmein','qwerty','123456','12345678','secret','changeme','change-me','default','test','test123','example','demo','shaarli','bookmark','root','master'];
        var SECRET_KEY = /(pass(word)?|passwd|pwd|secret|api[-_]?key|apikey|api[-_]?token|access[-_]?token|auth[-_]?token|private[-_]?key|salt|hash)/i;
        var PERM_RE = /(chmod\s+0?777|chmod\s+0?666|\b0777\b|\b0666\b|\b777\s+permissions|world[- ]writable|permissions?\s*[:=]\s*0?777)/i;

        function audit(text){
          var lines = text.split(/\r?\n/);
          var findings = [];
          var settings = [];
          var notParsed = [];
          var throttleSeen = false;

          function add(sev, line, key, msg){
            findings.push({ severity: sev, line: line, key: key, message: msg });
          }

          lines.forEach(function(raw, idx){
            var n = idx + 1;
            if (PERM_RE.test(raw)){
              add('HIGH', n, '—', 'Permissive file-permission hint in the pasted text (chmod 777 / world-writable style). World-writable config or data files let any local account — or any other compromised service — rewrite them. Restrict ownership and permissions instead (for example 750 on directories, 640 on files, owned by the web user).');
            }
            var p = parseLine(raw);
            if (p.kind === 'unparsed'){
              notParsed.push(n);
              add('LOW', n, '—', 'NOT PARSED: this line is not a recognizable key/value setting, comment, or structural line (' + raw.trim().length + ' characters). The auditor skipped it — if it was meant to be a setting, the server may be silently ignoring it too. Fix or remove the line.');
            }
            if (p.kind !== 'setting') return;
            var key = p.key, lk = key.toLowerCase(), val = p.value;
            settings.push({ key: key, line: n });

            /* Secrets — report key, line, and length only. Never the value. */
            if (SECRET_KEY.test(lk) && val !== null && typeof val !== 'object'){
              var sval = String(val);
              var len = sval.length;
              var isPasswordKey = /(pass(word)?|passwd|pwd)/.test(lk);
              var looksHashed = /^\$(2y|2a|2b|argon2)/.test(sval) || (lk.indexOf('hash') !== -1 && len >= 32);
              if (len === 0){
                add('HIGH', n, key, 'Secret setting is empty (length 0). An empty password or API secret is no protection at all. Set a long, unique value.');
              } else if (isPasswordKey && !looksHashed){
                add('CRITICAL', n, key, 'Password appears to be stored in plaintext (length ' + len + '). Anyone who reads this file owns the account. Store only a strong password hash (bcrypt/Argon2) and treat this value as compromised.');
              } else if (COMMON_SECRETS.indexOf(sval.toLowerCase()) !== -1 || /^(your[-_ ]|replace[-_ ]?me|xxx+|todo|placeholder)/i.test(sval)){
                add('CRITICAL', n, key, 'Secret is a well-known example or placeholder value (length ' + len + '). Anyone who has read the same example has this credential. Replace it with a long, unique, randomly generated value.');
              } else if (len < 8){
                add('CRITICAL', n, key, 'Secret is very short (length ' + len + '). Short secrets fall to guessing almost immediately. Use at least 32 random characters for API secrets and keys.');
              } else if (len < 16){
                add('HIGH', n, key, 'Secret is short (length ' + len + '). Use at least 32 random characters for API secrets and keys.');
              } else if (len < 32){
                add('MEDIUM', n, key, 'Secret is on the short side (length ' + len + '). 32 or more random characters is the safe target for API secrets and keys.');
              }
            }

            /* Open registration / public access */
            if (/(open[-_]?registration|allow[-_]?registration|enable[-_]?registration|registration[-_]?open|public[-_]?registration|signups?)/.test(lk) && isTruthy(val)){
              add('HIGH', n, key, 'Open registration is enabled: anyone who can reach the page can create an account. Turn registration off unless this instance is deliberately public, and create accounts by hand instead.');
            }
            if (/open[-_]?shaarli/.test(lk) && isTruthy(val)){
              add('HIGH', n, key, 'Open mode is enabled: visitors can add links without an account. Turn it off on any instance that is not a deliberate public board.');
            }
            if (/(public[-_]?links?|default[-_]?public|make[-_]?public|guest[-_]?access|anonymous[-_]?access|public[-_]?access)/.test(lk) && isTruthy(val)){
              add('HIGH', n, key, 'Public link access is enabled: bookmarks are visible without logging in. If any link is private — internal hosts, tokens in URLs, personal notes — it is exposed. Default links to private and publish deliberately.');
            }
            if (/(private[-_]?links?|default[-_]?private|require[-_]?login|force[-_]?login|login[-_]?required)/.test(lk) && isFalsySet(val)){
              add('HIGH', n, key, 'A privacy/login setting is switched off here, which makes links public or drops the login requirement. Switch it back on so bookmarks stay behind the login.');
            }

            /* http-only URL */
            if (typeof val === 'string' && /^http:\/\//i.test(val.trim())){
              add('HIGH', n, key, 'This URL uses plain http://. Logins, session cookies, and every bookmark cross the network unencrypted and can be intercepted or altered. Serve the site over https:// (for example behind a TLS reverse proxy) and update this URL.');
            }

            /* Debug mode */
            if (/(debug|dev[-_]?mode|display[-_]?errors|development)/.test(lk) && (isTruthy(val) || (typeof val === 'string' && /e_all/i.test(val)))){
              add('HIGH', n, key, 'Debug/development mode is on. Debug output leaks file paths, settings, and internals to anyone who can trigger an error. Turn it off in production.');
            }

            /* Update checks / leaking privacy settings */
            if (/(check[-_]?updates?|updates?[-_]?check|auto[-_]?update|telemetry|send[-_]?stats|usage[-_]?stats|phone[-_]?home|analytics)/.test(lk) && isTruthy(val)){
              add('MEDIUM', n, key, 'An update-check or reporting feature is on: the server phones home on a schedule, disclosing that this instance exists, its address, and what it runs. Turn it off and check for updates yourself on your own schedule.');
            }
            if (/hide[-_]?timestamps/.test(lk) && isFalsySet(val)){
              add('LOW', n, key, 'Timestamps are not hidden on public views, which leaks when links were saved and builds a picture of the owner\u2019s habits. Hide timestamps if any part of the instance is public.');
            }

            /* Login throttling / ban settings */
            if (/(ban|throttl|lockout|brute|login[-_]?attempts?|failed[-_]?login|rate[-_]?limit)/.test(lk)){
              throttleSeen = true;
              if (isFalsySet(val)){
                add('HIGH', n, key, 'A login throttling / ban setting is present but switched off (value 0 or false). Password guessing against the login is unthrottled. Enable banning after a handful of failed attempts.');
              }
            }
          });

          if (!throttleSeen){
            add('MEDIUM', null, '—', 'No login throttling or ban setting appears anywhere in this config. Without a ban-after-failed-attempts setting, the login page accepts unlimited password guesses. Add and enable one (for example ban_after plus ban_duration).');
          }

          var order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
          findings.sort(function(a, b){
            if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
            return (a.line || 0) - (b.line || 0);
          });

          var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
          findings.forEach(function(f){ counts[f.severity]++; });

          var verdict, vclass;
          if (counts.CRITICAL > 0 || counts.HIGH > 0){ verdict = 'DO NOT DEPLOY'; vclass = 'bad'; }
          else if (findings.length > 0){ verdict = 'DEPLOY WITH FIXES'; vclass = 'mid'; }
          else { verdict = 'SAFE TO DEPLOY'; vclass = 'good'; }

          return {
            verdict: verdict, vclass: vclass, findings: findings, counts: counts,
            totalLines: lines.length, parsedSettings: settings.length, notParsed: notParsed
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-shaarli-server-config-safety-auditortm',
  name: 'J-Dawgs Shaarli Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Shaarli bookmark-manager config offline into one deploy verdict — secrets by key/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
