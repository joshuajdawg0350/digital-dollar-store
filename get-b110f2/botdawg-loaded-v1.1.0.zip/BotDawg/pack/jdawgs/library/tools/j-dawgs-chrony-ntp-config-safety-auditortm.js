'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Chrony NTP Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "# Risky example - a config that should NOT be deployed.",
          "# One source, unbounded stepping, wide-open server, impossible minsources.",
          "server time1.example.net",
          "makestep 1 -1",
          "allow 0.0.0.0/0",
          "minsources 3",
          "rtcsync"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "# Clean example - a careful client-only config.",
          "driftfile /var/lib/chrony/drift",
          "makestep 1 3",
          "rtcsync",
          "maxupdateskew 100.0",
          "pool 0.pool.ntp.org iburst",
          "pool 1.pool.ntp.org iburst",
          "pool 2.pool.ntp.org iburst",
          "pool 3.pool.ntp.org iburst"
        ].join("\n");

        // Directives this audit recognises. Anything else is reported
        // NOT EVALUATED by name - never silently ignored.
        var KNOWN = {};
        ("server pool peer refclock makestep rtcsync rtcfile rtconutc rtcautotrim rtcdevice " +
         "driftfile hwclockfile maxupdateskew minsources maxsources local allow deny " +
         "bindaddress bindcmdaddress bindacqaddress cmdallow cmddeny cmdport port acquisitionport " +
         "logdir log logchange logbanner dumpdir pidfile user confdir sourcedir leapsectz leapseclist " +
         "stratumweight maxdistance maxdistancesamples maxjitter minsamples maxsamples combinelimit " +
         "authselectmode fallbackdrift initstepslew maxslewrate corrtimepoch mailonchange manual " +
         "noclientlog clientlog clientloglimit ratelimit cmdratelimit lock_all sched_priority " +
         "maxlockmemory ntsservercert ntsdumpdir nosystemcert systemcert ntsprocesses ptpport dscp " +
         "hwtimestamp selectopts reselection smoothmode activity checkinterval ntpport").split(" ")
          .forEach(function (d) { KNOWN[d] = true; });

        // Directives whose values are secret material. Flagged by name and
        // line only - the value is never copied into any output.
        var SECRET = {};
        ("keyfile commandkey password passwd secret keys ntsserverkey").split(" ")
          .forEach(function (d) { SECRET[d] = true; });

        function isNumber(s) { return s !== undefined && s !== "" && !isNaN(Number(s)); }

        // Classify an allow/cmdallow argument. Returns {kind, label}.
        function classifyScope(tokens) {
          if (tokens.length < 2) return { kind: "open", label: "no subnet given" };
          var arg = tokens[1];
          var low = arg.toLowerCase();
          if (low === "all") return { kind: "open", label: "all" };
          var slash = arg.indexOf("/");
          if (slash >= 0) {
            var prefix = parseInt(arg.slice(slash + 1), 10);
            var isV6 = arg.indexOf(":") >= 0;
            if (!isNaN(prefix)) {
              if (prefix === 0) return { kind: "open", label: arg };
              if (!isV6 && prefix <= 16) return { kind: "broad", label: arg };
              if (isV6 && prefix <= 48) return { kind: "broad", label: arg };
            }
            return { kind: "narrow", label: arg };
          }
          return { kind: "narrow", label: arg };
        }

        function audit(text) {
          var findings = [];       // {severity, line, directive, message, fix, malformed}
          var notEvaluated = [];   // {line, name}
          var sources = [];        // {type, host, line, iburst, prefer, nts}
          var seenSources = {};    // "type host" -> first line
          var state = {
            makestepSeen: false,
            driftfileSeen: false,
            maxupdateskewSeen: false,
            allowCount: 0,
            bindSeen: false,
            minsources: null,      // {value, line}
            contentLines: 0
          };

          function add(severity, line, directive, message, fix, malformed) {
            findings.push({
              severity: severity, line: line, directive: directive,
              message: message, fix: fix || "", malformed: !!malformed
            });
          }

          var rawLines = text.split(/\r?\n/);
          for (var i = 0; i < rawLines.length; i++) {
            var lineNo = i + 1;
            var raw = rawLines[i];
            // Comments: everything from the first # or ; is a comment.
            var cut = raw.length;
            var hashIdx = raw.indexOf("#");
            var semiIdx = raw.indexOf(";");
            if (hashIdx >= 0 && hashIdx < cut) cut = hashIdx;
            if (semiIdx >= 0 && semiIdx < cut) cut = semiIdx;
            var trimmed = raw.slice(0, cut).trim();
            if (trimmed === "") continue;
            var tokens = trimmed.split(/\s+/);
            var name = tokens[0].toLowerCase();

            if (!/^[a-z][a-z0-9_-]*$/.test(name)) {
              state.contentLines++;
              add("WARNING", lineNo, tokens[0],
                "This line could not be understood as a chrony directive, so it was excluded from the audit. chronyd would reject or ignore it too - check it by hand.",
                "Fix the line so it is a valid directive, or remove it.", true);
              continue;
            }
            state.contentLines++;

            if (SECRET[name]) {
              add("WARNING", lineNo, name,
                "This line references secret material (" + name + "). The value is deliberately not shown in this report. Anyone who can read this config file may be able to read the secret too.",
                "Store the config and any key file with restricted permissions (readable only by the chrony service account), and rotate the secret if this file has been shared.");
              continue;
            }

            if (!KNOWN[name]) {
              notEvaluated.push({ line: lineNo, name: name });
              continue;
            }

            if (name === "server" || name === "pool" || name === "peer" || name === "refclock") {
              if (tokens.length < 2) {
                add("WARNING", lineNo, name,
                  "A \"" + name + "\" line with no address names no time source at all, so it was excluded from the source count.",
                  "Give the " + name + " directive the address it should use, or delete the line.", true);
                continue;
              }
              var host = tokens[1];
              var opts = {};
              tokens.slice(2).forEach(function (t) { opts[t.toLowerCase()] = true; });
              var src = {
                type: name, host: host, line: lineNo,
                iburst: !!opts.iburst, prefer: !!opts.prefer, nts: !!opts.nts
              };
              var dupKey = name + " " + host.toLowerCase();
              if (seenSources[dupKey] !== undefined) {
                add("WARNING", lineNo, name,
                  "Duplicate source: \"" + name + " " + host + "\" already appears on line " + seenSources[dupKey] + " and again on line " + lineNo + ". The same source counted twice can skew source selection and wastes a slot that could hold an independent check.",
                  "Remove one of the two lines (line " + seenSources[dupKey] + " or line " + lineNo + "), and replace it with a different, independent source if you want the extra redundancy.");
              } else {
                seenSources[dupKey] = lineNo;
              }
              sources.push(src);
              if (name !== "refclock") {
                if (!src.iburst) {
                  add("INFO", lineNo, name,
                    "Source " + host + " has no iburst. Without it, chronyd polls slowly at first, so the clock takes noticeably longer to settle after boot or a network outage.",
                    "Add iburst to the line unless you have a specific reason to avoid the initial burst of polls.");
                }
                if (src.prefer) {
                  add("INFO", lineNo, name,
                    "Source " + host + " is flagged prefer, so chronyd will favour it over the others. That is fine while it is healthy, but a preferred source that goes wrong has more influence before it is outvoted.",
                    "Keep prefer only on a source you actively trust and monitor.");
                }
              }
              continue;
            }

            if (name === "makestep") {
              state.makestepSeen = true;
              if (tokens.length < 3 || !isNumber(tokens[1]) || !isNumber(tokens[2])) {
                add("WARNING", lineNo, name,
                  "This makestep line does not carry two numbers (threshold and update limit), so the step bound could not be evaluated and the line was excluded.",
                  "Write it in the form: makestep <threshold-seconds> <max-updates>, for example makestep 1 3.", true);
                continue;
              }
              var limit = Number(tokens[2]);
              if (limit < 0) {
                add("WARNING", lineNo, name,
                  "makestep " + tokens[1] + " " + tokens[2] + " lets chronyd step the clock - jump it instantly to a new time - at any point, forever, with no limit on how late in the run it can happen. A stepped clock can break logs, TLS sessions, cron jobs, database ordering, and anything that assumes time never jumps.",
                  "Bound it: allow steps only during the first few updates after start, for example makestep 1 3. After that, chronyd slews (adjusts gradually) instead of jumping.");
              } else if (limit >= 1000) {
                add("WARNING", lineNo, name,
                  "makestep's update limit here is " + tokens[2] + ", which is so large that in practice the clock can still be stepped at almost any time. The stepping risk is the same as an unbounded makestep: sudden jumps that break anything assuming time moves smoothly.",
                  "Use a small limit so steps can only happen right after start, for example makestep 1 3.");
              } else {
                add("INFO", lineNo, name,
                  "makestep is bounded: the clock may be stepped only within the first " + tokens[2] + " update(s) after start. After that, corrections are slewed gradually. This is the safe pattern.",
                  "");
              }
              continue;
            }

            if (name === "minsources") {
              if (tokens.length < 2 || !isNumber(tokens[1])) {
                add("WARNING", lineNo, name,
                  "This minsources line has no readable number, so it could not be checked against the source count and was excluded.",
                  "Write it as a plain count, for example: minsources 2", true);
                continue;
              }
              state.minsources = { value: parseInt(tokens[1], 10), line: lineNo };
              continue;
            }

            if (name === "local") {
              var stratum = 10; // chrony's default when no stratum is given
              var stratumGiven = false;
              for (var t = 1; t < tokens.length - 1; t++) {
                if (tokens[t].toLowerCase() === "stratum" && isNumber(tokens[t + 1])) {
                  stratum = parseInt(tokens[t + 1], 10);
                  stratumGiven = true;
                }
              }
              if (stratum <= 10) {
                add("WARNING", lineNo, name,
                  "The local directive presents this machine's own unsynchronised clock to others as a stratum " + stratum + " time source" + (stratumGiven ? "" : " (stratum 10 is the default when none is written)") + ". Stratum " + stratum + " looks like a believable source, so clients may trust a clock that is drifting free with nothing correcting it.",
                  "If this machine must serve time while unsynchronised, use a high stratum (for example local stratum 14) so clients treat it as a last resort, or remove the local directive entirely.");
              } else {
                add("INFO", lineNo, name,
                  "The local directive is set at stratum " + stratum + ", high enough that clients will treat this unsynchronised clock as a last resort only. That is the cautious setting.",
                  "");
              }
              continue;
            }

            if (name === "allow") {
              state.allowCount++;
              var sc = classifyScope(tokens);
              if (sc.kind === "open") {
                add("BLOCKER", lineNo, name,
                  "This allow line (" + (tokens.length < 2 ? "allow with nothing after it" : "allow " + sc.label) + ") opens the NTP server to everyone. This machine would answer time requests from the whole internet, which invites abuse - open NTP servers are routinely used to amplify denial-of-service attacks - and exposes it to constant scanning.",
                  "Restrict it to the networks that actually need time from this machine, for example allow 192.168.1.0/24 - or delete the allow line entirely if nothing else should be served.");
              } else if (sc.kind === "broad") {
                add("WARNING", lineNo, name,
                  "This allow line opens the NTP server to a broad subnet: " + sc.label + ". That is a very large number of machines allowed to query this server.",
                  "Narrow " + sc.label + " to the smallest subnet that covers the machines which genuinely need time from this server.");
              } else {
                add("INFO", lineNo, name,
                  "This allow line limits NTP service to " + sc.label + ". Only that scope can use this machine as a time server.",
                  "");
              }
              continue;
            }

            if (name === "cmdallow") {
              var cc = classifyScope(tokens);
              if (cc.kind === "open" || cc.kind === "broad") {
                add("WARNING", lineNo, name,
                  "cmdallow opens chronyd's command interface - the channel used to reconfigure and control the daemon - to " + (cc.kind === "open" ? "everyone" : "the broad subnet " + cc.label) + ". That is remote control of the clock, not just time queries.",
                  "Restrict cmdallow to the specific management hosts that need it, or remove it so the command interface stays local-only.");
              } else {
                add("INFO", lineNo, name,
                  "cmdallow limits the command interface to " + cc.label + ".",
                  "");
              }
              continue;
            }

            if (name === "bindaddress" || name === "bindcmdaddress" || name === "bindacqaddress") {
              state.bindSeen = true;
              add("INFO", lineNo, name,
                name + " is set, so chronyd binds that service to a specific address instead of every local address. Binding deliberately is the tighter posture.",
                "");
              continue;
            }

            if (name === "rtcsync") {
              add("INFO", lineNo, name,
                "rtcsync is present: the hardware real-time clock is kept in step with the system clock, so the machine starts closer to correct time after a reboot.",
                "");
              continue;
            }

            if (name === "driftfile") { state.driftfileSeen = true; continue; }
            if (name === "maxupdateskew") { state.maxupdateskewSeen = true; continue; }

            if (name === "logdir" || name === "log" || name === "logchange") {
              add("INFO", lineNo, name,
                "Logging is configured here (" + name + "). After any config change, confirm the log location is writable by the chrony service account, or chronyd may fail to start or run silently.",
                "");
              continue;
            }

            if (name === "sourcedir" || name === "confdir") {
              add("INFO", lineNo, name,
                name + " is set: chronyd may load further configuration or sources from files that are not in the pasted text. Every count in this report covers only what was pasted.",
                "Audit the files named by " + name + " as well before deploying.");
              continue;
            }

            // Any other recognised directive: evaluated as present, no
            // specific check applies.
          }

          // ---- Whole-file checks -------------------------------------------
          var ntpSources = sources.filter(function (s) { return s.type !== "refclock"; });

          if (sources.length === 0) {
            add("BLOCKER", null, "(whole file)",
              "No time sources at all: this config names no server, pool, peer, or reference clock. chronyd would start with nothing to synchronise to, and the clock would drift uncorrected.",
              "Add at least three independent sources, for example three pool lines with iburst.");
          } else if (sources.length === 1) {
            add("WARNING", sources[0].line, sources[0].type,
              "Only one time source is configured (" + sources[0].host + ", line " + sources[0].line + "). That is a single point of failure: if it goes wrong, nothing can outvote it - a false ticker cannot be detected because there is no second opinion to cross-check against.",
              "Add at least two more independent sources so a bad one can be outvoted.");
          }

          var ntsCount = sources.filter(function (s) { return s.nts; }).length;
          if (ntsCount > 0) {
            add("INFO", null, "(whole file)",
              "NTS (Network Time Security) is in use: " + ntsCount + " of " + sources.length + " source(s) authenticate their time answers, so a network attacker cannot quietly feed this machine false time from those sources.",
              "");
          }

          if (state.minsources) {
            if (state.minsources.value > sources.length) {
              add("BLOCKER", state.minsources.line, "minsources",
                "minsources is " + state.minsources.value + " but only " + sources.length + " source(s) are configured: " + state.minsources.value + " > " + sources.length + ". chronyd requires at least minsources sources before it will start disciplining the clock, and this config can never reach that number - synchronisation can never begin.",
                "Either lower minsources to " + sources.length + " or below, or add sources until at least " + state.minsources.value + " are configured.");
            } else {
              add("INFO", state.minsources.line, "minsources",
                "minsources is " + state.minsources.value + " and " + sources.length + " source(s) are configured (" + state.minsources.value + " <= " + sources.length + "), so the requirement can be met.",
                "");
            }
          }

          if (!state.makestepSeen) {
            add("WARNING", null, "(whole file)",
              "No makestep directive: there is no explicit step bound in this file. Nothing here says whether, or for how long after start, chronyd may jump the clock instead of slewing it gradually - the behaviour is left to defaults rather than a decision someone made.",
              "Add an explicit bounded makestep, for example makestep 1 3, so stepping is a deliberate, limited choice.");
          }

          if (!state.driftfileSeen) {
            add("INFO", null, "(whole file)",
              "No driftfile: the clock's drift rate is not saved to disk, so it is relearned from scratch on every boot and early synchronisation after each restart is slower and rougher.",
              "Add a driftfile line pointing at a writable path, for example driftfile /var/lib/chrony/drift.");
          }
          if (!state.maxupdateskewSeen) {
            add("INFO", null, "(whole file)",
              "No maxupdateskew: chronyd has no stated limit on how large a frequency error it will accept when updating its drift estimate, so a bad measurement can skew the learned drift.",
              "Consider adding maxupdateskew (a commonly used value is 100.0) to bound the drift estimate.");
          }

          if (state.allowCount === 0) {
            add("INFO", null, "(whole file)",
              "No allow lines at all: this NTP server serves nobody by default. That is the client-only posture - the machine takes time from its sources but offers time to no one, which is the right default for most machines.",
              "");
          }

          if (!state.bindSeen) {
            add("INFO", null, "(whole file)",
              "No bindaddress or bindcmdaddress: chronyd uses its defaults for which addresses it listens and accepts commands on. With no allow lines the service is still closed to others, but on a multi-homed machine an explicit bindaddress makes the posture deliberate.",
              "");
          }

          var order = { "BLOCKER": 0, "WARNING": 1, "INFO": 2 };
          findings.sort(function (a, b) {
            var d = order[a.severity] - order[b.severity];
            if (d !== 0) return d;
            var la = a.line === null ? 100000 : a.line;
            var lb = b.line === null ? 100000 : b.line;
            return la - lb;
          });

          var counts = { blocker: 0, warning: 0, info: 0, malformed: 0 };
          findings.forEach(function (f) {
            if (f.severity === "BLOCKER") counts.blocker++;
            else if (f.severity === "WARNING") counts.warning++;
            else if (f.severity === "INFO") counts.info++;
            if (f.malformed) counts.malformed++;
          });

          var verdict = counts.blocker > 0 ? "DO NOT DEPLOY"
            : counts.warning > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";

          return {
            verdict: verdict,
            counts: counts,
            findings: findings,
            notEvaluated: notEvaluated,
            sources: sources,
            ntpSources: ntpSources,
            empty: state.contentLines === 0
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-chrony-ntp-config-safety-auditortm',
  name: 'J-Dawgs Chrony NTP Config Safety Auditor',
  description: 'chronyd checks need the binary on a host and stop at validity; ours grades a pasted chrony.conf anywhere — source redundancy, step bounds, server exposure — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
