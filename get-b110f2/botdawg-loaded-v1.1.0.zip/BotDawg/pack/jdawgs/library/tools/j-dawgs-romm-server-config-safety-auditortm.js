'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs RomM Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (fake values only) ---------- */
      var RISKY_EXAMPLE = [
        "# RomM .env - RISKY worked example (fake values, do not use)",
        "DB_HOST=romm-db",
        "DB_PORT=3306",
        "DB_NAME=romm",
        "DB_USER=romm-user",
        "DB_PASSWD=romm123",
        "DB_ROOT_PASSWD=rootpass456",
        "ROMM_BASE_PATH=/",
        "ROMM_AUTH_SECRET_KEY=change-me-example-key",
        "IGDB_CLIENT_ID=fakeigdbclientid0001",
        "IGDB_CLIENT_SECRET=igdbsecretvalue789",
        "OIDC_ENABLED=true",
        "OIDC_PROVIDER=custom",
        "OIDC_CLIENT_ID=romm-web",
        "ENABLE_RESCAN_ON_FILESYSTEM_CHANGE=true",
        "RESCAN_ON_FILESYSTEM_CHANGE_DELAY=0"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# RomM .env - HARDENED worked example (fake values, do not use)",
        "DB_HOST=romm-db",
        "DB_PORT=3306",
        "DB_NAME=romm",
        "DB_USER=romm-user",
        "DB_PASSWD=Kx9!vR2#mQ7zLp4Wd8Hs",
        "DB_ROOT_PASSWD=Tr5&nB8@kJ3xQp9Wz2Vc",
        "ROMM_BASE_PATH=/romm/library",
        "ROMM_AUTH_SECRET_KEY=9f2c7a1e4b8d0f3a5c6e7d9b1a2f4c6e8d0a1b3c5e7f9a2b4c6d8e0f1a3b5c7d",
        "IGDB_CLIENT_ID=hardenedigdbclientid42",
        "IGDB_CLIENT_SECRET=Zx8Qw3Er7Ty2Ui5Op9As4Df6Gh",
        "OIDC_ENABLED=true",
        "OIDC_PROVIDER=custom",
        "OIDC_CLIENT_ID=romm-web",
        "OIDC_CLIENT_SECRET=Mnb6Vcx1Zaq2Wsx3Edc4Rfv5Tgb",
        "OIDC_REDIRECT_URI=https://romm.example.lan/auth/openid",
        "ENABLE_RESCAN_ON_FILESYSTEM_CHANGE=true",
        "RESCAN_ON_FILESYSTEM_CHANGE_DELAY=60"
      ].join("\n");

      /* ---------- Parsing ---------- */
      function parseEnv(text) {
        var entries = [], problems = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].replace(/^\s+|\s+$/g, "");
          if (!t || t.charAt(0) === "#") continue;
          if (t.indexOf("export ") === 0) t = t.slice(7).replace(/^\s+/, "");
          var eq = t.indexOf("=");
          if (eq < 1) { problems.push(lineNo); continue; }
          var key = t.slice(0, eq).replace(/\s+$/g, "");
          var val = t.slice(eq + 1).replace(/^\s+|\s+$/g, "");
          if (val.length >= 2) {
            var first = val.charAt(0), last = val.charAt(val.length - 1);
            if ((first === '"' && last === '"') || (first === "'" && last === "'")) val = val.slice(1, -1);
          }
          if (!/^[A-Za-z_][A-Za-z0-9_.]*$/.test(key)) { problems.push(lineNo); continue; }
          entries.push({ key: key, value: val, line: lineNo });
        }
        return { entries: entries, problems: problems, totalLines: lines.length };
      }

      function indexEntries(entries) {
        var map = {}, dupes = [];
        entries.forEach(function (e) {
          if (Object.prototype.hasOwnProperty.call(map, e.key)) dupes.push(e);
          map[e.key] = e; /* last value wins, like most env loaders */
        });
        return { map: map, dupes: dupes };
      }

      function isTruthy(v) { return /^(true|1|yes|on)$/i.test(v || ""); }
      function isFalsy(v) { return /^(false|0|no|off)$/i.test(v || ""); }

      var PLACEHOLDER_PATTERNS = ["example", "changeme", "change-me", "change_me", "change me",
        "placeholder", "your-", "your_", "your ", "insert-", "insert_", "replace", "todo",
        "xxxx", "secretkey", "secret-key", "secret_key", "romm-secret", "letmein", "defaultsecret"];
      function looksPlaceholder(v) {
        var s = (v || "").toLowerCase();
        for (var i = 0; i < PLACEHOLDER_PATTERNS.length; i++) {
          if (s.indexOf(PLACEHOLDER_PATTERNS[i]) !== -1) return true;
        }
        return false;
      }
      function charClasses(v) {
        var n = 0;
        if (/[a-z]/.test(v)) n++;
        if (/[A-Z]/.test(v)) n++;
        if (/[0-9]/.test(v)) n++;
        if (/[^A-Za-z0-9]/.test(v)) n++;
        return n;
      }
      function uniqueChars(v) {
        var seen = {};
        for (var i = 0; i < v.length; i++) seen[v.charAt(i)] = true;
        return Object.keys(seen).length;
      }
      function looksLikeRealSecret(v) {
        return v.length >= 16 && charClasses(v) >= 3 && !looksPlaceholder(v);
      }
      var CRED_KEY_RE = /(PASSWD|PASSWORD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|CREDENTIAL)/i;
      var TOKEN_SHAPE_RE = /^(ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|sk-[A-Za-z0-9_-]{16,}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN)/;

      /* ---------- The audit ----------
         PRIVACY INVARIANT: a finding object only ever carries severity, line,
         key, issue and fix. Secret VALUES are read to judge length/strength
         and are never copied into a finding, so they cannot be rendered. */
      function auditConfig(text) {
        var parsed = parseEnv(text);
        var entries = parsed.entries;
        var idx = indexEntries(entries);
        var map = idx.map;
        var findings = [];
        function add(severity, entry, key, issue, fix) {
          findings.push({
            severity: severity,
            line: entry ? entry.line : null,
            key: key,
            issue: issue,
            fix: fix
          });
        }
        function get(k) { return Object.prototype.hasOwnProperty.call(map, k) ? map[k] : null; }

        /* --- ROMM_AUTH_SECRET_KEY --- */
        var auth = get("ROMM_AUTH_SECRET_KEY");
        var authWeak = false, authWhy = "";
        if (!auth) {
          authWeak = true; authWhy = "it is missing";
          add("critical", null, "ROMM_AUTH_SECRET_KEY",
            "ROMM_AUTH_SECRET_KEY is not set anywhere in this config.",
            "RomM signs login sessions with this key. Generate a long random value (at least 32 characters) and set it before the server is reachable by anyone else.");
        } else if (auth.value.length === 0) {
          authWeak = true; authWhy = "it is empty";
          add("critical", auth, "ROMM_AUTH_SECRET_KEY",
            "ROMM_AUTH_SECRET_KEY is present but empty (value length 0).",
            "Set it to a freshly generated random value of at least 32 characters.");
        } else {
          var reasons = [];
          if (auth.value.length < 32) reasons.push("only " + auth.value.length + " characters long (minimum 32)");
          if (looksPlaceholder(auth.value)) reasons.push("an obvious example/placeholder value");
          if (reasons.length) {
            authWeak = true; authWhy = "it is " + reasons.join(" and ");
            add("critical", auth, "ROMM_AUTH_SECRET_KEY",
              "ROMM_AUTH_SECRET_KEY is " + reasons.join(" and ") + " (value length " + auth.value.length + ").",
              "Replace it with a freshly generated random secret of at least 32 characters, unique to this server. Anyone who has seen the public examples can guess a placeholder, and a short key is quick to brute-force.");
          } else if (uniqueChars(auth.value) < 10) {
            add("high", auth, "ROMM_AUTH_SECRET_KEY",
              "ROMM_AUTH_SECRET_KEY is long enough (value length " + auth.value.length + ") but built from very few distinct characters, so it is far weaker than its length suggests.",
              "Regenerate it from a proper random source so it uses a wide mix of characters.");
          }
        }

        /* --- OIDC --- */
        var oidcEnabledEntry = get("OIDC_ENABLED");
        var oidcOn = oidcEnabledEntry && isTruthy(oidcEnabledEntry.value);
        if (oidcOn) {
          var oidcSecret = get("OIDC_CLIENT_SECRET");
          if (!oidcSecret || oidcSecret.value.length === 0) {
            add("critical", oidcEnabledEntry, "OIDC_CLIENT_SECRET",
              "OIDC is enabled (OIDC_ENABLED is on) but OIDC_CLIENT_SECRET is " + (oidcSecret ? "empty" : "not set") + ".",
              "Set OIDC_CLIENT_SECRET to the client secret your identity provider issued for this app, or set OIDC_ENABLED=false until you have one. Single sign-on cannot complete its handshake without it.");
          }
          var oidcId = get("OIDC_CLIENT_ID");
          if (!oidcId || oidcId.value.length === 0) {
            add("high", oidcEnabledEntry, "OIDC_CLIENT_ID",
              "OIDC is enabled but OIDC_CLIENT_ID is " + (oidcId ? "empty" : "not set") + ".",
              "Set OIDC_CLIENT_ID to the client ID from your identity provider, or turn OIDC_ENABLED off.");
          }
          if (authWeak) {
            add("critical", oidcEnabledEntry, "OIDC_ENABLED",
              "OIDC single sign-on is enabled while ROMM_AUTH_SECRET_KEY is weak (" + authWhy + ").",
              "Fix the auth secret first: every OIDC login still lands in a RomM session signed by that key, so a guessable key undermines the whole sign-in chain.");
          }
          var redirect = get("OIDC_REDIRECT_URI");
          if (redirect && /^http:\/\//i.test(redirect.value) && !/^http:\/\/(localhost|127\.0\.0\.1)([:\/]|$)/i.test(redirect.value)) {
            add("warning", redirect, "OIDC_REDIRECT_URI",
              "The OIDC redirect URI uses plain http:// on a non-localhost address.",
              "Serve RomM over https:// (for example behind a reverse proxy) and update the redirect URI to match, so login codes are not sent in the clear.");
          }
        }

        /* --- Plaintext credentials & committed-looking secrets --- */
        var secretStoreFix = "Anyone who can read this file gets the credential. Keep the .env out of version control, restrict it to the service account (for example chmod 600), and prefer your platform's secret store or per-service environment injection over a shared plaintext file.";
        entries.forEach(function (e) {
          if (e.key === "ROMM_AUTH_SECRET_KEY") return; /* handled above */
          var isCred = CRED_KEY_RE.test(e.key);
          if (isCred) {
            if (e.value.length === 0) {
              add("high", e, e.key,
                e.key + " is set but empty (value length 0).",
                "Give it the real value, or remove the line. An empty credential usually means RomM fails to connect — or falls back to a weaker default.");
            } else if (looksLikeRealSecret(e.value)) {
              add("high", e, e.key,
                e.key + " looks like a real credential (value length " + e.value.length + ") stored in plaintext in this config file.",
                "If this file was ever committed, pasted into a ticket, or shared, treat the credential as exposed and rotate it. " + secretStoreFix);
            } else {
              add("warning", e, e.key,
                e.key + " is stored in plaintext in this config file (value length " + e.value.length + ").",
                secretStoreFix);
            }
          } else if (TOKEN_SHAPE_RE.test(e.value) || (e.value.length >= 32 && charClasses(e.value) >= 3 && /(KEY|TOKEN|SECRET|AUTH|SIGN)/i.test(e.key) && !looksPlaceholder(e.value))) {
            add("high", e, e.key,
              "The value on this line is shaped like a real API token or secret (value length " + e.value.length + ") sitting in a plaintext config.",
              "If this file was ever committed or shared, rotate that token now, and move it into a secret store instead of the config file.");
          }
        });

        /* Secret reuse across credential keys (values compared, never shown) */
        var byValue = {};
        entries.forEach(function (e) {
          if (e.key === "ROMM_AUTH_SECRET_KEY" || !CRED_KEY_RE.test(e.key)) return;
          if (e.value.length < 4) return;
          if (!byValue[e.value]) byValue[e.value] = [];
          byValue[e.value].push(e);
        });
        Object.keys(byValue).forEach(function (v) {
          var group = byValue[v];
          var keysSeen = {};
          group.forEach(function (e) { keysSeen[e.key] = true; });
          var distinct = Object.keys(keysSeen);
          if (distinct.length > 1) {
            add("high", group[group.length - 1], group[group.length - 1].key,
              "The same value is reused across multiple credential keys (" + distinct.join(", ") + ").",
              "Give each service its own unique credential. One leak should never unlock the database, the metadata providers, and sign-in all at once.");
          }
        });

        /* Database password missing while a database is configured */
        var dbHost = get("DB_HOST");
        var dbPass = get("DB_PASSWD");
        if (dbHost && dbHost.value.length > 0 && (!dbPass || dbPass.value.length === 0)) {
          add("high", dbHost, "DB_PASSWD",
            "DB_HOST is set, so RomM expects a database, but DB_PASSWD is " + (dbPass ? "empty" : "not set") + ".",
            "Set DB_PASSWD to the database user's password, matching the database container or server, or RomM cannot sign in to its own database.");
        }

        /* --- Base / library path --- */
        var baseEntry = get("ROMM_BASE_PATH");
        var broadBase = false;
        var BROAD_ROOTS = { "/home": true, "/root": true, "/etc": true, "/usr": true };
        function checkPath(e, isBase) {
          var v = e.value;
          if (v.length === 0) {
            add("high", e, e.key, e.key + " is set but empty.",
              "Point it at the dedicated folder that holds your library, for example /romm/library.");
            return true;
          }
          if (v.charAt(0) !== "/") {
            add("high", e, e.key, e.key + " is a relative path, not an absolute one.",
              "Use an absolute path such as /romm/library so RomM reads the same folder no matter how the container or service is started.");
            return false;
          }
          if (v === "/") {
            broadBase = true;
            add("critical", e, e.key, e.key + " points at the filesystem root (/).",
              "Point it at a dedicated folder such as /romm/library. At the root, scans and file operations can wander across the entire disk.");
            return true;
          }
          if (BROAD_ROOTS[v]) {
            broadBase = true;
            add("high", e, e.key, e.key + " points at a broad system root (" + v + ").",
              "Narrow it to the dedicated library folder, for example /romm/library, so RomM only ever touches your games.");
            return true;
          }
          if (v.indexOf("/home/") === 0) {
            add("warning", e, e.key, e.key + " sits inside a broad home directory.",
              "A dedicated path such as /romm/library is safer: home folders tend to collect unrelated files that scans will walk through.");
          }
          if (v === "/tmp" || v.indexOf("/tmp/") === 0) {
            add("warning", e, e.key, e.key + " points inside /tmp, which the system may wipe at reboot.",
              "Move the library to a persistent path such as /romm/library.");
          }
          return false;
        }
        if (baseEntry) {
          checkPath(baseEntry, true);
        } else {
          add("info", null, "ROMM_BASE_PATH",
            "ROMM_BASE_PATH is not set, so RomM falls back to its built-in default.",
            "That is fine if the default matches your volume mount. Setting it explicitly (for example /romm/library) makes the setup easier to audit later.");
        }
        entries.forEach(function (e) {
          if (e.key === "ROMM_BASE_PATH") return;
          if (/(BASE_PATH|LIBRARY_PATH|ROMS_PATH|LIBRARY_DIR)$/.test(e.key)) checkPath(e, false);
        });

        /* --- Scan / watcher settings --- */
        var rescan = get("ENABLE_RESCAN_ON_FILESYSTEM_CHANGE");
        var rescanOn = rescan && isTruthy(rescan.value);
        var delay = get("RESCAN_ON_FILESYSTEM_CHANGE_DELAY");
        if (delay) {
          var delayNum = parseInt(delay.value, 10);
          if (isNaN(delayNum)) {
            add("warning", delay, delay.key,
              "RESCAN_ON_FILESYSTEM_CHANGE_DELAY is not a number (value length " + delay.value.length + ").",
              "Set it to a plain number of seconds, for example 60.");
          } else if (rescanOn && delayNum === 0) {
            add("warning", delay, delay.key,
              "Automatic rescan is on with a delay of 0 seconds, so every single file change triggers an immediate full rescan.",
              "Give the watcher breathing room — a delay around 60 seconds batches changes and keeps disk and CPU load sane on a big library.");
          } else if (rescanOn && delayNum > 0 && delayNum < 10) {
            add("warning", delay, delay.key,
              "The rescan delay is very short (" + delayNum + " seconds), so bulk changes can set off near-constant rescans.",
              "Raise it toward 60 seconds unless you have measured a reason not to.");
          } else if (!rescanOn) {
            add("info", delay, delay.key,
              "A rescan delay is set, but ENABLE_RESCAN_ON_FILESYSTEM_CHANGE is not on, so the delay has no effect.",
              "Either enable rescan-on-change, or remove the delay line to keep the config honest.");
          }
        }
        if (rescanOn && broadBase) {
          add("high", rescan, rescan.key,
            "Automatic rescan on filesystem change is enabled while the base path is a broad root.",
            "The watcher will walk far more of the disk than your library on every change. Narrow ROMM_BASE_PATH to the library folder first, then decide if the watcher is still worth it.");
        }
        entries.forEach(function (e) {
          if (!/WATCH/.test(e.key) || e.key === "ENABLE_RESCAN_ON_FILESYSTEM_CHANGE") return;
          if (rescanOn && isFalsy(e.value)) {
            add("warning", e, e.key,
              e.key + " is off while ENABLE_RESCAN_ON_FILESYSTEM_CHANGE is on — the scan/watch settings contradict each other.",
              "Pick one behavior: if the filesystem watcher should react to changes, align both settings; if not, turn rescan-on-change off too.");
          }
          if (!rescanOn && rescan && isFalsy(rescan.value) && isTruthy(e.value)) {
            add("warning", e, e.key,
              e.key + " is on while ENABLE_RESCAN_ON_FILESYSTEM_CHANGE is off — the scan/watch settings contradict each other.",
              "Align the two settings so the config says one clear thing about whether file changes trigger scans.");
          }
        });

        /* --- Structural problems --- */
        idx.dupes.forEach(function (e) {
          add("warning", e, e.key,
            e.key + " is defined more than once; this later line wins in most loaders.",
            "Keep exactly one line per key so the config you read is the config RomM runs.");
        });
        parsed.problems.forEach(function (lineNo) {
          findings.push({ severity: "info", line: lineNo, key: "(line " + lineNo + ")",
            issue: "This line is not a KEY=VALUE pair, a comment, or blank, so it was ignored.",
            fix: "Fix the line to KEY=VALUE form, comment it out with #, or delete it." });
        });

        /* --- Verdict --- */
        var rank = { critical: 0, high: 1, warning: 2, info: 3 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          return (a.line || 0) - (b.line || 0);
        });
        var counts = { critical: 0, high: 0, warning: 0, info: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict, verdictClass, verdictWhy;
        if (counts.critical > 0) {
          verdict = "DO NOT DEPLOY"; verdictClass = "v-deny";
          verdictWhy = counts.critical + (counts.critical === 1 ? " critical finding" : " critical findings") + " — fix those before this config goes anywhere near a live server.";
        } else if (counts.high > 0 || counts.warning > 0) {
          verdict = "DEPLOY WITH FIXES"; verdictClass = "v-fixes";
          verdictWhy = "Nothing here is an outright blocker, but the findings below are worth fixing before you call this server done.";
        } else {
          verdict = "SAFE TO DEPLOY"; verdictClass = "v-safe";
          verdictWhy = "No problems tripped a check. Keep the config file itself protected — it still holds your credentials.";
        }
        return {
          verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
          findings: findings, counts: counts,
          keyCount: entries.length, lineCount: parsed.totalLines
        };
      }

      /* ---------- Rendering (findings only — no raw values exist here) ---------- */
      function escapeHtml(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }
      var SEV_LABEL = { critical: "Critical", high: "High", warning: "Warning", info: "Note" };
      function renderResultsHTML(result) {
        var html = "";
        html += '<div class="verdict ' + result.verdictClass + '">' + escapeHtml(result.verdict) +
          "<small>" + escapeHtml(result.verdictWhy) + "</small></div>";
        var c = result.counts;
        html += '<p class="summary">' + result.lineCount + (result.lineCount === 1 ? " line" : " lines") +
          " scanned · " + result.keyCount + (result.keyCount === 1 ? " key" : " keys") + " found · " +
          c.critical + " critical · " + c.high + " high · " + c.warning + (c.warning === 1 ? " warning" : " warnings") +
          " · " + c.info + (c.info === 1 ? " note" : " notes") + "</p>";
        if (!result.findings.length) {
          html += '<div class="empty-note">No findings. Nothing in this config tripped a check.</div>';
          return html;
        }
        html += '<ul class="findings">';
        result.findings.forEach(function (f) {
          html += '<li class="finding"><div class="f-top">' +
            '<span class="chip ' + f.severity + '">' + SEV_LABEL[f.severity] + "</span>" +
            '<span class="f-loc">' + (f.line ? "Line " + f.line : "Not present in file") + "</span>" +
            '<code class="f-key">' + escapeHtml(f.key) + "</code></div>" +
            '<p class="f-issue">' + escapeHtml(f.issue) + "</p>" +
            '<p class="f-fix"><strong>Fix:</strong> ' + escapeHtml(f.fix) + "</p></li>";
        });
        html += "</ul>";
        return html;
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-romm-server-config-safety-auditortm',
  name: 'J-Dawgs RomM Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted RomM .env config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
