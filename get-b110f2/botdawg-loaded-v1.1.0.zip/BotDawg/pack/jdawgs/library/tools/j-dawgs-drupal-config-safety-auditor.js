'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Drupal Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------------- Worked examples ---------------- */

        var RISKY_EXAMPLE = [
          "<?php",
          "// RISKY EXAMPLE — a settings.php that must not ship as-is.",
          "// Planted problems: open update access, no trusted hosts,",
          "// a short placeholder salt, and verbose error logging.",
          "",
          "$databases['default']['default'] = [",
          "  'database' => 'drupal_site',",
          "  'username' => 'drupal_user',",
          "  'password' => 'example-password-not-real',",
          "  'prefix' => '',",
          "  'host' => 'localhost',",
          "  'port' => '3306',",
          "  'driver' => 'mysql',",
          "];",
          "",
          "$settings['hash_salt'] = 'changeme';",
          "",
          "$settings['update_free_access'] = TRUE;",
          "",
          "$config['system.logging']['error_level'] = 'verbose';",
          ""
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "<?php",
          "// HARDENED EXAMPLE — a settings.php with deploy-safe posture.",
          "",
          "$databases['default']['default'] = [",
          "  'database' => 'drupal_site',",
          "  'username' => 'drupal_user',",
          "  'password' => 'example-password-not-real',",
          "  'prefix' => '',",
          "  'host' => 'localhost',",
          "  'port' => '3306',",
          "  'driver' => 'mysql',",
          "];",
          "",
          "$settings['hash_salt'] = 'f3a9c1e7b2d48a05f6c39e1b7d24a8c05e93f1b6d7a24c8e05f39b1d6a47c2e8b5';",
          "",
          "$settings['update_free_access'] = FALSE;",
          "",
          "$settings['trusted_host_patterns'] = [",
          "  '^example\\.com$',",
          "  '^www\\.example\\.com$',",
          "];",
          "",
          "$settings['file_private_path'] = '/var/www/private';",
          "",
          "$settings['config_sync_directory'] = '../config/sync';",
          "",
          "$settings['file_scan_ignore_directories'] = [",
          "  'node_modules',",
          "  'bower_components',",
          "];",
          "",
          "$config['system.logging']['error_level'] = 'hide';",
          ""
        ].join("\n");

        /* ---------------- Line scanner ----------------
           Splits each line into a code portion and a comment portion,
           tracking string state and block comments. Heuristic only. */

        function scanLines(text) {
          var rawLines = text.split(/\r?\n/);
          var inBlock = false;
          return rawLines.map(function (raw, idx) {
            var code = "", comment = "", inStr = null, i = 0, ch, nx;
            while (i < raw.length) {
              ch = raw[i]; nx = raw[i + 1];
              if (inBlock) {
                if (ch === "*" && nx === "/") { inBlock = false; comment += "*/"; i += 2; }
                else { comment += ch; i += 1; }
                continue;
              }
              if (inStr) {
                code += ch;
                if (ch === "\\" && nx !== undefined) { code += nx; i += 2; continue; }
                if (ch === inStr) { inStr = null; }
                i += 1; continue;
              }
              if (ch === "/" && nx === "*") { inBlock = true; comment += "/*"; i += 2; continue; }
              if (ch === "/" && nx === "/") { comment += raw.slice(i); i = raw.length; break; }
              if (ch === "#") { comment += raw.slice(i); i = raw.length; break; }
              if (ch === "'" || ch === '"') { inStr = ch; code += ch; i += 1; continue; }
              code += ch; i += 1;
            }
            return {
              n: idx + 1,
              raw: raw,
              code: code,
              comment: comment,
              endInString: inStr !== null,
              commentOnly: code.trim() === "" && comment.trim() !== ""
            };
          });
        }

        /* ---------------- Assignment collector ---------------- */

        function parseKeyPath(varName, brackets) {
          var segs = [];
          var re = /\[([^\]]*)\]/g, m;
          while ((m = re.exec(brackets)) !== null) {
            var s = m[1].trim();
            if ((s.charAt(0) === "'" && s.charAt(s.length - 1) === "'") ||
                (s.charAt(0) === '"' && s.charAt(s.length - 1) === '"')) {
              s = s.slice(1, -1);
            }
            segs.push(s);
          }
          return { root: varName, segs: segs, key: varName + (segs.length ? "." + segs.join(".") : "") };
        }

        function collectAssignments(lines) {
          var assigns = [], buf = null;
          lines.forEach(function (L) {
            if (L.commentOnly) return;
            var code = L.code;
            if (!buf) {
              var m = code.match(/^\s*\$([A-Za-z_]\w*)((?:\s*\[[^\]]*\])*)\s*=(?![=>])/);
              if (m) {
                buf = { startLine: L.n, path: parseKeyPath(m[1], m[2]), parts: [{ n: L.n, code: code }] };
                if (code.indexOf(";") !== -1) { assigns.push(buf); buf = null; }
              }
            } else {
              buf.parts.push({ n: L.n, code: code });
              if (code.indexOf(";") !== -1) { assigns.push(buf); buf = null; }
            }
          });
          if (buf) assigns.push(buf);
          return assigns;
        }

        function stmtText(a) {
          return a.parts.map(function (p) { return p.code; }).join("\n");
        }
        function lineOfMatch(a, re) {
          for (var i = 0; i < a.parts.length; i++) {
            if (re.test(a.parts[i].code)) return a.parts[i].n;
          }
          return a.startLine;
        }
        function rhsString(a) {
          var t = stmtText(a);
          var m = t.match(/=\s*'((?:[^'\\]|\\.)*)'/) || t.match(/=\s*"((?:[^"\\]|\\.))"/);
          return m ? m[1] : null;
        }
        function rhsStrings(a) {
          var t = stmtText(a);
          var eq = t.indexOf("=");
          if (eq === -1) return [];
          var rhs = t.slice(eq + 1), out = [], m;
          var re = /'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.))"/g;
          while ((m = re.exec(rhs)) !== null) out.push(m[1] !== undefined ? m[1] : m[2]);
          return out;
        }
        function rhsBool(a) {
          var t = stmtText(a);
          var m = t.match(/=\s*(TRUE|FALSE|true|false)\b/);
          if (m) return m[1].toUpperCase() === "TRUE";
          if (/=\s*1\s*;/.test(t)) return true;
          if (/=\s*0\s*;/.test(t)) return false;
          return null;
        }

        /* ---------------- Audit ---------------- */

        var SEV_ORDER = ["BLOCKER", "WARNING", "INFO", "NOT PARSED", "NOT VERIFIED"];
        var SEV_LABEL = { "NOT PARSED": "NOT PARSED", "NOT VERIFIED": "NOT VERIFIED" };

        function audit(text) {
          var findings = [];
          function add(sev, line, check, msg) {
            findings.push({ severity: sev, line: line, check: check, message: msg });
          }

          var lines = scanLines(text);
          var assigns = collectAssignments(lines);

          // Index last assignment + all lines per key.
          var lastByKey = {}, linesByKey = {};
          assigns.forEach(function (a) {
            var k = a.path.key;
            if (!linesByKey[k]) linesByKey[k] = [];
            linesByKey[k].push(a.startLine);
            lastByKey[k] = a;
          });
          function last(key) { return lastByKey[key] || null; }

          // Public-facing hint (comments or code mentioning a live/production context).
          var allText = lines.map(function (L) { return L.comment + " " + L.code; }).join("\n");
          var publicHint = /production|live site|public-facing|public facing/i.test(allText);

          /* --- NOT PARSED: unterminated strings --- */
          lines.forEach(function (L) {
            if (L.endInString && !L.commentOnly) {
              add("NOT PARSED", L.n, "Unterminated string",
                "Line " + L.n + " ends inside a quoted string. The heuristic scanner could not parse this line reliably, so settings on or after it may have been missed.");
            }
          });

          /* --- NOT PARSED: unbalanced braces (string-aware) --- */
          (function () {
            var stack = [], negLine = null;
            lines.forEach(function (L) {
              if (L.commentOnly) return;
              var inStr = null, code = L.code;
              for (var i = 0; i < code.length; i++) {
                var ch = code[i];
                if (inStr) {
                  if (ch === "\\") { i++; continue; }
                  if (ch === inStr) inStr = null;
                  continue;
                }
                if (ch === "'" || ch === '"') { inStr = ch; continue; }
                if (ch === "{") stack.push(L.n);
                else if (ch === "}") {
                  if (stack.length) stack.pop();
                  else if (negLine === null) negLine = L.n;
                }
              }
            });
            if (negLine !== null) {
              add("NOT PARSED", negLine, "Unbalanced braces",
                "Line " + negLine + " closes a brace that was never opened. File structure could not be fully parsed.");
            } else if (stack.length) {
              add("NOT PARSED", stack[0], "Unbalanced braces",
                "A brace opened at line " + stack[0] + " is never closed (" + stack.length + " unclosed). File structure could not be fully parsed.");
            }
          })();

          /* --- Commented-out risky lines -> INFO --- */
          lines.forEach(function (L) {
            if (!L.commentOnly && L.comment.trim() === "") return;
            var c = L.comment;
            if (/update_free_access/.test(c) && /TRUE|true/.test(c)) {
              add("INFO", L.n, "Commented-out setting",
                "Line " + L.n + " is a commented-out update_free_access = TRUE. It is inactive and not counted as a finding — noted so it is not re-enabled by accident.");
            } else if (/error_level/.test(c) && /verbose/.test(c)) {
              add("INFO", L.n, "Commented-out setting",
                "Line " + L.n + " is a commented-out verbose error_level. It is inactive and not counted as a finding.");
            } else if (/trusted_host_patterns/.test(c) && /\.\*/.test(c)) {
              add("INFO", L.n, "Commented-out setting",
                "Line " + L.n + " is a commented-out trusted_host_patterns entry that would trust every host. It is inactive and not counted as a finding.");
            } else if (/hash_salt/.test(c) && /=\s*(''|"")/.test(c)) {
              add("INFO", L.n, "Commented-out setting",
                "Line " + L.n + " is a commented-out empty hash_salt. It is inactive and not counted as a finding.");
            }
          });

          /* --- Duplicate assignments --- */
          Object.keys(linesByKey).forEach(function (k) {
            var ls = linesByKey[k];
            var a = lastByKey[k];
            var hasAppend = a.path.segs.some(function (s) { return s === ""; });
            if (ls.length > 1 && !hasAppend && (a.path.root === "settings" || a.path.root === "config" || a.path.root === "databases")) {
              add("WARNING", ls[ls.length - 1], "Duplicate assignment",
                "Key '" + k + "' is assigned more than once (lines " + ls.join(" and ") + "). Only the last value, at line " + ls[ls.length - 1] + ", takes effect — and it is the value graded here. Remove the dead assignment so the file says what it does.");
            }
          });

          /* --- $databases credentials --- */
          var dbAssigns = assigns.filter(function (a) { return a.path.root === "databases"; });
          if (dbAssigns.length) {
            var anyCred = false;
            dbAssigns.forEach(function (a) {
              ["password", "username"].forEach(function (credKey) {
                var re = new RegExp("'" + credKey + "'\\s*=>|\"" + credKey + "\"\\s*=>");
                if (re.test(stmtText(a))) {
                  anyCred = true;
                  var ln = lineOfMatch(a, re);
                  add("INFO", ln, "Database credentials in file",
                    "A database credential is present under key '" + credKey + "' (line " + ln + "). The value is never shown in this audit, the report, or the JSON. Credentials in settings.php are normal for Drupal — make sure the file itself is permission-locked and never committed to a public repository.");
                }
              });
            });
            if (!anyCred) {
              add("INFO", dbAssigns[0].startLine, "Database credentials in file",
                "A $databases block is present (line " + dbAssigns[0].startLine + ") but no inline 'password' or 'username' key was found — credentials may be supplied another way. Not verified either way.");
            }
          } else {
            add("INFO", null, "Database credentials in file",
              "No $databases block was found in the pasted text. A real settings.php needs one (or an include that provides it) before the site can run.");
          }

          /* --- hash_salt --- */
          var salt = last("settings.hash_salt");
          if (!salt) {
            add("BLOCKER", null, "hash_salt",
              "$settings['hash_salt'] is not set anywhere in the file. Drupal needs a salt for one-time login links and form tokens — generate a long random string and set it before deploying.");
          } else {
            var sv = rhsString(salt);
            if (sv === null) {
              add("NOT VERIFIED", salt.startLine, "hash_salt",
                "hash_salt is assigned at line " + salt.startLine + " from something other than a plain string literal (a variable, constant, or file read), so its strength cannot be graded from the pasted text.");
            } else if (sv.length === 0) {
              add("BLOCKER", salt.startLine, "hash_salt",
                "$settings['hash_salt'] at line " + salt.startLine + " is set to an empty string. Set a long random salt before deploying.");
            } else if (sv.length < 32) {
              add("WARNING", salt.startLine, "hash_salt",
                "$settings['hash_salt'] at line " + salt.startLine + " is only " + sv.length + " characters long (graded by length only — the value is never shown). Use at least 32 characters, ideally 64+, of random material.");
            } else {
              add("INFO", salt.startLine, "hash_salt",
                "$settings['hash_salt'] is set at line " + salt.startLine + " with a length of " + sv.length + " characters (graded by length only — the value is never shown). Length is adequate.");
            }
          }

          /* --- trusted_host_patterns --- */
          var thp = last("settings.trusted_host_patterns");
          if (!thp) {
            add("BLOCKER", null, "trusted_host_patterns",
              "$settings['trusted_host_patterns'] is not set. Without it, Drupal accepts any Host header, which enables host-header poisoning (password-reset and cache attacks). Set restrictive patterns for every real hostname before deploying.");
          } else {
            var pats = rhsStrings(thp);
            var permissive = pats.filter(function (p) { return /^\^?\.\*\$?$/.test(p.trim()) || /^\^?\.\+\$$/.test(p.trim()); });
            if (permissive.length) {
              add("BLOCKER", thp.startLine, "trusted_host_patterns",
                "trusted_host_patterns at line " + thp.startLine + " includes a pattern ('" + permissive[0] + "') that trusts every host — the same as having no protection at all. Replace it with patterns that name your real hostnames.");
            } else if (!pats.length) {
              add("NOT VERIFIED", thp.startLine, "trusted_host_patterns",
                "trusted_host_patterns is assigned at line " + thp.startLine + " but no plain string patterns could be read from it, so its restrictiveness is not verified.");
            } else {
              add("INFO", thp.startLine, "trusted_host_patterns",
                "trusted_host_patterns is set at line " + thp.startLine + " with " + pats.length + " pattern" + (pats.length === 1 ? "" : "s") + ", none of which trusts every host.");
            }
          }

          /* --- update_free_access --- */
          var ufa = last("settings.update_free_access");
          var ufaTrue = false;
          if (ufa) {
            var b = rhsBool(ufa);
            if (b === true) {
              ufaTrue = true;
              add("BLOCKER", ufa.startLine, "update_free_access",
                "$settings['update_free_access'] = TRUE at line " + ufa.startLine + ". Anyone who can reach update.php can run database updates with no login. Set it to FALSE before deploying — this is the single most dangerous line in a settings.php.");
            } else if (b === false) {
              add("INFO", ufa.startLine, "update_free_access",
                "$settings['update_free_access'] is FALSE at line " + ufa.startLine + ". Update access is properly closed.");
            } else {
              add("NOT VERIFIED", ufa.startLine, "update_free_access",
                "update_free_access is assigned at line " + ufa.startLine + " from a non-literal value, so whether update.php is open cannot be verified from the pasted text.");
            }
          } else {
            add("INFO", null, "update_free_access",
              "update_free_access is not set in the file; Drupal's default is FALSE (closed), but set it explicitly so the posture is visible in the file.");
          }

          /* --- error_level / display errors --- */
          var el = last("config.system.logging.error_level");
          var verboseLine = null;
          if (el) {
            var ev = rhsString(el);
            if (ev === "verbose") {
              verboseLine = el.startLine;
            } else if (ev) {
              add("INFO", el.startLine, "Error logging level",
                "$config['system.logging']['error_level'] is '" + ev + "' at line " + el.startLine + " — errors are not fully displayed to visitors.");
            }
          }
          var dispLine = null;
          lines.forEach(function (L) {
            if (L.commentOnly) return;
            if (/display_errors/.test(L.code) && /(on|1|true)/i.test(L.code)) dispLine = L.n;
          });
          if (verboseLine !== null || dispLine !== null) {
            var which = verboseLine !== null
              ? "$config['system.logging']['error_level'] = 'verbose' at line " + verboseLine
              : "display_errors is switched on at line " + dispLine;
            var ln2 = verboseLine !== null ? verboseLine : dispLine;
            if (ufaTrue || publicHint) {
              var why = ufaTrue
                ? "update_free_access is also enabled, so exposed error detail and open update access compound each other"
                : "the file references a production / public-facing context, where visitors would see this detail";
              add("BLOCKER", ln2, "Error display",
                which + " shows full error detail — paths, queries, and stack traces — to site visitors. Escalated to BLOCKER because " + why + ". Set error_level to 'hide' on any public site.");
            } else {
              add("WARNING", ln2, "Error display",
                which + " shows full error detail to site visitors. Fine on a local dev copy; set error_level to 'hide' before this file faces the public.");
            }
          }

          /* --- file_scan_ignore_directories --- */
          if (!last("settings.file_scan_ignore_directories")) {
            add("WARNING", null, "file_scan_ignore_directories",
              "$settings['file_scan_ignore_directories'] is not set. Without it, Drupal's file scanner walks node_modules and bower_components inside the webroot, slowing scans and surfacing files that should be ignored. Set it to ['node_modules', 'bower_components'].");
          }

          /* --- config_sync_directory --- */
          var csd = last("settings.config_sync_directory");
          if (!csd) {
            add("INFO", null, "config_sync_directory",
              "$settings['config_sync_directory'] is not set in this file (it may be set in an included file — not verified). If it points inside the webroot, exported configuration is web-accessible unless the server blocks it.");
          } else {
            var cp = rhsString(csd);
            if (cp === null) {
              add("NOT VERIFIED", csd.startLine, "config_sync_directory",
                "config_sync_directory is assigned at line " + csd.startLine + " from a non-literal value, so its location relative to the webroot is not verified.");
            } else if (cp.indexOf("../") === 0 || cp.indexOf("..\\") === 0) {
              add("INFO", csd.startLine, "config_sync_directory",
                "config_sync_directory at line " + csd.startLine + " points outside the webroot (a ../ relative path). That is the safe placement.");
            } else if (cp.charAt(0) === "/") {
              add("INFO", csd.startLine, "config_sync_directory",
                "config_sync_directory at line " + csd.startLine + " is an absolute path. Whether it sits outside the webroot cannot be confirmed from the pasted text alone.");
            } else {
              add("WARNING", csd.startLine, "config_sync_directory",
                "config_sync_directory at line " + csd.startLine + " is a plain relative path, which places exported configuration inside the webroot where it may be web-accessible. Move it outside the webroot (for example '../config/sync').");
            }
          }

          /* --- file_private_path --- */
          var fpp = last("settings.file_private_path");
          if (!fpp) {
            add("INFO", null, "file_private_path",
              "$settings['file_private_path'] is not set. If the site handles private files, set a path outside the webroot; without one, private-file handling falls back to defaults that may expose uploads.");
          } else {
            add("INFO", fpp.startLine, "file_private_path",
              "$settings['file_private_path'] is set at line " + fpp.startLine + ". (The path value itself is not shown.)");
          }

          /* --- reverse proxy posture: NOT VERIFIED when absent --- */
          var rp = last("settings.reverse_proxy");
          if (!rp) {
            add("NOT VERIFIED", null, "Reverse proxy posture",
              "No $settings['reverse_proxy'] declaration appears in the file. Whether the site sits behind a reverse proxy or load balancer — and whether trusted proxy addresses are configured — cannot be checked from settings.php alone and is NOT VERIFIED. It is never counted as passed.");
          } else {
            var rb = rhsBool(rp);
            if (rb === true && !last("settings.reverse_proxy_addresses")) {
              add("WARNING", rp.startLine, "Reverse proxy posture",
                "$settings['reverse_proxy'] is TRUE at line " + rp.startLine + " but no reverse_proxy_addresses are set, so Drupal cannot tell which proxies to trust for client IP headers. Add the trusted proxy addresses.");
            } else {
              add("INFO", rp.startLine, "Reverse proxy posture",
                "reverse_proxy posture is declared at line " + rp.startLine + ". Whether the listed proxies match the real infrastructure is not verified by this tool.");
            }
          }

          /* --- Standing NOT VERIFIED items --- */
          add("NOT VERIFIED", null, "Database reachability",
            "Whether the database server is reachable, and whether the credentials actually authenticate, cannot be checked by a text audit. NOT VERIFIED — never counted as passed.");
          add("NOT VERIFIED", null, "Runtime posture",
            "File permissions on settings.php, the PHP version, web-server configuration, and whether the site actually loads are outside a pasted-text audit. NOT VERIFIED.");

          /* --- Counts + verdict --- */
          var counts = { "BLOCKER": 0, "WARNING": 0, "INFO": 0, "NOT PARSED": 0, "NOT VERIFIED": 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict, why;
          if (counts.BLOCKER > 0) {
            verdict = "DO NOT DEPLOY";
            why = counts.BLOCKER + " blocker" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this configuration faces a server.";
          } else if (counts.WARNING > 0 || counts["NOT PARSED"] > 0) {
            verdict = "DEPLOY WITH FIXES";
            var bits = [];
            if (counts.WARNING > 0) bits.push(counts.WARNING + " warning" + (counts.WARNING === 1 ? "" : "s"));
            if (counts["NOT PARSED"] > 0) bits.push(counts["NOT PARSED"] + " unparsed section" + (counts["NOT PARSED"] === 1 ? "" : "s"));
            why = "No blockers, but " + bits.join(" and ") + " need attention before this is a clean deploy.";
          } else {
            verdict = "SAFE TO DEPLOY";
            why = "No blockers and no warnings in what the file shows. NOT VERIFIED items below were not checked and are not counted as passed.";
          }

          findings.sort(function (a, b) {
            var d = SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity);
            if (d !== 0) return d;
            var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
            return la - lb;
          });

          return { verdict: verdict, why: why, counts: counts, findings: findings };
        }

        /* ---------------- Report builders ---------------- */

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Drupal Config Safety Auditor — Audit Report");
          out.push("====================================================");
          out.push("VERDICT: " + r.verdict);
          out.push(r.why);
          out.push("");
          out.push("Counts: BLOCKER " + r.counts.BLOCKER + " · WARNING " + r.counts.WARNING +
                   " · INFO " + r.counts.INFO + " · NOT PARSED " + r.counts["NOT PARSED"] +
                   " · NOT VERIFIED " + r.counts["NOT VERIFIED"]);
          out.push("");
          SEV_ORDER.forEach(function (sev) {
            var group = r.findings.filter(function (f) { return f.severity === sev; });
            out.push("---- " + sev + " (" + group.length + ") ----");
            if (!group.length) { out.push("(none)"); }
            group.forEach(function (f) {
              out.push("[" + sev + "] " + (f.line !== null ? "Line " + f.line : "File-wide") + " — " + f.check + ": " + f.message);
            });
            out.push("");
          });
          out.push("Method: heuristic PHP text audit, run locally in the browser.");
          out.push("It is not a PHP parser, executes no code, connects to nothing,");
          out.push("and verifies nothing about a live site. No secret values");
          out.push("(database passwords, hash salt, credentials) appear in this");
          out.push("report — findings name keys and line numbers only.");
          return out.join("\n");
        }

        function buildJSON(r) {
          return JSON.stringify({
            tool: "J-Dawgs Drupal Config Safety Auditor",
            method: "Heuristic PHP text audit (not a PHP parser; no code executed; nothing uploaded)",
            verdict: r.verdict,
            verdictReason: r.why,
            counts: {
              blocker: r.counts.BLOCKER,
              warning: r.counts.WARNING,
              info: r.counts.INFO,
              notParsed: r.counts["NOT PARSED"],
              notVerified: r.counts["NOT VERIFIED"]
            },
            findings: r.findings.map(function (f) {
              return { severity: f.severity, line: f.line, check: f.check, message: f.message };
            }),
            secretHandling: "No secret values are included. Credentials are identified by key name and line only; hash_salt is graded by length only."
          }, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-drupal-config-safety-auditor',
  name: 'J-Dawgs Drupal Config Safety Auditor',
  description: 'Grades a pasted Drupal settings.php offline — update access, trusted hosts, salt and credential posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
