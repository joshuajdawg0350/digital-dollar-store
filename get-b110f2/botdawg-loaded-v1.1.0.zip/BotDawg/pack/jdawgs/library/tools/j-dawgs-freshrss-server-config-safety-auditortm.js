'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs FreshRSS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (line arrays: line number = index + 1) ---------- */

      var RISKY_LINES = [
        "<?php",
        "return array(",
        "  'salt' => 'example-salt-change-me',",
        "  'base_url' => 'http://rss.example.com',",
        "  'default_user' => 'admin',",
        "  'default_password' => 'admin123',",
        "  'allow_anonymous' => true,",
        "  'allow_anonymous_refresh' => true,",
        "  'allow_public_registration' => true,",
        "  'disable_update' => false,",
        "  'db' => array(",
        "    'type' => 'mysql',",
        "    'host' => 'localhost',",
        "    'user' => 'freshrss',",
        "    'password' => 'dbsecret99',",
        "    'base' => 'freshrss',",
        "  ),",
        "  'curlopt' => array(",
        "    CURLOPT_SSL_VERIFYPEER => false,",
        "  ),",
        ");"
      ];
      var RISKY_TEXT = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "<?php",
        "return array(",
        "  'salt' => 'kX9$mQ2!vR7#zLp4&nT8*wYs3@hJ6%fD1',",
        "  'base_url' => 'https://rss.example.com',",
        "  'default_user' => 'joshua',",
        "  'default_password' => getenv('FRESHRSS_ADMIN_PASSWORD'),",
        "  'allow_anonymous' => false,",
        "  'allow_anonymous_refresh' => false,",
        "  'allow_public_registration' => false,",
        "  'disable_update' => true,",
        "  'db' => array(",
        "    'type' => 'pgsql',",
        "    'host' => 'localhost',",
        "    'user' => 'freshrss',",
        "    'password' => getenv('FRESHRSS_DB_PASSWORD'),",
        "    'base' => 'freshrss',",
        "  ),",
        "  'curlopt' => array(",
        "    CURLOPT_SSL_VERIFYPEER => true,",
        "  ),",
        ");"
      ];
      var HARDENED_TEXT = HARDENED_LINES.join("\n");

      var WORKED_SNIPPET = "'salt' => 'abc123',\n'base_url' => 'http://feeds.internal',\n'allow_anonymous' => true,";

      /* ---------- Parsing ---------- */

      var KNOWN_KEYS = {
        salt: 1, base_url: 1, default_user: 1, allow_anonymous: 1,
        allow_anonymous_refresh: 1, allow_public_registration: 1,
        disable_update: 1, db: 1, type: 1, host: 1, user: 1, base: 1,
        curlopt: 1, extensions: 1, extensions_enabled: 1,
        trusted_proxy: 1, trusted_proxies: 1, trust_proxy: 1
      };
      var KNOWN_DEFAULT_PASSWORDS = ["admin", "admin123", "password", "password1", "freshrss", "changeme", "change-me", "default", "123456", "12345678", "letmein", "root", "secret"];
      var SALT_BAD_WORDS = ["example", "change", "default", "sample", "placeholder", "todo", "xxx"];

      function isPasswordKey(matchKey) {
        return /(password|passwd|pwd)/.test(matchKey);
      }

      function parseValue(raw) {
        var v = String(raw).trim();
        v = v.replace(/[,;]\s*$/, "").trim();
        if (/^getenv\s*\(/i.test(v) || /^\$_(ENV|SERVER)\b/.test(v) || /^env\s*\(/i.test(v)) {
          return { kind: "env", value: null, length: null };
        }
        var m = v.match(/^'((?:[^'\\]|\\.)*)'/) || v.match(/^"((?:[^"\\]|\\.)*)"/);
        if (m) return { kind: "string", value: m[1], length: m[1].length };
        if (/^true$/i.test(v)) return { kind: "bool", value: true, length: null };
        if (/^false$/i.test(v)) return { kind: "bool", value: false, length: null };
        if (/^-?\d+(\.\d+)?$/.test(v)) return { kind: "number", value: parseFloat(v), length: null };
        if (/^array\s*\(/i.test(v) || v.charAt(0) === "[") return { kind: "array", value: null, length: null };
        var bare = v.split(/\s+/)[0].replace(/['"]/g, "");
        if (bare) return { kind: "string", value: bare, length: bare.length };
        return { kind: "other", value: null, length: null };
      }

      function truthy(info) {
        if (!info) return false;
        if (info.kind === "bool") return info.value === true;
        if (info.kind === "number") return info.value !== 0;
        if (info.kind === "string") return /^(true|1|yes|on)$/i.test(info.value);
        return false;
      }
      function falsy(info) {
        if (!info) return false;
        if (info.kind === "bool") return info.value === false;
        if (info.kind === "number") return info.value === 0;
        if (info.kind === "string") return /^(false|0|no|off|)$/i.test(info.value);
        return false;
      }

      function extractEntry(line) {
        var m = line.match(/['"]([A-Za-z0-9_]+)['"]\s*=>\s*(.+)$/);
        if (m) return { key: m[1], raw: m[2] };
        m = line.match(/\b(CURLOPT_[A-Z0-9_]+)\s*=>\s*(.+)$/);
        if (m) return { key: m[1], raw: m[2] };
        if (line.indexOf("=>") === -1) {
          m = line.match(/^\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.+)$/);
          if (m) {
            var first = line.replace(/^\s+/, "").charAt(0);
            if (first !== "$" && first !== "<") return { key: m[1], raw: m[2] };
          }
        }
        return null;
      }

      function parseConfig(text) {
        var lines = String(text || "").split(/\r?\n/);
        var entries = [];
        var inDb = false;
        for (var i = 0; i < lines.length; i++) {
          var rawLine = lines[i];
          var trimmed = rawLine.trim();
          if (/^(\/\/|#|\/\*|\*)/.test(trimmed)) continue;
          var ent = extractEntry(rawLine);
          if (ent) {
            var matchKey = ent.key.toLowerCase().replace(/^freshrss_/, "");
            var isDbStart = matchKey === "db";
            if (isDbStart) inDb = true;
            entries.push({
              key: ent.key,
              matchKey: matchKey,
              line: i + 1,
              info: parseValue(ent.raw),
              inDb: inDb && !isDbStart
            });
          }
          if (inDb && (/^\s*\)\s*,?\s*$/.test(rawLine) || /^\s*\]\s*,?\s*$/.test(rawLine))) inDb = false;
        }
        return { lines: lines, entries: entries };
      }

      function isRecognized(e) {
        if (KNOWN_KEYS[e.matchKey]) return true;
        if (isPasswordKey(e.matchKey)) return true;
        if (/^curlopt_/.test(e.matchKey)) return true;
        return false;
      }

      /* ---------- Grading ---------- */

      var SEV_RANK = { critical: 0, high: 1, medium: 2, low: 3 };

      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var recognized = 0;
        var i, e;
        for (i = 0; i < entries.length; i++) if (isRecognized(entries[i])) recognized++;

        var findings = [];
        var passes = [];
        function add(sev, key, line, len, issue, fix) {
          findings.push({ severity: sev, key: key, line: line, valueLength: len, issue: issue, fix: fix });
        }
        function findEntry(matchKey) {
          for (var j = 0; j < entries.length; j++) if (entries[j].matchKey === matchKey) return entries[j];
          return null;
        }

        if (recognized === 0) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            findings: [],
            passes: [],
            recognized: 0,
            lineCount: parsed.lines.length,
            entries: entries
          };
        }

        /* salt */
        var salt = findEntry("salt");
        if (salt) {
          if (salt.info.kind === "env") {
            passes.push("salt is supplied from the environment, not stored in the file (line " + salt.line + ").");
          } else if (salt.info.kind === "string") {
            var sv = salt.info.value.toLowerCase();
            var badWord = null;
            for (i = 0; i < SALT_BAD_WORDS.length; i++) if (sv.indexOf(SALT_BAD_WORDS[i]) !== -1) { badWord = SALT_BAD_WORDS[i]; break; }
            if (badWord) {
              add("critical", "salt", salt.line, salt.info.length,
                "Salt looks like a placeholder: it contains \"" + badWord + "\" and is " + salt.info.length + " characters long.",
                "Generate a fresh random salt of at least 32 characters and store it in the config or an env variable.");
            } else if (salt.info.length < 16) {
              add("critical", "salt", salt.line, salt.info.length,
                "Salt is far too short at " + salt.info.length + " characters.",
                "Generate a fresh random salt of at least 32 characters.");
            } else if (salt.info.length < 32) {
              add("high", "salt", salt.line, salt.info.length,
                "Salt is only " + salt.info.length + " characters; 32 or more is the safe floor.",
                "Generate a fresh random salt of at least 32 characters.");
            } else {
              passes.push("salt is " + salt.info.length + " characters with no placeholder wording (line " + salt.line + ").");
            }
          }
        } else if (findEntry("base_url") || findEntry("default_user") || findEntry("db")) {
          add("high", "salt", null, null,
            "No salt setting was found in this config.",
            "Set a fresh random salt of at least 32 characters; sessions and tokens depend on it.");
        }

        /* base_url */
        var baseUrl = findEntry("base_url");
        if (baseUrl && baseUrl.info.kind === "string") {
          if (/^http:\/\//i.test(baseUrl.info.value)) {
            add("high", "base_url", baseUrl.line, null,
              "base_url uses plain http://, so logins and feed credentials cross the network unencrypted.",
              "Serve the instance over https and set base_url to the https:// address.");
          } else if (/^https:\/\//i.test(baseUrl.info.value)) {
            passes.push("base_url uses https (line " + baseUrl.line + ").");
          }
        }

        /* default_user */
        var dUser = findEntry("default_user");
        if (dUser && dUser.info.kind === "string") {
          if (dUser.info.value.toLowerCase() === "admin") {
            add("critical", "default_user", dUser.line, null,
              "The default admin account is still named \"admin\", the first name an attacker tries.",
              "Rename the default admin user to something unguessable.");
          } else {
            passes.push("default_user is not the well-known \"admin\" name (line " + dUser.line + ").");
          }
        }

        /* boolean access switches */
        var anon = findEntry("allow_anonymous");
        if (anon) {
          if (truthy(anon.info)) {
            add("high", "allow_anonymous", anon.line, null,
              "allow_anonymous is true: anyone on the internet can read the default user's feeds without logging in.",
              "Set allow_anonymous to false unless this instance is deliberately public.");
          } else if (falsy(anon.info)) {
            passes.push("allow_anonymous is off (line " + anon.line + ").");
          }
        }
        var anonRef = findEntry("allow_anonymous_refresh");
        if (anonRef) {
          if (truthy(anonRef.info)) {
            add("medium", "allow_anonymous_refresh", anonRef.line, null,
              "allow_anonymous_refresh is true: anonymous visitors can trigger feed refreshes, which can be abused to hammer upstream sites.",
              "Set allow_anonymous_refresh to false.");
          } else if (falsy(anonRef.info)) {
            passes.push("allow_anonymous_refresh is off (line " + anonRef.line + ").");
          }
        }
        var reg = findEntry("allow_public_registration");
        if (reg) {
          if (truthy(reg.info)) {
            add("high", "allow_public_registration", reg.line, null,
              "allow_public_registration is true: anyone can create an account on this instance.",
              "Set allow_public_registration to false and create accounts by hand.");
          } else if (falsy(reg.info)) {
            passes.push("allow_public_registration is off (line " + reg.line + ").");
          }
        }

        /* disable_update */
        var disUp = findEntry("disable_update");
        if (disUp) {
          if (falsy(disUp.info)) {
            add("medium", "disable_update", disUp.line, null,
              "disable_update is false: the in-app updater is enabled, so a compromised admin session can change the code on disk.",
              "Set disable_update to true and update through your deployment process instead.");
          } else if (truthy(disUp.info)) {
            passes.push("disable_update is on, so the in-app updater is disabled (line " + disUp.line + ").");
          }
        }

        /* passwords (admin + generic + db) */
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (!isPasswordKey(e.matchKey)) continue;
          var displayKey = e.inDb ? "db." + e.matchKey : e.matchKey;
          if (e.info.kind === "env") {
            passes.push(displayKey + " is supplied from the environment, not stored in the file (line " + e.line + ").");
            continue;
          }
          if (e.info.kind !== "string") continue;
          if (e.inDb) {
            add("high", displayKey, e.line, e.info.length,
              "Plaintext database password stored in the config (" + e.info.length + " characters). Anyone who reads this file owns the database.",
              "Move the database password into an environment variable or secret store and reference it instead of pasting it in.");
          } else if (e.matchKey === "default_password" || e.matchKey === "admin_password") {
            if (KNOWN_DEFAULT_PASSWORDS.indexOf(e.info.value.toLowerCase()) !== -1 || e.info.length < 12) {
              add("critical", displayKey, e.line, e.info.length,
                "Admin password is a documented default or a short plaintext password (" + e.info.length + " characters).",
                "Set a long, unique admin password and store it in a password manager or env variable, not in the config.");
            } else {
              add("high", displayKey, e.line, e.info.length,
                "Admin password is stored in plaintext in the config (" + e.info.length + " characters).",
                "Move the admin password into an environment variable or secret store.");
            }
          } else {
            if (e.info.length < 12) {
              add("critical", displayKey, e.line, e.info.length,
                "Short plaintext password stored in the config (" + e.info.length + " characters).",
                "Replace it with a long, unique secret kept in an env variable or secret store.");
            } else {
              add("high", displayKey, e.line, e.info.length,
                "Plaintext password stored in the config (" + e.info.length + " characters).",
                "Move this password into an environment variable or secret store.");
            }
          }
        }

        /* curl options + trusted proxy */
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          var upKey = e.key.toUpperCase();
          if (upKey === "CURLOPT_SSL_VERIFYPEER") {
            if (falsy(e.info)) {
              add("critical", e.key, e.line, null,
                "CURLOPT_SSL_VERIFYPEER is off: TLS certificates are not verified, so feed traffic can be intercepted or spoofed.",
                "Remove this override or set CURLOPT_SSL_VERIFYPEER to true.");
            } else if (truthy(e.info)) {
              passes.push("CURLOPT_SSL_VERIFYPEER is on, so TLS certificates are verified (line " + e.line + ").");
            }
          } else if (upKey === "CURLOPT_SSL_VERIFYHOST") {
            if (falsy(e.info) || (e.info.kind === "number" && e.info.value < 2)) {
              add("critical", e.key, e.line, null,
                "CURLOPT_SSL_VERIFYHOST is weakened: the certificate hostname is not properly checked.",
                "Set CURLOPT_SSL_VERIFYHOST to 2 or remove the override.");
            }
          } else if (upKey === "CURLOPT_NOPROXY") {
            if (e.info.kind === "string" && e.info.value.indexOf("*") !== -1) {
              add("medium", e.key, e.line, null,
                "CURLOPT_NOPROXY contains a wildcard, bypassing the proxy for every host.",
                "List only the specific internal hosts that must skip the proxy.");
            }
          }
          if (e.matchKey === "trusted_proxy" || e.matchKey === "trusted_proxies" || e.matchKey === "trust_proxy") {
            if (e.info.kind === "string" && (e.info.value === "*" || e.info.value.indexOf("0.0.0.0/0") !== -1)) {
              add("high", e.matchKey, e.line, null,
                "The trusted-proxy setting trusts every address, so any visitor can spoof proxy headers such as X-Forwarded-For.",
                "Restrict trusted proxies to the exact addresses of your own reverse proxy.");
            }
          }
        }

        /* extensions exposure */
        var extOn = findEntry("extensions_enabled");
        if (extOn && truthy(extOn.info)) {
          add("low", "extensions_enabled", extOn.line, null,
            "Extensions are enabled. Each extension runs with the app's privileges.",
            "Enable only extensions you have reviewed, and keep them updated.");
        }

        findings.sort(function (a, b) {
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          return (a.line || 0) - (b.line || 0);
        });

        var verdict;
        if (findings.length === 0) verdict = "SAFE TO DEPLOY";
        else if (findings.some(function (f) { return f.severity === "critical"; })) verdict = "DO NOT DEPLOY";
        else verdict = "DEPLOY WITH FIXES";

        return {
          verdict: verdict,
          findings: findings,
          passes: passes,
          recognized: recognized,
          lineCount: parsed.lines.length,
          entries: entries
        };
      }

      /* ---------- Exports (never contain secret values) ---------- */

      function countSeverity(findings, sev) {
        return findings.filter(function (f) { return f.severity === sev; }).length;
      }

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs FreshRSS Server Config Safety Auditor - Report");
        out.push("Verdict: " + result.verdict);
        out.push("Lines scanned: " + result.lineCount + " | Recognized settings: " + result.recognized +
          " | Findings: " + result.findings.length +
          " (critical " + countSeverity(result.findings, "critical") +
          ", high " + countSeverity(result.findings, "high") +
          ", medium " + countSeverity(result.findings, "medium") +
          ", low " + countSeverity(result.findings, "low") + ")");
        out.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          out.push("No recognizable FreshRSS settings were found in the pasted text, so there is nothing to grade.");
        } else if (result.findings.length === 0) {
          out.push("No findings. Every graded setting passed.");
        } else {
          out.push("FINDINGS");
          result.findings.forEach(function (f, idx) {
            out.push((idx + 1) + ". [" + f.severity.toUpperCase() + "] line " + (f.line == null ? "-" : f.line) +
              " | key \"" + f.key + "\"" +
              (f.valueLength != null ? " | value length " + f.valueLength : ""));
            out.push("   " + f.issue);
            out.push("   Fix: " + f.fix);
          });
        }
        if (result.passes.length) {
          out.push("");
          out.push("CHECKS PASSED");
          result.passes.forEach(function (p) { out.push("- " + p); });
        }
        out.push("");
        out.push("Secret values are never shown: findings carry the key name, line number, and value length only.");
        return out.join("\n");
      }

      function buildJSON(result) {
        var obj = {
          tool: "J-Dawgs FreshRSS Server Config Safety Auditor",
          verdict: result.verdict,
          linesScanned: result.lineCount,
          recognizedSettings: result.recognized,
          summary: {
            critical: countSeverity(result.findings, "critical"),
            high: countSeverity(result.findings, "high"),
            medium: countSeverity(result.findings, "medium"),
            low: countSeverity(result.findings, "low")
          },
          findings: result.findings.map(function (f) {
            return {
              severity: f.severity,
              key: f.key,
              line: f.line,
              valueLength: f.valueLength,
              issue: f.issue,
              fix: f.fix
            };
          }),
          passedChecks: result.passes,
          note: "Secret values are never included: findings carry key, line, and value length only."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-freshrss-server-config-safety-auditortm',
  name: 'J-Dawgs FreshRSS Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted FreshRSS config.php offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
