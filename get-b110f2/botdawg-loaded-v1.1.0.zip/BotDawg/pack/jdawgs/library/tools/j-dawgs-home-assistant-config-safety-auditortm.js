'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Home Assistant Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var inputEl = document.getElementById("config-input");
        var bannerEl = document.getElementById("verdict-banner");
        var reportEl = document.getElementById("report-body");
        var countsEl = document.getElementById("counts");
        var findingsBody = document.getElementById("findings-body");
        var findingsEmpty = document.getElementById("findings-empty");
        var notParsedList = document.getElementById("notparsed-list");
        var notParsedEmpty = document.getElementById("notparsed-empty");
        var copyNote = document.getElementById("copy-note");

        // The risky worked example is captured from the preloaded textarea so
        // its text lives in exactly one place on this page: the input box.
        var RISKY_EXAMPLE = inputEl.value;

        var HARDENED_EXAMPLE = [
          "homeassistant:",
          "  name: Home",
          '  external_url: "https://myhouse.example.com"',
          '  internal_url: "https://192.168.1.50:8123"',
          "  auth_providers:",
          "    - type: homeassistant",
          "  allowlist_external_dirs:",
          '    - "/config/www"',
          "http:",
          "  server_host: 127.0.0.1",
          "  server_port: 8123",
          "  use_x_forwarded_for: true",
          "  trusted_proxies:",
          "    - 127.0.0.1",
          "    - 172.30.33.0/24",
          "mqtt:",
          "  broker: 192.168.1.60",
          "  password: !secret mqtt_password"
        ].join("\n");

        var HA_TOP_KEYS = {
          homeassistant: true, http: true, default_config: true, logger: true,
          recorder: true, history: true, frontend: true, automation: true,
          script: true, scene: true, sensor: true
        };
        var SECRET_KEYS = ["api_password", "access_token", "client_secret", "api_key", "password", "token", "secret"];
        var SEV_ORDER = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };

        function cleanValue(raw) {
          var v = (raw || "").trim();
          if (v.charAt(0) === '"' || v.charAt(0) === "'") {
            var q = v.charAt(0);
            var end = v.indexOf(q, 1);
            if (end > 0) return v.slice(1, end);
            return v.slice(1);
          }
          var hash = v.indexOf(" #");
          if (hash >= 0) v = v.slice(0, hash);
          return v.trim();
        }

        function urlOrigin(v) {
          var m = v.match(/^(https?:\/\/[^\/\s"']+)/i);
          return m ? m[1] : v;
        }

        function isSecretKey(keyLower) {
          for (var i = 0; i < SECRET_KEYS.length; i++) {
            if (keyLower === SECRET_KEYS[i] || keyLower.indexOf(SECRET_KEYS[i]) !== -1) return true;
          }
          return false;
        }

        function isBroadProxy(v) {
          return v === "0.0.0.0/0" || v === "::/0" || v === "0.0.0.0" || v === "::" || /\/0$/.test(v);
        }

        function audit(text) {
          var findings = [];
          var notParsed = [];
          function add(sev, cat, line, msg) {
            findings.push({ severity: sev, category: cat, line: line, message: msg });
          }

          if (!text || !text.trim()) {
            return { graded: false, verdict: "NOT ENOUGH TO GRADE", findings: findings, notParsed: notParsed,
                     why: "The input box is empty. Paste a Home Assistant configuration.yaml to get a verdict." };
          }

          var lines = text.replace(/\r\n?/g, "\n").split("\n");

          // --- Pre-scan: Home Assistant detection ---
          var isHA = /homeassistant/i.test(text);
          for (var d = 0; d < lines.length; d++) {
            var dm = lines[d].match(/^([A-Za-z0-9_.\-]+)\s*:/);
            if (dm && HA_TOP_KEYS[dm[1].toLowerCase()]) { isHA = true; break; }
          }
          if (!isHA) {
            return { graded: false, verdict: "NOT ENOUGH TO GRADE", findings: findings, notParsed: notParsed,
                     why: "No Home Assistant top-level keys (homeassistant:, http:, default_config:, recorder:, automation:, …) were found, so this does not look like a Home Assistant configuration.yaml. Nothing was graded." };
          }

          // --- Main heuristic line pass ---
          var stack = []; // {key, indent}
          var homeassistantLine = 0;
          var authProvidersPresent = false;
          var typeFindings = []; // emitted only if auth_providers exists
          var uxff = null; // {line}
          var trustedProxiesPresent = false;
          var trustedProxyEntries = []; // {line, value}
          var recorderSeen = []; // {name, line}
          var limitsSeen = false;

          function ownerKey() {
            return stack.length ? stack[stack.length - 1].key : null;
          }

          function checkListEntry(owner, value, lineNo) {
            var v = cleanValue(value);
            if (!v) return;
            if (owner === "trusted_proxies") {
              trustedProxyEntries.push({ line: lineNo, value: v });
            } else if (owner === "allowlist_external_dirs" || owner === "whitelist_external_dirs") {
              if (v === "/" || v === "/*" || v === "*" || /\/\*$/.test(v)) {
                add("HIGH", "Allowlists", lineNo,
                  owner + ' includes "' + v + '" — that exposes effectively every directory on the system to Home Assistant file access. Narrow it to the specific folders the setup actually needs.');
              }
            } else if (owner === "allowlist_external_urls" || owner === "whitelist_external_urls") {
              if (v.indexOf("*") !== -1) {
                add("HIGH", "Allowlists", lineNo,
                  owner + ' includes the wildcard entry "' + urlOrigin(v) + '" (with a * wildcard) — any matching external URL can be fetched. Replace the wildcard with the exact URLs required.');
              } else if (/^http:\/\//i.test(v)) {
                add("MEDIUM", "Allowlists", lineNo,
                  owner + ' includes the plain-http URL "' + urlOrigin(v) + '" — fetched content travels unencrypted.');
              }
            } else if (owner === "exposed_domains") {
              add("MEDIUM", "Exposed domains", lineNo,
                'exposed_domains lists "' + v + '" — review that this domain is meant to be reachable through the exposed surface.');
            }
          }

          function checkKey(key, rawValue, lineNo, effIndent) {
            var keyLower = key.toLowerCase();
            var value = cleanValue(rawValue);
            var rawTrim = (rawValue || "").trim();

            // Inline flow list, e.g. trusted_proxies: [127.0.0.1, 10.0.0.0/8]
            if (rawTrim.charAt(0) === "[") {
              var inner = rawTrim.replace(/^\[/, "").replace(/\]$/, "");
              var parts = inner.split(",");
              for (var p = 0; p < parts.length; p++) {
                if (parts[p].trim()) checkListEntry(keyLower, parts[p], lineNo);
              }
            }

            if (keyLower === "server_host") {
              if (value === "0.0.0.0" || value === "::" || value === "[::]") {
                add("CRITICAL", "HTTP exposure", lineNo,
                  "http server_host binds all interfaces (" + value + ") — the Home Assistant web interface listens on every network interface, including any it was never meant to face. Bind it to 127.0.0.1 or one specific LAN address instead.");
              } else if (value === "127.0.0.1" || value === "::1" || value.toLowerCase() === "localhost") {
                add("INFO", "HTTP exposure", lineNo,
                  "http server_host is bound to " + value + " (loopback only) — not reachable from other devices directly.");
              }
            }

            if (keyLower === "server_port" && /^\d+$/.test(value)) {
              if (value === "8123") {
                add("INFO", "HTTP exposure", lineNo, "http server_port is 8123 (the Home Assistant default).");
              } else {
                add("LOW", "HTTP exposure", lineNo,
                  "http server_port is " + value + " — a non-standard port (the default is 8123). Fine if deliberate; make sure proxies, firewall rules, and bookmarks agree on it.");
              }
            }

            if (keyLower === "external_url" && /^http:\/\//i.test(value)) {
              add("HIGH", "Plain-HTTP URL", lineNo,
                'external_url uses plain http:// ("' + urlOrigin(value) + '") — the address the outside world uses to reach this instance is unencrypted, so sessions and credentials can be intercepted. Serve it over https:// with a valid certificate.');
            }
            if (keyLower === "internal_url" && /^http:\/\//i.test(value)) {
              add("MEDIUM", "Plain-HTTP URL", lineNo,
                'internal_url uses plain http:// ("' + urlOrigin(value) + '") — unencrypted on the home network. Lower risk than a public plain-http address, but https:// is the right default here too.');
            }

            if (keyLower === "use_x_forwarded_for" && /^(true|yes|on)$/i.test(value)) {
              uxff = { line: lineNo };
            }
            if (keyLower === "trusted_proxies") {
              trustedProxiesPresent = true;
              if (value && rawTrim.charAt(0) !== "[") {
                trustedProxyEntries.push({ line: lineNo, value: value });
              }
            }

            if (keyLower === "auth_providers") authProvidersPresent = true;
            if (keyLower === "type") {
              if (value === "trusted_networks") {
                typeFindings.push({ sev: "HIGH", line: lineNo,
                  msg: "auth_providers includes the trusted_networks provider — devices connecting from the listed networks can sign in without a password. One spoofed or over-broad network entry turns this into an open door." });
              } else if (value === "homeassistant") {
                typeFindings.push({ sev: "INFO", line: lineNo,
                  msg: "auth_providers uses the built-in homeassistant provider (username + password sign-in)." });
              }
            }

            if (keyLower === "allowlist_external_dirs" || keyLower === "whitelist_external_dirs" ||
                keyLower === "allowlist_external_urls" || keyLower === "whitelist_external_urls") {
              if (value) checkListEntry(keyLower, value, lineNo);
            }

            if (keyLower.indexOf("expose") !== -1 && keyLower !== "exposed_domains") {
              add("MEDIUM", "Exposed domains", lineNo,
                'Setting "' + key + '" controls what this instance exposes — review it line by line and expose only the domains and entities that are meant to be reachable.');
            }
            if (/\*\./.test(value)) {
              add("MEDIUM", "Exposed domains", lineNo,
                'Wildcard domain value on "' + key + '" — a *. wildcard exposes every subdomain at once. List the exact domains instead.');
            }

            if (keyLower === "purge_keep_days" || keyLower === "purge_interval" ||
                keyLower === "include" || keyLower === "exclude") {
              limitsSeen = true;
            }
            if (effIndent === 0 && (keyLower === "recorder" || keyLower === "history")) {
              recorderSeen.push({ name: keyLower, line: lineNo });
            }

            // --- Secret-looking keys: key name + line + length ONLY ---
            if (isSecretKey(keyLower) && rawTrim) {
              if (/^!secret\b/i.test(rawTrim)) {
                add("INFO", "Secrets", lineNo,
                  key + " (line " + lineNo + ") uses a !secret reference — good practice; the value lives in secrets.yaml and was not read.");
              } else if (value) {
                if (keyLower.indexOf("api_password") !== -1) {
                  add("CRITICAL", "Secrets", lineNo,
                    "Legacy api_password present in plaintext — api_password (line " + lineNo + ", value length " + value.length + " chars) — value redacted. api_password is the retired pre-token login mechanism; remove it and use long-lived access tokens or the normal sign-in instead.");
                } else {
                  add("HIGH", "Secrets", lineNo,
                    "Plaintext secret in " + key + " (line " + lineNo + ", value length " + value.length + " chars) — value redacted. Move it to secrets.yaml and reference it here as !" + "secret so the value never sits in the main config.");
                }
              }
            }
          }

          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            if (!raw.trim()) continue;

            var lead = raw.match(/^[ \t]*/)[0];
            if (lead.indexOf("\t") !== -1) {
              notParsed.push({ line: lineNo, note: "Tab indentation — YAML forbids tabs and this heuristic pass will not guess at the structure. NOT PARSED / NOT EVALUATED." });
              continue;
            }
            var indent = lead.length;
            var trimmed = raw.trim();
            if (trimmed.charAt(0) === "#") continue;

            var isItem = trimmed === "-" || trimmed.indexOf("- ") === 0;
            var content = isItem ? trimmed.slice(1).trim() : trimmed;

            if (content.indexOf("<<") === 0) {
              notParsed.push({ line: lineNo, note: "YAML merge key — merge keys are not evaluated by this heuristic pass. NOT PARSED / NOT EVALUATED." });
              continue;
            }

            var km = content.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
            if (km) {
              var key = km[1];
              var rawValue = km[2];
              var effIndent = isItem ? indent + 2 : indent;
              while (stack.length && stack[stack.length - 1].indent >= effIndent) stack.pop();
              checkKey(key, rawValue, lineNo, effIndent);
              if (effIndent === 0 && key.toLowerCase() === "homeassistant" && !homeassistantLine) {
                homeassistantLine = lineNo;
              }
              if (/^&[A-Za-z0-9_]+/.test((rawValue || "").trim())) {
                notParsed.push({ line: lineNo, note: 'Anchor on "' + key + '" — anchors and aliases are not resolved by this heuristic pass. NOT EVALUATED.' });
              }
              stack.push({ key: key.toLowerCase(), indent: effIndent });
            } else if (isItem) {
              while (stack.length && stack[stack.length - 1].indent > indent) stack.pop();
              var owner = ownerKey();
              if (owner) checkListEntry(owner, content, lineNo);
            } else {
              notParsed.push({ line: lineNo, note: "Line could not be classified as a key, a list entry, or a comment by the heuristic pass. NOT PARSED / NOT EVALUATED." });
            }
          }

          // --- Post-pass checks that need the whole file ---
          if (uxff) {
            if (!trustedProxiesPresent) {
              add("CRITICAL", "Forwarded headers", uxff.line,
                "use_x_forwarded_for: true with no trusted_proxies list anywhere in the config — Home Assistant will believe X-Forwarded-For headers from any client, so anyone can spoof their IP address and defeat IP-based protections. Add a trusted_proxies list naming only your real proxy, or turn use_x_forwarded_for off.");
            } else {
              var broad = trustedProxyEntries.filter(function (e) { return isBroadProxy(e.value); });
              if (broad.length) {
                broad.forEach(function (e) {
                  add("CRITICAL", "Forwarded headers", e.line,
                    'trusted_proxies includes "' + e.value + '" — that trusts forwarded headers from everywhere, which is the same as having no proxy restriction at all. List only the proxy\'s own address or its tight subnet.');
                });
              } else if (trustedProxyEntries.length) {
                add("INFO", "Forwarded headers", uxff.line,
                  "use_x_forwarded_for: true with a specific trusted_proxies list (" + trustedProxyEntries.length + (trustedProxyEntries.length === 1 ? " entry" : " entries") + ") — forwarded headers are trusted only from those proxies.");
              }
            }
          }

          if (authProvidersPresent) {
            typeFindings.forEach(function (f) { add(f.sev, "Authentication", f.line, f.msg); });
          } else {
            add("MEDIUM", "Authentication", homeassistantLine || 1,
              "No explicit auth_providers hardening found — the config never declares its sign-in providers, so it rides on defaults. Declare auth_providers under homeassistant: with type: homeassistant so the posture is a decision, not an accident.");
          }

          if (recorderSeen.length && !limitsSeen) {
            recorderSeen.forEach(function (r) {
              add("LOW", "Recorder / history", r.line,
                r.name + ": is enabled and no purge or include/exclude limits were detected by this heuristic pass — history can grow without bound and everything recorded stays browsable in the UI. Set purge_keep_days and include/exclude rules if that is not deliberate.");
            });
          }

          findings.sort(function (a, b) {
            if (a.line !== b.line) return a.line - b.line;
            return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          });
          notParsed.sort(function (a, b) { return a.line - b.line; });

          var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict, why;
          if (counts.CRITICAL > 0) {
            verdict = "DO NOT RUN";
            why = counts.CRITICAL + (counts.CRITICAL === 1 ? " critical finding" : " critical findings") + " — fix those before this configuration ever runs.";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0) {
            verdict = "RUN WITH FIXES";
            why = "No critical findings, but " + (counts.HIGH + counts.MEDIUM) + (counts.HIGH + counts.MEDIUM === 1 ? " high/medium finding needs" : " high/medium findings need") + " attention before this runs as-is.";
          } else {
            verdict = "SAFE TO RUN";
            why = "No critical, high, or medium findings. (This grades safety posture only — it does not promise the config will load.)";
          }
          return { graded: true, verdict: verdict, why: why, counts: counts, findings: findings, notParsed: notParsed };
        }

        var lastReport = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-home-assistant-config-safety-auditortm',
  name: 'J-Dawgs Home Assistant Config Safety Auditor',
  description: 'Grades a pasted Home Assistant configuration.yaml offline into one deploy verdict (SAFE TO RUN / RUN WITH FIXES / DO NOT RUN): all-interface http binding, http:// external/internal URLs, use_x_forwarded_for without trusted_proxies, legacy api_password, allowlist breadth — secrets reported by key nam',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
