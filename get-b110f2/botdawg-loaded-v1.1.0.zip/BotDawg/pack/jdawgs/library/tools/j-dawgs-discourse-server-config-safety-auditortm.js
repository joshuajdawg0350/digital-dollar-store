'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Discourse Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "## containers/app.yml - risky sample",
        "env:",
        "  DISCOURSE_HOSTNAME: forum.example.com",
        "  DISCOURSE_SMTP_ADDRESS: smtp.example.com",
        "  DISCOURSE_SMTP_PORT: 587",
        "  DISCOURSE_SMTP_PASSWORD: hunter2",
        "  # DISCOURSE_DB_PASSWORD: oldpassword123",
        "  DISCOURSE_HOSTNAME: forum.example.com",
        "  DISCOURSE_CDN_URL https://cdn.example.com",
        "expose:",
        "  - \"80:80\"",
        "  - \"443:443\"",
        "  - \"5432:5432\""
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "## containers/app.yml - hardened sample",
        "env:",
        "  LANG: en_US.UTF-8",
        "  UNICORN_WORKERS: 4",
        "  DISCOURSE_HOSTNAME: forum.example.com",
        "  DISCOURSE_DEVELOPER_EMAILS: admin@example.com",
        "  DISCOURSE_SMTP_ADDRESS: smtp.example.com",
        "  DISCOURSE_SMTP_PORT: 587",
        "  DISCOURSE_SMTP_ENABLE_START_TLS: true",
        "  DISCOURSE_SMTP_PASSWORD: ${DISCOURSE_SMTP_PASSWORD}",
        "  DISCOURSE_DB_PASSWORD: ${DB_PASSWORD}",
        "  DISCOURSE_REDIS_PASSWORD: ${REDIS_PASSWORD}",
        "  DISCOURSE_S3_SECRET_ACCESS_KEY: ${S3_SECRET_ACCESS_KEY}",
        "expose:",
        "  - \"80:80\"",
        "  - \"443:443\""
      ].join("\n");

      var PITCHES = {
        "pitch-store": "J-Dawgs AI Tool Store - browser-only safety auditors and working tools for people who run their own servers: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "pitch-exchange": "J-Dawgs Agent Exchange - hire an agent for the next job, or list your own: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "pitch-bundle": "Post It, Discuss It, Lift It Right Stack \u2014 Mastodon Server Config Safety Auditor + Discourse Server Config Safety Auditor + Garage Door Proposal, Work Record & Final Invoice Consistency Auditor: grade the federation server, grade the forum server, cross-check the garage-door bill ($2.75 full pass)."
      };

      var SECTION_NAMES = { env: 1, expose: 1, templates: 1, params: 1, volumes: 1, hooks: 1, run: 1, labels: 1, services: 1 };
      var SECRET_KEY_RE = /(PASSWORD|SECRET|_KEY)/;

      function unquote(v) {
        v = String(v).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }

      function isRecognizedKey(key) {
        return key.indexOf("DISCOURSE_") === 0 || key === "LANG" || key === "UNICORN_WORKERS";
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = [];       // {key, value, line}
        var exposeEntries = []; // {value, line}
        var commented = [];     // {line, keyGuess}
        var notParsed = [];     // line numbers
        var section = null;
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var trimmed = raw.trim();
          if (trimmed === "") continue;
          if (trimmed.charAt(0) === "#") {
            var body = trimmed.replace(/^#+\s*/, "");
            var km = body.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:/);
            commented.push({ line: lineNo, keyGuess: km ? km[1] : null });
            continue;
          }
          var listMatch = trimmed.match(/^-\s+(.+)$/);
          if (listMatch) {
            if (section === "expose") {
              exposeEntries.push({ value: unquote(listMatch[1]), line: lineNo });
            }
            continue; // list entries are parsed, just only graded under expose:
          }
          var kv = raw.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$/);
          if (kv) {
            var key = kv[1];
            var rawVal = kv[2].trim();
            if (rawVal === "" && SECTION_NAMES[key.toLowerCase()]) {
              section = key.toLowerCase();
              continue;
            }
            entries.push({ key: key, value: unquote(rawVal), line: lineNo });
            continue;
          }
          notParsed.push(lineNo);
        }
        return { entries: entries, exposeEntries: exposeEntries, commented: commented, notParsed: notParsed };
      }

      function audit(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, line, title, detail, fix) {
          findings.push({ severity: severity, line: line, title: title, detail: detail, fix: fix || "" });
        }

        // Effective settings: last value wins.
        var eff = {};
        var occurrences = {};
        parsed.entries.forEach(function (e) {
          eff[e.key] = e;
          if (!occurrences[e.key]) occurrences[e.key] = [];
          occurrences[e.key].push(e);
        });

        var recognized = {};
        parsed.entries.forEach(function (e) { if (isRecognizedKey(e.key)) recognized[e.key] = true; });
        var recognizedCount = Object.keys(recognized).length;

        // Parse-level findings are always reported.
        parsed.notParsed.forEach(function (lineNo) {
          add("NOT PARSED", lineNo, "Line could not be read",
            "This line is not a key: value pair, not a list entry, and not a comment or blank line, so it was not graded. Nothing about it was guessed.",
            "Rewrite it as KEY: value (or a \"- ...\" list entry under a section), or comment it out with # if it is just a note.");
        });
        parsed.commented.forEach(function (c) {
          var what = c.keyGuess ? (" The commented-out setting is " + c.keyGuess + ".") : "";
          add("COMMENTED", c.line, "Commented out - not active",
            "This line starts with #, so it is COMMENTED / NOT ACTIVE and was not graded as set." + what,
            "If you want this setting to apply, remove the leading #.");
        });

        if (recognizedCount < 3) {
          add("INFO", null, "Not enough recognized Discourse settings",
            "Only " + recognizedCount + " recognized Discourse setting(s) were found (keys such as DISCOURSE_HOSTNAME, DISCOURSE_SMTP_ADDRESS, LANG, UNICORN_WORKERS). A grade needs at least 3, so no deployment verdict can be given for this text.",
            "Paste the env: block (and expose: list) from a Discourse containers/app.yml-style config and audit again.");
          return finish("NOT ENOUGH TO GRADE", recognizedCount, findings,
            "Fewer than 3 recognized Discourse settings were found, so this text cannot be graded.");
        }

        // Production-looking? Used for the localhost hostname grade.
        var prodLooking = false;
        if (eff["DISCOURSE_SMTP_ADDRESS"] && eff["DISCOURSE_SMTP_ADDRESS"].value) prodLooking = true;
        if (eff["DISCOURSE_DEVELOPER_EMAILS"] && eff["DISCOURSE_DEVELOPER_EMAILS"].value) prodLooking = true;
        parsed.exposeEntries.forEach(function (x) {
          var segs = x.value.split(":");
          if (segs[segs.length - 1].replace(/\/(tcp|udp)$/i, "") === "443") prodLooking = true;
        });

        // --- DISCOURSE_HOSTNAME ---
        var host = eff["DISCOURSE_HOSTNAME"];
        if (!host || !host.value) {
          add("BLOCKER", host ? host.line : null, "DISCOURSE_HOSTNAME is missing",
            "DISCOURSE_HOSTNAME is not set. Discourse builds every link, email, and cookie around this hostname; without it the forum cannot run correctly.",
            "Add DISCOURSE_HOSTNAME: your-forum-domain.com (bare hostname only) to the env block.");
        } else {
          var hv = host.value;
          var problems = [];
          var rest = hv;
          if (/:\/\//.test(hv)) { problems.push("it includes a scheme (http:// or https://)"); rest = hv.split("://")[1] || ""; }
          if (rest.indexOf("/") !== -1) problems.push("it includes a path");
          if (/:\d+/.test(rest)) problems.push("it includes a port");
          var isLocal = /(^|\.)localhost$/.test(rest.split("/")[0].split(":")[0]) || rest.indexOf("127.0.0.1") === 0;
          if (isLocal) {
            if (prodLooking) {
              add("WARNING", host.line, "Hostname is localhost on a production-looking config",
                "DISCOURSE_HOSTNAME points at localhost, but the rest of this config looks like a production setup (mail and/or HTTPS exposure present). Links and emails would point at localhost for every visitor.",
                "Set DISCOURSE_HOSTNAME to the forum's real public hostname.");
            } else {
              add("INFO", host.line, "Hostname is localhost (development posture)",
                "DISCOURSE_HOSTNAME is localhost and nothing else in this config looks like production, so this reads as a local development setup. That is fine for development and wrong for a public forum.",
                "Before deploying publicly, change DISCOURSE_HOSTNAME to the forum's real public hostname.");
            }
          } else if (problems.length) {
            add("WARNING", host.line, "Hostname is not a bare hostname",
              "DISCOURSE_HOSTNAME is \"" + hv + "\": " + problems.join("; ") + ". Discourse expects the bare hostname only.",
              "Set it to the bare hostname, e.g. DISCOURSE_HOSTNAME: forum.example.com - no scheme, no port, no path.");
          } else {
            add("PASS", host.line, "DISCOURSE_HOSTNAME is a bare hostname",
              "DISCOURSE_HOSTNAME is set to a bare hostname with no scheme, port, or path - the shape Discourse expects.", "");
          }
        }

        // --- Plaintext secret keys (value is NEVER printed) ---
        parsed.entries.forEach(function (e) {
          if (!SECRET_KEY_RE.test(e.key)) return;
          var v = e.value;
          if (v === "") {
            add("PASS", e.line, e.key + " has no literal value in the file",
              "This password/key setting is present but empty, so no secret is stored in the config itself.", "");
          } else if (v.indexOf("${") === 0 || v.indexOf("{{") !== -1) {
            add("PASS", e.line, e.key + " uses a reference, not a literal secret",
              "The value of " + e.key + " is a ${...} reference or {{ ... }} template, so the actual secret lives outside this file. That is the safe pattern.", "");
          } else {
            add("HIGH", e.line, "Plaintext secret in " + e.key,
              e.key + " is set to a literal value in this file (value length: " + v.length + " characters - the value itself is never shown here). Anyone who can read this file - a backup, a screenshot, a pasted snippet - has the secret.",
              "Move the secret out of the file: reference it as ${...} from the environment or a secret store, and rotate the exposed secret since it has been written down in plaintext.");
          }
        });

        // --- DISCOURSE_DEVELOPER_EMAILS ---
        var dev = eff["DISCOURSE_DEVELOPER_EMAILS"];
        if (!dev || !dev.value) {
          add("WARNING", null, "DISCOURSE_DEVELOPER_EMAILS is missing",
            "DISCOURSE_DEVELOPER_EMAILS is not set. The addresses in this setting silently become admins when their accounts are created - with it missing, no account gets that automatic admin path, and on a fresh install you can be left with no way into the admin panel.",
            "Add DISCOURSE_DEVELOPER_EMAILS: you@example.com with the address you will sign up with first.");
        } else {
          add("PASS", dev.line, "DISCOURSE_DEVELOPER_EMAILS is set",
            "Developer emails are present. Remember what this setting does: those accounts silently become admins when created, so keep the list to addresses you control.", "");
        }

        // --- SMTP posture ---
        var smtp = eff["DISCOURSE_SMTP_ADDRESS"];
        if (!smtp || !smtp.value) {
          add("WARNING", null, "DISCOURSE_SMTP_ADDRESS is missing - mail will not send",
            "No SMTP server is configured. Outgoing mail will not send, which breaks signup confirmations and password-reset emails - new users cannot finish joining.",
            "Add DISCOURSE_SMTP_ADDRESS (plus the SMTP user name, password reference, and port your mail provider gives you).");
        } else {
          add("PASS", smtp.line, "DISCOURSE_SMTP_ADDRESS is set",
            "An SMTP server is configured, so signup and password-reset mail has a route out.", "");
        }
        var smtpPort = eff["DISCOURSE_SMTP_PORT"];
        if (smtpPort && smtpPort.value === "25") {
          var tlsWording = parsed.entries.some(function (e) { return /TLS|SSL/.test(e.key); });
          if (!tlsWording) {
            add("INFO", smtpPort.line, "SMTP port 25 with no TLS setting",
              "DISCOURSE_SMTP_PORT is 25 and no TLS-related setting (such as DISCOURSE_SMTP_ENABLE_START_TLS) appears in the config. Many providers block or downgrade plain port 25, and credentials can travel unencrypted.",
              "Prefer port 587 with DISCOURSE_SMTP_ENABLE_START_TLS: true, unless your mail provider specifically documents port 25.");
          }
        }

        // --- Expose / bind posture ---
        parsed.exposeEntries.forEach(function (x) {
          var segs = x.value.split(":").map(function (s) { return s.replace(/\/(tcp|udp)$/i, "").trim(); });
          var containerPort = segs[segs.length - 1];
          var publishes5432 = segs.indexOf("5432") !== -1;
          var publishes6379 = segs.indexOf("6379") !== -1;
          if (publishes5432) {
            add("BLOCKER", x.line, "PostgreSQL port 5432 is published to the internet",
              "This expose entry (\"" + x.value + "\") publishes the PostgreSQL database port. Discourse's database is meant to live inside the container network only; publishing it gives the whole internet a shot at your forum's data.",
              "Delete the 5432 expose entry. Only 80 and 443 belong in the expose list.");
          } else if (publishes6379) {
            add("BLOCKER", x.line, "Redis port 6379 is published to the internet",
              "This expose entry (\"" + x.value + "\") publishes the Redis cache port. Redis has no login wall of its own here; publishing it exposes the forum's cache and session data to the internet.",
              "Delete the 6379 expose entry. Only 80 and 443 belong in the expose list.");
          } else if (containerPort === "80" || containerPort === "443") {
            add("INFO", x.line, "Port " + containerPort + " exposed - normal for Discourse",
              "Binding port " + containerPort + " on all interfaces (\"" + x.value + "\") is the normal, expected way a Discourse container serves the web. This is graded INFO on purpose, not a warning.", "");
          } else {
            add("INFO", x.line, "Extra published port " + (containerPort || x.value),
              "This expose entry (\"" + x.value + "\") publishes a port beyond the usual 80/443. It is not graded as a database/cache exposure, but anything published is reachable from the internet.",
              "If this port is not deliberately serving something, remove the entry.");
          }
        });

        // --- UNICORN_WORKERS / LANG ---
        if (!eff["UNICORN_WORKERS"]) {
          add("INFO", null, "UNICORN_WORKERS is not set",
            "UNICORN_WORKERS is absent, so Discourse uses its built-in default number of web workers. Fine on a small forum; worth setting deliberately on a busy one.",
            "Optionally add UNICORN_WORKERS sized to your server (a common starting point is 2-4 on small hosts).");
        }
        if (!eff["LANG"]) {
          add("INFO", null, "LANG is not set",
            "LANG is absent, so the container falls back to its default locale. Usually harmless, but an explicit locale avoids odd character/encoding surprises.",
            "Optionally add LANG: en_US.UTF-8 to the env block.");
        }

        // --- Duplicate keys: last value wins ---
        Object.keys(occurrences).forEach(function (key) {
          var occ = occurrences[key];
          if (occ.length > 1) {
            var linesList = occ.map(function (o) { return o.line; }).join(" and ");
            add("WARNING", occ[occ.length - 1].line, "Duplicate key: " + key,
              key + " is set on lines " + linesList + ". Duplicate keys follow the last-value-wins rule: the value on line " + occ[occ.length - 1].line + " is the one Discourse actually uses, and the earlier line is silently ignored - a classic source of \"I changed it but nothing happened.\"",
              "Delete all but one " + key + " line and keep the value you intend on the remaining line.");
          }
        });

        // --- Verdict ---
        var counts = countSeverities(findings);
        var verdict, why;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          why = counts.BLOCKER + " blocker(s) must be fixed before this config goes anywhere near a server.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          why = "No blockers, but " + (counts.HIGH + counts.WARNING) + " high/warning finding(s) should be fixed first.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No blockers, no high findings, no warnings. The remaining notes are informational or passing checks.";
        }
        return finish(verdict, recognizedCount, findings, why);
      }

      function countSeverities(findings) {
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, PASS: 0, "NOT PARSED": 0, COMMENTED: 0 };
        findings.forEach(function (f) { if (counts.hasOwnProperty(f.severity)) counts[f.severity]++; });
        return counts;
      }

      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, "NOT PARSED": 3, INFO: 4, COMMENTED: 5, PASS: 6 };
      function finish(verdict, recognizedCount, findings, why) {
        findings.sort(function (a, b) {
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });
        return { verdict: verdict, why: why, recognizedCount: recognizedCount, counts: countSeverities(findings), findings: findings };
      }

      function buildTextReport(result) {
        var c = result.counts;
        var out = [];
        out.push("J-DAWGS DISCOURSE SERVER CONFIG SAFETY AUDITOR - REPORT");
        out.push("Verdict: " + result.verdict);
        out.push("Recognized Discourse settings found: " + result.recognizedCount);
        out.push("Counts: BLOCKER " + c.BLOCKER + " | HIGH " + c.HIGH + " | WARNING " + c.WARNING +
                 " | INFO " + c.INFO + " | PASS " + c.PASS + " | NOT PARSED " + c["NOT PARSED"] + " | COMMENTED " + c.COMMENTED);
        out.push("Note: secret values are never printed in this report. Findings name only the key, its line, and the value length.");
        out.push("");
        out.push("FINDINGS");
        if (!result.findings.length) out.push("(none)");
        result.findings.forEach(function (f) {
          out.push("[" + f.severity + "] " + (f.line != null ? "Line " + f.line + " - " : "") + f.title);
          out.push("  " + f.detail);
          if (f.fix) out.push("  Fix: " + f.fix);
        });
        return out.join("\n");
      }

      function buildJsonReport(result) {
        return JSON.stringify({
          tool: "J-Dawgs Discourse Server Config Safety Auditor",
          verdict: result.verdict,
          recognizedDiscourseSettings: result.recognizedCount,
          counts: result.counts,
          note: "Secret values are never included; secret findings carry key name, line, and value length only.",
          findings: result.findings.map(function (f) {
            return { severity: f.severity, line: f.line, check: f.title, explanation: f.detail, fix: f.fix };
          })
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-discourse-server-config-safety-auditortm',
  name: 'J-Dawgs Discourse Server Config Safety Auditor',
  description: 'Grades a pasted Discourse app.yml fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — plaintext SMTP and database passwords, developer-admin emails, and published database ports, with secrets shown by key name, line, and length only, nev',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
