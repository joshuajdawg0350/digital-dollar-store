'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Apache HTTPd Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky worked example - not ready to ship",
    "ServerTokens Full",
    "ServerSignature On",
    "TraceEnable On",
    "<VirtualHost *:80>",
    "    ServerName shop.example.test",
    "    DocumentRoot /var/www/html",
    "    <Directory /var/www/html>",
    "        Options Indexes FollowSymLinks",
    "        AllowOverride All",
    "        Require all granted",
    "    </Directory>",
    "    SetEnv APP_DB_PASSWORD s3cr3t-value-never-shown",
    "</VirtualHost>"
  ].join("\n");

  var CLEAN = [
    "# Hardened worked example",
    "ServerTokens Prod",
    "ServerSignature Off",
    "TraceEnable Off",
    "<VirtualHost *:443>",
    "    ServerName shop.example.test",
    "    DocumentRoot /var/www/html",
    "    SSLEngine on",
    "    SSLCertificateFile /etc/ssl/certs/shop.pem",
    "    SSLCertificateKeyFile /etc/ssl/private/shop.key",
    "    <Directory \"/\">",
    "        Options -Indexes",
    "        AllowOverride None",
    "        Require all denied",
    "    </Directory>",
    "    <Directory /var/www/html>",
    "        Options -Indexes +FollowSymLinks",
    "        AllowOverride None",
    "        Require all granted",
    "    </Directory>",
    "    <FilesMatch \"^\\.env$|^\\.git\">",
    "        Require all denied",
    "    </FilesMatch>",
    "    <FilesMatch \"\\.(bak|old|swp|sql|zip)$\">",
    "        Require all denied",
    "    </FilesMatch>",
    "    ErrorDocument 404 /errors/404.html",
    "    ErrorDocument 500 /errors/500.html",
    "    ErrorLog /var/log/apache2/error.log",
    "    CustomLog /var/log/apache2/access.log combined",
    "    LogLevel warn",
    "</VirtualHost>"
  ].join("\n");

  var input = document.getElementById("configInput");
  var verdictBox = document.getElementById("verdictBox");
  var verdictWord = document.getElementById("verdictWord");
  var verdictWhy = document.getElementById("verdictWhy");
  var countsRow = document.getElementById("countsRow");
  var findingsWrap = document.getElementById("findingsWrap");
  var findingsList = document.getElementById("findingsList");
  var reportBox = document.getElementById("reportBox");
  var auditStatus = document.getElementById("auditStatus");
  var copyStatus = document.getElementById("copyStatus");
  var pitchStatus = document.getElementById("pitchStatus");

  var SEV_RANK = { "BLOCKER":0, "HIGH":1, "WARN":2, "REVIEW":3, "INFO":4 };

  function addFinding(list, sev, line, title, detail, fix){
    list.push({ sev:sev, line:line, title:title, detail:detail, fix:fix });
  }

  function isCommentOrBlank(t){
    var s = t.replace(/^\s+/, "");
    return s === "" || s.charAt(0) === "#";
  }

  function audit(text){
    var findings = [];
    var lines = text.split(/\r?\n/);
    var i, line, t;

    // Track block context: Directory and VirtualHost, line by line.
    var dirStack = [];       // {path, startLine, body:[{n,text}]}
    var dirBlocks = [];
    var vhostStack = [];     // {addr, startLine, body:[{n,text}]}
    var vhostBlocks = [];
    var filesBlocks = [];    // {pattern, startLine, bodyText}
    var filesStack = [];

    for (i = 0; i < lines.length; i++){
      line = lines[i]; t = line.replace(/^\s+/, "");
      var n = i + 1;
      var mDir = t.match(/^<Directory\s+([^>]+)>/i);
      var mVhost = t.match(/^<VirtualHost\s+([^>]+)>/i);
      var mFiles = t.match(/^<Files(Match)?\s+([^>]+)>/i);
      if (mDir) dirStack.push({ path:mDir[1].replace(/["']/g,"").replace(/\s+$/,""), startLine:n, body:[] });
      if (mVhost) vhostStack.push({ addr:mVhost[1], startLine:n, body:[] });
      if (mFiles) filesStack.push({ pattern:mFiles[2], startLine:n, body:[] });
      if (/^<\/Directory>/i.test(t) && dirStack.length){ dirBlocks.push(dirStack.pop()); }
      if (/^<\/VirtualHost>/i.test(t) && vhostStack.length){ vhostBlocks.push(vhostStack.pop()); }
      if (/^<\/Files(Match)?>/i.test(t) && filesStack.length){ filesBlocks.push(filesStack.pop()); }
      if (dirStack.length) dirStack[dirStack.length-1].body.push({ n:n, text:line });
      if (vhostStack.length) vhostStack[vhostStack.length-1].body.push({ n:n, text:line });
      if (filesStack.length) filesStack[filesStack.length-1].body.push({ n:n, text:line });
    }
    while (dirStack.length) dirBlocks.push(dirStack.pop());
    while (vhostStack.length) vhostBlocks.push(vhostStack.pop());
    while (filesStack.length) filesBlocks.push(filesStack.pop());

    var hasRequire = false, firstOrderLine = 0, hasLegacyAllowDeny = false;
    var hasErrorDocument = false, hasErrorLog = false, hasCustomLog = false, hasLogLevel = false;
    var sslOffLines = [];

    for (i = 0; i < lines.length; i++){
      line = lines[i]; t = line.replace(/^\s+/, "");
      var ln = i + 1;
      if (isCommentOrBlank(line)) continue;

      // --- Directory listing: Options Indexes / +Indexes ---
      var mOpt = t.match(/^Options\s+(.+)$/i);
      if (mOpt){
        var tokens = mOpt[1].split(/\s+/);
        for (var k = 0; k < tokens.length; k++){
          if (tokens[k] === "Indexes" || tokens[k] === "+Indexes"){
            addFinding(findings, "BLOCKER", ln, "Directory listing is on (Options Indexes)",
              "This Options line enables Indexes, so anyone can browse a listing of every file in the affected folders, including files you never linked to.",
              "Remove Indexes, or use -Indexes, and re-audit.");
          }
        }
      }

      // --- ServerTokens Full ---
      if (/^ServerTokens\s+Full\b/i.test(t)){
        addFinding(findings, "WARN", ln, "ServerTokens Full advertises the exact build",
          "ServerTokens Full puts the full Apache version and module details in response headers and error pages, handing probers a shopping list of known vulnerabilities.",
          "Set ServerTokens Prod.");
      }

      // --- ServerSignature On ---
      if (/^ServerSignature\s+On\b/i.test(t)){
        addFinding(findings, "WARN", ln, "ServerSignature On stamps server details on error pages",
          "Server-generated pages (errors, directory listings) carry a footer with the server version and host name.",
          "Set ServerSignature Off.");
      }

      // --- TraceEnable On ---
      if (/^TraceEnable\s+On\b/i.test(t)){
        addFinding(findings, "HIGH", ln, "TraceEnable On enables HTTP TRACE",
          "TRACE echoes request headers back to the caller and is used in cross-site tracing attacks against visitors.",
          "Set TraceEnable Off.");
      }

      // --- AllowOverride All ---
      if (/^AllowOverride\s+All\b/i.test(t)){
        // Find enclosing Directory, if any.
        var enclosing = null;
        for (var d = 0; d < dirBlocks.length; d++){
          if (dirBlocks[d].startLine < ln){
            for (var b = 0; b < dirBlocks[d].body.length; b++){
              if (dirBlocks[d].body[b].n === ln) enclosing = dirBlocks[d];
            }
          }
        }
        var scope = enclosing ? ("inside <Directory " + enclosing.path + ">") : "outside any Directory block, so it applies broadly";
        addFinding(findings, "WARN", ln, "AllowOverride All " + scope,
          "Any .htaccess file dropped into scope can rewrite access rules, options, and handlers, quietly undoing the hardening in this file.",
          "Use AllowOverride None, or list only the directive groups you truly need (for example AuthConfig, Limit).");
      }

      // --- SSLEngine off ---
      if (/^SSLEngine\s+off\b/i.test(t)){
        sslOffLines.push(ln);
        addFinding(findings, "HIGH", ln, "SSLEngine off disables TLS",
          "SSLEngine is explicitly off here. If this belongs to a port 443 host, visitors get plaintext HTTP where they expect encryption.",
          "Set SSLEngine on for the 443 host and configure a certificate.");
      }

      // --- Access syntax tracking ---
      if (/^Require\s/i.test(t)) hasRequire = true;
      if (/^Order\s/i.test(t) && !firstOrderLine) firstOrderLine = ln;
      if (/^(Allow|Deny)\s+from\s/i.test(t)) hasLegacyAllowDeny = true;

      // --- Error / logging posture ---
      if (/^ErrorDocument\s/i.test(t)) hasErrorDocument = true;
      if (/^ErrorLog\s/i.test(t)) hasErrorLog = true;
      if (/^CustomLog\s/i.test(t)) hasCustomLog = true;
      if (/^LogLevel\s/i.test(t)) hasLogLevel = true;

      // --- Plaintext secrets: key NAME and line only, value masked ---
      var secretKey = null;
      var mSetEnv = t.match(/^SetEnv\s+([A-Za-z0-9_.-]+)\s+(\S+)/i);
      if (mSetEnv && /(PASSWORD|PASSWD|SECRET|API_?KEY|TOKEN|AUTH)/i.test(mSetEnv[1])
          && mSetEnv[2].charAt(0) !== "$" && mSetEnv[2].indexOf("${") !== 0) {
        secretKey = mSetEnv[1];
      }
      if (!secretKey){
        var mAssign = t.match(/^([A-Za-z0-9_.-]+)\s*=\s*(\S+)/);
        if (mAssign && /(PASSWORD|PASSWD|SECRET|API_?KEY|TOKEN)/i.test(mAssign[1])
            && mAssign[2].charAt(0) !== "$" && mAssign[2].indexOf("${") !== 0) {
          secretKey = mAssign[1];
        }
      }
      if (!secretKey){
        var mPhp = t.match(/^php_(value|admin_value)\s+([A-Za-z0-9_.-]+)\s+(\S+)/i);
        if (mPhp && /(PASSWORD|PASSWD|SECRET|API_?KEY|TOKEN)/i.test(mPhp[2])) secretKey = mPhp[2];
      }
      if (secretKey){
        addFinding(findings, "HIGH", ln, "Plaintext secret in the config (value masked)",
          "The key " + secretKey + " has a literal value on this line (shown masked: ••••••••). Config files get copied, committed, and backed up — the secret travels with every copy.",
          "Remove the value from the config, load it from outside the document root or the server environment, and rotate the secret since it has been written down.");
      }
    }

    // --- SSLEngine missing on a detectable :443 vhost ---
    for (var v = 0; v < vhostBlocks.length; v++){
      var vb = vhostBlocks[v];
      if (/:443\b/.test(vb.addr)){
        var hasSslOn = false;
        for (var s = 0; s < vb.body.length; s++){
          if (/^\s*SSLEngine\s+on\b/i.test(vb.body[s].text)) hasSslOn = true;
        }
        if (!hasSslOn && sslOffLines.length === 0){
          addFinding(findings, "REVIEW", vb.startLine, "Port 443 host with no SSLEngine on inside it",
            "This virtual host listens on 443 but the pasted text shows no SSLEngine on within the block, so it may be serving plaintext on the TLS port.",
            "Add SSLEngine on and a certificate inside this host, or confirm the TLS settings live in another file.");
        }
      }
    }

    // --- Directory / with Require all granted ---
    for (var db = 0; db < dirBlocks.length; db++){
      var block = dirBlocks[db];
      var p = block.path.replace(/\s+/g, "");
      if (p === "/" || p === "/*"){
        for (var g = 0; g < block.body.length; g++){
          if (/^\s*Require\s+all\s+granted/i.test(block.body[g].text)){
            addFinding(findings, "BLOCKER", block.body[g].n, "Root directory is open to everyone (<Directory /> with Require all granted)",
              "Granting the filesystem root means any path not covered by a tighter block is served by default — the opposite of the deny-first posture Apache recommends.",
              "Set the root block to Require all denied, then grant access folder by folder.");
          }
        }
      }
    }

    // --- Mixed deprecated and modern access control ---
    if (hasRequire && (firstOrderLine || hasLegacyAllowDeny)){
      addFinding(findings, "WARN", firstOrderLine || 1, "Deprecated Order / Allow / Deny mixed with Require",
        "This text mixes mod_access_compat directives (Order, Allow from, Deny from) with modern Require directives. The two systems merge in ways that are easy to misread, and the old syntax is gone in stricter setups.",
        "Pick one system: rewrite the legacy rules as Require directives and drop Order / Allow / Deny.");
    }

    // --- Sensitive-path protection (REVIEW, never certainty) ---
    var protectedGroups = { git:false, env:false, backup:false };
    var grantedGroups = { git:0, env:0, backup:0 };
    function groupOf(pat){
      var gs = [];
      if (/git|svn/i.test(pat)) gs.push("git");
      if (/env/i.test(pat)) gs.push("env");
      if (/bak|old|swp|sql|zip|tar|save|orig|dist|~|backup/i.test(pat)) gs.push("backup");
      return gs;
    }
    for (var f = 0; f < filesBlocks.length; f++){
      var fb = filesBlocks[f];
      var bodyText = "";
      var denied = false, granted = false;
      for (var q = 0; q < fb.body.length; q++){
        bodyText += fb.body[q].text + "\n";
        if (/Require\s+all\s+denied/i.test(fb.body[q].text) || /Deny\s+from\s+all/i.test(fb.body[q].text)) denied = true;
        if (/Require\s+all\s+granted/i.test(fb.body[q].text)) granted = true;
      }
      var gs2 = groupOf(fb.pattern);
      for (var gi = 0; gi < gs2.length; gi++){
        if (denied) protectedGroups[gs2[gi]] = true;
        if (granted && !grantedGroups[gs2[gi]]) grantedGroups[gs2[gi]] = fb.startLine;
      }
    }
    var groupNames = { git:".git / .svn version-control folders", env:".env files", backup:"backup and archive files (.bak, .old, .swp, .sql, .zip)" };
    var missing = [];
    for (var key in protectedGroups){
      if (grantedGroups[key]){
        addFinding(findings, "REVIEW", grantedGroups[key], "A sensitive path appears to be allowed",
          "A Files or FilesMatch rule for " + groupNames[key] + " uses Require all granted in the pasted text. REVIEW this by hand — context outside the paste may change the picture.",
          "If the path is truly public on purpose, note why; otherwise change the rule to Require all denied.");
      } else if (!protectedGroups[key]){
        missing.push(groupNames[key]);
      }
    }
    if (missing.length){
      addFinding(findings, "REVIEW", 1, "No deny rule found for sensitive paths (whole-file check)",
        "The pasted text shows no FilesMatch or Files deny rule covering: " + missing.join("; ") + ". If protection lives in another file, this is a false alarm — REVIEW, not a certainty. If it does not, those files may be downloadable by anyone who guesses the path.",
        "Add FilesMatch rules that return Require all denied for .git, .env, and backup extensions.");
    }

    // --- INFO: error pages and logging ---
    if (!hasErrorDocument){
      addFinding(findings, "INFO", 1, "No custom ErrorDocument pages (whole-file check)",
        "No ErrorDocument directive appears in the pasted text, so visitors get the default Apache error pages, which pair badly with any signature exposure above.",
        "Add ErrorDocument entries for at least 404 and 500 pointing at plain, branded pages.");
    }
    if (!hasErrorLog && !hasCustomLog && !hasLogLevel){
      addFinding(findings, "INFO", 1, "No logging directives found (whole-file check)",
        "No ErrorLog, CustomLog, or LogLevel appears in the pasted text. Logging may be set globally — but if it is not, you will have no record when something goes wrong.",
        "Confirm logging is set somewhere: an ErrorLog and a CustomLog at minimum.");
    }

    findings.sort(function(a, b){
      if (SEV_RANK[a.sev] !== SEV_RANK[b.sev]) return SEV_RANK[a.sev] - SEV_RANK[b.sev];
      return a.line - b.line;
    });

    var counts = { BLOCKER:0, HIGH:0, WARN:0, REVIEW:0, INFO:0 };
    for (var c = 0; c < findings.length; c++) counts[findings[c].sev]++;

    var verdict, cls, why;
    if (counts.BLOCKER > 0){
      verdict = "DO NOT DEPLOY"; cls = "bad";
      why = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " found. Fix every blocker before this config goes near a live server.";
    } else if (counts.HIGH + counts.WARN + counts.REVIEW > 0){
      verdict = "DEPLOY WITH FIXES"; cls = "warn";
      why = "No blockers, but " + (counts.HIGH + counts.WARN + counts.REVIEW) + " finding(s) need a fix or a deliberate review before deployment.";
    } else {
      verdict = "SAFE TO DEPLOY"; cls = "good";
      why = "No blocker, warning, or review finding fired on the pasted text. This is a heuristic text audit, not a proof — the live server still deserves a smoke test.";
    }
    return { findings:findings, counts:counts, verdict:verdict, cls:cls, why:why, lineCount:lines.length };
  }

  function buildReport(result){
    var out = [];
    out.push("J-Dawgs Apache HTTPd Config Safety Auditor - audit report");
    out.push("Verdict: " + result.verdict);
    out.push("Lines scanned: " + result.lineCount);
    out.push("Counts: BLOCKER " + result.counts.BLOCKER + " | HIGH " + result.counts.HIGH + " | WARN " + result.counts.WARN + " | REVIEW " + result.counts.REVIEW + " | INFO " + result.counts.INFO);
    out.push("Note: heuristic text audit only. Nothing was uploaded; Apache was not run and no server was contacted. Secret values are masked by design.");
    out.push("");
    if (!result.findings.length){
      out.push("Findings: none.");
    } else {
      out.push("Findings:");
      for (var i = 0; i < result.findings.length; i++){
        var f = result.findings[i];
        out.push("");
        out.push((i + 1) + ". Line " + f.line + " [" + f.sev + "] " + f.title);
        out.push("   " + f.detail);
        out.push("   Fix: " + f.fix);
      }
    }
    return out.join("\n");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-apache-httpd-config-safety-auditor',
  name: 'J-Dawgs Apache HTTPd Config Safety Auditor',
  description: 'Apache\'s own configtest needs a server install and answers syntax only; this grades a pasted httpd or .htaccess config anywhere for deploy-safety — directory listing, ServerTokens/TraceEnable, sensitive-path protection, secrets flagged by key name only with values masked — into one verdict: SAFE TO ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
