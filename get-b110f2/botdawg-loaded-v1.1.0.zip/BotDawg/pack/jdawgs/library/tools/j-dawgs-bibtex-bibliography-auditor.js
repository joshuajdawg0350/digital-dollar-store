'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BibTeX Bibliography Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var WORKED_EXAMPLE = [
          "@article{smith2020deep,",
          "  author  = {Smith, John and Lee, Maria},",
          "  title   = {Deep Learning for Bridge Inspection},",
          "  journal = {Journal of Structural Engineering},",
          "  year    = {2020},",
          "  doi     = {10.1000/xyz123}",
          "}",
          "",
          "@article{smith2020deep,",
          "  author  = {Smith, John and Patel, Ravi},",
          "  title   = {Vision Systems for Concrete Cracks},",
          "  journal = {Automation in Construction},",
          "  year    = {2019}",
          "}",
          "",
          "@inproceedings{jones2021sensors,",
          "  author    = {Jones, Amy and Brown, Tom},",
          "  title     = {Sensor Networks on Site},",
          "  booktitle = {Proceedings of the Construction Tech Conference},",
          "  year      = {2021},",
          "  doi       = {https://doi.org/10.1000/XYZ123}",
          "}",
          "",
          "@article{doe2022review,",
          "  author = {Doe, Jane},",
          "  title  = {A Review of Prefab Methods},",
          "  year   = {in press}",
          "}"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "@article{garcia2018timber,",
          "  author  = {Garcia, Luis and Nguyen, Mai},",
          "  title   = {Mass Timber in Mid-Rise Housing},",
          "  journal = {Journal of Architectural Engineering},",
          "  year    = {2018},",
          "  doi     = {10.1061/example.2018.001}",
          "}",
          "",
          "@book{okafor2015estimating,",
          "  author    = {Okafor, Chidi},",
          "  title     = {Practical Cost Estimating for Builders},",
          "  publisher = {Builder Press},",
          "  year      = {2015}",
          "}",
          "",
          "@inproceedings{kim2023drones,",
          "  author    = {Kim, Sara and Ortiz, Ben},",
          "  title     = {Drone Surveys for Roof Assessment},",
          "  booktitle = {Proceedings of the Smart Construction Summit},",
          "  year      = {2023},",
          "  month     = {jun}",
          "}"
        ].join("\n");

        /* ---------- Parsing ---------- */

        function lineOf(text, idx) {
          var n = 1;
          for (var i = 0; i < idx && i < text.length; i++) {
            if (text.charAt(i) === "\n") n++;
          }
          return n;
        }

        function splitTopLevel(body) {
          var parts = [], depth = 0, inStr = false, cur = "";
          for (var k = 0; k < body.length; k++) {
            var c = body.charAt(k);
            if (inStr) {
              cur += c;
              if (c === "\\" && k + 1 < body.length) { cur += body.charAt(k + 1); k++; }
              else if (c === "\"") inStr = false;
              continue;
            }
            if (c === "\"") { inStr = true; cur += c; continue; }
            if (c === "{" || c === "(") depth++;
            else if (c === "}" || c === ")") depth--;
            if (c === "," && depth === 0) { parts.push(cur); cur = ""; continue; }
            cur += c;
          }
          if (cur.replace(/\s+/g, "") !== "") parts.push(cur);
          return parts;
        }

        function cleanValue(raw) {
          var v = raw.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
          // Strip one layer of concatenation markers for display/sanity checks.
          var changed = true;
          while (changed) {
            changed = false;
            if (v.length >= 2 && v.charAt(0) === "{" && v.charAt(v.length - 1) === "}") {
              // Only strip if the outer pair is balanced across the whole string.
              var depth = 0, ok = true;
              for (var i = 0; i < v.length; i++) {
                if (v.charAt(i) === "{") depth++;
                else if (v.charAt(i) === "}") {
                  depth--;
                  if (depth === 0 && i < v.length - 1) { ok = false; break; }
                }
              }
              if (ok && depth === 0) { v = v.slice(1, -1).replace(/^\s+|\s+$/g, ""); changed = true; }
            } else if (v.length >= 2 && v.charAt(0) === "\"" && v.charAt(v.length - 1) === "\"") {
              v = v.slice(1, -1).replace(/^\s+|\s+$/g, ""); changed = true;
            }
          }
          return v;
        }

        function parseEntry(type, body, line) {
          var parts = splitTopLevel(body);
          var key = parts.length ? parts[0].replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "") : "";
          var fields = {};
          var order = [];
          for (var i = 1; i < parts.length; i++) {
            var eq = parts[i].indexOf("=");
            if (eq === -1) continue;
            var name = parts[i].slice(0, eq).replace(/\s+/g, "").toLowerCase();
            if (!name) continue;
            if (!(name in fields)) order.push(name);
            fields[name] = cleanValue(parts[i].slice(eq + 1));
          }
          return { type: type, key: key, fields: fields, order: order, line: line };
        }

        function parseBib(text) {
          var entries = [], notParsed = [], infos = [];
          var n = text.length, i = 0;
          while (i < n) {
            var at = text.indexOf("@", i);
            if (at === -1) break;
            var m = /^@\s*([A-Za-z]+)/.exec(text.slice(at, at + 48));
            if (!m) { i = at + 1; continue; }
            var type = m[1].toLowerCase();
            var j = at + m[0].length;
            while (j < n && /\s/.test(text.charAt(j))) j++;
            var open = text.charAt(j);
            if (open !== "{" && open !== "(") { i = at + 1; continue; }
            var close = open === "{" ? "}" : ")";
            var depth = 0, inStr = false, end = -1;
            for (var k = j; k < n; k++) {
              var c = text.charAt(k);
              if (inStr) {
                if (c === "\\") { k++; continue; }
                if (c === "\"") inStr = false;
                continue;
              }
              if (c === "\"") { inStr = true; continue; }
              if (c === open) depth++;
              else if (c === close) {
                depth--;
                if (depth === 0) { end = k; break; }
              }
            }
            var startLine = lineOf(text, at);
            if (end === -1) {
              notParsed.push({ line: startLine, type: type });
              break;
            }
            var body = text.slice(j + 1, end);
            if (type === "string" || type === "preamble" || type === "comment") {
              infos.push({ kind: "@" + type, line: startLine });
            } else {
              entries.push(parseEntry(type, body, startLine));
            }
            i = end + 1;
          }
          return { entries: entries, notParsed: notParsed, infos: infos };
        }

        /* ---------- Checks ---------- */

        var REQUIRED_STRICT = {
          article: ["author", "title", "journal", "year"],
          inproceedings: ["author", "title", "booktitle", "year"],
          conference: ["author", "title", "booktitle", "year"]
        };
        var MONTHS = ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];

        function normalizeDoi(v) {
          var d = v.replace(/\s+/g, "").toLowerCase();
          d = d.replace(/^https?:\/\/doi\.org\//, "");
          d = d.replace(/^doi:/, "");
          return d;
        }

        function normalizeTitle(v) {
          return v.toLowerCase()
            .replace(/[{}]/g, "")
            .replace(/[^a-z0-9]+/g, " ")
            .replace(/\s+/g, " ")
            .replace(/^\s+|\s+$/g, "");
        }

        function hasField(e, name) {
          return (name in e.fields) && e.fields[name] !== "";
        }

        function entryLabel(e) {
          return e.key ? e.key : "(no key — line " + e.line + ")";
        }

        function audit(text) {
          var parsed = parseBib(text);
          var findings = [];   // {sev, loc, locKey, msg}
          var duplicates = []; // {sev, msg}
          var i, e;

          function add(sev, loc, msg) {
            findings.push({ sev: sev, loc: loc, msg: msg });
          }

          // (1) Structure: NOT PARSED
          for (i = 0; i < parsed.notParsed.length; i++) {
            var np = parsed.notParsed[i];
            add("BLOCKER", "line " + np.line,
              "NOT PARSED — the @" + np.type + " entry starting at line " + np.line +
              " could not be parsed (brace balance or structure is broken). It was excluded from every other check.");
          }
          // (1) Structure: @string / @preamble / @comment as INFO
          for (i = 0; i < parsed.infos.length; i++) {
            var inf = parsed.infos[i];
            add("INFO", "line " + inf.line,
              inf.kind + " block at line " + inf.line + " — listed for completeness; not graded as an entry.");
          }

          var entries = parsed.entries;

          // (6) Key hygiene + empty-key
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (!e.key) {
              add("WARNING", "line " + e.line,
                "The @" + e.type + " entry at line " + e.line + " has no citation key.");
            } else if (/\s/.test(e.key) || /[^\x00-\x7F]/.test(e.key)) {
              add("WARNING", e.key,
                "Citation key \"" + e.key + "\" contains " +
                (/\s/.test(e.key) ? "a space" : "non-ASCII characters") +
                " — keys with spaces or non-ASCII characters break in some toolchains.");
            }
          }

          // (2) Duplicate citation keys
          var byKey = {};
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (!e.key) continue;
            (byKey[e.key] = byKey[e.key] || []).push(e);
          }
          Object.keys(byKey).forEach(function (k) {
            var group = byKey[k];
            if (group.length < 2) return;
            for (var a = 0; a < group.length; a++) {
              for (var b = a + 1; b < group.length; b++) {
                var msg = "Duplicate citation key \"" + k + "\" — used by the @" + group[a].type +
                  " entry at line " + group[a].line + " and the @" + group[b].type +
                  " entry at line " + group[b].line + ". One of them must be renamed; BibTeX cannot tell them apart.";
                add("BLOCKER", k, msg);
                duplicates.push({ sev: "BLOCKER", msg: msg });
              }
            }
          });

          // (3) Duplicate DOIs
          var byDoi = {};
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (!hasField(e, "doi")) continue;
            var d = normalizeDoi(e.fields.doi);
            if (!d) continue;
            (byDoi[d] = byDoi[d] || []).push(e);
          }
          Object.keys(byDoi).forEach(function (d) {
            var group = byDoi[d];
            if (group.length < 2) return;
            for (var a = 0; a < group.length; a++) {
              for (var b = a + 1; b < group.length; b++) {
                var msg = "Duplicate DOI " + d + " — carried by \"" + entryLabel(group[a]) +
                  "\" (line " + group[a].line + ") and \"" + entryLabel(group[b]) +
                  "\" (line " + group[b].line + "). The same source appears to be entered twice.";
                add("BLOCKER", entryLabel(group[a]) + " + " + entryLabel(group[b]), msg);
                duplicates.push({ sev: "BLOCKER", msg: msg });
              }
            }
          });

          // (3) Duplicate normalized titles
          var byTitle = {};
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (!hasField(e, "title")) continue;
            var t = normalizeTitle(e.fields.title);
            if (!t) continue;
            (byTitle[t] = byTitle[t] || []).push(e);
          }
          Object.keys(byTitle).forEach(function (t) {
            var group = byTitle[t];
            if (group.length < 2) return;
            for (var a = 0; a < group.length; a++) {
              for (var b = a + 1; b < group.length; b++) {
                var msg = "Duplicate title — \"" + entryLabel(group[a]) + "\" (line " + group[a].line +
                  ") and \"" + entryLabel(group[b]) + "\" (line " + group[b].line +
                  ") share the same normalized title. Check whether they are the same source entered twice.";
                add("WARNING", entryLabel(group[a]) + " + " + entryLabel(group[b]), msg);
                duplicates.push({ sev: "WARNING", msg: msg });
              }
            }
          });

          // (4) Required fields + (5) field sanity, per entry
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            var loc = entryLabel(e);

            if (e.type === "book") {
              if (!hasField(e, "author") && !hasField(e, "editor")) {
                add("BLOCKER", loc, "Missing required field \"author\" (or \"editor\") in book entry \"" + loc + "\".");
              }
              ["title", "publisher", "year"].forEach(function (f) {
                if (!hasField(e, f)) {
                  add("BLOCKER", loc, "Missing required field \"" + f + "\" in book entry \"" + loc + "\".");
                }
              });
            } else if (REQUIRED_STRICT[e.type]) {
              REQUIRED_STRICT[e.type].forEach(function (f) {
                if (!hasField(e, f)) {
                  add("BLOCKER", loc, "Missing required field \"" + f + "\" in " + e.type + " entry \"" + loc + "\".");
                }
              });
            } else {
              if (!hasField(e, "title")) {
                add("WARNING", loc, "Missing \"title\" in " + e.type + " entry \"" + loc + "\" — title and year are the minimum this auditor asks of misc/other types.");
              }
              if (!hasField(e, "year")) {
                add("WARNING", loc, "Missing \"year\" in " + e.type + " entry \"" + loc + "\" — title and year are the minimum this auditor asks of misc/other types.");
              }
            }

            // (5) Year sanity
            if (hasField(e, "year")) {
              var yv = e.fields.year;
              var okYear = /^\d{4}$/.test(yv) && parseInt(yv, 10) >= 1900 && parseInt(yv, 10) <= 2027;
              if (!okYear) {
                add("BLOCKER", loc, "Year \"" + yv + "\" in entry \"" + loc + "\" is not a 4-digit year between 1900 and 2027.");
              }
            }
            // (5) Month sanity
            if (hasField(e, "month")) {
              var mv = e.fields.month.toLowerCase();
              var okMonth = MONTHS.indexOf(mv) !== -1 ||
                (/^\d{1,2}$/.test(mv) && parseInt(mv, 10) >= 1 && parseInt(mv, 10) <= 12);
              if (!okMonth) {
                add("WARNING", loc, "Month \"" + e.fields.month + "\" in entry \"" + loc + "\" is outside jan–dec / 1–12.");
              }
            }
            // (5) Empty field values (non-required ones; empty required fields already fired above)
            for (var oi = 0; oi < e.order.length; oi++) {
              var fname = e.order[oi];
              if (e.fields[fname] === "") {
                var reqList = e.type === "book"
                  ? ["author", "editor", "title", "publisher", "year"]
                  : (REQUIRED_STRICT[e.type] || []);
                if (reqList.indexOf(fname) === -1) {
                  add("WARNING", loc, "Field \"" + fname + "\" in entry \"" + loc + "\" is present but empty.");
                }
              }
            }
            // (5) "et al" in author
            if (hasField(e, "author") && /et\s+al/i.test(e.fields.author)) {
              add("WARNING", loc, "Author field in entry \"" + loc + "\" contains \"et al\" — the author list is incomplete; BibTeX needs the full list and abbreviates it itself.");
            }
          }

          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var infos = findings.filter(function (f) { return f.sev === "INFO"; }).length;
          var verdict = blockers > 0 ? "DO NOT CITE YET" : (warnings > 0 ? "CITE WITH FIXES" : "READY TO CITE");

          return {
            entries: entries,
            notParsed: parsed.notParsed,
            verdict: verdict,
            findings: findings,
            duplicates: duplicates,
            blockers: blockers,
            warnings: warnings,
            infos: infos
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bibtex-bibliography-auditor',
  name: 'J-Dawgs BibTeX Bibliography Auditor',
  description: 'Audits a pasted .bib file: duplicate keys and DOIs, per-type missing required fields, year/month sanity — graded into one cite verdict (READY TO CITE / CITE WITH FIXES / DO NOT CITE YET).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
