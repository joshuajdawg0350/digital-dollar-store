'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs dnsdist Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are the audit's evidence) ---------- */
var RISKY = [
"-- Risky example - for grading practice only. Do not deploy.",
"setLocal('0.0.0.0:53')",
"setACL({'0.0.0.0/0', '::/0'})",
"webserver('0.0.0.0:8083', 'changeme', 'api123')",
"controlSocket('0.0.0.0:5199')",
"setKey('shortkey')",
"addDOHLocal('0.0.0.0:443')",
"addTLSLocal('0.0.0.0:853')",
"newServer({address='8.8.8.8:53', name='upstream1'})"
].join("\n");

var HARDENED = [
"-- Hardened example",
"setLocal('127.0.0.1:53')",
"addLocal('10.0.0.5:53')",
"setACL({'127.0.0.0/8', '10.0.0.0/8'})",
"webserver('127.0.0.1:8083', 'LongUniqueWebserverPassword-2026-Example', 'LongUniqueApiKeyValue-2026-Example-Only')",
"controlSocket('127.0.0.1:5199')",
"setKey('LongUniqueConsoleKeyValue-2026-Example-Only')",
"addDOHLocal('10.0.0.5:443', '/etc/dnsdist/tls/server.crt', '/etc/dnsdist/tls/server.key')",
"addTLSLocal('10.0.0.5:853', '/etc/dnsdist/tls/server.crt', '/etc/dnsdist/tls/server.key')",
"newServer({address='9.9.9.9:53', name='upstream1'})",
"newServer({address='149.112.112.112:53', name='upstream2'})",
"pc = newPacketCache(100000)",
"getPool(''):setCache(pc)",
"addAction(MaxQPSIPRule(50), DropAction())"
].join("\n");

/* ---------- Parser helpers ---------- */
var KNOWN = ["setLocal","addLocal","setACL","addACL","setConsoleACL","webserver","setWebserverConfig","setAPIWritable","controlSocket","setKey","addDOHLocal","addTLSLocal","addDOQLocal","addQUICLocal","newServer","setServerPolicy","setPoolPolicy","newPacketCache","setCache","getPool","addPool","addAction","addResponseAction","addCacheHitResponseAction","DynBlockRulesGroup","setDynBlocksAction","setMaxTCPClientThreads","setMaxUDPClientThreads","setStaleCacheEntriesTTL","setRingBuffersSize","setVerbose","setServFailWhenNoServer","PoolAction","DropAction","MaxQPSIPRule","makeRule","setLocalHealthCheck","setUpstreamDoH","setUpstreamDoT","addUpstreamDoH","addUpstreamDoT"];
var DEFAULT_SECRETS = ["changeme","password","dnsdist","secret","admin","letmein","123456","default","test1234","api123","shortkey"];

function stringsIn(line){
  var out=[], m, re = /'([^']*)'|"([^"]*)"/g;
  while((m = re.exec(line)) !== null){ out.push(m[1] !== undefined ? m[1] : m[2]); }
  return out;
}
function directiveIn(line){
  for(var i=0;i<KNOWN.length;i++){
    if(new RegExp("(^|[^A-Za-z0-9_])"+KNOWN[i]+"\\s*\\(").test(line)) return KNOWN[i];
  }
  return null;
}
function isStructural(line){
  var t = line.replace(/^\s+/,"");
  return /^(local\b|function\b|end\b|if\b|else\b|elseif\b|return\b|for\b|while\b|do\b|}|\{|\]|\)|')/.test(t) || t.indexOf("=") !== -1 && /[A-Za-z_][\w.]*\s*=/.test(t);
}
function bindsAllInterfaces(addr){
  if(!addr) return false;
  return addr.indexOf("0.0.0.0") === 0 || addr.indexOf("::") === 0 || addr.indexOf("*:") === 0 || addr.indexOf(":") === 0;
}
function isLocalBind(addr){
  if(!addr) return false;
  return addr.indexOf("127.") === 0 || addr.indexOf("::1") === 0 || addr.indexOf("10.") === 0 || addr.indexOf("192.168.") === 0 || /^172\.(1[6-9]|2\d|3[01])\./.test(addr);
}

/* ---------- Audit ---------- */
function audit(text){
  var lines = text.split(/\r?\n/);
  var findings = [];   /* {severity, line, check, title, detail} — never holds secret values */
  var secrets = [];    /* {key, line, length, assessment} — never holds secret values */
  var notParsed = [];
  var recognized = 0, nonEmpty = 0;
  var ctx = { listener:false, acl:false, aclOpen:false, downstream:0, webserver:false, controlSocket:false, hasKey:false, tlsListeners:0 };

  function add(sev, line, check, title, detail){ findings.push({severity:sev, line:line, check:check, title:title, detail:detail}); }
  function assessSecret(keyName, lineNo, value, check){
    var len = value.length;
    var isDefault = DEFAULT_SECRETS.indexOf(value.toLowerCase()) !== -1;
    var assessment;
    if(isDefault){ assessment = "Matches a well-known default value (value not shown)"; }
    else if(len === 0){ assessment = "Empty value"; }
    else if(len < 12){ assessment = "Too short — under 12 characters"; }
    else if(len < 16){ assessment = "Acceptable length — 16+ characters is stronger"; }
    else { assessment = "Strong length"; }
    secrets.push({key:keyName, line:lineNo, length:len, assessment:assessment});
    if(isDefault || len === 0 || len < 12){
      add("CRITICAL", lineNo, check, "Weak secret: " + keyName,
        "Key \"" + keyName + "\" on line " + lineNo + " has length " + len + ". " + assessment + ". The value itself is never shown in this audit. Use a unique value of at least 16 characters, stored outside the served config where possible.");
    } else {
      add("INFO", lineNo, check, "Secret length acceptable: " + keyName,
        "Key \"" + keyName + "\" on line " + lineNo + " has length " + len + " (" + assessment.toLowerCase() + "). Value not shown.");
    }
    return;
  }

  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var raw = lines[i];
    var t = raw.trim();
    if(t === "") continue;
    nonEmpty++;
    if(t.indexOf("--") === 0 || t.indexOf("#") === 0) continue;
    var dir = directiveIn(raw);
    if(!dir && !isStructural(raw)){ notParsed.push(lineNo); continue; }
    recognized++;
    var strs = stringsIn(raw);

    /* Listeners / binds */
    if(dir === "setLocal" || dir === "addLocal"){
      ctx.listener = true;
      var bind = strs[0] || "";
      if(bindsAllInterfaces(bind)){
        add("CRITICAL", lineNo, "Listeners & binds", "DNS listener bound to all interfaces",
          dir + " on line " + lineNo + " binds the DNS listener to every interface. Anyone who can reach this host can query it. Bind to localhost or a specific internal address unless public service is deliberate and the ACL is tight.");
      } else if(isLocalBind(bind)){
        add("INFO", lineNo, "Listeners & binds", "Listener bound to a local / private address",
          dir + " on line " + lineNo + " binds to a loopback or private address, which limits exposure.");
      } else if(bind){
        add("WARNING", lineNo, "Listeners & binds", "Listener bound to a specific address — verify it is intended",
          dir + " on line " + lineNo + " binds to a specific non-loopback address. Confirm that address is meant to serve DNS and that the ACL matches it.");
      } else {
        add("WARNING", lineNo, "Listeners & binds", "Listener with no explicit address",
          dir + " on line " + lineNo + " names no bind address, so the effective bind depends on defaults. State the address explicitly.");
      }
    }

    /* ACL openness */
    if(dir === "setACL" || dir === "addACL"){
      ctx.acl = true;
      var open = strs.some(function(s){ return s === "0.0.0.0/0" || s === "::/0" || s === "0.0.0.0" || s === "::"; });
      if(open){
        ctx.aclOpen = true;
        add("CRITICAL", lineNo, "ACL openness", "Unrestricted ACL — open resolver behaviour",
          dir + " on line " + lineNo + " allows queries from any address (0.0.0.0/0 and/or ::/0). Combined with a reachable listener this is an open resolver: it can be abused for DNS amplification and reflects queries for anyone on the internet. Restrict the ACL to your own networks.");
      } else {
        add("INFO", lineNo, "ACL openness", "ACL is restricted",
          dir + " on line " + lineNo + " lists specific networks rather than an any-address range.");
      }
    }
    if(dir === "setConsoleACL"){
      var cOpen = strs.some(function(s){ return s === "0.0.0.0/0" || s === "::/0"; });
      if(cOpen) add("CRITICAL", lineNo, "ACL openness", "Console ACL is unrestricted", "setConsoleACL on line " + lineNo + " allows console access from any address.");
    }

    /* Webserver / API */
    if(dir === "webserver"){
      ctx.webserver = true;
      var wbind = strs[0] || "";
      if(bindsAllInterfaces(wbind)){
        add("CRITICAL", lineNo, "Webserver / API exposure", "Webserver and REST API exposed on all interfaces",
          "webserver on line " + lineNo + " listens on every interface over plaintext HTTP. The dnsdist webserver exposes metrics and, with the API key, configuration control. Bind it to 127.0.0.1 and reach it through a tunnel or a TLS-terminating proxy.");
      } else if(isLocalBind(wbind)){
        add("INFO", lineNo, "Webserver / API exposure", "Webserver bound to a local address",
          "webserver on line " + lineNo + " is bound to a loopback or private address. It is still plaintext HTTP, so keep it off shared networks.");
      } else if(wbind){
        add("HIGH", lineNo, "Webserver / API exposure", "Webserver bound to a non-loopback address over plaintext HTTP",
          "webserver on line " + lineNo + " serves the status page and API over plaintext HTTP on a reachable address. Move it to localhost or protect it with TLS and network controls.");
      }
      if(strs.length >= 2){ assessSecret("webserver password", lineNo, strs[1], "Password & secret handling"); }
      else { add("CRITICAL", lineNo, "Password & secret handling", "Webserver has no password", "webserver on line " + lineNo + " sets no password argument. Anyone who can reach it can view server state."); }
      if(strs.length >= 3){ assessSecret("webserver API key", lineNo, strs[2], "Password & secret handling"); }
      else { add("WARNING", lineNo, "Password & secret handling", "Webserver has no API key", "webserver on line " + lineNo + " sets no API key argument. API access control then rests on the password and network position alone."); }
    }
    if(dir === "setAPIWritable"){
      if(/true/.test(raw)) add("HIGH", lineNo, "Webserver / API exposure", "API is writable", "setAPIWritable(true) on line " + lineNo + " lets API callers change the running configuration. Leave the API read-only unless remote changes are deliberate and tightly controlled.");
    }

    /* Console */
    if(dir === "controlSocket"){
      ctx.controlSocket = true;
      var cbind = strs[0] || "";
      if(bindsAllInterfaces(cbind)){
        add("CRITICAL", lineNo, "Console exposure", "Console control socket exposed on all interfaces",
          "controlSocket on line " + lineNo + " exposes the dnsdist console on every interface. The console can reconfigure the running server. Bind it to 127.0.0.1 only.");
      } else if(isLocalBind(cbind)){
        add("INFO", lineNo, "Console exposure", "Console bound to a local address",
          "controlSocket on line " + lineNo + " is bound to a loopback or private address, which is the expected posture for the console.");
      } else if(cbind){
        add("HIGH", lineNo, "Console exposure", "Console bound to a non-loopback address",
          "controlSocket on line " + lineNo + " binds the console to a reachable address. The console should stay on localhost.");
      }
    }
    if(dir === "setKey"){
      ctx.hasKey = true;
      if(strs.length >= 1) assessSecret("console key (setKey)", lineNo, strs[0], "Password & secret handling");
      else add("WARNING", lineNo, "Password & secret handling", "setKey with no readable key value", "setKey on line " + lineNo + " carries no quoted key this audit can measure. Confirm a long, unique console key is set.");
    }

    /* Generic secret assignments: password = "...", apiKey = "...", etc. */
    var gm = raw.match(/\b(password|passwd|api[_-]?key|apikey|secret|token)\b\s*=\s*(?:'([^']*)'|"([^"]*)")/i);
    if(gm && dir !== "webserver"){
      assessSecret(gm[1], lineNo, (gm[2] !== undefined ? gm[2] : gm[3]) || "", "Password & secret handling");
    }

    /* DoH / DoT / DoQ TLS posture */
    if(dir === "addDOHLocal" || dir === "addTLSLocal" || dir === "addDOQLocal" || dir === "addQUICLocal"){
      ctx.tlsListeners++;
      var proto = dir === "addDOHLocal" ? "DoH" : (dir === "addTLSLocal" ? "DoT" : "DoQ");
      var hasCert = /\.crt\b|\.pem\b|\.key\b|cert/i.test(raw);
      var tbind = strs[0] || "";
      if(!hasCert){
        add("CRITICAL", lineNo, "DoH / DoT / DoQ TLS posture", proto + " listener with no TLS certificate referenced",
          dir + " on line " + lineNo + " declares an encrypted-DNS listener but names no certificate or key file on the line. Without a valid certificate the listener either fails to start or serves an identity clients cannot verify. Reference the certificate and key (and keep the key file private).");
      } else {
        add("INFO", lineNo, "DoH / DoT / DoQ TLS posture", proto + " listener references TLS material",
          dir + " on line " + lineNo + " references certificate/key material. This audit cannot verify the files, their expiry, or their permissions — check those on the host.");
      }
      if(bindsAllInterfaces(tbind)){
        add("HIGH", lineNo, "DoH / DoT / DoQ TLS posture", proto + " listener bound to all interfaces",
          dir + " on line " + lineNo + " binds the " + proto + " listener to every interface. That is normal for a public DoH/DoT service, but only safe with a restricted ACL and rate limiting in place.");
      }
    }

    /* Downstream servers */
    if(dir === "newServer"){
      ctx.downstream++;
      var addrM = raw.match(/address\s*=\s*(?:'([^']*)'|"([^"]*)")/);
      var addr = addrM ? (addrM[1] !== undefined ? addrM[1] : addrM[2]) : (strs[0] || "");
      if(!addr){
        add("WARNING", lineNo, "Downstream servers", "Downstream server with no address",
          "newServer on line " + lineNo + " names no downstream address this audit can read. A pool with no reachable upstream cannot resolve.");
      } else if(addr.indexOf("0.0.0.0") === 0){
        add("HIGH", lineNo, "Downstream servers", "Downstream address is a wildcard address",
          "newServer on line " + lineNo + " points at a wildcard address, which is not a real upstream. Name the resolver's actual address.");
      }
    }
  }

  /* Whole-config posture checks */
  var fullText = text;
  var hasCache = /newPacketCache|PacketCache|setCache\s*\(/.test(fullText);
  var hasRate = /MaxQPSIPRule|MaxQPSRule|DynBlock|dynBlock|RateLimit|rateLimit|addDynBlocks/i.test(fullText);

  if(ctx.acl && !ctx.aclOpen){
    /* restricted ACL already noted per line */
  }
  if(!ctx.acl && recognized >= 3){
    add("WARNING", null, "ACL openness", "No explicit ACL found",
      "No setACL / addACL directive was recognised. dnsdist then falls back to its default ACL, which may not match the networks you intend to serve. State the ACL explicitly.");
  }
  if(ctx.controlSocket && !ctx.hasKey && recognized >= 3){
    add("WARNING", null, "Console exposure", "Console socket with no setKey found",
      "A controlSocket is configured but no setKey directive was recognised. The console should be protected by a long, unique key.");
  }
  if(recognized >= 3 && ctx.downstream === 0){
    add("WARNING", null, "Downstream servers", "No downstream server configured",
      "No newServer directive was recognised. dnsdist is a balancer/proxy — without at least one downstream it has nothing to forward queries to.");
  }
  if(recognized >= 3 && ctx.downstream === 1){
    add("INFO", null, "Downstream servers", "Single downstream server",
      "Exactly one downstream is configured. That is a single point of failure — a second upstream adds resilience.");
  }
  if(recognized >= 3 && !ctx.listener){
    add("WARNING", null, "Listeners & binds", "No DNS listener found",
      "No setLocal / addLocal directive was recognised. Confirm the config actually opens a DNS listener.");
  }
  if(recognized >= 3){
    if(hasCache){
      add("INFO", null, "Cache posture", "Packet cache configured",
        "A packet cache (newPacketCache / setCache) is present, which reduces upstream load. Confirm its size and TTLs suit your traffic.");
    } else {
      add("WARNING", null, "Cache posture", "No packet cache configured",
        "No packet cache was recognised. Caching is optional, but without it every query goes upstream — more latency and more upstream load.");
    }
    if(hasRate){
      add("INFO", null, "Rate-limit posture", "Rate limiting / dynamic blocking present",
        "Rate-limit or dynamic-block controls (for example MaxQPSIPRule or DynBlock rules) are present, which helps contain abuse and amplification.");
    } else {
      add("WARNING", null, "Rate-limit posture", "No rate limiting or dynamic blocking found",
        "No rate-limit rule (for example MaxQPSIPRule) and no dynamic blocking were recognised. On any listener reachable by untrusted clients, per-source rate limits are a core defence against amplification and floods.");
    }
  }

  /* Verdict */
  var counts = {CRITICAL:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });
  var verdict;
  if(recognized < 3 || nonEmpty < 3){
    verdict = "NOT ENOUGH TO GRADE";
  } else if(counts.CRITICAL > 0){
    verdict = "DO NOT SERVE";
  } else if(counts.HIGH > 0){
    verdict = "DO NOT SERVE";
  } else {
    verdict = "SAFE TO SERVE";
  }

  return { verdict:verdict, findings:findings, secrets:secrets, notParsed:notParsed,
           counts:counts, stats:{ totalLines:lines.length, nonEmpty:nonEmpty, recognized:recognized,
           downstream:ctx.downstream, tlsListeners:ctx.tlsListeners } };
}

/* ---------- Rendering ---------- */
var lastResult = null;
var els = {};
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dnsdist-server-config-safety-auditortm',
  name: 'J-Dawgs dnsdist Server Config Safety Auditor',
  description: 'Grades a pasted dnsdist.conf fully offline into one serve verdict — SAFE TO SERVE / SERVE WITH FIXES / DO NOT SERVE / NOT ENOUGH TO GRADE. Studied tools only check a dnsdist config by starting the daemon; this one grades the paste itself — ACL openness, webserver/console exposure, and DoH/DoT TLS po',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
