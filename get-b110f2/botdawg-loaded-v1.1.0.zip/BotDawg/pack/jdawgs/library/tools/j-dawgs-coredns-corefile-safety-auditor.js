'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CoreDNS Corefile Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var KNOWN = {};
("acl any auto autopath azure bind bufsize cache cancel chaos clouddns debug dns64 dnssec dnstap erratic errors etcd file forward geoip grpc header health hosts import k8s_external kubernetes loadbalance local log loop metadata metrics prometheus minimal nsid pprof proxy ready reload rewrite root route53 secondary sign template tls trace transfer whoami on").split(" ").forEach(function(n){ KNOWN[n]=true; });

var RISKY = [
".:53 {",
"    forward . /etc/resolv.conf",
"    proxy . 8.8.8.8:53",
"    cache",
"    log",
"    whoami",
"}"
].join("\n");

var HARDENED = [
".:53 {",
"    bind 127.0.0.53",
"    acl {",
"        allow net 127.0.0.0/8",
"        block",
"    }",
"    forward . tls://1.1.1.1 tls://9.9.9.9 {",
"        tls_servername cloudflare-dns.com",
"    }",
"    cache 30 {",
"        success 10000 3600",
"        denial 5000 3600",
"    }",
"    errors",
"    health localhost:8080",
"    ready",
"    reload 10s",
"}"
].join("\n");

var MALFORMED = [
".:53 {",
"    forward . tls://1.1.1.1",
"    errors"
].join("\n");

var ta = document.getElementById("corefile");
var gutter = document.getElementById("gutter");
var note = document.getElementById("copy-note");
var lastTextReport = "", lastJsonReport = "";

function stripComment(line){
  var i = line.indexOf("#");
  return i === -1 ? line : line.slice(0, i);
}
function countChar(s, ch){ var n=0; for (var i=0;i<s.length;i++) if (s[i]===ch) n++; return n; }
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function segmentText(rawLines, idx){
  var out = [], local = 0;
  for (var j = idx; j < rawLines.length; j++){
    out.push(rawLines[j]);
    var t = stripComment(rawLines[j]);
    local += countChar(t, "{") - countChar(t, "}");
    if (local <= 0) break;
  }
  return out.join("\n");
}

function parse(text){
  var rawLines = text.split("\n");
  var blocks = [], current = null, depth = 0, braceStack = [];
  var notParsed = null;
  for (var i = 0; i < rawLines.length; i++){
    var lineNo = i + 1;
    var code = stripComment(rawLines[i]);
    var trimmed = code.replace(/^\s+|\s+$/g, "");
    var depthBefore = depth;
    var opens = countChar(code, "{"), closes = countChar(code, "}");
    if (depthBefore === 0 && trimmed && trimmed.charAt(0) !== "}" && opens > 0){
      var header = trimmed.slice(0, trimmed.indexOf("{")).replace(/\s+$/,"");
      current = { header: header, zones: header.split(/\s+/).filter(Boolean),
        startLine: lineNo, endLine: lineNo, snippet: header.charAt(0) === "(",
        directives: [], raw: [] };
      blocks.push(current);
    }
    if (current) current.raw.push(rawLines[i]);
    if (current && !current.snippet && depthBefore === 1 && trimmed && trimmed.charAt(0) !== "}"){
      var parts = trimmed.split(/\s+/);
      var name = parts[0].replace(/:$/,"");
      current.directives.push({ name: name, line: lineNo,
        args: parts.slice(1).join(" "), segment: segmentText(rawLines, i) });
    }
    for (var k = 0; k < opens; k++) braceStack.push(lineNo);
    for (var m = 0; m < closes; m++){
      if (braceStack.length === 0 && !notParsed) notParsed = { line: lineNo };
      else braceStack.pop();
    }
    depth = depthBefore + opens - closes;
    if (depth < 0 && !notParsed) notParsed = { line: lineNo };
    if (current && depth === 0){ current.endLine = lineNo; current = null; }
    if (depth < 0) depth = 0;
  }
  if (!notParsed && braceStack.length > 0) notParsed = { line: braceStack[0] };
  return { blocks: blocks, notParsed: notParsed, lineCount: rawLines.length };
}

function audit(text){
  var parsed = parse(text);
  var findings = [];
  function add(sev, line, directive, msg, fix, blockIdx){
    findings.push({ severity: sev, line: line, directive: directive, message: msg, fix: fix, block: blockIdx });
  }
  if (parsed.notParsed){
    add("NOT PARSED", parsed.notParsed.line, "braces",
      "Unbalanced braces: the structure breaks at or before line " + parsed.notParsed.line + " (a block opened there is never closed, or a closing brace has no opener). The file was not graded further.",
      "Balance every opening brace with a closing brace, then re-run the audit.", -1);
    return finish(parsed, findings);
  }
  var seenZones = {};
  parsed.blocks.forEach(function(block, bi){
    if (block.snippet) return;
    var names = {};
    block.directives.forEach(function(d){ (names[d.name] = names[d.name] || []).push(d); });
    function has(n){ return !!names[n]; }
    var isWild53 = block.zones.some(function(z){ return z === "." || z === ".:53" || z.indexOf(".:") === 0; });
    var blockText = block.raw.join("\n");
    var tlsInBlock = blockText.indexOf("tls://") !== -1;

    block.directives.forEach(function(d){
      if (!KNOWN[d.name]){
        add("INFO", d.line, d.name, "Directive '" + d.name + "' is not in the known CoreDNS plugin set — NOT CHECKED. The auditor makes no judgment about it.",
          "Confirm this plugin exists in your CoreDNS build and review its documentation manually.", bi);
      }
    });
    (names["proxy"] || []).forEach(function(d){
      add("BLOCKER", d.line, "proxy", "Legacy 'proxy' plugin present. It was removed from CoreDNS and replaced by 'forward'; a current CoreDNS build will refuse this block.",
        "Replace the 'proxy' directive with 'forward' and re-audit.", bi);
    });
    var plaintextForward = null;
    (names["forward"] || []).forEach(function(d){
      if (d.segment.indexOf("/etc/resolv.conf") !== -1){
        add("BLOCKER", d.line, "forward", "'forward' sends queries to /etc/resolv.conf. The server inherits whatever resolvers the host happens to use — unencrypted, unaudited, and outside your control.",
          "Forward to named upstreams over TLS (tls://) instead of /etc/resolv.conf.", bi);
      } else {
        var ups = d.args.split(/\s+/).slice(1).filter(function(t){ return t && t !== "{" && t !== "}"; });
        var plain = ups.some(function(t){ return t.indexOf("tls://") !== 0; });
        if (plain && !plaintextForward) plaintextForward = d;
      }
    });
    if (plaintextForward && !tlsInBlock){
      add("BLOCKER", plaintextForward.line, "forward", "'forward' uses plaintext UDP upstreams and no tls:// upstream exists anywhere in this server block. Queries and answers cross the network unencrypted and can be spoofed or logged by any on-path party.",
        "Use tls:// upstreams (DNS over TLS) for this block.", bi);
    }
    if (isWild53 && has("forward") && !has("acl")){
      var extra = (has("whoami") && has("log")) ? " This block also runs 'whoami' with 'log', advertising the resolver and recording who uses it." : "";
      add("BLOCKER", block.startLine, "forward/acl", "Open-resolver posture: this .:53 block forwards to upstreams with no 'acl' plugin, so any internet client can use it as a recursive resolver — a classic DNS amplification abuse target." + extra,
        "Add an 'acl' block that allows only your own networks and blocks the rest, or bind the server to internal interfaces only.", bi);
    }
    (names["cache"] || []).forEach(function(d){
      var bounded = /\d/.test(d.args) || /(success|denial)\s+\d/.test(d.segment);
      if (!bounded){
        add("WARNING", d.line, "cache", "'cache' is enabled with no size or TTL bounds in its arguments or options block. An unbounded cache can grow without limit and keep stale answers alive.",
          "Give 'cache' an explicit TTL and bounded success/denial counts.", bi);
      }
    });
    (names["log"] || []).forEach(function(d){
      add("WARNING", d.line, "log", "'log' is enabled: full query logging records every client query, which is sensitive browsing data. Keep it deliberate, access-controlled, and short-lived.",
        "Remove 'log' for normal operation, or restrict and rotate the logs if you must keep it.", bi);
    });
    if (!has("errors")){
      add("WARNING", block.startLine, "errors", "No 'errors' plugin in this server block — resolution errors will not be logged in the standard CoreDNS form, so failures go quiet.",
        "Add the 'errors' directive to this server block.", bi);
    }
    if (!has("health")){
      add("WARNING", block.startLine, "health", "No 'health' endpoint in this server block — orchestrators and load balancers cannot probe liveness.",
        "Add a 'health' directive (for example, health localhost:8080) to this server block.", bi);
    }
    if (!has("ready")){
      add("WARNING", block.startLine, "ready", "No 'ready' endpoint in this server block — nothing reports when all plugins have finished loading and the server is truly ready to serve.",
        "Add the 'ready' directive to this server block.", bi);
    }
    if (!has("reload")){
      add("WARNING", block.startLine, "reload", "No 'reload' plugin in this server block — Corefile changes will not be picked up automatically; every edit needs a manual restart.",
        "Add a 'reload' directive (for example, reload 10s) to this server block.", bi);
    }
    if (isWild53 && !has("bind")){
      add("WARNING", block.startLine, "bind", "Note: no 'bind' directive on this .:53 block — CoreDNS listens on all interfaces. Acceptable on a dedicated DNS host; risky anywhere else, and part of the open-resolver picture when combined with unrestricted forwarding.",
        "Add 'bind' with the intended interfaces, or confirm all-interfaces listening is deliberate.", bi);
    }
    var authDir = (names["file"] || []).concat(names["secondary"] || [])[0];
    if (authDir && !has("dnssec")){
      add("WARNING", authDir.line, "dnssec", "Authoritative zone ('" + authDir.name + "' present) with no 'dnssec' plugin — the zone is served unsigned. Warning only: unsigned zones still resolve, but resolvers cannot validate answers.",
        "Add the 'dnssec' directive with signing keys for this zone, or record a deliberate decision to serve it unsigned.", bi);
    }
    var key = block.zones.join(" ").toLowerCase();
    if (key && seenZones[key] !== undefined){
      add("WARNING", block.startLine, block.zones.join(" "), "Duplicate server block for the same zone and port: first defined at line " + seenZones[key] + ", again at line " + block.startLine + ". CoreDNS will reject or shadow one of them.",
        "Merge the duplicate blocks at lines " + seenZones[key] + " and " + block.startLine + " into one server block.", bi);
    } else if (key) seenZones[key] = block.startLine;
  });
  return finish(parsed, findings);
}

function finish(parsed, findings){
  var blockers = findings.filter(function(f){ return f.severity === "BLOCKER" || f.severity === "NOT PARSED"; }).length;
  var warnings = findings.filter(function(f){ return f.severity === "WARNING"; }).length;
  var infos = findings.filter(function(f){ return f.severity === "INFO"; }).length;
  var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
  var blockSummaries = parsed.blocks.map(function(b, bi){
    var bf = findings.filter(function(f){ return f.block === bi; });
    var bb = bf.filter(function(f){ return f.severity === "BLOCKER"; }).length;
    var bw = bf.filter(function(f){ return f.severity === "WARNING"; }).length;
    return { zone: b.snippet ? b.header + " (snippet — not graded)" : b.header, startLine: b.startLine, endLine: b.endLine,
      plugins: b.directives.map(function(d){ return d.name; }),
      blockers: bb, warnings: bw,
      verdict: b.snippet ? "NOT GRADED" : (bb > 0 ? "DO NOT DEPLOY" : (bw > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY")) };
  });
  var fixes = [], seenFix = {};
  findings.forEach(function(f){
    if ((f.severity === "BLOCKER" || f.severity === "WARNING" || f.severity === "NOT PARSED") && !seenFix[f.fix]){ seenFix[f.fix] = true; fixes.push(f.fix); }
  });
  return { verdict: verdict, counts: { blockers: findings.filter(function(f){return f.severity==="BLOCKER";}).length,
      notParsed: findings.filter(function(f){return f.severity==="NOT PARSED";}).length, warnings: warnings, info: infos },
    blocks: blockSummaries, findings: findings, fixes: fixes };
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-coredns-corefile-safety-auditor',
  name: 'J-Dawgs CoreDNS Corefile Safety Auditor',
  description: 'CoreDNS\'s built-in check stops at whether the Corefile loads on an installed host; ours grades a pasted Corefile anywhere — plaintext upstreams, unbounded cache, query-log exposure, and missing health endpoints included — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
