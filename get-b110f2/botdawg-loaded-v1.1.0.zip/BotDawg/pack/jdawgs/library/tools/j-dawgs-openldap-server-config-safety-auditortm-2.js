'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenLDAP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */
      var RISKY = [
        "# Risky example - a training config. Do not deploy anything like this.",
        "database mdb",
        "suffix \"dc=example,dc=com\"",
        "rootdn \"cn=admin,dc=example,dc=com\"",
        "rootpw Tr0pic@lStorm99",
        "password-hash {CLEARTEXT}",
        "access to * by anonymous write"
      ].join("\n");

      var HARDENED = [
        "# Hardened example - ldaps only, authenticated access, hashed credentials.",
        "SLAPD_URLS=\"ldaps://ldap.example.com/\"",
        "TLSCertificateFile /etc/ldap/tls/server.crt",
        "TLSCertificateKeyFile /etc/ldap/tls/server.key",
        "TLSCACertificateFile /etc/ldap/tls/ca.crt",
        "security ssf=128",
        "password-hash {ARGON2}",
        "sizelimit 500",
        "timelimit 120",
        "disallow bind_anon",
        "database mdb",
        "suffix \"dc=example,dc=com\"",
        "rootdn \"cn=admin,dc=example,dc=com\"",
        "rootpw {SSHA}8f3kQ2xYbNpLsV7mWdR9aT4cHjKl==",
        "access to attrs=userPassword",
        "  by self write",
        "  by anonymous auth",
        "  by * none",
        "access to *",
        "  by users read",
        "  by anonymous auth",
        "  by * none"
      ].join("\n");

      /* ---------- Parsing ---------- */
      var GRADED = {
        "access": 1, "rootpw": 1, "rootdn": 1, "password-hash": 1,
        "tlscertificatefile": 1, "tlscertificatekeyfile": 1,
        "tlscacertificatefile": 1, "tlscacertificatepath": 1,
        "security": 1, "sizelimit": 1, "timelimit": 1, "disallow": 1
      };
      var SINGLETONS = ["rootpw", "rootdn", "password-hash", "tlscertificatefile",
        "tlscertificatekeyfile", "tlscacertificatefile", "security", "sizelimit", "timelimit"];

      function parseConfig(text) {
        var rawLines = text.split(/\r?\n/);
        var logical = [];
        var i, raw;
        for (i = 0; i < rawLines.length; i++) {
          raw = rawLines[i];
          if (/^[ \t]/.test(raw) && raw.trim() !== "" && logical.length > 0) {
            logical[logical.length - 1].text += " " + raw.trim();
          } else {
            logical.push({ text: raw, line: i + 1 });
          }
        }
        var entries = [], notParsed = [], urls = [];
        logical.forEach(function (L) {
          var t = L.text.trim();
          if (t === "" || t.charAt(0) === "#") return;
          var um, urlRe = /(ldaps?|ldapi):\/\/[^\s"']+/g;
          while ((um = urlRe.exec(t)) !== null) {
            var rest = um[0].split("://")[1] || "";
            var host = rest.split(/[\/:]/)[0];
            urls.push({
              url: um[0], scheme: um[1], host: host, line: L.line,
              allInterfaces: (host === "" || host === "0.0.0.0" || host === "::" || host === "*")
            });
          }
          var m = t.match(/^([A-Za-z][A-Za-z0-9_-]*)(:)?[ \t]+(.*)$/) || t.match(/^([A-Za-z][A-Za-z0-9_-]*)(:)?$/);
          if (!m) {
            var assign = t.match(/^([A-Za-z][A-Za-z0-9_-]*)=(.*)$/);
            if (assign) { m = [assign[0], assign[1], null, assign[2]]; }
          }
          if (!m) { notParsed.push(L.line); return; }
          var name = m[1];
          var norm = name.toLowerCase();
          var base = norm.indexOf("olc") === 0 ? norm.slice(3) : norm;
          entries.push({
            name: name, base: base, value: (m[3] || "").trim(), line: L.line,
            listenerStmt: (norm === "slapd_urls" || norm === "slapd_services")
          });
        });
        return { entries: entries, notParsed: notParsed, urls: urls, lineTotal: rawLines.length };
      }

      function byBase(entries, base) {
        return entries.filter(function (e) { return e.base === base; });
      }
      function firstToken(v) {
        var parts = v.trim().split(/\s+/);
        return parts.length ? parts[0] : "";
      }
      function isWriteLevel(l) {
        l = (l || "").toLowerCase();
        if (l.indexOf("write") !== -1) return true;
        if (l === "add" || l === "delete" || l === "manage") return true;
        if (l.charAt(0) === "=" && /[wadm]/.test(l.slice(1))) return true;
        return false;
      }
      function isReadLevel(l) {
        l = (l || "").toLowerCase();
        if (l.indexOf("read") !== -1) return true;
        if (l === "search" || l === "compare" || l === "disclose") return true;
        if (l.charAt(0) === "=" && l.slice(1).indexOf("r") !== -1) return true;
        return false;
      }
      function parseAccessClauses(value) {
        var cut = value.search(/\bby\b/);
        var target = cut === -1 ? value : value.slice(0, cut);
        var clauses = [];
        var re = /\bby\s+(\S+)\s+(\S+)/g, cm;
        while ((cm = re.exec(value)) !== null) {
          clauses.push({ who: cm[1].replace(/["',]+$/, ""), level: cm[2].replace(/,+$/, "") });
        }
        return { target: target, clauses: clauses };
      }

      /* ---------- Audit ---------- */
      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries, urls = parsed.urls;
        var findings = [];
        function F(severity, directive, lines, message, fix) {
          findings.push({ severity: severity, directive: directive, lines: lines, message: message, fix: fix });
        }

        var notAuditedMap = {};
        entries.forEach(function (e) {
          if (!GRADED[e.base] && !e.listenerStmt) {
            if (!notAuditedMap[e.name]) notAuditedMap[e.name] = [];
            notAuditedMap[e.name].push(e.line);
          }
        });
        var notAudited = Object.keys(notAuditedMap).sort().map(function (n) {
          return { name: n, lines: notAuditedMap[n] };
        });

        /* Listeners */
        var listenersNotSet = urls.length === 0;
        var anyAllInterfaces = listenersNotSet || urls.some(function (u) { return u.allInterfaces; });
        var plaintextExternal = listenersNotSet || urls.some(function (u) { return u.scheme === "ldap" && u.allInterfaces; });
        if (listenersNotSet) {
          F("WARNING", "listeners (-h)", [],
            "Listeners are NOT SET IN FILE: no -h restriction or listener URL was pasted, so this audit treats the config as running with slapd's default listener — plaintext ldap:/// on all interfaces.",
            "Start slapd with an explicit -h listener list, ideally ldaps:// on a named interface only, and paste that line with the config so it can be graded.");
        } else {
          var desc = urls.map(function (u) { return u.url + " (line " + u.line + ")"; }).join(", ");
          F("INFO", "listeners (-h)", urls.map(function (u) { return u.line; }),
            "Listener(s) found in the pasted text: " + desc + ".",
            "No fix needed for the listener line itself; the findings below grade what that exposure is paired with.");
        }

        /* TLS posture */
        var certE = byBase(entries, "tlscertificatefile");
        var keyE = byBase(entries, "tlscertificatekeyfile");
        var caE = byBase(entries, "tlscacertificatefile").concat(byBase(entries, "tlscacertificatepath"));
        var tlsMissing = certE.length === 0 || keyE.length === 0;
        if (tlsMissing) {
          var missing = [];
          if (certE.length === 0) missing.push("TLSCertificateFile");
          if (keyE.length === 0) missing.push("TLSCertificateKeyFile");
          var presentLines = certE.concat(keyE).map(function (e) { return e.line; });
          F(plaintextExternal ? "BLOCKER" : "WARNING",
            missing.join(" / "), presentLines,
            missing.join(" and ") + " NOT SET IN FILE — no complete TLS certificate is configured, so binds and searches can travel in plaintext.",
            "Set TLSCertificateFile and TLSCertificateKeyFile (or olcTLSCertificateFile / olcTLSCertificateKeyFile) to a real certificate and key, and prefer ldaps:// listeners.");
        }
        if (!tlsMissing && caE.length === 0) {
          F("INFO", "TLSCACertificateFile", [],
            "TLSCACertificateFile is NOT SET IN FILE while a TLS certificate is configured. That is workable for a self-contained server certificate, but clients and replication peers may be unable to verify a chained or CA-issued certificate.",
            "Set TLSCACertificateFile to the issuing CA bundle if the server certificate is CA-issued or replication peers must verify it.");
        }
        var securityE = byBase(entries, "security");
        var ssfMax = 0;
        securityE.forEach(function (e) {
          var sm = e.value.match(/(?:^|\s)ssf\s*=\s*(\d+)/);
          if (sm) ssfMax = Math.max(ssfMax, parseInt(sm[1], 10));
        });
        var hasSSF = ssfMax >= 1;
        if (!hasSSF && tlsMissing) {
          F("WARNING", "security", securityE.map(function (e) { return e.line; }),
            "No security directive requiring an ssf (such as \"security ssf=128\" or olcSecurity) is set, and TLS is not configured either — nothing in the file forces encryption strength on connections.",
            "Add \"security ssf=128\" (or the olcSecurity equivalent) so sessions below that encryption strength are refused.");
        }

        /* Access control */
        var accessE = byBase(entries, "access");
        var anonWriteExists = false, anonAccessExists = false;
        accessE.forEach(function (e) {
          var parsedRule = parseAccessClauses(e.value);
          var targetLc = parsedRule.target.toLowerCase();
          var touchesPassword = targetLc.indexOf("userpassword") !== -1;
          parsedRule.clauses.forEach(function (c) {
            var who = c.who.toLowerCase();
            var anonymousish = (who === "anonymous" || who === "*");
            if (who === "anonymous") anonAccessExists = true;
            if (anonymousish && isWriteLevel(c.level)) {
              anonWriteExists = true;
              F("BLOCKER", e.name, [e.line],
                "This access rule grants WRITE access to " + (who === "anonymous" ? "anonymous (unauthenticated) clients" : "everyone (\"by *\")") + ". Anyone who can reach the listener can change directory data without proving any identity.",
                "Remove the anonymous write grant. Require authentication instead, for example: access to * by users write, with anonymous limited to \"auth\" on the password attribute only.");
            }
            if (anonymousish && touchesPassword && isReadLevel(c.level)) {
              F("WARNING", e.name, [e.line],
                "This access rule lets " + (who === "anonymous" ? "anonymous clients" : "any client") + " read the userPassword attribute — password hashes should never be readable by unauthenticated clients.",
                "Restrict userPassword to: by self write, by anonymous auth, by * none — so anonymous clients can authenticate against it but never read it.");
            }
          });
        });
        if (accessE.length === 0) {
          F(anyAllInterfaces ? "BLOCKER" : "WARNING", "access", [],
            "No access directive exists in the file at all. slapd's permissive built-in default then applies: any client that can connect — including anonymous clients — can read the directory.",
            "Add explicit access rules: protect userPassword first (self write, anonymous auth, everyone else none), then grant the rest of the tree only the access it truly needs.");
        }

        /* Exposure pairing */
        if (anyAllInterfaces && (tlsMissing || anonWriteExists || anonAccessExists)) {
          var listenerHalf = listenersNotSet
            ? "no listener restriction in the file (NOT SET IN FILE), so slapd listens on all interfaces by default"
            : "a listener on all interfaces (line " + urls.filter(function (u) { return u.allInterfaces; }).map(function (u) { return u.line; }).join(", ") + ")";
          var otherHalf = tlsMissing
            ? "no TLS certificate configured"
            : (anonWriteExists ? "an access rule grants anonymous write" : "access rules grant anonymous access");
          F((plaintextExternal && tlsMissing) ? "BLOCKER" : "WARNING", "listeners + " + (tlsMissing ? "TLS" : "access"), [],
            "Exposure pairing: " + listenerHalf + ", paired with " + otherHalf + ". Each half is worse because of the other — the reachable surface and the weakness sit on the same server.",
            "Break the pairing: restrict listeners with -h (ideally ldaps:// on a named interface), configure TLS, and remove anonymous grants so no single half can expose the directory.");
        }

        /* Credentials — rootpw values are never read into any output. */
        var rootpwE = byBase(entries, "rootpw");
        var rootdnE = byBase(entries, "rootdn");
        rootpwE.forEach(function (e) {
          var v = e.value.replace(/^["']/, "");
          var hm = v.match(/^\{([A-Za-z0-9-]+)\}/);
          if (hm) {
            F("INFO", e.name, [e.line],
              "rootpw on this line is stored as a hashed value using the {" + hm[1].toUpperCase() + "} scheme. The value itself is never printed by this tool.",
              "No fix needed. Keep the hashed form, and re-hash with {ARGON2} or {SSHA} if the hash is ever regenerated.");
          } else {
            F("BLOCKER", e.name, [e.line],
              "rootpw on this line is stored in PLAINTEXT — the value does not begin with a {SCHEME} hash marker such as {SSHA} or {ARGON2}. Anyone who reads this file holds the directory's master credential. The value itself is never printed by this tool.",
              "Replace it with a hash: run slappasswd -s (your password) and paste the {SSHA} or {ARGON2} output as the rootpw value, then restrict who can read the config file.");
          }
        });
        if (rootdnE.length > 0 && rootpwE.length === 0) {
          F("INFO", "rootdn", rootdnE.map(function (e) { return e.line; }),
            "rootdn is set but no rootpw appears in the file. The root DN then has no password credential in this config — it may rely on an external SASL identity, a separate cn=config entry, or be effectively unusable.",
            "If the root DN should bind with a password, add a hashed rootpw. If root access is intentionally external or disabled, no fix is needed.");
        }
        var pwhE = byBase(entries, "password-hash");
        pwhE.forEach(function (e) {
          var schemes = [], sm2, re2 = /\{([A-Za-z0-9-]+)\}/g;
          while ((sm2 = re2.exec(e.value)) !== null) schemes.push(sm2[1].toUpperCase());
          schemes.forEach(function (s) {
            if (s === "CLEARTEXT") {
              F("BLOCKER", e.name, [e.line],
                "password-hash is set to {CLEARTEXT}: every password set through this server will be stored readable, exactly as typed.",
                "Set password-hash to {ARGON2} (or {SSHA} at minimum) so stored passwords are hashed.");
            } else if (s === "MD5" || s === "SHA" || s === "SMD5" || s === "SSHA1") {
              F("WARNING", e.name, [e.line],
                "password-hash uses the legacy {" + s + "} scheme — fast, unsalted-or-weakly-salted hashes that fall quickly to offline guessing if the directory leaks.",
                "Move to password-hash {ARGON2} (or {SSHA}) and have passwords re-set so they are re-hashed.");
            } else if (s === "CRYPT") {
              F("INFO", e.name, [e.line],
                "password-hash uses {CRYPT}, a legacy scheme. Its strength depends entirely on the host crypt implementation, which this tool cannot see from pasted text.",
                "Prefer password-hash {ARGON2} or {SSHA} so the strength does not depend on the host's crypt defaults.");
            }
          });
        });

        /* Limits & safety */
        var sizeE = byBase(entries, "sizelimit");
        var timeE = byBase(entries, "timelimit");
        if (sizeE.length === 0) {
          F("WARNING", "sizelimit", [],
            "sizelimit is NOT SET IN FILE — searches are unbounded, so one broad query can return the entire directory and exhaust the server.",
            "Set an explicit sizelimit sized to real clients, for example \"sizelimit 500\".");
        } else {
          sizeE.forEach(function (e) {
            var tok = firstToken(e.value).toLowerCase();
            if (tok === "unlimited" || tok === "-1") {
              F("WARNING", e.name, [e.line],
                "sizelimit is explicitly set to unlimited — searches have no result cap.",
                "Replace it with a finite sizelimit sized to real clients, for example \"sizelimit 500\".");
            }
          });
        }
        if (timeE.length === 0) {
          F("WARNING", "timelimit", [],
            "timelimit is NOT SET IN FILE — a single search can run without a time bound and hold server resources.",
            "Set an explicit timelimit in seconds, for example \"timelimit 120\".");
        } else {
          timeE.forEach(function (e) {
            var tok = firstToken(e.value).toLowerCase();
            if (tok === "unlimited" || tok === "-1") {
              F("WARNING", e.name, [e.line],
                "timelimit is explicitly set to unlimited — searches have no time bound.",
                "Replace it with a finite timelimit in seconds, for example \"timelimit 120\".");
            }
          });
        }
        var disallowE = byBase(entries, "disallow");
        var bindAnonSet = disallowE.some(function (e) { return e.value.toLowerCase().indexOf("bind_anon") !== -1; });
        var anonMentioned = accessE.some(function (e) { return e.value.toLowerCase().indexOf("anonymous") !== -1; });
        if (accessE.length > 0 && anonMentioned && !bindAnonSet) {
          F("WARNING", "disallow", [],
            "disallow bind_anon is NOT SET IN FILE while access rules grant anonymous access. Anonymous binds stay enabled, so unauthenticated sessions are always available to pair with those grants.",
            "Add \"disallow bind_anon\" (or olcDisallows) if anonymous binds are not required — or keep it only with a written reason, since some public-lookup directories need it.");
        }

        /* Duplicates — singleton directives, last value wins. Values are never printed. */
        SINGLETONS.forEach(function (b) {
          var list = byBase(entries, b);
          if (list.length > 1) {
            var lines = list.map(function (e) { return e.line; });
            F("INFO", list[0].name, lines,
              "This directive appears " + list.length + " times, on lines " + lines.join(" and ") + ". The last value (line " + lines[lines.length - 1] + ") wins; earlier values are silently overridden.",
              "Delete the overridden earlier line(s) so the file says once what it means.");
          }
        });

        /* Sort: severity, then earliest line, line-less findings last within a tier. */
        var rank = { "BLOCKER": 0, "WARNING": 1, "INFO": 2 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          var la = a.lines.length ? Math.min.apply(null, a.lines) : 1000000000;
          var lb = b.lines.length ? Math.min.apply(null, b.lines) : 1000000000;
          return la - lb;
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

        var notSet = [];
        if (accessE.length === 0) notSet.push("access (olcAccess)");
        if (listenersNotSet) notSet.push("listeners (-h restriction)");
        if (certE.length === 0) notSet.push("TLSCertificateFile (olcTLSCertificateFile)");
        if (keyE.length === 0) notSet.push("TLSCertificateKeyFile (olcTLSCertificateKeyFile)");
        if (caE.length === 0) notSet.push("TLSCACertificateFile (olcTLSCACertificateFile)");
        if (!hasSSF) notSet.push("security ssf requirement (olcSecurity)");
        if (sizeE.length === 0) notSet.push("sizelimit (olcSizeLimit)");
        if (timeE.length === 0) notSet.push("timelimit (olcTimeLimit)");
        if (!bindAnonSet) notSet.push("disallow bind_anon (olcDisallows)");
        if (rootpwE.length === 0) notSet.push("rootpw (olcRootPw)");

        var coverage = [
          { item: "Access rules (access / olcAccess)", set: accessE.length > 0, lines: accessE.map(function (e) { return e.line; }) },
          { item: "Listeners (-h / listener URLs)", set: !listenersNotSet, lines: urls.map(function (u) { return u.line; }) },
          { item: "TLS certificate file", set: certE.length > 0, lines: certE.map(function (e) { return e.line; }) },
          { item: "TLS certificate key file", set: keyE.length > 0, lines: keyE.map(function (e) { return e.line; }) },
          { item: "TLS CA certificate file", set: caE.length > 0, lines: caE.map(function (e) { return e.line; }) },
          { item: "security ssf requirement", set: hasSSF, lines: securityE.map(function (e) { return e.line; }) },
          { item: "rootpw (hashed or not — see findings)", set: rootpwE.length > 0, lines: rootpwE.map(function (e) { return e.line; }) },
          { item: "password-hash", set: pwhE.length > 0, lines: pwhE.map(function (e) { return e.line; }) },
          { item: "sizelimit", set: sizeE.length > 0, lines: sizeE.map(function (e) { return e.line; }) },
          { item: "timelimit", set: timeE.length > 0, lines: timeE.map(function (e) { return e.line; }) },
          { item: "disallow bind_anon", set: bindAnonSet, lines: disallowE.map(function (e) { return e.line; }) }
        ];

        return {
          verdict: verdict, counts: counts, findings: findings,
          notParsed: parsed.notParsed, notAudited: notAudited,
          notSet: notSet, coverage: coverage,
          parsedLines: entries.length, totalLines: parsed.lineTotal
        };
      }

      /* ---------- Reports (built only from findings — no config values, ever) ---------- */
      function lineLabel(lines) {
        if (!lines || lines.length === 0) return "not set in file";
        return lines.length === 1 ? "line " + lines[0] : "lines " + lines.join(", ");
      }
      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs OpenLDAP Server Config Safety Auditor(TM) - Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Findings: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.WARNING + " WARNING, " + r.counts.INFO + " INFO");
        out.push("Directives parsed: " + r.parsedLines + " of " + r.totalLines + " pasted lines");
        out.push("");
        if (r.findings.length === 0) {
          out.push("No findings.");
        }
        r.findings.forEach(function (f, idx) {
          out.push((idx + 1) + ". [" + f.severity + "] " + f.directive + " - " + lineLabel(f.lines));
          out.push("   Finding: " + f.message);
          out.push("   Fix: " + f.fix);
        });
        out.push("");
        out.push("NOT PARSED lines: " + (r.notParsed.length ? r.notParsed.join(", ") : "none"));
        out.push("NOT AUDITED directives: " + (r.notAudited.length
          ? r.notAudited.map(function (n) { return n.name + " (" + lineLabel(n.lines) + ")"; }).join("; ")
          : "none"));
        out.push("NOT SET IN FILE: " + (r.notSet.length ? r.notSet.join("; ") : "none"));
        out.push("");
        out.push("Note: rootpw values are never printed in this report. This audit parses pasted text only; it does not connect to or verify a live server.");
        return out.join("\n");
      }
      function buildJsonReport(r) {
        var obj = {
          tool: "J-Dawgs OpenLDAP Server Config Safety Auditor\u2122",
          verdict: r.verdict,
          counts: { blockers: r.counts.BLOCKER, warnings: r.counts.WARNING, infos: r.counts.INFO },
          directivesParsed: r.parsedLines,
          pastedLines: r.totalLines,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, directive: f.directive, lines: f.lines, finding: f.message, fix: f.fix };
          }),
          notParsedLines: r.notParsed,
          notAuditedDirectives: r.notAudited.map(function (n) { return { directive: n.name, lines: n.lines }; }),
          notSetInFile: r.notSet,
          note: "rootpw values are never included in this report. This audit parses pasted text only; it does not connect to or verify a live server."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openldap-server-config-safety-auditortm-2',
  name: 'J-Dawgs OpenLDAP Server Config Safety Auditor',
  description: 'pasting a slapd.conf or OpenLDAP cn=config',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
