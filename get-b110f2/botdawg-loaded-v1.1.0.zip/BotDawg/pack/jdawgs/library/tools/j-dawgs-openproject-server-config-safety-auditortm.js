'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenProject Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples ---------- */

      var RISKY_EXAMPLE = [
        "# Risky sample - training values only, not a real server",
        "OPENPROJECT_HOST__NAME=http://projects.example.internal",
        "OPENPROJECT_HTTPS=false",
        "SECRET_KEY_BASE=openproject",
        "DATABASE_URL=postgres://openproject:dbpass123@db.internal:5432/openproject",
        "OPENPROJECT_SMTP_ADDRESS=mail.example.internal",
        "OPENPROJECT_SMTP_PASSWORD=mailpass789",
        "OPENPROJECT_SELF__REGISTRATION=true",
        "RAILS_LOG_LEVEL=info"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened sample - training values only, not a real server",
        "OPENPROJECT_HOST__NAME=https://projects.example.com",
        "OPENPROJECT_HTTPS=true",
        "OPENPROJECT_SECRET_KEY_BASE=${SECRET_KEY_BASE_FROM_VAULT}",
        "OPENPROJECT_DATABASE_URL_FILE=/run/secrets/openproject_db_url",
        "OPENPROJECT_SMTP_ADDRESS=mail.example.com",
        "OPENPROJECT_SMTP_PASSWORD_FILE=/run/secrets/openproject_smtp_password",
        "OPENPROJECT_SELF__REGISTRATION=false",
        "RAILS_LOG_LEVEL=info"
      ].join("\n");

      var PROSE_EXAMPLE = [
        "This server runs our team projects and the wiki.",
        "We should probably look at the settings sometime next week.",
        "Ask Sam about the database when he is back from leave."
      ].join("\n");

      /* ---------- Parsing ---------- */

      function normKey(k){
        return k.toUpperCase().replace(/[.\-]/g, "_");
      }

      function cleanValue(raw){
        var v = raw.replace(/^\s+/, "").replace(/\s+$/, "");
        if (v.length >= 2 && (v.charAt(0) === '"' || v.charAt(0) === "'")){
          var q = v.charAt(0);
          var end = v.indexOf(q, 1);
          if (end > 0) return v.slice(1, end);
          return v.slice(1);
        }
        var hash = v.indexOf(" #");
        if (hash >= 0) v = v.slice(0, hash);
        return v.replace(/\s+$/, "");
      }

      function parseConfig(text){
        var entries = [];
        var notParsed = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var s = lines[i].replace(/^\s+/, "").replace(/\s+$/, "");
          if (!s) continue;
          if (s.charAt(0) === "#") continue;
          var work = s;
          if (work.indexOf("- ") === 0) work = work.slice(2).replace(/^\s+/, "");
          if (/^export\s+/i.test(work)) work = work.replace(/^export\s+/i, "");
          var m = work.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
          if (m){
            entries.push({ line: lineNo, key: m[1], norm: normKey(m[1]), value: cleanValue(m[2]) });
            continue;
          }
          var bare = work.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)$/);
          if (bare){
            entries.push({ line: lineNo, key: bare[1], norm: normKey(bare[1]), value: "" });
            continue;
          }
          notParsed.push(lineNo);
        }
        return { entries: entries, notParsed: notParsed };
      }

      /* ---------- Value helpers (values are inspected, never rendered) ---------- */

      function isRef(v){ return /^\$\{[^}]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v); }
      function isMasked(v){ return /^\*+$/.test(v) || /^x+$/i.test(v); }
      function truthy(v){
        var s = v.toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function falsy(v){
        var s = v.toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off";
      }

      var KNOWN_KEYS = {
        SECRET_KEY_BASE:1, DATABASE_URL:1, RAILS_ENV:1, RAILS_LOG_LEVEL:1,
        HOST:1, HOSTNAME:1, BIND:1, BIND_ADDRESS:1, DEBUG:1, ENVIRONMENT:1,
        SMTP_ADDRESS:1, SMTP_PASSWORD:1, SMTP_USER_NAME:1, SMTP_USERNAME:1
      };

      function isRecognized(norm){
        if (norm.indexOf("OPENPROJECT") === 0) return true;
        if (KNOWN_KEYS[norm]) return true;
        if (norm.indexOf("SECRET_KEY") >= 0) return true;
        if (/DATABASE_URL/.test(norm)) return true;
        if (norm.indexOf("SMTP") >= 0) return true;
        if (norm.indexOf("REGISTRATION") >= 0 || norm.indexOf("SIGNUP") >= 0 || norm.indexOf("SIGN_UP") >= 0) return true;
        if (norm.indexOf("PASSWORD") >= 0) return true;
        return false;
      }

      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      /* ---------- The audit ---------- */

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        var passed = [];

        function add(sev, line, key, reason, fix, valueLength){
          var f = { severity: sev, line: (line == null ? null : line), key: key, reason: reason, fix: fix };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }
        function pass(textPass){ passed.push(textPass); }
        function byNorm(name){
          for (var i = 0; i < entries.length; i++) if (entries[i].norm === name) return entries[i];
          return null;
        }

        var recognized = 0;
        for (var r = 0; r < entries.length; r++) if (isRecognized(entries[r].norm)) recognized++;

        /* --- Transport context: is HTTPS on, off, or unstated? --- */
        var httpsEntry = byNorm("OPENPROJECT_HTTPS");
        var httpsOff = false, httpsOn = false;
        if (httpsEntry){
          if (falsy(httpsEntry.value)) httpsOff = true;
          else if (truthy(httpsEntry.value)) httpsOn = true;
        }
        var httpUrlLines = [];
        for (var u = 0; u < entries.length; u++){
          if (/^http:\/\//i.test(entries[u].value)) { httpUrlLines.push(entries[u]); httpsOff = true; }
        }

        /* --- SECRET_KEY_BASE (either naming form) --- */
        var secretSeen = false;
        entries.forEach(function(e){
          if (e.norm === "SECRET_KEY_BASE_FILE" || e.norm === "OPENPROJECT_SECRET_KEY_BASE_FILE"){
            secretSeen = true;
            pass(e.key + " (line " + e.line + ") loads the secret key base from a file reference instead of a pasted value.");
            return;
          }
          if (e.norm !== "SECRET_KEY_BASE" && e.norm !== "OPENPROJECT_SECRET_KEY_BASE") return;
          secretSeen = true;
          var v = e.value;
          if (isRef(v)){
            pass(e.key + " (line " + e.line + ") is supplied through a variable reference, so no secret value sits in the config text.");
            return;
          }
          var lower = v.toLowerCase();
          var placeholderWords = ["secret", "changeme", "change-me", "example", "test", "openproject", "placeholder"];
          var readsPlaceholder = false;
          for (var p = 0; p < placeholderWords.length; p++){
            if (lower.indexOf(placeholderWords[p]) >= 0){ readsPlaceholder = true; break; }
          }
          var longPlaceholder = lower.indexOf("changeme") >= 0 || lower.indexOf("example") >= 0 ||
                                lower.indexOf("placeholder") >= 0 || lower.indexOf("openproject") >= 0;
          if (v.length < 32){
            add("BLOCKER", e.line, e.key,
              "The secret key base is only " + v.length + " characters long" + (readsPlaceholder ? " and reads as an example/placeholder value" : "") + ". This key signs session cookies and tokens; a short or guessable one lets anyone forge a login session for any account, including admins. Reported by length only - the value is never shown.",
              "Generate a long random value (64+ characters from a password manager or your secret store) and supply it through a secret file or variable reference instead of pasting it into the config.",
              v.length);
          } else if (longPlaceholder){
            add("BLOCKER", e.line, e.key,
              "The secret key base is " + v.length + " characters long but reads as an example/placeholder value. Sample values are public knowledge, so anyone can use it to forge session cookies and tokens. Reported by length only - the value is never shown.",
              "Replace it with a freshly generated long random value kept in a secret store, and supply it by file or variable reference.",
              v.length);
          } else {
            pass(e.key + " (line " + e.line + ") is present at " + v.length + " characters, which clears the 32-character floor. Length reported only - the value is never shown.");
          }
        });
        if (!secretSeen && recognized > 0){
          add("INFO", null, "SECRET_KEY_BASE",
            "No secret key base appears in this paste under either naming form (SECRET_KEY_BASE or OPENPROJECT_SECRET_KEY_BASE). It may be set somewhere this paste does not cover.",
            "Confirm a long random secret key base is set wherever the rest of the configuration lives before deploying.");
        }

        /* --- HTTPS posture --- */
        if (httpsEntry){
          if (falsy(httpsEntry.value)){
            add("HIGH", httpsEntry.line, httpsEntry.key,
              "HTTPS is switched off. Logins, session cookies, and everything users type travel over plain HTTP, where anyone on the network path can read or steal them.",
              "Set OPENPROJECT_HTTPS=true and put the server behind a proper TLS endpoint (reverse proxy or load balancer) before real users sign in.");
          } else if (truthy(httpsEntry.value)){
            pass(httpsEntry.key + " (line " + httpsEntry.line + ") turns HTTPS on.");
          } else {
            add("INFO", httpsEntry.line, httpsEntry.key,
              "The HTTPS setting carries a value this tool does not recognize as on or off, so the transport posture cannot be confirmed from the paste.",
              "Set OPENPROJECT_HTTPS explicitly to true for a production deploy.");
          }
        }
        httpUrlLines.forEach(function(e){
          add("HIGH", e.line, e.key,
            "This host/site address uses http://, so traffic to it is unencrypted even if other settings look right - session cookies and logins cross the network in the clear.",
            "Change the address to its https:// form and make sure the server actually serves TLS on it.");
        });
        if (!httpsEntry && httpUrlLines.length === 0 && recognized > 0){
          add("INFO", null, "OPENPROJECT_HTTPS",
            "The paste does not state an HTTPS posture at all - no OPENPROJECT_HTTPS setting and no host/site URL to learn from.",
            "State OPENPROJECT_HTTPS=true explicitly in the deployed config so the transport posture is a decision, not an accident.");
        }

        /* --- DATABASE_URL with an embedded password --- */
        entries.forEach(function(e){
          if (e.norm === "DATABASE_URL_FILE" || e.norm === "OPENPROJECT_DATABASE_URL_FILE"){
            pass(e.key + " (line " + e.line + ") loads the database connection from a file reference, keeping credentials out of the config text.");
            return;
          }
          if (e.norm !== "DATABASE_URL" && e.norm !== "OPENPROJECT_DATABASE_URL") return;
          var v = e.value;
          if (isRef(v)){
            pass(e.key + " (line " + e.line + ") is supplied through a variable reference, so no database credential sits in the config text.");
            return;
          }
          var m = v.match(/^[A-Za-z][A-Za-z0-9+.\-]*:\/\/[^:\/@]+:([^@\/]+)@/);
          if (m && !isRef(m[1])){
            add("HIGH", e.line, e.key,
              "The database URL embeds a plaintext password (" + m[1].length + " characters; full value " + v.length + " characters - neither is shown). Anyone who can read this config - a repo, a backup, a screenshot - owns the database.",
              "Move the connection string into a secret file or variable reference (for example a *_FILE key), and rotate the database password, since the pasted one must be treated as exposed.",
              v.length);
          } else if (m && isRef(m[1])){
            pass(e.key + " (line " + e.line + ") keeps the database password behind a variable reference instead of plaintext.");
          } else {
            pass(e.key + " (line " + e.line + ") carries no embedded plaintext password - no password segment sits between the username and the host.");
          }
        });

        /* --- Plaintext password keys (SMTP, admin, database, generic) --- */
        entries.forEach(function(e){
          if (e.norm.indexOf("PASSWORD") < 0) return;
          if (/_FILE$/.test(e.norm)){
            pass(e.key + " (line " + e.line + ") loads its password from a file reference instead of a pasted value.");
            return;
          }
          var v = e.value;
          if (!v) return; /* named but supplied elsewhere - nothing pasted to grade */
          if (isRef(v)){
            pass(e.key + " (line " + e.line + ") is supplied through a variable reference, so no password sits in the config text.");
            return;
          }
          if (isMasked(v)){
            pass(e.key + " (line " + e.line + ") appears already masked in the paste, so there is no readable password to grade.");
            return;
          }
          var what = "password";
          if (e.norm.indexOf("SMTP") >= 0 || e.norm.indexOf("MAIL") >= 0) what = "mail (SMTP) password";
          else if (e.norm.indexOf("ADMIN") >= 0) what = "initial admin password";
          else if (e.norm.indexOf("DATABASE") >= 0 || e.norm.indexOf("DB_") >= 0) what = "database password";
          add("HIGH", e.line, e.key,
            "This " + what + " is written in plaintext (" + v.length + " characters - the value is never shown). Config files get committed, backed up, and screenshotted; a password in one must be treated as public.",
            "Move it into a secret file or variable reference (use the matching *_FILE key where the platform offers one) and rotate the password, since the pasted one must be treated as exposed.",
            v.length);
        });

        /* --- Self-registration / open signup --- */
        entries.forEach(function(e){
          if (e.norm.indexOf("REGISTRATION") < 0 && e.norm.indexOf("SIGNUP") < 0 && e.norm.indexOf("SIGN_UP") < 0) return;
          var v = e.value.toLowerCase();
          var enabled = v === "true" || v === "yes" || v === "on" || v === "1" || v === "2" || v === "3" ||
                        v === "enabled" || v === "automatic" || v === "auto" || v === "open";
          var restricted = v === "false" || v === "no" || v === "off" || v === "0" ||
                           v === "disabled" || v === "none" || v === "restricted" || v === "closed";
          if (enabled){
            if (httpsOff){
              add("HIGH", e.line, e.key,
                "Self-registration is open while HTTPS is off. Anyone on the network path can watch strangers create accounts and sign in over plain HTTP - open doors, held open on an unencrypted connection.",
                "Restrict registration (admin-created or invite-only accounts) and turn HTTPS on before this server faces real users.");
            } else {
              add("WARNING", e.line, e.key,
                "Self-registration is open: anyone who can reach the login page can create an account. On a team server that usually means strangers, bots, and spam projects get in without an invite.",
                "Restrict registration to admin-created or invite-only accounts unless this instance is deliberately public.");
            }
          } else if (restricted){
            pass(e.key + " (line " + e.line + ") keeps self-registration restricted.");
          } else {
            add("INFO", e.line, e.key,
              "This registration setting carries a value this tool cannot classify as open or restricted, so it is reported rather than guessed at.",
              "Check the value against your intent: open means anyone can sign up; restricted means admins or invites only.");
          }
        });

        /* --- Host bound to all interfaces --- */
        var BIND_KEYS = { HOST:1, BIND:1, BIND_ADDRESS:1, OPENPROJECT_BIND:1, OPENPROJECT_BIND_ADDRESS:1, OPENPROJECT_LISTEN:1 };
        entries.forEach(function(e){
          if (!BIND_KEYS[e.norm]) return;
          var v = e.value;
          if (v === "0.0.0.0" || v === "::" || v === "[::]"){
            if (httpsOff){
              add("HIGH", e.line, e.key,
                "The server binds to every network interface (0.0.0.0) while HTTPS is off. That combination matters: the app is reachable from every network it touches, and every login on every one of those networks travels unencrypted. Either fact alone is a caution; together they are an open, unencrypted front door.",
                "Bind to a specific interface or put the app behind a TLS-terminating reverse proxy, and turn HTTPS on.");
            } else {
              add("WARNING", e.line, e.key,
                "The server binds to every network interface (0.0.0.0). That is normal behind a reverse proxy or inside a container network, and a exposure risk anywhere else.",
                "Confirm a proxy, firewall, or container boundary sits in front of this bind; otherwise bind to a specific interface.");
            }
          } else if (v === "127.0.0.1" || v.toLowerCase() === "localhost"){
            pass(e.key + " (line " + e.line + ") binds to the local interface only.");
          }
        });

        /* --- Debug / verbose logging and development posture --- */
        entries.forEach(function(e){
          var v = e.value.toLowerCase();
          var isLogLevel = (e.norm.indexOf("LOG") >= 0 && e.norm.indexOf("LEVEL") >= 0) || e.norm === "OPENPROJECT_LOG_LEVEL";
          if (isLogLevel){
            if (v === "debug" || v === "verbose" || v === "trace"){
              add("WARNING", e.line, e.key,
                "Logging is set to a debug/verbose level. Debug logs slow the server, fill disks, and tend to record request details - sometimes including tokens and personal data - that production logs should never keep.",
                "Set the log level to info (or warn) for production and save debug logging for short, supervised troubleshooting.");
            } else if (v){
              pass(e.key + " (line " + e.line + ") uses a non-debug log level.");
            }
            return;
          }
          if (e.norm === "DEBUG" || /_DEBUG$/.test(e.norm)){
            if (truthy(e.value) || v === "debug"){
              add("WARNING", e.line, e.key,
                "A debug switch is turned on. Debug modes in Rails apps can expose detailed error pages and internals that hand an attacker a map of the system.",
                "Turn debug off for production; enable it only briefly, on a private copy, while troubleshooting.");
            }
            return;
          }
          if (e.norm === "RAILS_ENV" || e.norm === "OPENPROJECT_ENV" || e.norm === "ENVIRONMENT"){
            if (v === "development" || v === "dev"){
              add("WARNING", e.line, e.key,
                "The environment posture is development. Development mode trades safety for convenience - verbose errors, relaxed checks, and debug tooling - and is not meant to face real users or real data.",
                "Set the environment to production for a deployed server.");
            } else if (v === "production"){
              pass(e.key + " (line " + e.line + ") runs in production posture.");
            }
          }
        });

        /* --- Sort worst first, then by line --- */
        findings.sort(function(a, b){
          var d = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (d !== 0) return d;
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict, verdictWhy;
        if (recognized === 0){
          verdict = "NOT ENOUGH TO GRADE";
          verdictWhy = entries.length === 0 && parsed.notParsed.length === 0
            ? "The paste is empty. There is nothing here to grade."
            : "No recognizable OpenProject configuration keys were found in this paste, so grading it would be guessing. Paste environment-style KEY=value lines (or docker-compose environment lines) from the server configuration.";
        } else if (counts.BLOCKER > 0){
          verdict = "DO NOT DEPLOY";
          verdictWhy = "At least one BLOCKER finding must be fixed before this configuration goes anywhere near a real server.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0){
          verdict = "DEPLOY WITH FIXES";
          verdictWhy = "Nothing here is an outright stop, but the HIGH and WARNING findings above should be fixed before real users and real data depend on this server.";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictWhy = "No BLOCKER, HIGH, or WARNING findings on the checks this tool runs. That covers the pasted text only - it is not a promise about the server, the network, or anything the paste left out.";
        }

        return {
          verdict: verdict,
          verdictWhy: verdictWhy,
          counts: counts,
          findings: findings,
          passed: passed,
          notParsed: parsed.notParsed,
          recognized: recognized,
          parsedLines: entries.length
        };
      }

      /* ---------- Reports ---------- */

      function lineLabel(f){ return f.line == null ? "not in paste" : "line " + f.line; }

      function buildTextReport(res){
        var out = [];
        out.push("J-Dawgs OpenProject Server Config Safety Auditor - report");
        out.push("Grades pasted text only. Never connected to a server. Secrets are reported by key name, line, and value length only.");
        out.push("");
        out.push("VERDICT: " + res.verdict);
        out.push(res.verdictWhy);
        out.push("");
        out.push("Counts: BLOCKER " + res.counts.BLOCKER + " | HIGH " + res.counts.HIGH + " | WARNING " + res.counts.WARNING + " | INFO " + res.counts.INFO);
        out.push("Recognized OpenProject keys: " + res.recognized + " | Parsed lines: " + res.parsedLines + " | Not parsed: " + (res.notParsed.length ? res.notParsed.join(", ") : "none"));
        out.push("");
        out.push("FINDINGS (worst first):");
        if (!res.findings.length) out.push("  None.");
        res.findings.forEach(function(f){
          out.push("  [" + f.severity + "] " + f.key + " (" + lineLabel(f) + ")" + (typeof f.valueLength === "number" ? " - value length " + f.valueLength + " characters, value never shown" : ""));
          out.push("    Why: " + f.reason);
          out.push("    Fix: " + f.fix);
        });
        out.push("");
        out.push("PASSED CHECKS:");
        if (!res.passed.length) out.push("  None.");
        res.passed.forEach(function(p){ out.push("  - " + p); });
        out.push("");
        out.push("NOT PARSED LINES: " + (res.notParsed.length ? res.notParsed.join(", ") : "none"));
        return out.join("\n");
      }

      function buildJsonReport(res){
        var obj = {
          tool: "J-Dawgs OpenProject Server Config Safety Auditor",
          scope: "Pasted text only. No server connection. Secrets reported by key name, line, and value length only.",
          verdict: res.verdict,
          verdictWhy: res.verdictWhy,
          counts: res.counts,
          recognizedKeys: res.recognized,
          parsedLines: res.parsedLines,
          findings: res.findings.map(function(f){
            var o = { severity: f.severity, line: f.line, key: f.key, reason: f.reason, fix: f.fix };
            if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
            return o;
          }),
          passedChecks: res.passed,
          notParsedLines: res.notParsed
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "PROSE_EXAMPLE": (typeof PROSE_EXAMPLE !== 'undefined' ? PROSE_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openproject-server-config-safety-auditortm',
  name: 'J-Dawgs OpenProject Server Config Safety Auditor',
  description: 'Grades a pasted OpenProject server config offline into one deploy verdict, with secrets reported by key name, line, and length only, never values.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "PROSE_EXAMPLE": __core["PROSE_EXAMPLE"] }
};
