'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Superset Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# Risky example — for testing only, do not deploy",
'SECRET_KEY = "thisISaSECRET_1234"',
'SQLALCHEMY_DATABASE_URI = "sqlite:///superset.db"',
'SQLALCHEMY_DATABASE_URI = "postgresql://superset:SuperSecretPass123@db.example.com:5432/superset"',
'PUBLIC_ROLE_LIKE = "Admin"',
"WTF_CSRF_ENABLED = False",
"DEBUG = True"
].join("\n");

var HARDENED = [
"import os",
"# SECRET_KEY is loaded from the environment — never hardcode it.",
'SECRET_KEY = os.environ["SUPERSET_SECRET_KEY"]',
'SQLALCHEMY_DATABASE_URI = "postgresql://superset@db.internal:5432/superset"',
"WTF_CSRF_ENABLED = True",
"WTF_CSRF_EXEMPT_LIST = []",
"TALISMAN_ENABLED = True",
"TALISMAN_FORCE_HTTPS = True",
"SESSION_COOKIE_SECURE = True",
"SESSION_COOKIE_HTTPONLY = True",
"ENABLE_PROXY_FIX = True",
"SQLLAB_ASYNC_TIME_LIMIT = 600",
"SUPERSET_WEBSERVER_TIMEOUT = 120",
"DEBUG = False",
'FLASK_ENV = "production"'
].join("\n");

var KNOWN_KEYS = {
  SECRET_KEY:1, SQLALCHEMY_DATABASE_URI:1, PUBLIC_ROLE_LIKE:1,
  WTF_CSRF_ENABLED:1, WTF_CSRF_EXEMPT_LIST:1, WTF_CSRF_TIME_LIMIT:1,
  AUTH_TYPE:1, AUTH_USER_REGISTRATION:1, AUTH_ROLES_SYNC_AT_LOGIN:1,
  TALISMAN_ENABLED:1, TALISMAN_FORCE_HTTPS:1, TALISMAN_CONFIG:1,
  ENABLE_PROXY_FIX:1, SESSION_COOKIE_SECURE:1, SESSION_COOKIE_HTTPONLY:1, SESSION_COOKIE_SAMESITE:1,
  MAPBOX_API_KEY:1, SQLLAB_ASYNC_TIME_LIMIT:1, SQLLAB_TIMEOUT:1, SUPERSET_WEBSERVER_TIMEOUT:1,
  SUPERSET_WEBSERVER_ADDRESS:1, SUPERSET_WEBSERVER_PORT:1, DEBUG:1, FLASK_ENV:1, FLASK_USE_RELOAD:1,
  ROW_LIMIT:1, VIZ_ROW_LIMIT:1, CACHE_CONFIG:1, DATA_CACHE_CONFIG:1, RESULTS_BACKEND:1,
  FEATURE_FLAGS:1, SMTP_HOST:1, SMTP_PORT:1, SMTP_USER:1, SMTP_MAIL_FROM:1,
  BABEL_DEFAULT_LOCALE:1, LANGUAGES:1, SECRET_KEY_ROTATION:1, SQL_VALIDATE_ALL:1,
  SUPERSET_LOG_LEVEL:1, ENABLE_TIME_ROTATE:1, FILENAME:1, FAB_API_SWAGGER_UI:1
};

var KNOWN_EXAMPLE_SECRETS = ["thisisasecret_1234","thisisasecret","your_secret_key","your-secret-key","your_secret","secret","secret_key","secretkey","changeme","change_me","change-me","supersecret","super_secret","supersecretkey","example","example_key","default","password","letmein","12345678","xxxxxxxx"];

function isSecretKeyName(key){
  return key === "MAPBOX_API_KEY" || /(_API_KEY|_PASSWORD|_TOKEN|_SECRET|_PRIVATE_KEY)$/.test(key);
}
function isEnvRef(raw){
  return /os\.environ|os\.getenv|getenv\s*\(|environ\.get|environ\s*\[/.test(raw);
}
function stringLiteral(raw){
  var t = raw.replace(/\s+#.*$/,"").trim();
  var m = t.match(/^["']([\s\S]*)["']\s*$/);
  if(m) return m[1];
  var m2 = t.match(/^["']([^"']*)["']/);
  if(m2) return m2[1];
  return null;
}
function isTrue(raw){ return raw.replace(/\s+#.*$/,"").trim() === "True"; }
function isFalse(raw){ return raw.replace(/\s+#.*$/,"").trim() === "False"; }
function looksExample(s){
  var l = s.toLowerCase();
  if(KNOWN_EXAMPLE_SECRETS.indexOf(l) !== -1) return true;
  if(l.indexOf("thisisasecret") !== -1) return true;
  if(l.indexOf("example") !== -1 || l.indexOf("changeme") !== -1 || l.indexOf("your_") === 0 || l.indexOf("your-") === 0) return true;
  return false;
}
function looksExampleGeneric(s){
  var l = s.toLowerCase();
  return looksExample(s) || l.indexOf("test") === 0 || l.indexOf("demo") !== -1 || l.indexOf("xxx") !== -1 || l.indexOf("placeholder") !== -1 || l.indexOf("sample") !== -1;
}

function audit(text){
  var findings = [];
  var notParsed = [];
  var assignments = {}; // key -> array of {line, raw, str}
  var order = [];

  function add(sev, key, line, title, why, fix, safeDetail){
    findings.push({severity:sev, key:key, line:(line==null?null:line), title:title, explanation:why, fix:fix, detail:safeDetail||""});
  }

  if(text == null) text = "";
  var lines = text.split(/\r?\n/);

  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var rawLine = lines[i];
    var trimmed = rawLine.trim();
    if(trimmed === "") continue;
    if(trimmed.charAt(0) === "#") continue;
    if(/^(import\s+\S|from\s+\S+\s+import\s+)/.test(trimmed)) continue;
    var m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\s\S]*)$/);
    if(m){
      var key = m[1], rawVal = m[2].trim();
      if(!assignments[key]){ assignments[key] = []; order.push(key); }
      assignments[key].push({line:lineNo, raw:rawVal, str:stringLiteral(rawVal)});
    } else {
      notParsed.push(lineNo);
      findings.push({severity:"INFO", key:"NOT PARSED", line:lineNo, title:"Line " + lineNo + " was not parsed",
        explanation:"This line is not an assignment, a comment, or an import, so the auditor skipped it rather than guessing what it does. Multi-line values and statements are not followed.",
        fix:"If this line sets a Superset option, rewrite it as a single-line assignment (KEY = value) so it can be graded; otherwise no action is needed.",
        detail:""});
    }
  }

  // Recognizable?
  var recognizable = 0;
  for(var k in assignments){
    if(KNOWN_KEYS[k] || isSecretKeyName(k)) recognizable++;
  }
  var gradable = recognizable > 0;

  if(gradable){

    /* SECRET_KEY */
    if(!assignments["SECRET_KEY"]){
      add("BLOCKER","SECRET_KEY",null,"SECRET_KEY is missing",
        "Superset uses SECRET_KEY to sign sessions and encrypt stored credentials. Without one set in this config, the deployment falls back to an insecure or unset key.",
        "Set SECRET_KEY to a unique random value of at least 64 characters, loaded from the environment — for example: SECRET_KEY = os.environ[\"SUPERSET_SECRET_KEY\"].","");
    } else {
      assignments["SECRET_KEY"].forEach(function(a){
        if(isEnvRef(a.raw)) return; // SAFE, no finding
        if(a.str != null){
          var len = a.str.length;
          if(looksExample(a.str)){
            add("BLOCKER","SECRET_KEY",a.line,"SECRET_KEY is a known example/default value (length " + len + ")",
              "This SECRET_KEY matches a documented example or default-style value (reported by length only — the value is never shown). Anyone who has read the public examples knows it, so sessions can be forged.",
              "Replace it with a unique random value of at least 64 characters that appears in no example, and load it from the environment.","length " + len);
          } else if(len < 32){
            add("BLOCKER","SECRET_KEY",a.line,"SECRET_KEY is too short (length " + len + ")",
              "This SECRET_KEY is under 32 characters (reported by length only — the value is never shown). Short keys are practical to brute-force, which puts signed sessions at risk.",
              "Generate a unique random key of at least 64 characters and load it from the environment instead of hardcoding it.","length " + len);
          } else if(len < 64){
            add("WARNING","SECRET_KEY",a.line,"SECRET_KEY is usable but short (length " + len + ")",
              "This SECRET_KEY is between 32 and 63 characters (reported by length only — the value is never shown). It clears the minimum, but current practice is 64 characters or more for a production signing key.",
              "Rotate to a unique random key of at least 64 characters, loaded from the environment.","length " + len);
          }
        } else {
          add("INFO","SECRET_KEY",a.line,"SECRET_KEY strength could not be verified",
            "SECRET_KEY is assigned from an expression that is not a plain string literal or a recognised environment reference, so its length and origin could not be graded from the pasted text.",
            "Confirm the value comes from the environment or a secrets manager and is a unique random value of at least 64 characters.","");
        }
      });
    }

    /* SQLALCHEMY_DATABASE_URI */
    if(assignments["SQLALCHEMY_DATABASE_URI"]){
      assignments["SQLALCHEMY_DATABASE_URI"].forEach(function(a){
        if(isEnvRef(a.raw)) return;
        if(a.str == null) return;
        var uri = a.str;
        var pm = uri.match(/^([a-zA-Z][a-zA-Z0-9+.\-]*):\/\/([^:\/@]+):([^@]+)@([\s\S]*)$/);
        if(pm){
          var pwLen = pm[3].length;
          var hostPart = pm[4].split("/")[0];
          add("HIGH","SQLALCHEMY_DATABASE_URI",a.line,"Database URI embeds a plaintext password (password length " + pwLen + ")",
            "This URI carries a password in plain text (" + pm[1] + "://***@" + hostPart + " — the password itself is never shown, length only). Anyone who can read this config file has the metadata database password.",
            "Remove the password from the URI and supply it through the environment or a secrets manager; rotate the password, since it has appeared in a config file.","password length " + pwLen);
        } else if(/sqlite/i.test(uri)){
          add("WARNING","SQLALCHEMY_DATABASE_URI",a.line,"Database URI points at the example sqlite metadata database",
            "A sqlite URI is the example/demo metadata database setup. It is not built for concurrent production use and is a common sign an example config was deployed unchanged.",
            "Point SQLALCHEMY_DATABASE_URI at your production metadata database (for example PostgreSQL or MySQL) and supply its credentials via the environment.","");
        }
      });
    }

    /* PUBLIC_ROLE_LIKE */
    if(assignments["PUBLIC_ROLE_LIKE"]){
      assignments["PUBLIC_ROLE_LIKE"].forEach(function(a){
        if(a.str == null) return;
        var v = a.str;
        if(/^admin$/i.test(v) || /^alpha$/i.test(v)){
          add("BLOCKER","PUBLIC_ROLE_LIKE",a.line,"PUBLIC_ROLE_LIKE is set to \"" + v + "\"",
            "PUBLIC_ROLE_LIKE gives anonymous, unauthenticated visitors the permissions of the named role. Setting it to \"" + v + "\" hands editor/admin-like abilities to anyone who can reach the login page.",
            "Remove PUBLIC_ROLE_LIKE, or set it to a locked-down role with only the specific public dashboards it needs — never Admin or Alpha.","");
        } else if(/^gamma$/i.test(v)){
          add("WARNING","PUBLIC_ROLE_LIKE",a.line,"PUBLIC_ROLE_LIKE is set to \"Gamma\"",
            "PUBLIC_ROLE_LIKE gives anonymous visitors the permissions of the named role. \"Gamma\" is a broad built-in role, so the public would see and use more than most deployments intend.",
            "Prefer a custom public role containing only the dashboards meant to be public; remove PUBLIC_ROLE_LIKE entirely if nothing should be public.","");
        }
      });
    }

    /* CSRF */
    if(assignments["WTF_CSRF_ENABLED"]){
      assignments["WTF_CSRF_ENABLED"].forEach(function(a){
        if(isFalse(a.raw)){
          add("HIGH","WTF_CSRF_ENABLED",a.line,"WTF_CSRF_ENABLED is False — CSRF protection is off",
            "With CSRF protection disabled, a malicious page can make a logged-in user's browser submit forms and actions to Superset without their intent.",
            "Set WTF_CSRF_ENABLED = True and restart; only exempt a specific endpoint if it genuinely cannot carry a token.","");
        }
      });
    }
    if(assignments["WTF_CSRF_EXEMPT_LIST"]){
      assignments["WTF_CSRF_EXEMPT_LIST"].forEach(function(a){
        var r = a.raw;
        var broad = /\*/.test(r) || /["']\/["']/.test(r);
        var count = 0;
        var inner = r.match(/\[([\s\S]*)\]/);
        if(inner && inner[1].trim() !== "") count = inner[1].split(",").filter(function(x){return x.trim()!=="";}).length;
        if(broad || count > 4){
          add("WARNING","WTF_CSRF_EXEMPT_LIST",a.line,"WTF_CSRF_EXEMPT_LIST looks broad (" + (broad ? "wildcard/root entry" : count + " entries") + ")",
            "Every exempt endpoint skips CSRF checks. A wildcard, the root path, or a long exemption list quietly re-opens the hole that WTF_CSRF_ENABLED = True closes.",
            "Trim the exemption list to only the exact endpoints that cannot carry a CSRF token, and review each one.","");
        }
      });
    }

    /* AUTH_TYPE */
    if(assignments["AUTH_TYPE"]){
      var fullLower = text.toLowerCase();
      var tlsNoted = fullLower.indexOf("ldaps") !== -1 || /auth_ldap_use_tls\s*=\s*true/.test(fullLower) || fullLower.indexOf("start_tls") !== -1 || /auth_ldap_tls/.test(fullLower);
      assignments["AUTH_TYPE"].forEach(function(a){
        var r = a.raw.toUpperCase();
        if(r.indexOf("AUTH_REMOTE_USER") !== -1 || r.indexOf("AUTH_LDAP") !== -1){
          if(!tlsNoted){
            add("INFO","AUTH_TYPE",a.line,"Verify the identity-provider link is protected",
              "AUTH_TYPE delegates sign-in to a remote user header or an LDAP provider, and this config notes no TLS posture for that link. If the identity traffic travels unencrypted, credentials and identity headers can be intercepted or spoofed.",
              "Confirm the connection to the identity provider uses TLS (for example ldaps:// or AUTH_LDAP_USE_TLS) and that remote-user headers are only accepted from your trusted proxy.","");
          }
        }
      });
    }

    /* TALISMAN */
    if(assignments["TALISMAN_ENABLED"]){
      assignments["TALISMAN_ENABLED"].forEach(function(a){
        if(isFalse(a.raw)) add("WARNING","TALISMAN_ENABLED",a.line,"TALISMAN_ENABLED is False",
          "Talisman supplies browser security headers and transport protections. Turning it off removes clickjacking and related header protections for every page Superset serves.",
          "Set TALISMAN_ENABLED = True; if a specific header breaks an embed, tune TALISMAN_CONFIG instead of disabling Talisman.","");
      });
    }
    if(assignments["TALISMAN_FORCE_HTTPS"]){
      assignments["TALISMAN_FORCE_HTTPS"].forEach(function(a){
        if(isFalse(a.raw)) add("WARNING","TALISMAN_FORCE_HTTPS",a.line,"TALISMAN_FORCE_HTTPS is False",
          "Without forced HTTPS, Superset can be reached over plain HTTP, exposing sessions and credentials in transit and weakening the clickjacking/transport posture Talisman provides.",
          "Set TALISMAN_FORCE_HTTPS = True behind your HTTPS-terminating proxy or load balancer.","");
      });
    }

    /* PROXY FIX & COOKIES */
    if(assignments["ENABLE_PROXY_FIX"]){
      assignments["ENABLE_PROXY_FIX"].forEach(function(a){
        if(isFalse(a.raw)) add("WARNING","ENABLE_PROXY_FIX",a.line,"ENABLE_PROXY_FIX is False",
          "If Superset sits behind a proxy or load balancer, a disabled proxy fix means scheme and host headers are taken at face value, which can break secure-cookie and HTTPS handling.",
          "If you run behind a proxy, set ENABLE_PROXY_FIX = True and make sure only the proxy can set forwarded headers; if there is no proxy, this can stay off deliberately.","");
      });
    }
    if(assignments["SESSION_COOKIE_SECURE"]){
      assignments["SESSION_COOKIE_SECURE"].forEach(function(a){
        if(isFalse(a.raw)) add("WARNING","SESSION_COOKIE_SECURE",a.line,"SESSION_COOKIE_SECURE is False",
          "Session cookies without the Secure flag can be sent over plain HTTP, where the session can be captured and replayed.",
          "Set SESSION_COOKIE_SECURE = True and serve Superset over HTTPS.","");
      });
    } else {
      add("INFO","SESSION_COOKIE_SECURE",null,"SESSION_COOKIE_SECURE is not set",
        "This config never states SESSION_COOKIE_SECURE, so whether session cookies are restricted to HTTPS is left to defaults rather than decided on purpose.",
        "Set SESSION_COOKIE_SECURE = True explicitly for any HTTPS deployment.","");
    }
    if(!assignments["SESSION_COOKIE_HTTPONLY"]){
      add("INFO","SESSION_COOKIE_HTTPONLY",null,"SESSION_COOKIE_HTTPONLY is not set",
        "This config never states SESSION_COOKIE_HTTPONLY, so the session cookie's script-access posture is left unstated. HttpOnly cookies cannot be read by page scripts, which limits session theft through cross-site scripting.",
        "Set SESSION_COOKIE_HTTPONLY = True explicitly.","");
    } else {
      assignments["SESSION_COOKIE_HTTPONLY"].forEach(function(a){
        if(isFalse(a.raw)) add("WARNING","SESSION_COOKIE_HTTPONLY",a.line,"SESSION_COOKIE_HTTPONLY is False",
          "With HttpOnly off, page scripts can read the session cookie, so any cross-site scripting flaw can steal live sessions.",
          "Set SESSION_COOKIE_HTTPONLY = True.","");
      });
    }

    /* Generic secrets */
    order.forEach(function(key){
      if(key === "SECRET_KEY") return;
      if(key === "SQLALCHEMY_DATABASE_URI") return;
      if(!isSecretKeyName(key)) return;
      // Skip value-less / clearly non-secret holders like SMTP password from env
      assignments[key].forEach(function(a){
        if(isEnvRef(a.raw)) return;
        if(a.str == null || a.str === "") return;
        var len = a.str.length;
        var esc = len < 20 || looksExampleGeneric(a.str);
        add(esc ? "HIGH" : "WARNING", key, a.line,
          key + " is hardcoded (length " + len + ")",
          key + " is assigned a literal value in the config (reported by name, line, and length only — the value is never shown)" + (esc ? ". It is also short or example-looking, which escalates this finding." : ".") + " Secrets in a config file leak with every copy, backup, and commit of that file.",
          "Move " + key + " into the environment or a secrets manager and reference it there (for example via os.environ); rotate the value, since it has appeared in a file.",
          "length " + len);
      });
    });

    /* Timeouts absent */
    if(!assignments["SQLLAB_ASYNC_TIME_LIMIT"]){
      add("INFO","SQLLAB_ASYNC_TIME_LIMIT",null,"SQLLAB_ASYNC_TIME_LIMIT is not set",
        "The long-running query posture is unstated: nothing in this config says how long an asynchronous SQL Lab query may run, so workers can be tied up by runaway queries.",
        "Set SQLLAB_ASYNC_TIME_LIMIT to a deliberate value in seconds that fits your data sources.","");
    }
    if(!assignments["SUPERSET_WEBSERVER_TIMEOUT"]){
      add("INFO","SUPERSET_WEBSERVER_TIMEOUT",null,"SUPERSET_WEBSERVER_TIMEOUT is not set",
        "The long-running query posture is unstated: nothing in this config says how long the web server waits before giving up on a request, so slow dashboards fail unpredictably.",
        "Set SUPERSET_WEBSERVER_TIMEOUT to a deliberate value in seconds, aligned with your async query limit.","");
    }

    /* DEBUG / FLASK_ENV */
    if(assignments["DEBUG"]){
      assignments["DEBUG"].forEach(function(a){
        if(isTrue(a.raw)) add("HIGH","DEBUG",a.line,"DEBUG is True",
          "Debug mode in a deployed Flask app can expose interactive debugging and detailed internals, and it disables production safeguards.",
          "Set DEBUG = False in any deployed config; keep debug on only in a local development file that never ships.","");
      });
    }
    if(assignments["FLASK_ENV"]){
      assignments["FLASK_ENV"].forEach(function(a){
        var v = (a.str != null ? a.str : a.raw).toLowerCase();
        if(v.indexOf("development") !== -1) add("HIGH","FLASK_ENV",a.line,"FLASK_ENV is development",
          "A deployed config declaring the development environment enables development behaviours, including debug tooling, in production.",
          "Set FLASK_ENV = \"production\" (or remove it and rely on your process manager) for deployment.","");
      });
    }
  }

  // Severity order for display: BLOCKER, HIGH, WARNING, INFO; then line
  var rank = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
  findings.sort(function(a,b){
    if(rank[a.severity] !== rank[b.severity]) return rank[a.severity]-rank[b.severity];
    var la = a.line==null?99999:a.line, lb = b.line==null?99999:b.line;
    return la-lb;
  });

  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict;
  if(!gradable) verdict = "NOT ENOUGH TO GRADE";
  else if(counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
  else if(counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict:verdict, counts:counts, findings:findings, notParsed:notParsed, gradable:gradable, recognized:recognizable};
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "KNOWN_EXAMPLE_SECRETS": (typeof KNOWN_EXAMPLE_SECRETS !== 'undefined' ? KNOWN_EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-superset-server-config-safety-auditortm',
  name: 'J-Dawgs Superset Server Config Safety Auditor',
  description: 'Superset startup answers will-it-start only; ours grades a pasted superset_config.py offline — SECRET_KEY strength and example values, PUBLIC_ROLE_LIKE exposure, CSRF/Talisman posture, plaintext database passwords by length only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "KNOWN_EXAMPLE_SECRETS": __core["KNOWN_EXAMPLE_SECRETS"] }
};
