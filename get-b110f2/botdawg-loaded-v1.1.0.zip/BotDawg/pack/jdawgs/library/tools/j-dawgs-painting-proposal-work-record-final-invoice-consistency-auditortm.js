'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Painting Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";
    var $ = function(id){ return document.getElementById(id); };

    /* ---------------- Worked examples ---------------- */
    var BAD = {
      proposal:
"PAINTING PROPOSAL — Dawson Residence, Springfield MO\n" +
"Prepared by: BrightCoat Painting LLC\n" +
"Date: October 12, 2026\n" +
"\n" +
"SCOPE OF WORK\n" +
"- Living Room — 320 sq ft — walls and ceiling\n" +
"- Kitchen — 240 sq ft — walls\n" +
"- Primary Bedroom — 280 sq ft — walls\n" +
"- Hallway — 120 sq ft — walls\n" +
"\n" +
"PAINT\n" +
"Paint: Sherwin-Williams Emerald Interior, color \"Agreeable Gray\"\n" +
"Coats: 2 coats on all walls\n" +
"Estimated paint: 6 gallons at $58.00 per gallon = $348.00\n" +
"\n" +
"LABOR & PREP\n" +
"Prep: 4 hours included\n" +
"Labor: 24 hours at $45.00 per hour = $1,080.00\n" +
"Materials & supplies: $400.00\n" +
"\n" +
"DEPOSIT\n" +
"Deposit due at signing: $400.00 (applied to final invoice)\n" +
"\n" +
"TOTAL PROPOSAL: $1,828.00\n" +
"\n" +
"WARRANTY\n" +
"Workmanship warranty: 2 years on all painted surfaces.",
      work:
"WORK RECORD — Dawson Residence\n" +
"Crew: BrightCoat Painting LLC\n" +
"Dates: October 19-21, 2026\n" +
"\n" +
"AREAS PAINTED\n" +
"- Living Room — 320 sq ft — painted\n" +
"- Kitchen — 240 sq ft — painted\n" +
"- Primary Bedroom — 280 sq ft — painted\n" +
"(Hallway not started — ran out of time)\n" +
"\n" +
"COATS APPLIED\n" +
"Living Room: 1 coat applied\n" +
"Kitchen: 2 coats applied\n" +
"Primary Bedroom: 2 coats applied\n" +
"\n" +
"PAINT USED\n" +
"Sherwin-Williams Emerald Interior, \"Agreeable Gray\" — 5 gallons used\n" +
"\n" +
"HOURS\n" +
"Prep: 4 hours\n" +
"Labor: 22 hours worked\n" +
"\n" +
"Deposit received: $400.00",
      invoice:
"FINAL INVOICE — BrightCoat Painting LLC\n" +
"Invoice #1042 — October 22, 2026\n" +
"\n" +
"Living Room painting (2 coats) — $520.00\n" +
"Kitchen painting (2 coats) — $390.00\n" +
"Primary Bedroom painting (2 coats) — $455.00\n" +
"Hallway painting (2 coats) — $210.00\n" +
"Paint: Benjamin Moore Regal Select, \"Agreeable Gray\" — 8 gallons at $64.00 per gallon — $512.00\n" +
"Labor: 30 hours at $45.00 per hour — $1,350.00\n" +
"Disposal fee — $75.00\n" +
"Travel surcharge — $60.00\n" +
"\n" +
"INVOICE TOTAL: $3,647.00\n" +
"\n" +
"Warranty: 1 year workmanship warranty."
    };

    var GOOD = {
      proposal:
"PAINTING PROPOSAL — Miller Residence, Springfield MO\n" +
"Prepared by: BrightCoat Painting LLC\n" +
"Date: November 2, 2026\n" +
"\n" +
"SCOPE OF WORK\n" +
"- Living Room — 300 sq ft — walls\n" +
"- Kitchen — 220 sq ft — walls\n" +
"\n" +
"PAINT\n" +
"Paint: Sherwin-Williams Duration Home, color \"Repose Gray\"\n" +
"Coats: 2 coats on all walls\n" +
"Estimated paint: 5 gallons at $52.00 per gallon = $260.00\n" +
"\n" +
"LABOR & PREP\n" +
"Prep: 3 hours included\n" +
"Labor: 20 hours at $45.00 per hour = $900.00\n" +
"Materials & supplies: $150.00\n" +
"\n" +
"DEPOSIT\n" +
"Deposit due at signing: $300.00 (applied to final invoice)\n" +
"\n" +
"TOTAL PROPOSAL: $1,310.00\n" +
"\n" +
"WARRANTY\n" +
"Workmanship warranty: 2 years on all painted surfaces.",
      work:
"WORK RECORD — Miller Residence\n" +
"Crew: BrightCoat Painting LLC\n" +
"Dates: November 9-10, 2026\n" +
"\n" +
"AREAS PAINTED\n" +
"- Living Room — 300 sq ft — painted\n" +
"- Kitchen — 220 sq ft — painted\n" +
"\n" +
"COATS APPLIED\n" +
"Living Room: 2 coats applied\n" +
"Kitchen: 2 coats applied\n" +
"\n" +
"PAINT USED\n" +
"Sherwin-Williams Duration Home, \"Repose Gray\" — 5 gallons used\n" +
"\n" +
"HOURS\n" +
"Prep: 3 hours\n" +
"Labor: 20 hours worked\n" +
"\n" +
"Deposit received: $300.00",
      invoice:
"FINAL INVOICE — BrightCoat Painting LLC\n" +
"Invoice #1051 — November 11, 2026\n" +
"\n" +
"Rooms painted: Living Room (2 coats), Kitchen (2 coats)\n" +
"Labor: 20 hours at $45.00 per hour — $900.00\n" +
"Paint: Sherwin-Williams Duration Home, \"Repose Gray\" — 5 gallons at $52.00 per gallon — $260.00\n" +
"Materials & supplies — $150.00\n" +
"Deposit credit — -$300.00\n" +
"\n" +
"INVOICE TOTAL: $1,010.00\n" +
"\n" +
"Warranty: 2 years workmanship warranty."
    };

    /* ---------------- Helpers ---------------- */
    function money(n){
      var s = Math.abs(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      return (n < 0 ? "-$" : "$") + s;
    }
    function parseMoney(str){ return parseFloat(String(str).replace(/[$,]/g, "")); }
    function moneyVals(line){
      var out = [], m, re = /\$\s*([\d,]+(?:\.\d{1,2})?)/g;
      while ((m = re.exec(line)) !== null) out.push(parseMoney(m[1]));
      return out;
    }
    function approx(a, b){ return Math.abs(a - b) < 0.005; }
    function esc(s){
      return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    /* ---------------- Room / area extraction ---------------- */
    var ROOM_DEFS = [
      ["Primary Bedroom", /\bprimary bedroom\b/i],
      ["Master Bedroom", /\bmaster bedroom\b/i],
      ["Living Room", /\bliving room\b/i],
      ["Dining Room", /\bdining room\b/i],
      ["Laundry Room", /\blaundry room\b/i],
      ["Family Room", /\bfamily room\b/i],
      ["Guest Bedroom", /\bguest bedroom\b/i],
      ["Bedroom", /\bbedrooms?\b/i],
      ["Bathroom", /\bbathrooms?\b/i],
      ["Kitchen", /\bkitchen\b/i],
      ["Hallway", /\bhallway\b/i],
      ["Hall", /\bhall\b/i],
      ["Office", /\boffice\b/i],
      ["Nursery", /\bnursery\b/i],
      ["Basement", /\bbasement\b/i],
      ["Garage", /\bgarage\b/i],
      ["Sunroom", /\bsunroom\b/i],
      ["Pantry", /\bpantry\b/i],
      ["Foyer", /\bfoyer\b/i],
      ["Den", /\bden\b/i],
      ["Porch", /\bporch\b/i],
      ["Exterior", /\bexterior\b/i]
    ];
    function findRooms(str){
      var work = " " + str + " ", found = [], i, m;
      for (i = 0; i < ROOM_DEFS.length; i++){
        var re = new RegExp(ROOM_DEFS[i][1].source, "gi");
        m = work.match(re);
        if (m){ found.push(ROOM_DEFS[i][0]); work = work.replace(re, " "); }
      }
      return found;
    }

    var BRANDS = ["Sherwin-Williams", "Benjamin Moore", "Behr", "Valspar", "PPG",
      "Dunn-Edwards", "Kelly-Moore", "Farrow & Ball", "Glidden", "Rust-Oleum", "KILZ", "Zinsser"];

    /* ---------------- Fact extraction ---------------- */
    function extract(text){
      var f = {
        present: !!(text && text.trim().length > 0),
        rooms: [], notDone: [], sqft: {}, coatsByRoom: {}, coatsGlobal: null,
        paint: null, paintLine: null, color: null,
        gallons: null, pricePerGallon: null,
        laborHours: null, laborRate: null, laborAmount: null, prepHours: null,
        deposit: null, depositCredit: null, total: null, totalLine: null,
        warrantyMonths: null, warrantyLine: null,
        lineItems: [], hasFacts: false
      };
      if (!f.present) return f;
      var lines = text.split(/\r?\n/);
      var roomSet = {}, notDoneSet = {}, i, line, rooms, j;

      for (i = 0; i < lines.length; i++){
        line = lines[i];
        rooms = findRooms(line);
        var negated = /not\s+(started|painted|completed|done)|did not|wasn'?t|were not|incomplete|pending/i.test(line);
        for (j = 0; j < rooms.length; j++){
          if (negated) notDoneSet[rooms[j]] = true; else roomSet[rooms[j]] = true;
        }
        if (rooms.length && !negated){
          var sf = line.match(/([\d,]+)\s*(?:sq\.?\s*ft|square feet)/i);
          if (sf) for (j = 0; j < rooms.length; j++) f.sqft[rooms[j]] = parseFloat(sf[1].replace(/,/g, ""));
          var cm = line.match(/(\d+)\s*coats?\b/i);
          if (cm) for (j = 0; j < rooms.length; j++) f.coatsByRoom[rooms[j]] = parseInt(cm[1], 10);
        }
        var gm = line.match(/coats?\s*[:\-–—]?\s*(\d+)\s*coats?\b/i);
        if (gm && !rooms.length && f.coatsGlobal === null) f.coatsGlobal = parseInt(gm[1], 10);

        if (/labor/i.test(line) && f.laborHours === null){
          var lh = line.match(/(\d+(?:\.\d+)?)\s*hours?\b/i);
          if (lh){
            f.laborHours = parseFloat(lh[1]);
            var lr = line.match(/\$\s*([\d,]+(?:\.\d{1,2})?)\s*(?:per\s*hour|\/\s*(?:hr|hour))/i);
            if (lr) f.laborRate = parseMoney(lr[1]);
            var lv = moneyVals(line);
            if (lv.length) f.laborAmount = lv[lv.length - 1];
          }
        }
        if (/prep/i.test(line) && f.prepHours === null){
          var ph = line.match(/(\d+(?:\.\d+)?)\s*hours?\b/i);
          if (ph) f.prepHours = parseFloat(ph[1]);
        }
        if (/deposit/i.test(line)){
          var dv = moneyVals(line);
          if (dv.length){
            if (/credit/i.test(line) || /-\s*\$/.test(line)) { if (f.depositCredit === null) f.depositCredit = dv[0]; }
            else if (f.deposit === null) f.deposit = dv[0];
          }
        }
        if (/total/i.test(line)){
          var tv = moneyVals(line);
          if (tv.length){ f.total = tv[tv.length - 1]; f.totalLine = line.trim(); }
        }
        if (/warrant|guarantee/i.test(line) && f.warrantyMonths === null &&
            /(\d+\s*(?:years?|yrs?|months?)|no warranty|not warranted|lifetime)/i.test(line)){
          f.warrantyLine = line.trim();
          var wd = line.match(/(\d+)\s*(years?|yrs?|months?)/i);
          if (wd) f.warrantyMonths = parseInt(wd[1], 10) * (/month/i.test(wd[2]) ? 1 : 12);
          else if (/lifetime/i.test(line)) f.warrantyMonths = 999;
          else f.warrantyMonths = 0;
        }
        /* Invoice-style line items: a money amount on a non-total line. */
        var vals = moneyVals(line);
        if (vals.length && !/total/i.test(line)){
          var neg = /-\s*\$/.test(line) || /credit/i.test(line);
          var amt = vals[vals.length - 1];
          if (neg) amt = -Math.abs(amt);
          var label = line.split("$")[0].replace(/[\s—–:\-]+$/, "").replace(/^[\s\-\*•]+/, "").trim();
          f.lineItems.push({ label: label || line.trim(), amount: amt, raw: line.trim() });
        }
      }
      Object.keys(roomSet).forEach(function(r){ if (!notDoneSet[r]) f.rooms.push(r); });
      f.notDone = Object.keys(notDoneSet).filter(function(r){ return !roomSet[r]; });
      f.rooms.sort(); f.notDone.sort();

      /* Paint identity: brand + following capitalized product words, from the line that names a brand. */
      for (i = 0; i < lines.length; i++){
        line = lines[i];
        for (j = 0; j < BRANDS.length; j++){
          var bi = line.toLowerCase().indexOf(BRANDS[j].toLowerCase());
          if (bi >= 0){
            var after = line.slice(bi + BRANDS[j].length);
            var pm = after.match(/^[\s,:\-–—]*(?:paint\s+)?([A-Z][A-Za-z]*(?:\s+[A-Z][A-Za-z]*){0,2})/);
            var product = pm ? pm[1].trim() : "";
            f.paint = (BRANDS[j] + (product ? " " + product : "")).trim();
            f.paintLine = line.trim();
            var q = line.match(/"([^"]{2,40})"/);
            if (q) f.color = q[1];
            break;
          }
        }
        if (f.paint) break;
      }
      if (!f.color){
        var col = text.match(/colou?r\s*[:\-]?\s*"?([A-Z][A-Za-z ]{2,30}?)"?(?=[,.\n]|$)/im);
        if (col) f.color = col[1].trim();
      }
      var gal = text.match(/(^|[^\d.])(\d+(?:\.\d+)?)\s*gallons?\b/i);
      if (gal) f.gallons = parseFloat(gal[2]);
      var ppg = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)\s*per\s*gallon/i);
      if (ppg) f.pricePerGallon = parseMoney(ppg[1]);
      if (f.laborRate === null){
        var anyRate = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)\s*(?:per\s*hour|\/\s*(?:hr|hour))/i);
        if (anyRate) f.laborRate = parseMoney(anyRate[1]);
      }
      f.hasFacts = f.rooms.length > 0 || f.notDone.length > 0 || f.total !== null ||
        f.gallons !== null || f.laborHours !== null || f.coatsGlobal !== null ||
        Object.keys(f.coatsByRoom).length > 0 || f.deposit !== null || f.paint !== null ||
        moneyVals(text).length > 0;
      return f;
    }
    function coatsFor(f, room){
      if (f.coatsByRoom[room] != null) return f.coatsByRoom[room];
      return f.coatsGlobal;
    }

    /* ---------------- The audit ---------------- */
    var DOC_NAMES = { proposal: "Proposal", work: "Work Record", invoice: "Invoice" };
    var lastResult = null;

    function audit(pText, wText, iText){
      var P = extract(pText), W = extract(wText), I = extract(iText);
      var docs = { proposal: P, work: W, invoice: I };
      var findings = [], passes = [];
      function add(sev, check, title, detail, quote){ findings.push({ severity: sev, check: check, title: title, detail: detail, quote: quote || "" }); }
      function pass(check, text){ passes.push({ check: check, text: text }); }

      var pasted = ["proposal", "work", "invoice"].filter(function(k){ return docs[k].present; });
      var missing = ["proposal", "work", "invoice"].filter(function(k){ return !docs[k].present; });
      var noFacts = pasted.filter(function(k){ return !docs[k].hasFacts; });

      var result = {
        tool: "J-Dawgs Painting Proposal, Work Record & Final Invoice Consistency Auditor",
        verdict: "", reason: "", capped: false, missing: missing.map(function(k){ return DOC_NAMES[k]; }),
        findings: findings, passes: passes, facts: {}
      };
      ["proposal", "work", "invoice"].forEach(function(k){
        var f = docs[k];
        result.facts[k] = {
          present: f.present, rooms: f.rooms, not_recorded_as_done: f.notDone, sqft: f.sqft,
          coats_by_room: f.coatsByRoom, coats_overall: f.coatsGlobal, paint: f.paint, color: f.color,
          gallons: f.gallons, price_per_gallon: f.pricePerGallon, labor_hours: f.laborHours,
          labor_rate: f.laborRate, labor_amount: f.laborAmount, prep_hours: f.prepHours,
          deposit: f.deposit, deposit_credit: f.depositCredit, total: f.total,
          warranty_months: f.warrantyMonths, line_items: f.lineItems
        };
      });

      if (pasted.length < 2){
        result.verdict = "NOT ENOUGH TO COMPARE";
        result.reason = pasted.length === 0
          ? "Nothing pasted yet. Paste at least two of the three documents to run a comparison."
          : "Only one document pasted (" + DOC_NAMES[pasted[0]] + "). A comparison needs at least two of the three documents.";
        return finish(result);
      }
      if (noFacts.length){
        result.verdict = "NOT ENOUGH TO COMPARE";
        result.reason = "The " + noFacts.map(function(k){ return DOC_NAMES[k]; }).join(" and ") +
          " paste(s) contain no extractable facts (no rooms, coats, gallons, hours, amounts, or totals the tool can read). Paste the real document text and run again.";
        return finish(result);
      }

      /* ---- Scope identity ---- */
      if (P.present && W.present){
        var scopeIssue = false;
        P.rooms.forEach(function(r){
          if (W.rooms.indexOf(r) < 0){
            scopeIssue = true;
            var wasInvoiced = I.present && I.rooms.indexOf(r) >= 0;
            add(wasInvoiced ? "MAJOR" : "FIX", "Scope identity",
              r + " proposed but missing from the work record" + (wasInvoiced ? " — yet billed on the invoice" : ""),
              "The proposal lists " + r + " in scope" +
              (W.notDone.indexOf(r) >= 0 ? ", and the work record marks it as not started / not done" : ", but the work record never lists it as painted") +
              (wasInvoiced ? ". The invoice still bills for it. Billed scope with no record of the work being done must be explained or removed before payment." : ". Either the work was not done or the record is incomplete — confirm before paying for it."));
          }
        });
        W.rooms.forEach(function(r){
          if (P.rooms.indexOf(r) < 0){
            scopeIssue = true;
            add("FIX", "Scope identity", r + " in the work record but never proposed",
              "The work record lists " + r + " as painted, but the proposal never included it. Unproposed work needs written approval before it can be billed.");
          }
        });
        if (!scopeIssue && P.rooms.length) pass("Scope identity", "Every proposed room appears in the work record, and the work record adds nothing unproposed (" + P.rooms.join(", ") + ").");
        /* Square footage */
        var sfBad = false;
        P.rooms.forEach(function(r){
          if (P.sqft[r] != null && W.sqft[r] != null && P.sqft[r] !== W.sqft[r]){
            sfBad = true;
            add("FIX", "Scope identity", r + " square footage differs",
              "Proposal states " + P.sqft[r] + " sq ft for " + r + "; the work record states " + W.sqft[r] + " sq ft. Difference: " + Math.abs(P.sqft[r] - W.sqft[r]) + " sq ft.");
          }
        });
        if (!sfBad && P.rooms.some(function(r){ return P.sqft[r] != null && W.sqft[r] != null; }))
          pass("Scope identity", "Square footage agrees between proposal and work record where both state it.");
      }
      if (P.present && I.present){
        var invScopeIssue = false;
        I.rooms.forEach(function(r){
          if (P.rooms.indexOf(r) < 0){
            invScopeIssue = true;
            add("MAJOR", "Scope identity", r + " invoiced but never proposed (invoice-only scope)",
              "The invoice bills for " + r + ", which appears nowhere in the approved proposal. Unapproved scope should not be paid without a written change order.");
          }
        });
        P.rooms.forEach(function(r){
          if (I.rooms.indexOf(r) < 0 && !(W.present && W.rooms.indexOf(r) < 0)){
            invScopeIssue = true;
            add("FIX", "Scope identity", r + " proposed but missing from the invoice",
              "The proposal includes " + r + " but no invoice line names it. If it was painted, the bill is incomplete; if it was not, the proposal scope and the bill disagree.");
          }
        });
        if (!invScopeIssue && P.rooms.length && I.rooms.length)
          pass("Scope identity", "Invoice scope matches proposal scope — nothing billed that was never proposed.");
      }

      /* ---- Coats ---- */
      var allRooms = {};
      [P, W, I].forEach(function(f){ f.rooms.forEach(function(r){ allRooms[r] = true; }); });
      var coatChecked = false, coatBad = false;
      Object.keys(allRooms).forEach(function(r){
        var billed = I.present ? coatsFor(I, r) : null;
        var applied = W.present ? coatsFor(W, r) : null;
        var promised = P.present ? coatsFor(P, r) : null;
        if (billed != null && applied != null){
          coatChecked = true;
          if (billed > applied){
            coatBad = true;
            add("BLOCKER", "Coats", r + ": " + billed + " coats billed, " + applied + " coat(s) recorded as applied",
              "The invoice bills " + r + " at " + billed + " coats; the work record shows " + applied + " coat(s) applied. Billing for a coat that the record says was never applied is an overcharge — do not pay that coat until the record or the bill is corrected.");
          }
        }
        if (promised != null && applied != null && applied < promised){
          coatChecked = true; coatBad = true;
          add("FIX", "Coats", r + ": " + promised + " coats promised, " + applied + " applied",
            "The proposal promised " + promised + " coats on " + r + "; the work record shows " + applied + ". The job as recorded does not match the job as sold.");
        }
        if (billed != null && promised != null && billed > promised && !(applied != null && billed > applied)){
          coatChecked = true; coatBad = true;
          add("FIX", "Coats", r + ": " + billed + " coats billed vs " + promised + " promised",
            "The invoice bills more coats on " + r + " than the proposal promised. Extra coats need written approval.");
        }
      });
      if (coatChecked && !coatBad) pass("Coats", "Coats billed never exceed coats recorded as applied, and applied coats meet the proposal, room by room.");

      /* ---- Paint identity, gallons, price ---- */
      if (P.present && I.present && P.paint && I.paint){
        if (P.paint.toLowerCase() !== I.paint.toLowerCase()){
          add("FIX", "Paint identity & price", "Paint product changed between proposal and invoice",
            "Proposal paint: " + P.paint + ". Invoice paint: " + I.paint + ". A product swap changes material cost and finish — it needs written approval, and the price should follow the product actually billed.",
            "Proposal: " + (P.paintLine || P.paint) + "\nInvoice: " + (I.paintLine || I.paint));
        } else {
          pass("Paint identity & price", "Same paint product on proposal and invoice: " + P.paint + ".");
        }
        if (P.color && I.color && P.color.toLowerCase() !== I.color.toLowerCase()){
          add("FIX", "Paint identity & price", "Paint color changed: \"" + P.color + "\" vs \"" + I.color + "\"",
            "The proposal names the color \"" + P.color + "\"; the invoice names \"" + I.color + "\".");
        }
      }
      if (I.present && W.present && I.gallons !== null && W.gallons !== null){
        if (I.gallons > W.gallons){
          var extra = I.gallons - W.gallons;
          var extraCost = I.pricePerGallon !== null ? " — at the invoiced " + money(I.pricePerGallon) + " per gallon that is " + money(extra * I.pricePerGallon) + " of paint billed beyond what the record says was used" : "";
          add("MAJOR", "Paint identity & price", "Gallons invoiced (" + I.gallons + ") above gallons recorded as used (" + W.gallons + ")",
            "Invoice bills " + I.gallons + " gallons; the work record says " + W.gallons + " gallons used. Difference: " + extra + " gallon(s)" + extraCost + ". Leftover paint kept by the customer is billable only if the proposal says so.");
        } else {
          pass("Paint identity & price", "Gallons billed (" + I.gallons + ") do not exceed gallons recorded as used (" + W.gallons + ").");
        }
      }
      if (P.present && I.present && P.pricePerGallon !== null && I.pricePerGallon !== null){
        if (I.pricePerGallon > P.pricePerGallon){
          add("FIX", "Paint identity & price", "Per-gallon price raised: " + money(P.pricePerGallon) + " → " + money(I.pricePerGallon),
            "The proposal priced paint at " + money(P.pricePerGallon) + " per gallon; the invoice charges " + money(I.pricePerGallon) + " per gallon — " + money(I.pricePerGallon - P.pricePerGallon) + " more per gallon" +
            (I.gallons !== null ? ", worth " + money((I.pricePerGallon - P.pricePerGallon) * I.gallons) + " across the " + I.gallons + " gallons billed" : "") + ".");
        } else if (approx(I.pricePerGallon, P.pricePerGallon)) {
          pass("Paint identity & price", "Per-gallon price held at " + money(P.pricePerGallon) + " from proposal to invoice.");
        }
      }

      /* ---- Labor ---- */
      var rate = (P.laborRate !== null ? P.laborRate : I.laborRate);
      if (W.present && I.present && W.laborHours !== null && I.laborAmount !== null && rate !== null){
        var expected = W.laborHours * rate;
        if (I.laborAmount > expected + 0.005){
          add("MAJOR", "Labor", "Labor charged above recorded hours × agreed rate",
            "Work record: " + W.laborHours + " hours. Agreed rate: " + money(rate) + " per hour. " +
            W.laborHours + " × " + money(rate) + " = " + money(expected) + " expected. Invoice labor charged: " + money(I.laborAmount) +
            (I.laborHours !== null ? " (billed as " + I.laborHours + " hours — " + (I.laborHours - W.laborHours) + " hours above the record)" : "") +
            ". Overage: " + money(I.laborAmount - expected) + ".");
        } else {
          pass("Labor", "Labor checks out: " + W.laborHours + " recorded hours × " + money(rate) + " = " + money(expected) + "; invoice labor charged " + money(I.laborAmount) + ", no overage.");
        }
      } else if (W.present && I.present && W.laborHours !== null && I.laborHours !== null && I.laborHours > W.laborHours){
        add("MAJOR", "Labor", "Hours billed (" + I.laborHours + ") above hours recorded (" + W.laborHours + ")",
          "The invoice bills " + I.laborHours + " labor hours; the work record shows " + W.laborHours + " hours worked. Difference: " + (I.laborHours - W.laborHours) + " hours. (No hourly rate was extractable, so the dollar overage could not be computed.)");
      }
      if (P.present && W.present && P.prepHours !== null && W.prepHours !== null){
        if (W.prepHours > P.prepHours){
          add("FIX", "Labor", "Prep hours grew: " + P.prepHours + " proposed vs " + W.prepHours + " recorded",
            "The proposal allowed " + P.prepHours + " prep hours; the work record shows " + W.prepHours + ". Extra prep time should be approved before it is billed.");
        } else {
          pass("Labor", "Prep hours within the proposal: " + P.prepHours + " proposed, " + W.prepHours + " recorded.");
        }
      }

      /* ---- Deposit credit ---- */
      var depositStated = null;
      if (P.deposit !== null) depositStated = P.deposit;
      if (W.deposit !== null) depositStated = depositStated === null ? W.deposit : Math.max(depositStated, W.deposit);
      if (I.present && depositStated !== null && depositStated > 0){
        var credited = I.depositCredit !== null ? I.depositCredit : 0;
        if (credited < depositStated - 0.005){
          add("BLOCKER", "Deposit credit", "Deposit of " + money(depositStated) + " not credited on the invoice",
            "A deposit of " + money(depositStated) + " is stated in the " + (P.deposit !== null ? "proposal" : "work record") + (W.deposit !== null ? " and confirmed in the work record" : "") +
            ", but the invoice credits only " + money(credited) + " of it. Uncredited amount: " + money(depositStated - credited) +
            ". Paying this invoice as written collects the deposit twice.");
        } else {
          pass("Deposit credit", "Deposit of " + money(depositStated) + " is credited on the invoice.");
        }
      }

      /* ---- Invoice-only charges ---- */
      if (I.present && I.lineItems.length){
        var othersText = ((pText || "") + "\n" + (wText || "")).toLowerCase();
        var feeRe = /fee|surcharge|charge|disposal|travel|delivery|handling|fuel|service/i;
        var onlyFound = false;
        I.lineItems.forEach(function(item){
          if (item.amount <= 0) return;
          if (/labor|paint/i.test(item.label)) return;
          if (!feeRe.test(item.label)) return;
          var words = item.label.toLowerCase().replace(/[^a-z ]/g, " ").split(/\s+/).filter(function(w){ return w.length > 3 && w !== "fee" && w !== "fees"; });
          var mentioned = words.some(function(w){ return othersText.indexOf(w) >= 0; });
          if (!mentioned){
            onlyFound = true;
            add("FIX", "Invoice-only charges", "Invoice-only charge: " + item.label + " — " + money(item.amount),
              "\"" + item.label + "\" (" + money(item.amount) + ") appears on the invoice and in neither the proposal nor the work record. It was never quoted — it needs written approval or removal.");
          }
        });
        if (!onlyFound) pass("Invoice-only charges", "No fee, surcharge, or disposal/travel charge on the invoice is missing from the other documents.");
      }

      /* ---- Totals ---- */
      if (I.present && I.lineItems.length && I.total !== null){
        var sum = I.lineItems.reduce(function(a, it){ return a + it.amount; }, 0);
        if (!approx(sum, I.total)){
          var parts = I.lineItems.map(function(it){ return money(it.amount); }).join(" + ").replace(/\+ -/g, "− ");
          add("MAJOR", "Totals", "Invoice line items do not re-add to the stated total",
            "Re-added line items: " + parts + " = " + money(sum) + ". Stated invoice total: " + money(I.total) +
            ". The stated total is " + money(Math.abs(I.total - sum)) + (I.total > sum ? " higher" : " lower") + " than the lines support.");
        } else {
          pass("Totals", "Invoice line items re-add exactly to the stated total of " + money(I.total) + ".");
        }
      }
      if (P.present && I.present && P.total !== null && I.total !== null){
        if (I.total > P.total + 0.005){
          add("FIX", "Totals", "Invoice total exceeds proposal total by " + money(I.total - P.total),
            "Proposal total: " + money(P.total) + ". Invoice total: " + money(I.total) + ". Delta: " + money(I.total) + " − " + money(P.total) + " = " + money(I.total - P.total) +
            " above the approved quote. Every dollar above the approved total needs a written change order behind it.");
        } else {
          pass("Totals", "Invoice total (" + money(I.total) + ") does not exceed the proposal total (" + money(P.total) + ").");
        }
      }

      /* ---- Warranty ---- */
      if (P.present && I.present && P.warrantyMonths !== null && I.warrantyMonths !== null){
        if (P.warrantyMonths !== I.warrantyMonths){
          add("FIX", "Warranty", "Warranty term changed: " + P.warrantyMonths + " months → " + I.warrantyMonths + " months",
            "The proposal promises a " + P.warrantyMonths + "-month warranty; the invoice states " + I.warrantyMonths + " months. The shorter term on the final bill overrides what was sold unless corrected in writing.",
            "Proposal: " + (P.warrantyLine || "") + "\nInvoice: " + (I.warrantyLine || ""));
        } else {
          pass("Warranty", "Warranty term unchanged at " + P.warrantyMonths + " months from proposal to invoice.");
        }
      }

      /* ---- Verdict ---- */
      var blockers = findings.filter(function(x){ return x.severity === "BLOCKER"; }).length;
      var majors = findings.filter(function(x){ return x.severity === "MAJOR"; }).length;
      result.capped = pasted.length === 2;
      if (blockers > 0 || majors > 0){
        result.verdict = "DO NOT PAY YET";
        result.reason = blockers + " blocker(s) and " + majors + " major discrepancy(ies) — money is billed that the other documents do not support. Fix the items below before paying." +
          (result.capped ? " (Also capped: the " + DOC_NAMES[missing[0]] + " was not pasted, so this comparison is two-way only.)" : "");
      } else if (findings.length > 0){
        result.verdict = "PAY WITH FIXES";
        result.reason = findings.length + " discrepancy(ies) to fix or explain in writing before paying — none of them bill for work the record contradicts, but the documents do not agree yet." +
          (result.capped ? " The " + DOC_NAMES[missing[0]] + " was not pasted, so this verdict is capped at PAY WITH FIXES." : "");
      } else if (result.capped){
        result.verdict = "PAY WITH FIXES";
        result.reason = "The two pasted documents agree on everything checkable — but the " + DOC_NAMES[missing[0]] + " was not pasted, and a two-way comparison is capped at PAY WITH FIXES. Paste the " + DOC_NAMES[missing[0]] + " to clear this bill completely.";
        findings.push({ severity: "NOTE", check: "Missing document", title: "Missing document: " + DOC_NAMES[missing[0]],
          detail: "Only two of the three documents were pasted. The verdict is capped at PAY WITH FIXES until the " + DOC_NAMES[missing[0]] + " is pasted and cross-checked too.", quote: "" });
      } else {
        result.verdict = "SAFE TO PAY";
        result.reason = "All three documents agree on every checkable fact: scope, coats, paint, gallons, price, labor, deposit credit, charges, totals, and warranty.";
      }
      return finish(result);
    }
    function finish(r){ lastResult = r; return r; }

    /* ---------------- Rendering ---------------- */
    function factRows(f){
      function row(k, v){ return v === null || v === undefined || v === "" ? "" : "<dt>" + k + "</dt><dd>" + esc(v) + "</dd>"; }
      var rooms = f.rooms.length ? f.rooms.join(", ") : null;
      if (f.not_recorded_as_done.length) rooms = (rooms ? rooms + "; " : "") + "not done: " + f.not_recorded_as_done.join(", ");
      var coats = Object.keys(f.coats_by_room).map(function(r){ return r + ": " + f.coats_by_room[r]; }).join("; ");
      if (f.coats_overall !== null) coats = (coats ? coats + "; " : "") + "overall: " + f.coats_overall;
      var sf = Object.keys(f.sqft).map(function(r){ return r + " " + f.sqft[r]; }).join("; ");
      var html = "<dl>" +
        row("Rooms", rooms) +
        row("Sq ft", sf || null) +
        row("Coats", coats || null) +
        row("Paint", f.paint ? f.paint + (f.color ? " — \"" + f.color + "\"" : "") : null) +
        row("Gallons", f.gallons !== null ? String(f.gallons) : null) +
        row("$/gallon", f.price_per_gallon !== null ? money(f.price_per_gallon) : null) +
        row("Labor hrs", f.labor_hours !== null ? String(f.labor_hours) : null) +
        row("Rate", f.labor_rate !== null ? money(f.labor_rate) + "/hr" : null) +
        row("Prep hrs", f.prep_hours !== null ? String(f.prep_hours) : null) +
        row("Deposit", f.deposit !== null ? money(f.deposit) : null) +
        row("Deposit credit", f.deposit_credit !== null ? money(f.deposit_credit) : null) +
        row("Total", f.total !== null ? money(f.total) : null) +
        row("Warranty", f.warranty_months !== null ? f.warranty_months + " months" : null) +
        "</dl>";
      return html === "<dl></dl>" ? "<p>No extractable facts.</p>" : html;
    }

    function buildTextReport(r){
      var L = [];
      L.push("J-DAWGS PAINTING PROPOSAL, WORK RECORD & FINAL INVOICE CONSISTENCY AUDITOR");
      L.push("VERDICT: " + r.verdict);
      L.push(r.reason);
      if (r.missing.length) L.push("Documents not pasted: " + r.missing.join(", "));
      L.push("");
      L.push("DISCREPANCIES (" + r.findings.length + "):");
      if (!r.findings.length) L.push("  None.");
      r.findings.forEach(function(f, i){
        L.push("  " + (i + 1) + ". [" + f.severity + "] (" + f.check + ") " + f.title);
        L.push("     " + f.detail);
        if (f.quote) L.push("     Quoted: " + f.quote.replace(/\n/g, " | "));
      });
      L.push("");
      L.push("CHECKS PASSED (" + r.passes.length + "):");
      if (!r.passes.length) L.push("  None recorded.");
      r.passes.forEach(function(p){ L.push("  - (" + p.check + ") " + p.text); });
      L.push("");
      L.push("Text cross-check only: this report compares what the pasted documents say. It does not verify work was performed, does not judge paint quality, and is not trade or legal advice.");
      return L.join("\n");
    }

    function render(r){
      var box = $("verdictBox"), cls = "verdict ";
      cls += r.verdict === "SAFE TO PAY" ? "safe" : r.verdict === "PAY WITH FIXES" ? "fixes" : r.verdict === "DO NOT PAY YET" ? "donot" : "notenough";
      box.className = cls;
      $("verdictLabel").textContent = r.verdict;
      $("verdictReason").textContent = r.reason;

      var fb = $("findingsBox");
      if (!r.findings.length){
        fb.innerHTML = "<p>No discrepancies found in the documents pasted.</p>";
      } else {
        fb.innerHTML = r.findings.map(function(f){
          return "<div class=\"finding\"><div class=\"f-head\"><span class=\"chip " + f.severity.toLowerCase() + "\">" + f.severity + "</span>" +
            "<span class=\"f-title\">" + esc(f.title) + "</span></div>" +
            "<p class=\"f-detail\">" + esc(f.detail) + "</p>" +
            (f.quote ? "<blockquote>" + esc(f.quote) + "</blockquote>" : "") + "</div>";
        }).join("");
      }
      $("passBox").innerHTML = r.passes.length
        ? r.passes.map(function(p){ return "<li><span class=\"chip pass\">Pass</span><span><strong>" + esc(p.check) + ":</strong> " + esc(p.text) + "</span></li>"; }).join("")
        : "<li>No checks completed.</li>";

      $("factsBox").innerHTML = ["proposal", "work", "invoice"].map(function(k){
        var f = r.facts[k];
        return "<div class=\"factbox\"><h4>" + DOC_NAMES[k] + (f.present ? "" : " — not pasted") + "</h4>" +
          (f.present ? factRows(f) : "<p>Not pasted.</p>") + "</div>";
      }).join("");

      $("reportOut").value = buildTextReport(r);
    }

    function runAudit(scroll){
      var r = audit($("inProposal").value, $("inWork").value, $("inInvoice").value);
      render(r);
      if (scroll) $("verdictBox").scrollIntoView({ behavior: "smooth", block: "center" });
    }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-painting-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Painting Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Every painting system grades its own document alone; ours cross-checks a painting proposal against the work record and the final invoice — coats billed vs applied, gallons and per-gallon price, recorded hours × rate vs labor charged, deposit credit, and invoice-only fees, with arithmetic shown acros',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
