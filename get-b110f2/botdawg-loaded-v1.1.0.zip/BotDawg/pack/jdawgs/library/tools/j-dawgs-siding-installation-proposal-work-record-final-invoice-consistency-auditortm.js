'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Siding Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
function num(s){ if(s==null) return null; var v=parseFloat(String(s).replace(/[$,]/g,"")); return isNaN(v)?null:v; }
function money(n){ return "$"+Number(n||0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,","); }
function norm(s){ return String(s||"").toLowerCase().replace(/[^a-z0-9 ]/g," ").replace(/\s+/g," ").trim(); }
function coreName(s){ return norm(s).replace(/\binstalled\b/g,"").replace(/\s+/g," ").trim(); }

function parseDoc(text){
  var d={squares:null,pricePerSq:null,laborHours:null,laborRate:null,depositPaid:null,depositCredited:null,total:null,material:"",brand:"",items:[],present:(text||"").trim().length>0};
  if(!d.present) return d;
  var lines=String(text).split(/\r?\n/);
  lines.forEach(function(raw){
    var line=raw.trim(); if(!line) return;
    if(line.indexOf("|")>=0){
      var p=line.split("|").map(function(x){return x.trim();});
      if(p.length>=4){ var it={name:p[0],qty:num(p[1]),unitPrice:num(p[2]),amount:num(p[3]),raw:line}; if(it.qty!=null&&it.unitPrice!=null&&it.amount!=null) d.items.push(it); }
      return;
    }
    var m;
    if(m=line.match(/squares(?:\s+installed)?\s*:\s*\$?([\d.,]+)/i)) d.squares=num(m[1]);
    else if(m=line.match(/(?:price|rate)\s+per\s+square\s*:\s*\$?([\d.,]+)/i)) d.pricePerSq=num(m[1]);
    else if(m=line.match(/labor\s+hours\s*:\s*([\d.,]+)/i)) d.laborHours=num(m[1]);
    else if(m=line.match(/labor\s+rate\s*:\s*\$?([\d.,]+)/i)) d.laborRate=num(m[1]);
    else if(m=line.match(/deposit\s+paid\s*:\s*\$?([\d.,]+)/i)) d.depositPaid=num(m[1]);
    else if(m=line.match(/deposit\s+credited\s*:\s*\$?([\d.,]+)/i)) d.depositCredited=num(m[1]);
    else if(m=line.match(/deposit\s+credit\s*:\s*\$?([\d.,]+)/i)) d.depositCredited=num(m[1]);
    else if(m=line.match(/material\s*:\s*(.+)/i)) d.material=m[1].trim();
    else if(m=line.match(/brand\s*:\s*(.+)/i)) d.brand=m[1].trim();
    else if(m=line.match(/^total\s*:\s*\$?([\d.,]+)/i)) d.total=num(m[1]);
  });
  // Derive price per square / hours from line items when labeled lines are absent
  d.items.forEach(function(it){
    var n=coreName(it.name);
    if(d.pricePerSq==null && /siding/.test(n) && it.unitPrice!=null) d.pricePerSq=it.unitPrice;
    if(d.squares==null && /siding/.test(n) && it.qty!=null) d.squares=it.qty;
    if(d.laborHours==null && n==="labor" && it.qty!=null) d.laborHours=it.qty;
    if(d.laborRate==null && n==="labor" && it.unitPrice!=null) d.laborRate=it.unitPrice;
  });
  d.materialFull=norm((d.material+" "+d.brand).trim());
  return d;
}

function audit(pText,wText,iText){
  var P=parseDoc(pText), W=parseDoc(wText), I=parseDoc(iText);
  var docs=[["Proposal",P],["Work Record",W],["Final Invoice",I]];
  var present=docs.filter(function(x){return x[1].present;});
  var missing=docs.filter(function(x){return !x[1].present;}).map(function(x){return x[0];});
  var findings=[]; var over=0;
  function add(id,title,detail,amount){ findings.push({id:id,title:title,detail:detail,amount:(amount==null?null:Math.round(amount*100)/100)}); if(amount) over+=amount; }

  if(present.length<2){
    return {verdict:"NOT ENOUGH TO COMPARE",verdictClass:"warn",overcharge:0,findings:[],missing:missing,presentCount:present.length,
      sub:"Only "+present.length+" document(s) provided. Paste at least two of the three — Proposal, Work Record, Final Invoice — to compare."};
  }

  // 1 Squares billed above installed
  if(I.squares!=null && W.squares!=null && I.squares>W.squares){
    var price=I.pricePerSq!=null?I.pricePerSq:(P.pricePerSq!=null?P.pricePerSq:null);
    if(price!=null){ var a=(I.squares-W.squares)*price; add("squares","Squares billed above squares installed","Invoice bills "+I.squares+" squares; work record shows "+W.squares+" installed.\n("+I.squares+" − "+W.squares+") × "+money(price)+" per square = "+money(a),a); }
    else add("squares","Squares billed above squares installed","Invoice bills "+I.squares+" squares; work record shows "+W.squares+" installed, but no price per square was found to price the difference.",0);
  }
  // 2 Material swap (flagged, not priced)
  if(I.present && W.present){
    var pm = P.materialFull, wm=W.materialFull, im=I.materialFull;
    var rec = wm||pm;
    if(im && rec && im!==rec){
      add("material","Material billed differs from material recorded — swap flagged (not priced)","Invoice material: “"+((I.material+" "+I.brand).trim())+"” vs recorded: “"+(((W.present&&wm)?(W.material+" "+W.brand):(P.material+" "+P.brand)).trim())+"”.\nFlagged for confirmation only — no dollar amount is added for a material swap.",0);
    }
  }
  // 3 Labor billed above recorded hours × rate
  if(I.laborHours!=null && W.laborHours!=null && I.laborHours>W.laborHours){
    var rate=I.laborRate!=null?I.laborRate:(P.laborRate!=null?P.laborRate:W.laborRate);
    if(rate!=null){ var la=(I.laborHours-W.laborHours)*rate; add("labor","Labor billed above recorded hours × rate","Invoice bills "+I.laborHours+" labor hours; work record shows "+W.laborHours+" hours.\n("+I.laborHours+" − "+W.laborHours+") × "+money(rate)+"/hr = "+money(la),la); }
  }
  // 4 Deposit paid but not credited
  var paidVals=[P.depositPaid,W.depositPaid,I.depositPaid].filter(function(v){return v!=null;});
  if(I.present && paidVals.length){
    var paid=Math.max.apply(null,paidVals);
    var credited=I.depositCredited==null?0:I.depositCredited;
    if(paid>credited){ var da=paid-credited; add("deposit","Deposit paid but not credited on the invoice","Deposit paid: "+money(paid)+"; deposit credited on invoice: "+money(credited)+".\n"+money(paid)+" − "+money(credited)+" = "+money(da)+" short-credit",da); }
  }
  // 5 Duplicate line items on invoice
  if(I.present){
    var groups={};
    I.items.forEach(function(it){ var k=coreName(it.name)+" @ "+it.unitPrice; (groups[k]=groups[k]||[]).push(it); });
    Object.keys(groups).forEach(function(k){
      var g=groups[k];
      if(g.length>1){ var da2=0; for(var j=1;j<g.length;j++) da2+=g[j].amount;
        add("duplicate","Duplicate line item on invoice: "+g[0].name,"“"+g[0].name+"” appears "+g.length+" times on the invoice at "+money(g[0].amount)+" each.\nExtra copies: "+(g.length-1)+" × "+money(g[0].amount)+" = "+money(da2),da2); }
    });
  }
  // 6 Invoice-only fees / lines
  if(I.present && (P.present||W.present)){
    var known=[];
    P.items.concat(W.items).forEach(function(it){ known.push(coreName(it.name)); });
    var seenCount={};
    I.items.forEach(function(it){ var cn=coreName(it.name); seenCount[cn]=(seenCount[cn]||0)+1;
      var isKnown=known.some(function(k){ return k===cn||k.indexOf(cn)>=0||cn.indexOf(k)>=0; });
      if(!isKnown && seenCount[cn]===1){ add("invoice-only","Invoice-only charge (in neither proposal nor work record): "+it.name,"“"+it.name+"” appears only on the final invoice — not in the proposal and not in the work record.\nCharge: "+money(it.amount),it.amount); }
    });
  }
  // 7 Per-line amount = qty × unit price
  [["Proposal",P],["Work Record",W],["Final Invoice",I]].forEach(function(pair){
    var doc=pair[1]; if(!doc.present) return;
    doc.items.forEach(function(it){
      var exp=Math.round(it.qty*it.unitPrice*100)/100;
      if(Math.abs(exp-it.amount)>0.01){
        var excess=(pair[0]==="Final Invoice" && it.amount>exp)?(it.amount-exp):0;
        add("line-math","Line amount mismatch ("+pair[0]+"): "+it.name,it.qty+" × "+money(it.unitPrice)+" = "+money(exp)+", but the line states "+money(it.amount)+".\nDifference: "+money(Math.abs(it.amount-exp))+(excess?" counted as overcharge.":" flagged only."),excess);
      }
    });
  });
  // 8 Invoice total re-add
  if(I.present && I.total!=null && I.items.length){
    var sum=I.items.reduce(function(s,it){return s+it.amount;},0); sum=Math.round(sum*100)/100;
    if(Math.abs(sum-I.total)>0.01){
      var tex=I.total>sum?(I.total-sum):0;
      add("total","Invoice total does not re-add","Invoice lines add to "+money(sum)+", but the stated Total is "+money(I.total)+".\n"+money(I.total)+" − "+money(sum)+" = "+money(I.total-sum)+(tex?" counted as overcharge.":" flagged only."),tex);
    }
  }

  over=Math.round(over*100)/100;
  var verdict, vc, sub;
  if(missing.length===1){
    verdict="PAY WITH FIXES"; vc="warn";
    sub="Missing document: "+missing[0]+". Two documents were compared; the third is needed for a full check."+(over>0?" Documented overcharge in the documents provided: "+money(over)+".":" No priced overcharge found in the documents provided.");
  } else if(over>0){
    verdict="DO NOT PAY YET — OVERCHARGE FOUND"; vc="bad";
    sub="Documented overcharge: "+money(over)+". Hold payment on the disputed amount until the invoice is corrected.";
  } else if(findings.length>0){
    verdict="PAY WITH FIXES"; vc="warn";
    sub="No priced overcharge, but "+findings.length+" flag(s) above need confirmation before paying. Documented overcharge: $0.00.";
  } else {
    verdict="OK TO PAY"; vc="ok";
    sub="All three documents agree on squares, material, labor, deposit, line math, and totals. SAFE TO PAY — documented overcharge: $0.00.";
  }
  return {verdict:verdict,verdictClass:vc,overcharge:over,findings:findings,missing:missing,presentCount:present.length,sub:sub};
}

/* ---------- Examples ---------- */
var BAD_P=[
"Proposal — Siding Installation",
"Material: fiber cement",
"Brand: HardiePlank",
"Squares: 24",
"Price per square: $850",
"Labor hours: 40",
"Labor rate: $65",
"Deposit paid: $2000",
"Line items:",
"Fiber cement siding | 24 | 850 | 20400",
"House wrap | 1 | 450 | 450",
"Labor | 40 | 65 | 2600",
"Total: $23450"].join("\n");
var BAD_W=[
"Work Record — Crew Log",
"Material: fiber cement",
"Brand: HardiePlank",
"Squares installed: 22",
"Squares: 22",
"Labor hours: 36",
"Labor rate: $65",
"Deposit paid: $2000",
"Line items:",
"Fiber cement siding | 22 | 850 | 18700",
"House wrap | 1 | 450 | 450",
"Labor | 36 | 65 | 2340"].join("\n");
var BAD_I=[
"Final Invoice",
"Material: fiber cement",
"Brand: HardiePlank",
"Squares: 24",
"Price per square: $850",
"Labor hours: 44",
"Labor rate: $65",
"Deposit paid: $2000",
"Deposit credited: $0",
"Line items:",
"Fiber cement siding | 24 | 850 | 20400",
"House wrap | 1 | 450 | 450",
"House wrap | 1 | 450 | 450",
"Labor | 44 | 65 | 2860",
"Disposal fee | 1 | 275 | 275",
"Total: $24435"].join("\n");

var GOOD_P=[
"Proposal — Siding Installation",
"Material: vinyl",
"Brand: CertainTeed",
"Squares: 20",
"Price per square: $700",
"Labor hours: 30",
"Labor rate: $60",
"Deposit paid: $1500",
"Line items:",
"Vinyl siding | 20 | 700 | 14000",
"House wrap | 1 | 400 | 400",
"Labor | 30 | 60 | 1800",
"Total: $16200"].join("\n");
var GOOD_W=[
"Work Record — Crew Log",
"Material: vinyl",
"Brand: CertainTeed",
"Squares installed: 20",
"Squares: 20",
"Labor hours: 30",
"Labor rate: $60",
"Deposit paid: $1500",
"Line items:",
"Vinyl siding | 20 | 700 | 14000",
"House wrap | 1 | 400 | 400",
"Labor | 30 | 60 | 1800"].join("\n");
var GOOD_I=[
"Final Invoice",
"Material: vinyl",
"Brand: CertainTeed",
"Squares: 20",
"Price per square: $700",
"Labor hours: 30",
"Labor rate: $60",
"Deposit paid: $1500",
"Deposit credited: $1500",
"Line items:",
"Vinyl siding | 20 | 700 | 14000",
"House wrap | 1 | 400 | 400",
"Labor | 30 | 60 | 1800",
"Total: $16200"].join("\n");
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-siding-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Siding Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
