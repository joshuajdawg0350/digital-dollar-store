'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Unbound DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the lesson) ---------- */
var RISKY = [
"server:",
"    verbosity: 5",
"    interface: 0.0.0.0",
"    interface: ::0",
"    port: 53",
"    access-control: 0.0.0.0/0 allow",
"    access-control: ::0/0 allow",
"    do-not-query-localhost: no",
"    hide-identity: no",
"    hide-version: no",
"    qname-minimisation: no",
"    tls-upstream: no",
"    cache-min-ttl: 86400",
"    cache-max-ttl: 31536000",
"    prefetch: no",
"    serve-expired: yes",
"    harden-glue: no",
"    harden-dnssec-stripped: no",
"    harden-below-nxdomain: no",
"    module-config: \"iterator\"",
"    this line has no colon and will not parse",
"remote-control:",
"    control-enable: yes",
"    control-use-cert: no",
"    control-interface: 0.0.0.0",
"    control-password: \"changeme\""
].join("\n");

var HARDENED = [
"server:",
"    verbosity: 1",
"    logfile: \"/var/log/unbound/unbound.log\"",
"    interface: 127.0.0.1",
"    interface: 192.168.1.53",
"    port: 53",
"    access-control: 127.0.0.0/8 allow",
"    access-control: 192.168.1.0/24 allow",
"    access-control: 0.0.0.0/0 refuse",
"    do-not-query-localhost: yes",
"    private-address: 10.0.0.0/8",
"    private-address: 172.16.0.0/12",
"    private-address: 192.168.0.0/16",
"    private-address: 127.0.0.0/8",
"    private-domain: \"home.arpa\"",
"    hide-identity: yes",
"    hide-version: yes",
"    qname-minimisation: yes",
"    tls-upstream: yes",
"    tls-cert-bundle: \"/etc/ssl/certs/ca-certificates.crt\"",
"    cache-min-ttl: 300",
"    cache-max-ttl: 86400",
"    cache-max-negative-ttl: 3600",
"    prefetch: yes",
"    serve-expired: no",
"    harden-glue: yes",
"    harden-dnssec-stripped: yes",
"    harden-below-nxdomain: yes",
"    harden-referral-path: yes",
"    harden-algo-downgrade: yes",
"    harden-large-queries: yes",
"    harden-short-bufsize: yes",
"    module-config: \"validator iterator\"",
"remote-control:",
"    control-enable: no",
"    control-use-cert: yes"
].join("\n");

/* ---------- Parsing (heuristic text audit — not a real Unbound parser) ---------- */
function stripQuotes(v){ return v.replace(/^"+|"+$/g,"").replace(/^'+|'+$/g,""); }
function isSecretKey(key){
  if(/file/.test(key)) return false; /* key-file / cert-file paths are not secret values */
  return /password|passwd|secret|token|api[-_]?key|private[-_]?key/.test(key);
}
function parseConfig(text){
  var lines = text.split(/\r?\n/);
  var entries = [], notParsed = [], section = null;
  for(var i=0;i<lines.length;i++){
    var n = i+1, raw = lines[i], t = raw.trim();
    if(t==="" || t.charAt(0)==="#") continue;
    var sec = t.match(/^([a-z][a-z0-9-]*):\s*$/);
    if(sec){ section = sec[1]; continue; }
    var dir = t.match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*:\s*(.*)$/);
    if(dir){
      entries.push({line:n, section:section, key:dir[1].toLowerCase(), value:stripQuotes(dir[2].trim())});
    } else {
      var secretish = /password|secret|token/i.test(t);
      notParsed.push({line:n, preview: secretish ? "[redacted — looks like a secret-bearing line]" : (t.length>90 ? t.slice(0,90)+"…" : t)});
    }
  }
  return {entries:entries, notParsed:notParsed, lineCount:lines.length};
}
function findAll(entries, key, section){
  return entries.filter(function(e){ return e.key===key && (section===undefined || e.section===section) && e.section!=="remote-control" || (e.key===key && section==="remote-control" && e.section==="remote-control"); });
}
function srv(entries, key){ /* server-scope lookup: any section except remote-control */
  return entries.filter(function(e){ return e.key===key && e.section!=="remote-control"; });
}
function rc(entries, key){
  return entries.filter(function(e){ return e.key===key && e.section==="remote-control"; });
}
function lastVal(list){ return list.length ? list[list.length-1] : null; }
function yesNo(v){ v=(v||"").toLowerCase(); if(v==="yes"||v==="true"||v==="1") return true; if(v==="no"||v==="false"||v==="0") return false; return null; }

/* ---------- Audit ---------- */
function audit(text){
  var parsed = parseConfig(text);
  var E = parsed.entries, F = [];
  function add(sev, line, check, msg, fix){ F.push({severity:sev, line:line, check:check, message:msg, fix:fix||""}); }

  /* Secrets — name, line, length ONLY. Values are never copied into findings. */
  E.forEach(function(e){
    if(isSecretKey(e.key)){
      var len = e.value.length;
      if(len < 12) add("HIGH", e.line, "Secret: "+e.key, "Key \""+e.key+"\" on line "+e.line+" holds a plaintext secret of length "+len+" — short secrets are guessable, and any secret sitting in the config is exposed to anyone who can read the file.", "Move the secret out of the config into a root-only file or secret store, use a long random value, and rotate this one — it has been pasted as plaintext.");
      else add("MEDIUM", e.line, "Secret: "+e.key, "Key \""+e.key+"\" on line "+e.line+" holds a plaintext secret of length "+len+". The value is not shown anywhere in this audit.", "Prefer a root-only key file or secret store over an inline value, and restrict config file permissions.");
    }
  });

  /* Interface binds */
  var ifaces = srv(E,"interface");
  if(!ifaces.length){
    add("MEDIUM", null, "Interface binds", "No interface: directive found. Unbound falls back to defaults you did not choose — the bind posture is unreviewed.", "Bind explicitly to loopback and/or specific LAN addresses you intend to serve.");
  } else {
    ifaces.forEach(function(e){
      var v = e.value.split("@")[0].trim();
      if(v==="0.0.0.0") add("HIGH", e.line, "Interface binds", "interface: 0.0.0.0 binds every IPv4 address on the host, including any public interface.", "Bind 127.0.0.1 and specific internal addresses instead; let access-control refuse everything else.");
      else if(v==="::0"||v==="::") add("HIGH", e.line, "Interface binds", "interface: "+v+" binds every IPv6 address on the host, including any public interface.", "Bind ::1 and specific internal addresses instead.");
      else add("PASS", e.line, "Interface binds", "interface: "+v+" is a specific bind, not a wildcard.");
    });
  }

  /* Access control */
  var acs = srv(E,"access-control");
  if(!acs.length){
    add("MEDIUM", null, "Access control", "No access-control: directives found. Who may query this resolver is left to defaults.", "Add access-control rules: allow your loopback/LAN ranges, and refuse 0.0.0.0/0 and ::0/0.");
  } else {
    acs.forEach(function(e){
      var parts = e.value.split(/\s+/), net = parts[0]||"", act = (parts[1]||"").toLowerCase();
      var isWorld = (net==="0.0.0.0/0"||net==="0.0.0.0"||net==="::0/0"||net==="::/0");
      if(isWorld && act!=="refuse" && act!=="drop"){
        add("BLOCKER", e.line, "Access control — open resolver", "access-control: "+net+" "+(act||"(no action)")+" lets the entire internet query this resolver — an open resolver, usable for DNS amplification attacks.", "Change it to refuse: access-control: "+net+" refuse — and allow only the networks you serve.");
      } else if(isWorld){
        add("PASS", e.line, "Access control", "access-control: "+net+" "+act+" explicitly shuts the door on the open internet.");
      } else {
        add("PASS", e.line, "Access control", "access-control: "+net+" "+(act||"")+" is a scoped range, not a world-open rule.");
      }
    });
  }

  /* do-not-query-localhost */
  var dnql = lastVal(srv(E,"do-not-query-localhost"));
  if(!dnql) add("LOW", null, "do-not-query-localhost", "do-not-query-localhost is not set. Unbound's default is yes, but the posture is not stated in the config.", "Set do-not-query-localhost: yes explicitly.");
  else if(yesNo(dnql.value)===false) add("HIGH", dnql.line, "do-not-query-localhost", "do-not-query-localhost: no lets the resolver query localhost addresses — a rebinding/SSRF foothold into services on the resolver host.", "Set do-not-query-localhost: yes.");
  else add("PASS", dnql.line, "do-not-query-localhost", "do-not-query-localhost: yes — the resolver will not query localhost.");

  /* Private address / domain (rebind protection) */
  var pas = srv(E,"private-address");
  if(!pas.length) add("HIGH", null, "Private-address rebind protection", "No private-address: ranges set. Public DNS answers can point at private IPs, so DNS rebinding into your LAN is not blocked.", "Add private-address for 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 and 127.0.0.0/8 (adjust to ranges you do not legitimately resolve).");
  else add("PASS", pas[0].line, "Private-address rebind protection", pas.length+" private-address range(s) set — public answers pointing at private space are stripped.");
  var pds = srv(E,"private-domain");
  if(!pds.length) add("MEDIUM", null, "Private-domain", "No private-domain: set. Domains that legitimately resolve to private addresses are not carved out, which pushes operators to disable rebind protection entirely.", "List internal domains (for example \"home.arpa\") as private-domain so protection can stay on.");
  else add("PASS", pds[0].line, "Private-domain", "private-domain carve-out(s) present, so rebind protection can stay enabled safely.");

  /* hide-identity / hide-version */
  [["hide-identity","Hide identity"],["hide-version","Hide version"]].forEach(function(pair){
    var e = lastVal(srv(E,pair[0]));
    if(!e) add("MEDIUM", null, pair[1], pair[0]+" is not set (default is no). The resolver answers identity/version queries, fingerprinting the host for attackers.", "Set "+pair[0]+": yes.");
    else if(yesNo(e.value)===false) add("MEDIUM", e.line, pair[1], pair[0]+": no — the resolver discloses this to anyone who can query it.", "Set "+pair[0]+": yes.");
    else add("PASS", e.line, pair[1], pair[0]+": yes — not disclosed to queriers.");
  });

  /* qname minimisation */
  var qm = lastVal(srv(E,"qname-minimisation"));
  if(!qm) add("MEDIUM", null, "QNAME minimisation", "qname-minimisation is not set. Full query names may be sent to upstream servers, leaking browsing detail.", "Set qname-minimisation: yes.");
  else if(yesNo(qm.value)===false) add("MEDIUM", qm.line, "QNAME minimisation", "qname-minimisation: no — full query names go upstream, leaking more than resolvers need.", "Set qname-minimisation: yes.");
  else add("PASS", qm.line, "QNAME minimisation", "qname-minimisation: yes — only the needed labels go upstream.");

  /* TLS upstream posture */
  var tls = lastVal(srv(E,"tls-upstream")), bundle = lastVal(srv(E,"tls-cert-bundle"));
  if(!tls) add("MEDIUM", null, "TLS upstream", "tls-upstream is not set. If forward zones expect DNS-over-TLS, upstream traffic posture is unstated and defaults to plaintext.", "Set tls-upstream: yes with tls-cert-bundle, or document that upstream is intentionally plaintext on a trusted path.");
  else if(yesNo(tls.value)===false) add("HIGH", tls.line, "TLS upstream", "tls-upstream: no — upstream queries travel in plaintext: visible to, and alterable by, anyone on the path.", "Set tls-upstream: yes and configure tls-cert-bundle so upstream answers are authenticated.");
  else if(!bundle) add("MEDIUM", tls.line, "TLS upstream", "tls-upstream: yes but no tls-cert-bundle is set — the resolver may be unable to authenticate upstream certificates.", "Set tls-cert-bundle to the system CA bundle path.");
  else add("PASS", tls.line, "TLS upstream", "tls-upstream: yes with tls-cert-bundle on line "+bundle.line+" — encrypted, authenticated upstream.");

  /* Remote control */
  var ce = lastVal(rc(E,"control-enable")), cuc = lastVal(rc(E,"control-use-cert")), ci = lastVal(rc(E,"control-interface"));
  if(ce && yesNo(ce.value)===true){
    if(!cuc || yesNo(cuc.value)===false){
      add("BLOCKER", cuc ? cuc.line : ce.line, "Remote control", "remote-control is enabled with control-use-cert off — unbound-control can be driven without certificate authentication.", "Set control-use-cert: yes and generate control keys/certs, or disable remote control.");
    } else {
      add("PASS", ce.line, "Remote control", "Remote control is enabled with control-use-cert: yes.");
    }
    if(ci && (ci.value==="0.0.0.0"||ci.value==="::0"||ci.value==="::")){
      add("HIGH", ci.line, "Remote control", "control-interface: "+ci.value+" exposes remote control on every interface.", "Bind control-interface to 127.0.0.1 (or a unix socket) only.");
    }
  } else if(ce){
    add("PASS", ce.line, "Remote control", "Remote control is disabled (control-enable: no) — no control channel to protect.");
  } else {
    add("PASS", null, "Remote control", "No remote-control section enables control — the control channel is off.");
  }

  /* Verbosity / logfile */
  var verb = lastVal(srv(E,"verbosity"));
  if(!verb) add("LOW", null, "Verbosity", "verbosity is not set. The default (1) is reasonable, but the logging posture is unstated.", "Set verbosity: 1 for production.");
  else {
    var vn = parseInt(verb.value,10);
    if(isNaN(vn)) add("MEDIUM", verb.line, "Verbosity", "verbosity value \""+verb.value+"\" is not a number this audit can grade.", "Use a numeric verbosity: 0–5, with 1 recommended for production.");
    else if(vn>=4) add("HIGH", verb.line, "Verbosity", "verbosity: "+vn+" is debug-level logging — it can flood disks, slow the resolver, and record full query detail.", "Run production at verbosity: 1 (2 at most while diagnosing).");
    else if(vn===3) add("MEDIUM", verb.line, "Verbosity", "verbosity: 3 logs operational detail continuously — noisy and query-revealing for steady state.", "Drop to verbosity: 1 for production.");
    else add("PASS", verb.line, "Verbosity", "verbosity: "+vn+" is a sane production level.");
  }
  var lf = lastVal(srv(E,"logfile"));
  if(!lf || lf.value==="") add("LOW", null, "Logfile", "No logfile: set — logging goes wherever the defaults send it, which may be nowhere reviewable.", "Set logfile to a path your log rotation covers, or confirm syslog logging is intended.");
  else add("PASS", lf.line, "Logfile", "logfile is set — resolver logs land in a known place.");

  /* Cache TTL bounds */
  var cmin = lastVal(srv(E,"cache-min-ttl")), cmax = lastVal(srv(E,"cache-max-ttl")), cneg = lastVal(srv(E,"cache-max-negative-ttl"));
  var cminN = cmin ? parseInt(cmin.value,10) : NaN, cmaxN = cmax ? parseInt(cmax.value,10) : NaN;
  if(!cmin) add("LOW", null, "Cache min TTL", "cache-min-ttl is not set (default 0). Publisher TTLs are honored as-is.", "Consider cache-min-ttl: 300 to smooth very short TTL churn — no higher.");
  else if(!isNaN(cminN) && cminN>21600) add("HIGH", cmin.line, "Cache min TTL", "cache-min-ttl: "+cminN+" forces answers to be cached far beyond publisher intent — stale or poisoned data persists for hours.", "Lower cache-min-ttl to 300 or less.");
  else if(!isNaN(cminN) && cminN>3600) add("MEDIUM", cmin.line, "Cache min TTL", "cache-min-ttl: "+cminN+" overrides publisher TTLs for over an hour — stale answers outlive the publisher's intent.", "Lower cache-min-ttl to 300 or less.");
  else add("PASS", cmin.line, "Cache min TTL", "cache-min-ttl: "+cmin.value+" is within sane bounds.");
  if(!cmax) add("MEDIUM", null, "Cache max TTL", "cache-max-ttl is not set. The cache ceiling is whatever the default allows — not a reviewed bound.", "Set cache-max-ttl explicitly (86400 is a common ceiling).");
  else if(!isNaN(cmaxN) && cmaxN>2592000) add("MEDIUM", cmax.line, "Cache max TTL", "cache-max-ttl: "+cmaxN+" lets a single answer live in cache for over 30 days — effectively unbounded.", "Cap cache-max-ttl at 86400 (one day) or justify a longer ceiling.");
  else add("PASS", cmax.line, "Cache max TTL", "cache-max-ttl: "+cmax.value+" is a bounded ceiling.");
  if(cmin && cmax && !isNaN(cminN) && !isNaN(cmaxN) && cminN>cmaxN)
    add("HIGH", cmax.line, "Cache TTL bounds", "cache-min-ttl ("+cminN+") is greater than cache-max-ttl ("+cmaxN+") — contradictory bounds the resolver cannot honor as written.", "Make cache-min-ttl smaller than cache-max-ttl.");
  if(!cneg) add("LOW", null, "Cache negative TTL", "cache-max-negative-ttl is not set — negative answers (NXDOMAIN) caching is unbounded by this config.", "Set cache-max-negative-ttl: 3600.");
  else add("PASS", cneg.line, "Cache negative TTL", "cache-max-negative-ttl: "+cneg.value+" bounds negative caching.");

  /* Prefetch / serve-expired */
  var pf = lastVal(srv(E,"prefetch"));
  if(!pf) add("LOW", null, "Prefetch", "prefetch is not set. Popular entries expire cold, adding latency spikes.", "Set prefetch: yes so hot entries refresh before expiry.");
  else if(yesNo(pf.value)===true) add("PASS", pf.line, "Prefetch", "prefetch: yes — hot entries refresh before they expire.");
  else add("LOW", pf.line, "Prefetch", "prefetch: no — popular entries expire cold and the next query pays full resolution latency.", "Set prefetch: yes unless upstream load is a concern.");
  var se = lastVal(srv(E,"serve-expired"));
  if(!se) add("LOW", null, "Serve-expired", "serve-expired is not set (default no). Fine, but the stale-answer posture is unstated.", "State serve-expired explicitly.");
  else if(yesNo(se.value)===true) add("LOW", se.line, "Serve-expired", "serve-expired: yes — clients can be handed stale answers when upstream is unreachable. That is a resilience choice with a correctness cost.", "Keep it only if stale answers beat outages for your users, and bound it with serve-expired-ttl.");
  else add("PASS", se.line, "Serve-expired", "serve-expired: no — expired answers are never served as fresh.");

  /* harden-* flags */
  var HARDEN = ["harden-glue","harden-dnssec-stripped","harden-below-nxdomain","harden-referral-path","harden-algo-downgrade","harden-large-queries","harden-short-bufsize"];
  HARDEN.forEach(function(k){
    var e = lastVal(srv(E,k));
    if(!e) add("LOW", null, k, k+" is not set. Its default may protect you, but the hardening posture is not stated or reviewed.", "Set "+k+": yes explicitly.");
    else if(yesNo(e.value)===false) add("MEDIUM", e.line, k, k+": no — this hardening check is switched off, widening the spoofing/poisoning surface.", "Set "+k+": yes unless you have a documented interoperability reason.");
    else add("PASS", e.line, k, k+": yes.");
  });

  /* module-config (DNSSEC validation posture) */
  var mc = lastVal(srv(E,"module-config"));
  if(!mc) add("MEDIUM", null, "Module config", "No module-config: found. Whether the validator runs is left to build defaults.", "Set module-config: \"validator iterator\" so DNSSEC validation is explicit.");
  else if(mc.value.indexOf("validator")===-1) add("HIGH", mc.line, "Module config", "module-config: \""+mc.value+"\" does not include the validator module — DNSSEC answers are not validated, so spoofed signed-zone data passes.", "Set module-config: \"validator iterator\".");
  else add("PASS", mc.line, "Module config", "module-config includes the validator — DNSSEC validation is on.");

  /* do-daemonize note */
  var dd = lastVal(srv(E,"do-daemonize"));
  if(dd && yesNo(dd.value)===false) add("LOW", dd.line, "Daemon mode", "do-daemonize: no runs Unbound in the foreground. Right for containers/systemd supervision, wrong for a classic daemon install.", "Confirm the deployment actually supervises the foreground process.");

  /* Verdict */
  var counts = {BLOCKER:0,HIGH:0,MEDIUM:0,LOW:0,PASS:0};
  F.forEach(function(f){ counts[f.severity]++; });
  var verdict;
  if(E.length < 4) verdict = "NOT ENOUGH TO GRADE";
  else if(counts.BLOCKER>0) verdict = "DO NOT DEPLOY";
  else if(counts.HIGH>0 || counts.MEDIUM>0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict:verdict, findings:F, counts:counts, notParsed:parsed.notParsed,
          directiveCount:E.length, lineCount:parsed.lineCount};
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-unbound-dns-server-config-safety-auditortm',
  name: 'J-Dawgs Unbound DNS Server Config Safety Auditor',
  description: 'Grades a pasted Unbound resolver config (unbound.conf) fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — open-resolver exposure, access-control and private-address posture, and remote-control interface settings, with secrets shown by k',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
