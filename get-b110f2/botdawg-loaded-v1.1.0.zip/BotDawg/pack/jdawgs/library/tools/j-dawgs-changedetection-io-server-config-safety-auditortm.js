'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Changedetection.io Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# RISKY worked example - training config, do not deploy",
        "PORT=5000",
        "BIND_ADDRESS=0.0.0.0",
        "PASSWORD=",
        "BASE_URL=http://watch.example.com",
        "NOTIFICATION_URLS=mailto://admin:RISKYMAILPASS99@smtp.example.com:587/alerts@example.com",
        "FETCH_BACKEND=webdriver",
        "WEBDRIVER_URL=http://localhost:4444/wd/hub",
        "ALLOW_FILE_URI=true",
        "HTTP_PROXY=http://proxyuser:RISKYPROXYPASS88@proxy.example.com:8080",
        "SECRET_KEY=changeme",
        "API_TOKEN=short1",
        "SNAPSHOTS_DIR=/tmp/snapshots"
      ].join("\n");

      var HARDENED = [
        "# HARDENED worked example",
        "PORT=5000",
        "BIND_ADDRESS=127.0.0.1",
        "PASSWORD=Str0ng-Long-Passphrase-2026!",
        "BASE_URL=https://watch.example.com",
        "NOTIFICATION_URLS=mailto://alerts@example.com",
        "FETCH_BACKEND=html_requests",
        "ALLOW_FILE_URI=false",
        "SECRET_KEY=k7f2m9x4q8w1e5r6t3y7u2i9o0p4a6s8d1f5g3h7j2",
        "API_TOKEN=t8k3m7x2q9w4e6r1t5y8u3i7o2p9a4s6d1f8g5h3",
        "SNAPSHOTS_DIR=/data/snapshots"
      ].join("\n");

      var PLANTED_SECRETS = ["RISKYMAILPASS99", "RISKYPROXYPASS88", "short1"];
      var HARDENED_SECRETS = ["Str0ng-Long-Passphrase-2026!", "k7f2m9x4q8w1e5r6t3y7u2i9o0p4a6s8d1f5g3h7j2", "t8k3m7x2q9w4e6r1t5y8u3i7o2p9a4s6d1f8g5h3"];

      var EXAMPLE_WORDS = ["changeme", "change-me", "change_me", "password", "password123", "admin123",
        "letmein", "123456", "12345678", "qwerty", "secret", "mysecret", "default", "test123",
        "example", "placeholder", "your_secret", "your-secret", "replace_me", "replace-me", "todo", "sample"];

      function isExampleValue(v) {
        var low = v.toLowerCase();
        for (var i = 0; i < EXAMPLE_WORDS.length; i++) {
          if (low === EXAMPLE_WORDS[i] || low.indexOf("changeme") !== -1 || low.indexOf("placeholder") !== -1) return true;
        }
        return false;
      }
      function isTruthy(v) {
        var low = v.toLowerCase();
        return low === "true" || low === "1" || low === "yes" || low === "on" || low === "enabled";
      }
      function schemeOf(v) {
        var m = v.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : "";
      }
      function embeddedPasswordLength(v) {
        var m = v.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/@\s]*)/);
        if (m && v.indexOf("@") !== -1) {
          var ui = m[1];
          var idx = ui.indexOf(":");
          if (idx !== -1) {
            var pw = ui.slice(idx + 1);
            if (pw.length > 0) return pw.length;
          }
        }
        var q = v.match(/[?&](?:password|passwd|pwd)=([^&\s]+)/i);
        if (q) return q[1].length;
        return 0;
      }

      function parseConfig(text) {
        var entries = [];
        var lines = String(text || "").split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var t = lines[i].trim();
          if (!t || t.charAt(0) === "#") continue;
          if (t.indexOf("- ") === 0) t = t.slice(2).trim();
          if (t.indexOf("export ") === 0) t = t.slice(7).trim();
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var key = m[1].toUpperCase().replace(/-/g, "_");
          var val = m[2].trim();
          if (val.length >= 2 && ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
              (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'"))) {
            val = val.slice(1, -1);
          }
          entries.push({ line: i + 1, key: key, value: val, length: val.length });
        }
        return entries;
      }

      function findEntries(entries, test) {
        var out = [];
        for (var i = 0; i < entries.length; i++) if (test(entries[i])) out.push(entries[i]);
        return out;
      }

      function audit(text) {
        var entries = parseConfig(text);
        var findings = [];
        function add(sev, line, key, check, message) {
          findings.push({ severity: sev, line: line, key: key, check: check, message: message });
        }
        if (entries.length === 0) {
          add("INFO", null, "(input)", "not-enough-input",
            "No parseable KEY=value lines were found, so there is nothing to grade. Paste an environment-variable style config and audit again.");
          return { verdict: "NOT ENOUGH TO GRADE", findings: findings, counts: countFindings(findings), entries: entries };
        }

        var flaggedLines = {};

        /* --- Web UI password --- */
        var pwEntries = findEntries(entries, function (e) { return e.key.indexOf("PASSWORD") !== -1; });
        var effectivePassword = false;
        if (pwEntries.length === 0) {
          add("BLOCKER", null, "(missing) PASSWORD", "password-missing",
            "No password key was found in the config. The web UI would be reachable with no password set. Add a long, unique password key before deploying.");
        } else {
          pwEntries.forEach(function (e) {
            if (e.length === 0) {
              add("BLOCKER", e.line, e.key, "password-empty",
                "Key " + e.key + " on line " + e.line + " is set but empty (length 0). The web UI would have no password. Set a long, unique value.");
            } else if (isExampleValue(e.value)) {
              add("BLOCKER", e.line, e.key, "password-placeholder",
                "Key " + e.key + " on line " + e.line + " holds a placeholder / example value (length " + e.length + "). Anyone who has seen a sample config knows it. Replace it with a long, unique password.");
            } else if (e.length < 8) {
              add("BLOCKER", e.line, e.key, "password-short",
                "Key " + e.key + " on line " + e.line + " is very short (length " + e.length + "). Use at least 12 characters; 16 or more is better.");
            } else if (e.length < 12) {
              add("HIGH", e.line, e.key, "password-short",
                "Key " + e.key + " on line " + e.line + " is short (length " + e.length + "). Use at least 12 characters; 16 or more is better.");
            } else {
              effectivePassword = true;
            }
          });
        }

        /* --- Bind address --- */
        var bindEntries = findEntries(entries, function (e) {
          return e.key === "BIND_ADDRESS" || e.key === "BIND" || e.key === "BIND_HOST" ||
                 e.key === "HOST" || e.key === "LISTEN_ADDRESS";
        });
        bindEntries.forEach(function (e) {
          var v = e.value.trim();
          if (v === "0.0.0.0" || v === "::" || v === "*") {
            if (!effectivePassword) {
              add("BLOCKER", e.line, e.key, "bind-open-no-auth",
                "Key " + e.key + " on line " + e.line + " binds the server on all interfaces (0.0.0.0) and there is no effective password posture in this config. Anyone who can reach the port can reach the UI. Bind to 127.0.0.1 behind a reverse proxy, or set a strong password first.");
            } else {
              add("WARNING", e.line, e.key, "bind-open-with-auth",
                "Key " + e.key + " on line " + e.line + " binds the server on all interfaces (0.0.0.0). A password is set, but confirm a firewall or reverse proxy also restricts who can reach the port.");
            }
          }
        });

        /* --- BASE_URL --- */
        var baseEntries = findEntries(entries, function (e) { return e.key === "BASE_URL" || e.key === "PUBLIC_URL"; });
        if (baseEntries.length === 0) {
          add("INFO", null, "(missing) BASE_URL", "base-url-missing",
            "No BASE_URL key was found. Links the app puts in notifications may point at the wrong address. Set BASE_URL to the exact https address users reach it at.");
        } else {
          baseEntries.forEach(function (e) {
            if (schemeOf(e.value) === "http") {
              add("HIGH", e.line, e.key, "base-url-http",
                "Key " + e.key + " on line " + e.line + " uses the http scheme instead of https. Logins and session cookies tied to that address travel unencrypted. Serve the app over https and update this key to match.");
            }
          });
        }

        /* --- Notification URLs with plaintext credentials --- */
        var notifEntries = findEntries(entries, function (e) {
          return e.key.indexOf("NOTIFICATION") !== -1 || e.key.indexOf("NOTIFY") !== -1 ||
                 e.key.indexOf("APPRISE") !== -1 || e.key.indexOf("WEBHOOK") !== -1;
        });
        notifEntries.forEach(function (e) {
          var parts = e.value.split(/[\s,]+/);
          for (var i = 0; i < parts.length; i++) {
            var pwLen = embeddedPasswordLength(parts[i]);
            if (pwLen > 0) {
              add("HIGH", e.line, e.key, "notification-credentials",
                "A notification URL in key " + e.key + " on line " + e.line + " (scheme: " + (schemeOf(parts[i]) || "unknown") + ") embeds a plaintext password (password length " + pwLen + "). Anyone who reads this config owns that mailbox or service account. Move the credential into a secrets store or a restricted file, and rotate the password that was pasted here.");
              flaggedLines[e.line + ":cred"] = true;
              break;
            }
          }
        });

        /* --- Fetch backend / webdriver --- */
        var backendEntries = findEntries(entries, function (e) {
          return e.key === "FETCH_BACKEND" || e.key === "FETCHER" || e.key === "FETCH_METHOD";
        });
        backendEntries.forEach(function (e) {
          var low = e.value.toLowerCase();
          if (low.indexOf("webdriver") !== -1 || low.indexOf("selenium") !== -1 || low.indexOf("playwright") !== -1 ||
              low.indexOf("browser") !== -1 || low.indexOf("chrome") !== -1 || low.indexOf("puppeteer") !== -1) {
            add("WARNING", e.line, e.key, "fetch-backend-browser",
              "Key " + e.key + " on line " + e.line + " selects a browser / webdriver fetch backend. A real browser fetches whatever pages it is pointed at, including internal addresses if a watch is misconfigured. Restrict outbound network access for the browser service and only watch pages you trust.");
          }
        });
        var wdEntries = findEntries(entries, function (e) {
          return e.key.indexOf("WEBDRIVER") !== -1 || e.key.indexOf("SELENIUM") !== -1 || e.key.indexOf("PLAYWRIGHT") !== -1;
        });
        wdEntries.forEach(function (e) {
          add("WARNING", e.line, e.key, "webdriver-endpoint",
            "Key " + e.key + " on line " + e.line + " configures a browser / webdriver endpoint. That endpoint can drive a full browser; make sure it is not reachable from outside the deployment and sits on a private network only.");
        });

        /* --- Local file URI access --- */
        var fileEntries = findEntries(entries, function (e) {
          return e.key.indexOf("FILE_URI") !== -1 || e.key.indexOf("LOCAL_FILE") !== -1 || e.key.indexOf("FILE_ACCESS") !== -1;
        });
        fileEntries.forEach(function (e) {
          if (isTruthy(e.value)) {
            add("BLOCKER", e.line, e.key, "file-uri-enabled",
              "Key " + e.key + " on line " + e.line + " enables local-file / file-URI access. A watch pointed at a local file can read files off the server itself. Turn this off unless you have a specific, contained reason for it.");
          }
        });

        /* --- Proxy credentials --- */
        var proxyEntries = findEntries(entries, function (e) { return e.key.indexOf("PROXY") !== -1; });
        proxyEntries.forEach(function (e) {
          var pwLen = embeddedPasswordLength(e.value);
          if (pwLen > 0) {
            add("HIGH", e.line, e.key, "proxy-credentials",
              "The proxy URL in key " + e.key + " on line " + e.line + " embeds a plaintext password (password length " + pwLen + "). Anyone who reads this config can use and abuse that proxy account. Move the credential into a secrets store and rotate the password that was pasted here.");
            flaggedLines[e.line + ":cred"] = true;
          } else if (e.key.indexOf("PASSWORD") !== -1 && e.length > 0) {
            add("WARNING", e.line, e.key, "proxy-password-plaintext",
              "Key " + e.key + " on line " + e.line + " stores a proxy password directly in the config (length " + e.length + "). Prefer a secrets store or a config file readable only by the service account.");
          }
        });

        /* --- Secret / token keys --- */
        var secretEntries = findEntries(entries, function (e) {
          return e.key.indexOf("SECRET") !== -1 || e.key.indexOf("TOKEN") !== -1 ||
                 e.key.indexOf("API_KEY") !== -1 || e.key.indexOf("APIKEY") !== -1 ||
                 e.key.indexOf("PRIVATE_KEY") !== -1 || e.key.indexOf("ACCESS_KEY") !== -1;
        });
        secretEntries.forEach(function (e) {
          if (e.key.indexOf("PASSWORD") !== -1) return;
          if (e.length === 0) {
            add("HIGH", e.line, e.key, "secret-empty",
              "Key " + e.key + " on line " + e.line + " is set but empty (length 0). Set a long random value, or remove the key if the feature is unused.");
          } else if (isExampleValue(e.value)) {
            add("HIGH", e.line, e.key, "secret-placeholder",
              "Key " + e.key + " on line " + e.line + " holds a placeholder / example value (length " + e.length + "). Sample values are public knowledge. Replace it with a long random value generated for this deployment.");
          } else if (e.length < 16) {
            add("HIGH", e.line, e.key, "secret-short",
              "Key " + e.key + " on line " + e.line + " is short (length " + e.length + "). Secrets and tokens should be at least 16 characters, generated randomly for this deployment.");
          }
        });

        /* --- Generic: any other URL carrying an embedded password --- */
        entries.forEach(function (e) {
          if (flaggedLines[e.line + ":cred"]) return;
          if (e.key.indexOf("NOTIFICATION") !== -1 || e.key.indexOf("PROXY") !== -1) return;
          var pwLen = embeddedPasswordLength(e.value);
          if (pwLen > 0 && schemeOf(e.value)) {
            add("HIGH", e.line, e.key, "url-credentials",
              "The URL in key " + e.key + " on line " + e.line + " (scheme: " + schemeOf(e.value) + ") embeds a plaintext password (password length " + pwLen + "). Move the credential into a secrets store and rotate the password that was pasted here.");
            flaggedLines[e.line + ":cred"] = true;
          }
        });

        /* --- Snapshots / data directory posture (INFO) --- */
        var dataEntries = findEntries(entries, function (e) {
          return e.key.indexOf("SNAPSHOT") !== -1 || e.key.indexOf("DATA_DIR") !== -1 ||
                 e.key.indexOf("DATA_PATH") !== -1 || e.key === "DATA" || e.key.indexOf("STORAGE_DIR") !== -1;
        });
        if (dataEntries.length === 0) {
          add("INFO", null, "(missing) SNAPSHOTS_DIR / DATA_DIR", "data-dir-missing",
            "No snapshots / data directory key was found. Confirm where snapshots and watch data persist, that the location survives restarts, and that it is included in backups.");
        } else {
          dataEntries.forEach(function (e) {
            add("INFO", e.line, e.key, "data-dir-posture",
              "Key " + e.key + " on line " + e.line + " sets the snapshots / data location (the path itself is not shown here). Confirm it is persistent across restarts, backed up, writable only by the service account, and not readable by other users on the host.");
          });
        }

        findings.sort(function (a, b) {
          var la = a.line === null ? 9999 : a.line;
          var lb = b.line === null ? 9999 : b.line;
          return la - lb;
        });

        var counts = countFindings(findings);
        var verdict;
        if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict: verdict, findings: findings, counts: counts, entries: entries };
      }

      function countFindings(findings) {
        var c = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, total: findings.length };
        findings.forEach(function (f) { c[f.severity]++; });
        return c;
      }

      function buildReport(result, sourceLabel) {
        var lines = [];
        lines.push("J-Dawgs Changedetection.io Server Config Safety Auditor - Audit Report");
        lines.push("Source: " + sourceLabel);
        lines.push("Verdict: " + result.verdict);
        lines.push("Findings: " + result.counts.total + " total - " +
          result.counts.BLOCKER + " BLOCKER, " + result.counts.HIGH + " HIGH, " +
          result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO");
        lines.push("Note: secret values are never included in this report. Findings name the key, the line, and the value length only.");
        lines.push("");
        if (result.findings.length === 0) lines.push("No findings.");
        result.findings.forEach(function (f, i) {
          var loc = f.line === null ? "Line: (not present in config)" : "Line " + f.line;
          lines.push((i + 1) + ". [" + f.severity + "] " + loc + " - " + f.key + " (" + f.check + ")");
          lines.push("   " + f.message);
        });
        return lines.join("\n");
      }

      function buildJson(result, sourceLabel) {
        var obj = {
          tool: "J-Dawgs Changedetection.io Server Config Safety Auditor",
          source: sourceLabel,
          verdict: result.verdict,
          counts: { BLOCKER: result.counts.BLOCKER, HIGH: result.counts.HIGH, WARNING: result.counts.WARNING, INFO: result.counts.INFO, total: result.counts.total },
          secretValuesIncluded: false,
          findings: result.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, check: f.check, message: f.message };
          })
        };
        return JSON.stringify(obj, null, 2);
      }

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }

      var lastResult = null, lastReport = "", lastJson = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-changedetection-io-server-config-safety-auditortm',
  name: 'J-Dawgs Changedetection.io Server Config Safety Auditor',
  description: 'Changedetection.io\'s own checks only answer whether the app starts on the host; ours grades a pasted Changedetection.io config fully offline — password protection, bind and port exposure, base URL, notification URLs carrying embedded credentials, with secrets shown by key name/line/length only — int',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
