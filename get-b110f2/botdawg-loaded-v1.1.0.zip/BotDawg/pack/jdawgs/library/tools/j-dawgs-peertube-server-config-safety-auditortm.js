'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PeerTube Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example — PeerTube production.yaml (planted problems)",
          "listen:",
          "  hostname: '0.0.0.0'",
          "  port: 9000",
          "",
          "webserver:",
          "  https: false",
          "  hostname: 'videos.example.com'",
          "  port: 80",
          "",
          "secrets:",
          "  peertube: 'RISKYSECRETVALUE_PEERTUBE_9911'",
          "",
          "database:",
          "  hostname: 'localhost'",
          "  port: 5432",
          "  username: 'peertube'",
          "  password: 'dbpass123'",
          "",
          "redis:",
          "  hostname: 'localhost'",
          "  port: 6379",
          "  password: 'redispass456'",
          "",
          "admin:",
          "  email: 'admin@example.com'",
          "",
          "signup:",
          "  enabled: true",
          "  requires_email_verification: false",
          "  limit: 10000",
          "",
          "smtp:",
          "  hostname: 'mail.example.com'",
          "  tls: false",
          "  disable_starttls: true",
          "  password: 'smtppass789'",
          "",
          "storage:",
          "  s3:",
          "    endpoint: 'http://s3.example.com'",
          "    access_key_id: 'AKIAEXAMPLE123'",
          "    secret_access_key: 's3secretkeyvalue987654321'",
          "",
          "transcoding:",
          "  enabled: true",
          "  threads: 0",
          "",
          "live:",
          "  enabled: true",
          "  rtmp:",
          "    port: 1935",
          "",
          "log:",
          "  level: 'debug'",
          "",
          "instance:",
          "  name: 'Risky Tube'"
        ].join("\n");

        var HARDENED = [
          "# Hardened example — PeerTube production.yaml",
          "listen:",
          "  hostname: '127.0.0.1'",
          "  port: 9000",
          "",
          "webserver:",
          "  https: true",
          "  hostname: 'tube.jdawgsindustries.com'",
          "  port: 443",
          "",
          "secrets:",
          "  peertube: '${PEERTUBE_SECRET}'",
          "",
          "database:",
          "  hostname: 'localhost'",
          "  port: 5432",
          "  username: 'peertube'",
          "  password: '${PEERTUBE_DB_PASSWORD}'",
          "",
          "redis:",
          "  hostname: 'localhost'",
          "  port: 6379",
          "  password: '${PEERTUBE_REDIS_PASSWORD}'",
          "",
          "admin:",
          "  email: 'ops@jdawgsindustries.com'",
          "",
          "signup:",
          "  enabled: false",
          "",
          "smtp:",
          "  hostname: 'mail.jdawgsindustries.com'",
          "  port: 587",
          "  tls: true",
          "  disable_starttls: false",
          "  password: '${PEERTUBE_SMTP_PASSWORD}'",
          "",
          "storage:",
          "  s3:",
          "    endpoint: 'https://s3.jdawgsindustries.com'",
          "    access_key_id: '${PEERTUBE_S3_ACCESS_KEY_ID}'",
          "    secret_access_key: '${PEERTUBE_S3_SECRET_ACCESS_KEY}'",
          "",
          "transcoding:",
          "  enabled: true",
          "  threads: 2",
          "",
          "live:",
          "  enabled: false",
          "",
          "log:",
          "  level: 'info'",
          "",
          "instance:",
          "  name: 'J-Dawgs Tube'",
          "  description: 'Community video instance'"
        ].join("\n");

        var VOCAB = {};
        ["listen","webserver","secrets","database","datasources","redis","admin","signup","smtp","storage","transcoding","live","log","instance","federation","followers","followings","contact_form","contact-form","import","cache","redundancy","trending","peertube","postgres","s3","rtmp","mail"].forEach(function (w) { VOCAB[w] = true; });

        var SECRET_CTX = /(database|datasources|postgres|redis|smtp|storage|s3|secrets|admin|peertube|(^|\.)db(\.|$))/;
        var WEAK_WORD = /(example|default|changeme|change-me|secret|password|letmein|qwerty|12345|admin123)/i;

        var lastResult = null;
        var secretValues = [];

        function $(id) { return document.getElementById(id); }

        function normKey(k) {
          return k.trim().toLowerCase().replace(/[\s]+/g, "_").replace(/^['"]|['"]$/g, "");
        }
        function cleanValue(v) {
          v = (v == null ? "" : String(v)).trim();
          if (v.length >= 2 && ((v.charAt(0) === "'" && v.charAt(v.length - 1) === "'") || (v.charAt(0) === '"' && v.charAt(v.length - 1) === '"'))) {
            return v.slice(1, -1);
          }
          var ci = v.indexOf(" #");
          if (ci >= 0) v = v.slice(0, ci);
          return v.trim();
        }
        function truthy(v) { return ["true", "yes", "on", "1"].indexOf(String(v).toLowerCase()) >= 0; }
        function falsy(v) { return ["false", "no", "off", "0"].indexOf(String(v).toLowerCase()) >= 0; }
        function isEnvRef(v) { return /^\$\{[^}]+\}$/.test(v) || /^env:/i.test(v); }
        function isPlaceholder(v) { return /^(redacted|xxx+|\*{3,}|<[^>]*>|todo|placeholder)$/i.test(v); }

        function parse(text) {
          var lines = text.split(/\r\n|\r|\n/);
          var entries = [];
          var notParsed = [];
          var stack = [];
          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i];
            var lineNo = i + 1;
            var trimmed = raw.trim();
            if (trimmed === "" || trimmed.charAt(0) === "#") continue;
            var indent = raw.length - raw.replace(/^\s+/, "").length;
            var envM = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (envM) {
              var ekey = envM[1].toLowerCase();
              entries.push({
                line: lineNo,
                path: ekey.replace(/_/g, "."),
                leaf: ekey.split("_").pop(),
                value: cleanValue(envM[2]),
                rawKey: envM[1]
              });
              continue;
            }
            if (trimmed.charAt(0) === "-") { notParsed.push(lineNo); continue; }
            var ym = trimmed.match(/^([^:\s][^:]*?):\s*(.*)$/);
            if (!ym) { notParsed.push(lineNo); continue; }
            var key = normKey(ym[1]);
            if (!key) { notParsed.push(lineNo); continue; }
            while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
            var parts = stack.map(function (s) { return s.key; });
            parts.push(key);
            entries.push({
              line: lineNo,
              path: parts.join("."),
              leaf: key,
              value: cleanValue(ym[2]),
              rawKey: ym[1].trim()
            });
            stack.push({ indent: indent, key: key });
          }
          var recognized = 0;
          entries.forEach(function (e) {
            var segs = e.path.split(".");
            for (var j = 0; j < segs.length; j++) {
              if (VOCAB[segs[j]]) { recognized++; break; }
            }
          });
          return { totalLines: lines.length, entries: entries, notParsed: notParsed, recognized: recognized };
        }

        function isSecretEntry(e) {
          if (e.path === "secrets.peertube") return true;
          if (e.leaf === "secret") return true;
          if (["password", "passwd", "secret_access_key", "auth"].indexOf(e.leaf) >= 0 && SECRET_CTX.test(e.path)) return true;
          if (e.leaf === "access_key_id" && /(storage|s3)/.test(e.path)) return true;
          return false;
        }

        function audit(text) {
          secretValues = [];
          var parsed = parse(text);
          var entries = parsed.entries;
          var recognized = parsed.recognized;
          var findings = [];

          function add(sev, line, key, title, explanation, fix, extra) {
            var f = { severity: sev, blocker: sev === "CRITICAL", line: line, key: key, title: title, explanation: explanation, fix: fix };
            if (extra) { for (var k in extra) f[k] = extra[k]; }
            findings.push(f);
          }
          function byPath(p) {
            for (var i = 0; i < entries.length; i++) if (entries[i].path === p) return entries[i];
            return null;
          }
          function hasSection(name) {
            return entries.some(function (e) { return e.path === name || e.path.indexOf(name + ".") === 0; });
          }

          // --- Secrets first: register values for redaction, emit findings ---
          entries.forEach(function (e) {
            if (!isSecretEntry(e)) return;
            if (e.value === "") return;
            if (isEnvRef(e.value) || isPlaceholder(e.value)) {
              add("INFO", e.line, e.path, "Secret supplied by reference, not plaintext",
                "This secret is set by an environment/secret-store reference rather than a pasted value, so there is nothing to grade and nothing to leak.",
                "Keep secrets in the environment or a secret store; never paste real values into config files.");
              return;
            }
            if (e.value.length >= 4) secretValues.push(e.value);
            var weak = e.value.length < 32 || WEAK_WORD.test(e.value);
            var sev = weak ? "CRITICAL" : "HIGH";
            if (e.path.indexOf("admin") === 0 && e.leaf === "password") sev = "CRITICAL";
            add(sev, e.line, e.path, "Plaintext secret in pasted config",
              "A secret is written in plaintext at this line (" + e.value.length + " characters; the value itself is never shown). Anyone who can read this file — backups, repos, screenshots — has the credential.",
              "Move to env/secret store, rotate this secret now, and scrub it from file history.",
              { valueLength: e.value.length });
          });

          // --- 1. Listen hostname ---
          var lh = byPath("listen.hostname");
          if (lh) {
            if (lh.value === "0.0.0.0" || lh.value === "::" || lh.value === "*" || lh.value === "") {
              add("HIGH", lh.line, "listen.hostname", "Listening on all network interfaces",
                "The listen hostname binds PeerTube to every interface on the host, so the app port answers the public internet directly instead of sitting behind a local reverse proxy.",
                "Bind to 127.0.0.1 and put a reverse proxy (nginx/Caddy) in front, or firewall the app port to localhost only.");
            } else if (["127.0.0.1", "localhost", "::1"].indexOf(lh.value) >= 0) {
              add("INFO", lh.line, "listen.hostname", "Localhost binding",
                "PeerTube binds to localhost only, so the app port is not directly reachable from the network.",
                "No change needed; keep the reverse proxy as the only public entry point.");
            }
          }

          // --- 2. HTTPS posture ---
          var httpsE = byPath("webserver.https");
          var wsHost = byPath("webserver.hostname");
          if (httpsE && falsy(httpsE.value)) {
            var exposed = (lh && (lh.value === "0.0.0.0" || lh.value === "::")) ||
              (wsHost && ["localhost", "127.0.0.1", "::1"].indexOf(wsHost.value) < 0);
            add(exposed ? "CRITICAL" : "HIGH", httpsE.line, "webserver.https", "HTTPS is turned off",
              "webserver.https is false, so PeerTube serves plain HTTP" + (exposed ? " on a publicly reachable hostname — logins, sessions, and uploads cross the network unencrypted." : "."),
              "Set webserver.https to true and serve the instance over HTTPS (directly or via a TLS-terminating reverse proxy).");
          }
          var wsp = byPath("webserver.port");
          if (wsp && wsp.value === "80") {
            add("HIGH", wsp.line, "webserver.port", "Webserver on plain HTTP port 80",
              "Port 80 is the plain-HTTP port; serving the app there without a redirect to HTTPS leaves traffic unencrypted.",
              "Serve on 443 with HTTPS, or use port 80 only to redirect to HTTPS.");
          }
          if (!httpsE && hasSection("webserver") && recognized >= 3) {
            add("WARNING", null, "webserver.https", "HTTPS setting not seen in pasted text",
              "No webserver.https key appears in the paste, so the HTTPS posture cannot be confirmed from this text.",
              "Verify separately that HTTPS is enabled on the server; do not assume it from this paste.");
          }

          // --- 3. Signup ---
          var su = byPath("signup.enabled");
          var signupOn = !!(su && truthy(su.value));
          if (signupOn) {
            var ver = byPath("signup.requires_email_verification");
            if (!ver || falsy(ver.value)) {
              add("CRITICAL", ver ? ver.line : su.line, "signup.requires_email_verification", "Open signup without email verification",
                "Public signup is enabled and email verification is off or not set, so anyone — including bots — can register accounts with unverified addresses.",
                "Set signup.requires_email_verification to true, or disable signup and invite users manually.");
            } else {
              add("HIGH", su.line, "signup.enabled", "Public signup is enabled",
                "Anyone on the internet can register an account on this instance.",
                "Disable signup unless the instance is meant to be public, and keep email verification and a signup limit in place.");
            }
            var lim = byPath("signup.limit");
            if (!lim) {
              add("WARNING", su.line, "signup.limit", "No signup limit seen",
                "Signup is enabled but no signup.limit appears in the paste, so registrations may be unbounded.",
                "Set a signup.limit that matches the size of instance you intend to run.");
            } else {
              var n = parseInt(lim.value, 10);
              if (!isNaN(n) && n > 1000) {
                add("WARNING", lim.line, "signup.limit", "Signup limit is very high",
                  "The signup limit is " + lim.value + ", which allows mass registration if the instance is discovered by bots.",
                  "Lower signup.limit to a number you can actually moderate.");
              }
            }
          }

          // --- 4. Admin email (admin password handled by the secret scan) ---
          var ae = byPath("admin.email");
          if (recognized >= 3) {
            if (!ae || ae.value === "") {
              add("WARNING", ae ? ae.line : null, "admin.email", "Admin email not seen in pasted text",
                "No usable admin.email appears in the paste; PeerTube needs a real admin address for account recovery and system mail.",
                "Set admin.email to a mailbox you actually read.");
            } else if (/example\.(com|org|net)|changeme|@example/i.test(ae.value)) {
              add("HIGH", ae.line, "admin.email", "Admin email looks like a placeholder",
                "The admin email matches a placeholder/example pattern, so admin mail and recovery messages would go nowhere real.",
                "Set admin.email to a real mailbox you control.");
            }
          }

          // --- 6. Federation ---
          entries.forEach(function (e) {
            if (e.leaf === "auto_follow_back" && truthy(e.value)) {
              add("WARNING", e.line, e.path, "Auto follow-back is enabled",
                "The instance automatically follows back remote instances, which grows the federation surface without review.",
                "Turn auto follow-back off and approve followings deliberately.");
            }
            if (e.leaf === "manual_approval" && falsy(e.value)) {
              add("WARNING", e.line, e.path, "Follower manual approval is off",
                "Remote followers are accepted automatically, with no chance to review who federates with this instance.",
                "Enable manual approval for followers, or review the follower list regularly.");
            }
            if ((e.leaf.indexOf("allow_all") >= 0 && truthy(e.value)) ||
                (e.path.indexOf("federation") >= 0 && e.leaf === "restrictions" && e.value.toLowerCase() === "none")) {
              add("HIGH", e.line, e.path, "Federation safety explicitly opened up",
                "This setting removes federation restrictions, so the instance will federate with anyone by default.",
                "Restore federation restrictions and allow-list deliberately.");
            }
          });

          // --- 7. Transcoding / live ---
          var te = byPath("transcoding.enabled");
          if (te && truthy(te.value)) {
            var th = byPath("transcoding.threads");
            if (!th) {
              add("WARNING", te.line, "transcoding.threads", "No transcoding thread limit seen",
                "Transcoding is enabled but no thread limit appears in the paste, so a transcoding burst can consume every CPU core on the host.",
                "Set transcoding.threads to a bounded number that leaves CPU for the app itself.");
            } else if (th.value === "0") {
              add("WARNING", th.line, "transcoding.threads", "Transcoding threads set to 0 (unbounded)",
                "A thread count of 0 lets transcoding use all available cores, which can starve the web app and database on the same host.",
                "Set transcoding.threads to a fixed number below the host's core count.");
            }
          }
          var le = byPath("live.enabled");
          if (le && truthy(le.value)) {
            var hasLimit = entries.some(function (e) { return e.path.indexOf("live") === 0 && /max|limit/.test(e.leaf); });
            if (!hasLimit) {
              add("WARNING", le.line, "live.enabled", "Live streaming enabled with no limits seen",
                "Live is on but no maximum duration or other live limit appears in the paste, so streams can run and store indefinitely.",
                "Set live limits (for example a max duration) that match your storage and moderation capacity.");
            }
          }
          var rtmp = null;
          entries.forEach(function (e) { if (!rtmp && e.path.indexOf("rtmp") >= 0 && e.leaf === "port") rtmp = e; });
          if (rtmp) {
            add("INFO", rtmp.line, rtmp.path, "RTMP ingest port is configured",
              "An RTMP port is set for live ingest. It only needs to be reachable by people who stream to this instance.",
              "Firewall the RTMP port to trusted streamers where you can.");
          }

          // --- 8. Object storage endpoint ---
          entries.forEach(function (e) {
            if (e.leaf === "endpoint" && /(storage|s3)/.test(e.path) && /^http:\/\//i.test(e.value)) {
              add("HIGH", e.line, e.path, "Object storage endpoint uses plain HTTP",
                "The S3 endpoint is http://, so video traffic and signed requests to object storage cross the network unencrypted.",
                "Use the https:// endpoint for your object storage provider.");
            }
          });

          // --- 9. SMTP ---
          var smtpHost = byPath("smtp.hostname");
          if (signupOn && !smtpHost && recognized >= 3) {
            add("WARNING", su.line, "smtp.hostname", "Signup enabled but no SMTP hostname seen",
              "Signup is on, but no smtp.hostname appears in the paste, so verification and notification mail may never leave the server.",
              "Configure smtp.hostname (and credentials by reference) before opening signup.");
          }
          var stls = byPath("smtp.tls");
          if (stls && falsy(stls.value)) {
            add("HIGH", stls.line, "smtp.tls", "SMTP TLS is disabled",
              "Mail — including password resets and verification links — is sent without TLS.",
              "Set smtp.tls to true.");
          }
          var dstart = byPath("smtp.disable_starttls");
          if (dstart && truthy(dstart.value)) {
            add("HIGH", dstart.line, "smtp.disable_starttls", "SMTP STARTTLS is disabled",
              "disable_starttls is true, so the connection to the mail server is not upgraded to encryption — mail credentials and message contents can cross the network in plaintext.",
              "Set smtp.disable_starttls to false so STARTTLS stays on.");
          }

          // --- 10. Log level ---
          var ll = byPath("log.level");
          if (ll) {
            var lv = ll.value.toLowerCase();
            if (lv === "debug" || lv === "trace") {
              add("WARNING", ll.line, "log.level", "Verbose log level (" + lv + ")",
                "Debug/trace logging is verbose enough to record request details and tokens that should not sit in log files.",
                "Run production at log.level info or warn.");
            } else if (["info", "warn", "warning", "error"].indexOf(lv) >= 0) {
              add("INFO", ll.line, "log.level", "Log level is sensible",
                "The log level is " + lv + ", a normal production setting.",
                "No change needed.");
            }
          }

          // --- 11. Contact form / instance ---
          var cf = byPath("contact_form.enabled");
          if (cf && truthy(cf.value)) {
            var hasRate = entries.some(function (e) { return /rate.?limit/.test(e.path); });
            if (!hasRate) {
              add("WARNING", cf.line, "contact_form.enabled", "Contact form enabled with no rate limit seen",
                "The contact form is on and no rate-limit key appears in the paste, which makes the form an easy spam relay.",
                "Put the contact form behind rate limiting or a captcha.");
            } else {
              add("INFO", cf.line, "contact_form.enabled", "Contact form enabled with rate limiting present",
                "A rate-limit key appears alongside the contact form in the paste.",
                "No change needed.");
            }
          }
          if (recognized >= 3) {
            var iname = byPath("instance.name");
            var idesc = byPath("instance.description");
            if (!iname) {
              add("INFO", null, "instance.name", "Instance name not seen in pasted text",
                "No instance.name appears in the paste; the instance will present a default identity to visitors and federation peers.",
                "Set instance.name and instance.description before announcing the instance.");
            } else if (!idesc) {
              add("INFO", iname.line, "instance.description", "Instance description not seen in pasted text",
                "The instance has a name but no description in the paste.",
                "Add a short instance.description so visitors and peers know what the instance is for.");
            }
          }

          // --- 12. Missing important sections ---
          if (recognized >= 3) {
            if (!hasSection("webserver")) {
              add("WARNING", null, "webserver", "Webserver section not seen in pasted text — verify separately",
                "No webserver keys appear in this paste. That only means they are not in the pasted text, not that they are missing on the server.",
                "Paste the full config, or verify the webserver section on the host separately.");
            }
            if (!hasSection("database") && !hasSection("datasources")) {
              add("WARNING", null, "database", "Database section not seen in pasted text — verify separately",
                "No database keys appear in this paste. That only means they are not in the pasted text, not that they are missing on the server.",
                "Paste the full config, or verify the database section on the host separately.");
            }
          }

          var rank = { CRITICAL: 0, HIGH: 1, WARNING: 2, INFO: 3 };
          findings.sort(function (a, b) {
            if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
            var la = a.line == null ? 999999 : a.line;
            var lb = b.line == null ? 999999 : b.line;
            if (la !== lb) return la - lb;
            return a.key < b.key ? -1 : (a.key > b.key ? 1 : 0);
          });

          var counts = { CRITICAL: 0, HIGH: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict;
          if (recognized < 3) verdict = "NOT ENOUGH TO GRADE";
          else if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
          else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return {
            verdict: verdict,
            counts: counts,
            findings: findings,
            totalLines: parsed.totalLines,
            parsedKeys: parsed.entries.length,
            notParsed: parsed.notParsed,
            recognized: recognized
          };
        }

        function redact(s) {
          var out = s;
          secretValues.forEach(function (v) {
            if (v && v.length >= 4) out = out.split(v).join("[value hidden]");
          });
          return out;
        }

        function buildTextReport(r) {
          var lines = [];
          lines.push("J-Dawgs PeerTube Server Config Safety Auditor™ — text report");
          lines.push("Verdict: " + r.verdict);
          lines.push("Lines: " + r.totalLines + " total · " + r.parsedKeys + " parsed keys · " + r.notParsed.length + " not parsed · " + r.recognized + " PeerTube keys recognized");
          lines.push("Findings: CRITICAL " + r.counts.CRITICAL + " · HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO);
          lines.push("");
          if (r.findings.length === 0) lines.push("No findings.");
          r.findings.forEach(function (f) {
            lines.push("[" + f.severity + (f.blocker ? " · BLOCKER" : "") + "] " + (f.line == null ? "Not in paste" : "Line " + f.line) + " — " + f.key + " — " + f.title + (f.valueLength != null ? " (secret length: " + f.valueLength + " characters)" : ""));
            lines.push("  " + f.explanation);
            lines.push("  Fix: " + f.fix);
          });
          lines.push("");
          lines.push("NOT PARSED lines: " + (r.notParsed.length ? r.notParsed.join(", ") : "none"));
          return redact(lines.join("\n"));
        }

        function buildJSON(r) {
          var obj = {
            tool: "J-Dawgs PeerTube Server Config Safety Auditor™",
            verdict: r.verdict,
            counts: {
              totalLines: r.totalLines,
              parsedKeys: r.parsedKeys,
              notParsed: r.notParsed.length,
              recognizedPeerTubeKeys: r.recognized,
              bySeverity: r.counts
            },
            findings: r.findings.map(function (f) {
              var o = {
                severity: f.severity,
                blocker: f.blocker,
                line: f.line,
                key: f.key,
                title: f.title,
                explanation: f.explanation,
                fix: f.fix
              };
              if (f.valueLength != null) o.secretValueLength = f.valueLength;
              return o;
            }),
            notParsed: r.notParsed.slice()
          };
          return redact(JSON.stringify(obj, null, 2));
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-peertube-server-config-safety-auditortm',
  name: 'J-Dawgs PeerTube Server Config Safety Auditor',
  description: 'Grades a pasted PeerTube server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — short or example secrets, plaintext database and Redis passwords, and federation, streaming, and bind posture, with secrets shown by key name, lin',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
