'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs HAProxy Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      // ---------------- Worked examples ----------------
      var RISKY_EXAMPLE = [
        '# haproxy.cfg - storefront (production?)',
        'global',
        '    log /dev/log local0',
        '    maxconn 4096',
        '    stats socket /run/haproxy/admin.sock level admin',
        '    daemon',
        '',
        'defaults',
        '    mode http',
        '    timeout connect 5s',
        '    timeout client 30s',
        '    # note: no timeout server anywhere in this file',
        '',
        'frontend web_in',
        '    bind *:80',
        '    bind *:443 ssl crt /etc/haproxy/certs/site.pem',
        '    default_backend app_servers',
        '',
        'backend app_servers',
        '    balance roundrobin',
        '    server app1 10.0.0.11:80',
        '    server app2 10.0.0.12:443 ssl ssl-verify none',
        '',
        'listen stats_page',
        '    bind *:8404',
        '    stats enable',
        '    stats uri /stats',
        '    stats refresh 10s',
        '',
        'userlist admins',
        '    user jdoe insecure-password EXAMPLE-ONLY-not-a-real-password'
      ].join('\n');

      var CLEAN_EXAMPLE = [
        '# haproxy.cfg - hardened storefront',
        'global',
        '    log /dev/log local0',
        '    maxconn 4096',
        '    stats socket /run/haproxy/admin.sock mode 660 level admin user haproxy group haproxy',
        '    ssl-default-bind-options ssl-min-ver TLSv1.2 no-tls-tickets',
        '    daemon',
        '',
        'defaults',
        '    mode http',
        '    timeout connect 5s',
        '    timeout client 30s',
        '    timeout server 30s',
        '    option httplog',
        '',
        'frontend web_in',
        '    bind 203.0.113.10:80',
        '    bind 203.0.113.10:443 ssl crt /etc/haproxy/certs/site.pem ssl-min-ver TLSv1.2',
        '    http-request deny if { path_beg /admin } !{ src 127.0.0.1 }',
        '    default_backend app_servers',
        '',
        'backend app_servers',
        '    balance leastconn',
        '    option httpchk GET /healthz',
        '    server app1 10.0.0.11:8443 ssl verify required ca-file /etc/haproxy/ca.pem check',
        '    server app2 10.0.0.12:8443 ssl verify required ca-file /etc/haproxy/ca.pem check'
      ].join('\n');

      // ---------------- Parser ----------------
      var SECTION_TYPES = {
        'global': 1, 'defaults': 1, 'frontend': 1, 'backend': 1, 'listen': 1,
        'resolvers': 1, 'peers': 1, 'userlist': 1, 'mailers': 1, 'cache': 1,
        'program': 1, 'ring': 1, 'log-forward': 1, 'http-errors': 1,
        'fcgi-app': 1, 'crt-store': 1
      };
      var DIRECTIVES = {};
      ('log maxconn daemon user group chroot pidfile stats nbproc nbthread cpu-map mode timeout option bind server default-server default_backend acl balance cookie redirect errorfile errorfiles retries monitor-uri monitor stick-table stick tcp-request tcp-response http-request http-response http-check http-after-response use_backend capture description enabled disabled external-check insecure-fork-wanted nosplice spread-checks source dispatch fullconn persist redispatch setenv presetenv master-worker nameserver server-state-file-name load-server-state-from-file http-reuse grace hard-stop-after seamless-mreload quiet zero-warning ca-base crt-base key-base anonkey thread-groups setcap expose-external-errors ssl-engine ssl-mode-async resolve-prefer resolve-net resolve-opts parse-resolv-conf hold valid none default ca-file crt verify required stick store-request unique-id hash-type errorloc errorloc302 errorloc303 warning-file environment extra-ssl-options no-sslv3 process strict-limits num-stats-sockets')
        .split(/\s+/)
        .forEach(function (w) { DIRECTIVES[w] = 1; });

      function isDirective(tok) {
        if (DIRECTIVES[tok]) return true;
        if (/^(ssl-|tune\.|http-|tcp-|fcgi-|log-)/.test(tok)) return true;
        if (tok.indexOf('.') > 0) return true; // dotted global options, e.g. tune.ssl.*
        return false;
      }

      function stripComment(line) {
        var i = line.indexOf('#');
        return i === -1 ? line : line.slice(0, i);
      }

      function parseConfig(text) {
        var sections = [];
        var notParsed = [];
        var current = null;
        var rawLines = text.split(/\r?\n/);
        for (var i = 0; i < rawLines.length; i++) {
          var num = i + 1;
          var raw = rawLines[i];
          var code = stripComment(raw).trim();
          if (!code) continue;
          var tok = code.split(/\s+/)[0].toLowerCase();
          var indented = /^\s/.test(raw);
          if (!indented && SECTION_TYPES[tok]) {
            var parts = code.split(/\s+/);
            current = { type: tok, name: parts[1] || '', headerLine: num, lines: [] };
            sections.push(current);
            continue;
          }
          if (indented) {
            if (!current) {
              notParsed.push({ line: num, reason: 'Line appears before any section header, so it cannot be placed in a section. It was not audited.' });
            } else if (current.type !== '__unknown__') {
              current.lines.push({ num: num, code: code });
            }
            continue;
          }
          // Flush-left line that is not a section header.
          if (isDirective(tok)) {
            if (!current) {
              notParsed.push({ line: num, reason: 'Directive appears outside any section. It was not audited.' });
            } else if (current.type !== '__unknown__') {
              current.lines.push({ num: num, code: code });
            }
            continue;
          }
          notParsed.push({ line: num, reason: 'Unrecognized section header. This block was not parsed and its lines were not audited.' });
          current = { type: '__unknown__', name: '', headerLine: num, lines: [] };
        }
        return { sections: sections, notParsed: notParsed };
      }

      // ---------------- Helpers ----------------
      function bindClass(addrTok) {
        if (!addrTok) return 'public';
        if (addrTok.charAt(0) === '/') return 'local'; // unix socket
        var host;
        if (addrTok.charAt(0) === '[') {
          var end = addrTok.indexOf(']');
          host = end === -1 ? addrTok : addrTok.slice(1, end);
        } else {
          var idx = addrTok.lastIndexOf(':');
          host = idx === -1 ? addrTok : addrTok.slice(0, idx);
        }
        if (host === '' || host === '*' || host === '0.0.0.0' || host === '::') return 'public';
        if (host === '127.0.0.1' || host === '::1' || host.toLowerCase() === 'localhost') return 'local';
        if (/^127\./.test(host)) return 'local';
        return 'public';
      }

      function isProxyType(t) { return t === 'frontend' || t === 'backend' || t === 'listen'; }
      function sectionLabel(s) { return s.name ? (s.type + ' "' + s.name + '"') : ('the ' + s.type + ' section'); }
      function timeoutsOf(s) {
        var t = {};
        s.lines.forEach(function (l) {
          var m = l.code.match(/^timeout\s+(connect|client|server)\b/);
          if (m) t[m[1]] = true;
        });
        return t;
      }

      // ---------------- Audit ----------------
      function auditConfig(text) {
        var parsed = parseConfig(text);
        var sections = parsed.sections;
        var notParsed = parsed.notParsed;
        var blockers = [], warnings = [], infos = [];
        function B(line, msg) { blockers.push({ line: line, msg: msg }); }
        function W(line, msg) { warnings.push({ line: line, msg: msg }); }
        function I(line, msg) { infos.push({ line: line, msg: msg }); }

        // Global minimum-TLS posture (ssl-default-bind-options / -server-options).
        var globalMinTls = false;
        sections.forEach(function (s) {
          if (s.type !== 'global') return;
          s.lines.forEach(function (l) {
            if (/^ssl-default-(bind|server)-options\b/.test(l.code) && /(ssl-min-ver|no-tlsv10|no-tlsv11)/.test(l.code)) globalMinTls = true;
          });
        });

        // (1a) Stats socket with admin level.
        sections.forEach(function (s) {
          s.lines.forEach(function (l) {
            var m = l.code.match(/^stats\s+socket\s+(\S+)([\s\S]*)$/);
            if (!m) return;
            var rest = m[2] || '';
            if (!/\blevel\s+admin\b/.test(rest)) return;
            var restricted = /\bmode\s+\d{3,4}\b/.test(rest) || /\buser\s+\S+/.test(rest) || /\bgroup\s+\S+/.test(rest);
            if (restricted) {
              I(l.num, 'Stats socket runs at admin level, but mode/user/group restrictions are stated on the line, so access is limited to the named local accounts. Keep those permissions tight — admin level can reconfigure HAProxy at runtime.');
            } else {
              B(l.num, 'Admin-level stats socket with no permission restriction stated on the line. Anyone who can reach this socket can reconfigure HAProxy at runtime. Add mode/user/group restrictions, or drop it to "level operator".');
            }
          });
        });

        // (3) Timeouts: defaults first, then each proxy (never double-report a gap defaults already owns).
        var REQ = ['connect', 'client', 'server'];
        var defaultsSec = null;
        sections.forEach(function (s) { if (s.type === 'defaults' && !defaultsSec) defaultsSec = s; });
        var defaultsTimeouts = defaultsSec ? timeoutsOf(defaultsSec) : {};
        var defaultsMissing = [];
        if (defaultsSec) {
          REQ.forEach(function (r) {
            if (!defaultsTimeouts[r]) {
              defaultsMissing.push(r);
              W(defaultsSec.headerLine, 'Missing timeout: the defaults section never sets "timeout ' + r + '", and no proxy supplies its own. Until one is set, stalled ' + r + '-side connections can be held far longer than intended.');
            }
          });
        }
        sections.forEach(function (s) {
          if (!isProxyType(s.type)) return;
          var own = timeoutsOf(s);
          REQ.forEach(function (r) {
            if (!own[r] && !defaultsTimeouts[r] && defaultsMissing.indexOf(r) === -1) {
              W(s.headerLine, 'Missing timeout: ' + sectionLabel(s) + ' never sets "timeout ' + r + '", and defaults does not supply one either.');
            }
          });
        });

        // Per-proxy checks.
        sections.forEach(function (s) {
          if (!isProxyType(s.type)) return;

          var binds = [];
          s.lines.forEach(function (l) {
            var bm = l.code.match(/^bind\s+(\S+)/);
            if (bm) binds.push({ num: l.num, addr: bm[1], cls: bindClass(bm[1]) });
          });
          var publicBinds = binds.filter(function (b) { return b.cls === 'public'; });

          // (1b) Stats enabled / stats URI in this section.
          var statsEnableLine = 0, statsUri = false, statsAuth = false;
          s.lines.forEach(function (l) {
            if (/^stats\s+enable\b/.test(l.code) && !statsEnableLine) statsEnableLine = l.num;
            if (/^stats\s+uri\b/.test(l.code)) statsUri = true;
            if (/^stats\s+auth\b/.test(l.code)) statsAuth = true;
            if (/^http-request\s+auth\b/.test(l.code)) statsAuth = true;
          });
          if ((statsEnableLine || statsUri) && !statsAuth) {
            var at = statsEnableLine || s.headerLine;
            if (publicBinds.length) {
              B(at, 'Stats are enabled in ' + sectionLabel(s) + ' with no "stats auth", and this section binds a public address (' + publicBinds[0].addr + '). The stats page — including runtime admin actions if admin mode is on — is reachable from the network. Add "stats auth", or bind stats to 127.0.0.1 only.');
            } else if (binds.length) {
              W(at, 'Stats are enabled in ' + sectionLabel(s) + ' with no "stats auth". The bind looks local, which limits exposure, but any local account or compromised process can still read full traffic statistics. Add "stats auth".');
            } else {
              W(at, 'Stats are enabled in ' + sectionLabel(s) + ' with no "stats auth" and no bind line to judge exposure from. Add "stats auth" or restrict the bind to a local address.');
            }
          }
          // (1c) stats admin if TRUE.
          s.lines.forEach(function (l) {
            if (/^stats\s+admin\s+if\s+TRUE\s*$/i.test(l.code)) {
              if (publicBinds.length) {
                B(l.num, '"stats admin if TRUE" turns on stats admin actions unconditionally in a publicly bound section — anyone who can reach the stats page can change runtime configuration. Gate it behind a restrictive ACL.');
              } else {
                W(l.num, '"stats admin if TRUE" turns on stats admin actions unconditionally. Gate it behind a restrictive ACL so only trusted sources get admin actions.');
              }
            }
          });

          // (2a) TLS binds with no minimum TLS version.
          s.lines.forEach(function (l) {
            if (!/^bind\s/.test(l.code)) return;
            var toks = l.code.split(/\s+/);
            if (toks.indexOf('ssl') === -1) return;
            if (/(ssl-min-ver|no-tlsv10|no-tlsv11)/.test(l.code)) return;
            if (globalMinTls) return;
            W(l.num, 'TLS bind with no minimum TLS version stated: neither this bind line nor a global "ssl-default-bind-options" sets "ssl-min-ver" (or no-tlsv10 / no-tlsv11), so obsolete protocol versions may still be negotiated. State "ssl-min-ver TLSv1.2" or higher.');
          });

          // Server lines.
          var serverLines = s.lines.filter(function (l) { return /^server\s+\S+\s+\S+/.test(l.code); });
          serverLines.forEach(function (l) {
            var toks = l.code.split(/\s+/);
            var svIdx = toks.indexOf('ssl-verify');
            var verifyNone = (svIdx !== -1 && toks[svIdx + 1] === 'none') || /\bverify\s+none\b/.test(l.code);
            if (verifyNone) {
              W(l.num, 'Backend server does not verify the upstream certificate ("ssl-verify none" / "verify none"). HAProxy will encrypt traffic to whatever answers — including an impostor. Verify against a CA file instead.');
            }
            var addr = toks[2] || '';
            var pIdx = addr.lastIndexOf(':');
            var port = pIdx === -1 ? '' : addr.slice(pIdx + 1);
            if (toks.indexOf('ssl') !== -1 && ['80', '8080', '8000', '8888'].indexOf(port) !== -1) {
              I(l.num, 'This server line sets the "ssl" flag but points at port ' + port + ', which is normally a plain-HTTP port. Text alone cannot prove that is wrong — if that port genuinely speaks TLS, ignore this note; if not, the TLS handshake will fail.');
            }
          });

          // (6) Balance + health checks for backends / listens that have servers.
          if ((s.type === 'backend' || s.type === 'listen') && serverLines.length) {
            var hasBalance = s.lines.some(function (l) { return /^balance\s+\S+/.test(l.code); });
            if (!hasBalance) {
              I(s.headerLine, 'No "balance" algorithm stated in ' + sectionLabel(s) + ' — HAProxy silently falls back to roundrobin. Fine if that is intended; stating it explicitly makes the choice reviewed instead of accidental.');
            }
            var hasChkOption = s.lines.some(function (l) {
              return /^option\s+(httpchk|tcp-check|smtpchk|mysql-check|pgsql-check|redis-check|ldap-check|external-check)\b/.test(l.code) || /^http-check\b/.test(l.code);
            });
            var hasServerCheck = serverLines.some(function (l) { return l.code.split(/\s+/).indexOf('check') !== -1; });
            if (!hasChkOption && !hasServerCheck) {
              W(s.headerLine, 'No health checks in ' + sectionLabel(s) + ': no "option httpchk" (or equivalent) and no "check" on any server line, so a dead backend keeps receiving traffic until clients notice. Add checks so failed servers are pulled automatically.');
            }
          }

          // (5) Public frontend with no deny/auth rule — posture note.
          if (s.type === 'frontend' && publicBinds.length) {
            var guard = s.lines.some(function (l) {
              return /^http-request\s+(deny|auth|tarpit)\b/.test(l.code) ||
                     /^http-response\s+deny\b/.test(l.code) ||
                     /^tcp-request\s+content\s+reject\b/.test(l.code);
            });
            if (!guard) {
              W(publicBinds[0].num, 'Posture note — not proof of exposure: ' + sectionLabel(s) + ' binds a public address (' + publicBinds[0].addr + ') and sets no http-request deny or auth rule, so everything routed here is reachable exactly as configured. If any part of this frontend should be restricted, add an auth/deny rule or bind a private address.');
            }
          }
        });

        // (4) Secrets — flagged by key name only. Values are never copied into any message.
        sections.forEach(function (s) {
          s.lines.forEach(function (l) {
            if (/^stats\s+auth\s+\S+/.test(l.code)) {
              W(l.num, 'Credential written in plain text under the key "stats auth": the credentials sit in the config file itself. (The value is never shown in this audit or its report.) Prefer protecting the stats page by bind address plus a credential held outside the config, and restrict who can read this file.');
              return;
            }
            var imp = l.code.match(/\binsecure-password\s+(\S+)/);
            if (imp) {
              W(l.num, 'Credential written in plain text under the key "insecure-password": anyone who can read this config has the password. (The value is never shown in this audit or its report.) Use a hashed password entry or an external secret store.');
              return;
            }
            var pm = l.code.match(/\bpassword\s+(\S+)/);
            if (pm && pm[1].charAt(0) !== '$') {
              W(l.num, 'Literal value written under the key "password": if that value is a real password rather than a hash, it is exposed to anyone who can read this config. (The value is never shown in this audit or its report.) Store a hash or move the secret out of the file.');
            }
          });
        });

        function byLine(a, b) { return a.line - b.line; }
        blockers.sort(byLine); warnings.sort(byLine); infos.sort(byLine);
        notParsed.sort(function (a, b) { return a.line - b.line; });

        var verdict, verdictClass, verdictWhy;
        if (blockers.length) {
          verdict = 'DO NOT DEPLOY'; verdictClass = 'blocker';
          verdictWhy = blockers.length + ' blocker finding' + (blockers.length === 1 ? '' : 's') + ' must be fixed before this config goes live.';
        } else if (warnings.length || notParsed.length) {
          verdict = 'DEPLOY WITH FIXES'; verdictClass = 'warning';
          verdictWhy = 'No blockers, but ' +
            (warnings.length ? warnings.length + ' warning' + (warnings.length === 1 ? '' : 's') + ' to fix' : 'no warnings') +
            (notParsed.length ? ', and ' + notParsed.length + ' line' + (notParsed.length === 1 ? '' : 's') + ' could not be parsed and so could not be vouched for' : '') + '.';
        } else {
          verdict = 'SAFE TO DEPLOY'; verdictClass = 'safe';
          verdictWhy = 'No blocker or warning findings in the pasted text. Still run haproxy -c on the server before deploying — this audit grades safety, not syntax.';
        }
        return {
          verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
          blockers: blockers, warnings: warnings, infos: infos, notParsed: notParsed
        };
      }

      // ---------------- Report ----------------
      function buildReport(r) {
        var out = [];
        out.push('J-DAWGS HAPROXY CONFIG SAFETY AUDITOR - REPORT');
        out.push('Verdict: ' + r.verdict);
        out.push('Findings: ' + r.blockers.length + ' BLOCKER / ' + r.warnings.length + ' WARNING / ' + r.infos.length + ' INFO / ' + r.notParsed.length + ' NOT PARSED');
        out.push('');
        function group(title, items, fmt) {
          out.push(title + ' (' + items.length + ')');
          if (!items.length) { out.push('  None.'); }
          items.forEach(function (f) { out.push(fmt(f)); });
          out.push('');
        }
        group('BLOCKER', r.blockers, function (f) { return '  Line ' + f.line + ' - ' + f.msg; });
        group('WARNING', r.warnings, function (f) { return '  Line ' + f.line + ' - ' + f.msg; });
        group('INFO', r.infos, function (f) { return '  Line ' + f.line + ' - ' + f.msg; });
        group('NOT PARSED (structure that could not be read; those lines were not checked)', r.notParsed, function (f) { return '  Line ' + f.line + ' - ' + f.reason; });
        out.push('Limits: text audit only; not a replacement for haproxy -c. This audit cannot see certificate contents, ACL or map file contents, included files, or runtime state. Secret values are never included in this report - findings name the key only.');
        return out.join('\n');
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-haproxy-config-safety-auditortm',
  name: 'J-Dawgs HAProxy Config Safety Auditor',
  description: 'HAProxy’s own config test needs a live binary and a deploy target; ours grades a pasted haproxy.cfg anywhere for deploy safety — stats exposure, TLS posture, missing timeouts, and secrets surfaced by key name only — into one verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
