# Test results — BotDawg Tool Library Pack

Every CALLABLE module below was loaded headlessly in Node and run with a real input:
the tool's own shipped RISKY/HARDENED worked examples where the page carries them,
otherwise one of its shipped examples, otherwise a generic probe input. A module that
failed was reclassified OPEN-ONLY and is listed in the failures section with its error.

## Callable — passed (400)

| Tool | Entry | Test input | Result |
|---|---|---|---|
| j-dawgs-accessibility-pre-flight-auditor | audit | example-probe: `EXAMPLE_A` | PASS — DO NOT SHIP — ACCESS BARRIERS PRESENT — 7 finding(s) |
| j-dawgs-activemq-artemis-broker-config-safety-auditortm | analyze | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-activemq-artemis-broker-config-safety-auditortm | analyze | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-actual-budget-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-adguard-home-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-affine-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-affine-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-agent-failure-postmortem-builder | analyze | risky-example: `FAILED_SAMPLE` | PASS — done |
| j-dawgs-agent-failure-postmortem-builder | analyze | clean-example: `CLEAN_SAMPLE` | PASS — done |
| j-dawgs-airflow-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-alert-routing-amp-escalation-auditor | audit | generic-probe: `generic-probe` | PASS — ROUTING GAPS — 4 finding(s) |
| j-dawgs-alertmanager-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-ansible-playbook-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-apache-httpd-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-api-deprecation-sunset-radar | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-apisix-gateway-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-appsmith-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-appsmith-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 9 finding(s) |
| j-dawgs-appwrite-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-arangodb-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-arangodb-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-arangodb-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-arangodb-server-config-safety-auditortm-3 | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 1 finding(s) |
| j-dawgs-asterisk-pbx-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 3 finding(s) |
| j-dawgs-audiobookshelf-server-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-audiobookshelf-server-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 8 finding(s) |
| j-dawgs-authelia-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-authentik-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-baserow-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-bazarr-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-bazarr-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — DEPLOY WITH FIXES — 2 finding(s) |
| j-dawgs-beets-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — RUN WITH FIXES — 4 finding(s) |
| j-dawgs-beszel-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-bibtex-bibliography-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — READY TO CITE — 0 finding(s) |
| j-dawgs-bind-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO_NOT_DEPLOY — 10 finding(s) |
| j-dawgs-bind-named-conf-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — OPEN RESOLVER — 6 finding(s) |
| j-dawgs-bind9-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-blocky-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 11 finding(s) |
| j-dawgs-bookkeeper-bookie-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-bookkeeper-bookie-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-bookstack-server-config-safety-auditor | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-bug-report-reproducibility-auditor | audit | example-probe: `WEAK_EXAMPLE` | PASS — NOT REPRODUCIBLE YET |
| j-dawgs-bundler-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done — 0 finding(s) |
| j-dawgs-caddy-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-caddy-server-config-safety-auditor-2 | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-caddy-server-config-safety-auditor-2 | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-calendar-invite-integrity-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT IMPORT |
| j-dawgs-calendar-invite-meeting-readiness-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — READY TO SEND — 1 finding(s) |
| j-dawgs-calibre-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-calibre-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-cargo-toml-dependency-publish-auditor | audit | generic-probe: `generic-probe` | PASS — COULD NOT AUDIT — 2 finding(s) |
| j-dawgs-cassandra-cluster-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-changedetection-io-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-changelog-quality-auditor | audit | generic-probe: `generic-probe` | PASS — READY TO RELEASE — 1 finding(s) |
| j-dawgs-chatwoot-server-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-chatwoot-server-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-chrony-ntp-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-chrony-ntp-config-safety-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-chunk-boundary-damage-bench | analyze | example-probe: `EXAMPLE_DOC` | PASS — DAMAGE HEAVY |
| j-dawgs-clickhouse-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-cockroachdb-node-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-cockroachdb-node-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-concrete-installation-proposal-work-record-final-invoice-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — DONOTPAY |
| j-dawgs-concrete-proposal-work-record-final-invoice-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-connector-credential-egress-verifier | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-consent-scope-auditor | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-consul-agent-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 8 finding(s) |
| j-dawgs-container-build-safety-auditor | audit | risky-example: `BAD_EXAMPLE` | PASS — DO NOT BUILD — 10 finding(s) |
| j-dawgs-container-build-safety-auditor | audit | clean-example: `GOOD_EXAMPLE` | PASS — SAFE TO BUILD — 0 finding(s) |
| j-dawgs-coolify-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 2 finding(s) |
| j-dawgs-coredns-corefile-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-coredns-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT SERVE — 13 finding(s) |
| j-dawgs-coredns-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO SERVE — 12 finding(s) |
| j-dawgs-coturn-turn-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-couchbase-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-couchdb-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-couchdb-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-csv-tabular-integrity-auditor | audit | clean-example: `CLEAN_SAMPLE` | PASS — CLEAN ENOUGH TO USE — 0 finding(s) |
| j-dawgs-cups-print-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 7 finding(s) |
| j-dawgs-curl-command-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-curl-command-safety-translator | analyze | risky-example: `BAD_SAMPLE` | PASS — SAFE TO RUN — 1 finding(s) |
| j-dawgs-curl-command-safety-translator | analyze | clean-example: `GOOD_SAMPLE` | PASS — SAFE TO RUN — 1 finding(s) |
| j-dawgs-dashy-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 2 finding(s) |
| j-dawgs-decision-log-reversal-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — LOG HOLDS UP |
| j-dawgs-deck-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-deck-patio-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 1 finding(s) |
| j-dawgs-directus-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-direnv-envrc-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-discourse-app-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-discourse-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 13 finding(s) |
| j-dawgs-discourse-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 10 finding(s) |
| j-dawgs-dns-record-pre-flight-auditor | audit | risky-example: `BAD_SAMPLE` | PASS — DO NOT PUBLISH — 6 finding(s) |
| j-dawgs-dns-record-pre-flight-auditor | audit | clean-example: `CLEAN_SAMPLE` | PASS — SAFE TO PUBLISH — 0 finding(s) |
| j-dawgs-dnscrypt-proxy-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT SERVE — 15 finding(s) |
| j-dawgs-dnscrypt-proxy-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO SERVE — 6 finding(s) |
| j-dawgs-dnsdist-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT SERVE — 6 finding(s) |
| j-dawgs-dnsmasq-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-dnsmasq-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-dnsmasq-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-docker-daemon-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 1 finding(s) |
| j-dawgs-dockge-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-dockge-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 2 finding(s) |
| j-dawgs-docmost-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-documenso-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-dovecot-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-dovecot-mail-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 8 finding(s) |
| j-dawgs-dragonflydb-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-dragonflydb-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 6 finding(s) |
| j-dawgs-druid-cluster-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-druid-cluster-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 8 finding(s) |
| j-dawgs-drupal-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-drupal-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 11 finding(s) |
| j-dawgs-dryer-vent-cleaning-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-drywall-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — SAFE TO PAY — 0 finding(s) |
| j-dawgs-drywall-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES |
| j-dawgs-elasticsearch-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-elasticsearch-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-elasticsearch-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-electrical-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-email-header-deliverability-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — done |
| j-dawgs-emby-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 19 finding(s) |
| j-dawgs-emby-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-employee-offboarding-access-revocation-auditor | audit | generic-probe: `generic-probe` | PASS — FULLY REVOKED |
| j-dawgs-emqx-broker-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-env-config-drift-auditor | audit | clean-example: `SAMPLE_CLEAN_ACTUAL` | PASS — SAFE TO DEPLOY |
| j-dawgs-env-file-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done — 5 finding(s) |
| j-dawgs-envoy-proxy-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT PARSED — 0 finding(s) |
| j-dawgs-epoxy-flooring-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE |
| j-dawgs-erpnext-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 15 finding(s) |
| j-dawgs-erpnext-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 9 finding(s) |
| j-dawgs-eslint-flat-config-auditor | audit | risky-example: `EXAMPLE_BAD_CONFIG` | PASS — DO NOT TRUST THIS GATE — 1 finding(s) |
| j-dawgs-eslint-flat-config-auditor | audit | clean-example: `EXAMPLE_GOOD_CONFIG` | PASS — DO NOT TRUST THIS GATE — 3 finding(s) |
| j-dawgs-etcd-cluster-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done — 7 finding(s) |
| j-dawgs-example-data-leak-detector | scan | example-probe: `EXAMPLE_TEXT` | PASS — done — 6 finding(s) |
| j-dawgs-exim-mail-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — OPEN RELAY RISK — 6 finding(s) |
| j-dawgs-exim-mail-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 7 finding(s) |
| j-dawgs-experiment-readout-ship-decision-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT SETTLED |
| j-dawgs-fail2ban-jail-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT ENABLE — 20 finding(s) |
| j-dawgs-fail2ban-jail-safety-auditortm | auditConfig | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO ENABLE — 2 finding(s) |
| j-dawgs-fencing-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH CORRECTIONS — 0 finding(s) |
| j-dawgs-few-shot-example-auditor | audit | clean-example: `CLEAN_EXAMPLES` | PASS — DO NOT SHIP YET — 1 finding(s) |
| j-dawgs-firefly-iii-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-fireplace-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES |
| j-dawgs-flink-cluster-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-flink-cluster-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-flooring-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT PAY YET — 1 finding(s) |
| j-dawgs-flowise-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-fluent-bit-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-fluent-bit-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-fluentd-log-collector-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-fluentd-log-collector-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-focalboard-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-forgejo-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done — 12 finding(s) |
| j-dawgs-formbricks-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-freeradius-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done — 1 finding(s) |
| j-dawgs-freeswitch-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-freeswitch-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-freshrss-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 1 finding(s) |
| j-dawgs-garage-door-proposal-work-record-final-invoice-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE |
| j-dawgs-generator-installation-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE |
| j-dawgs-geode-cluster-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-ghost-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-ghostfolio-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-ghostfolio-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 5 finding(s) |
| j-dawgs-gitea-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-github-actions-workflow-safety-auditor | audit | risky-example: `EXAMPLE_BAD` | PASS — done |
| j-dawgs-github-actions-workflow-safety-auditor | audit | clean-example: `EXAMPLE_CLEAN` | PASS — done |
| j-dawgs-gitlab-ci-pipeline-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-gitlab-runner-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-gitlab-runner-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-glitchtip-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-gotify-server-config-safety-auditortm | auditConfig | example-probe: `ENV_SAMPLE` | PASS — DO NOT DEPLOY — 2 finding(s) |
| j-dawgs-grafana-dashboard-json-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — IMPORT WITH FIXES — 4 finding(s) |
| j-dawgs-grafana-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-grafana-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-graylog-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 14 finding(s) |
| j-dawgs-graylog-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 12 finding(s) |
| j-dawgs-grist-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-grocy-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_SAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-grocy-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_SAMPLE` | PASS — SAFE TO DEPLOY — 9 finding(s) |
| j-dawgs-gutter-cleaning-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES — 1 finding(s) |
| j-dawgs-handoff-acknowledgement-checker | check | clean-example: `EXAMPLE_ACK_CLEAN` | PASS — DO NOT START |
| j-dawgs-haproxy-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY |
| j-dawgs-haproxy-config-safety-auditortm | auditConfig | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY |
| j-dawgs-harbor-registry-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-hasura-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 3 finding(s) |
| j-dawgs-hazelcast-cluster-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-headscale-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SERVE WITH FIXES — 3 finding(s) |
| j-dawgs-healthchecks-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-hedgedoc-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-helm-chart-pre-flight-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-home-assistant-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO RUN — 5 finding(s) |
| j-dawgs-homebox-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-homebox-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-homer-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-html-escaping-entity-safety-auditortm | audit | risky-example: `BROKEN_EXAMPLE` | PASS — DO NOT PUBLISH — ESCAPING RISKS — 5 finding(s) |
| j-dawgs-html-escaping-entity-safety-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO PUBLISH — 0 finding(s) |
| j-dawgs-http-response-header-safety-auditor | audit | risky-example: `EXAMPLE_BAD` | PASS — done — 6 finding(s) |
| j-dawgs-http-response-header-safety-auditor | audit | clean-example: `EXAMPLE_CLEAN` | PASS — done — 3 finding(s) |
| j-dawgs-idempotency-duplicate-action-guard | analyze | risky-example: `PROBLEM_SAMPLE` | PASS — done |
| j-dawgs-idempotency-duplicate-action-guard | analyze | clean-example: `CLEAN_SAMPLE` | PASS — done |
| j-dawgs-ignite-cluster-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-ignore-rule-publish-safety-auditor | evaluate | example-probe: `EXAMPLE_RULES` | PASS — done |
| j-dawgs-immich-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-immich-server-config-safety-auditortm-2 | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-immich-server-config-safety-auditortm-2 | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 2 finding(s) |
| j-dawgs-influxdb-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-influxdb-server-config-safety-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY — 8 finding(s) |
| j-dawgs-instruction-conflict-scanner | scan | clean-example: `CLEAN_SAMPLE` | PASS — done |
| j-dawgs-invisible-character-unicode-trap-sweepertm | scan | clean-example: `CLEAN_SAMPLE` | PASS — CLEAN — 0 finding(s) |
| j-dawgs-invoice-ninja-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-invoice-payment-details-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES — 5 finding(s) |
| j-dawgs-invoice-quote-payment-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — NO COMPARISON POSSIBLE — 1 finding(s) |
| j-dawgs-irrigation-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES — 2 finding(s) |
| j-dawgs-isc-dhcp-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-itinerary-booking-consistency-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — CONSISTENT — READY TO BOOK — 0 finding(s) |
| j-dawgs-jellyfin-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-jellyfin-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-jenkins-controller-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT RUN — 10 finding(s) |
| j-dawgs-jenkins-controller-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO RUN — 0 finding(s) |
| j-dawgs-jenkins-pipeline-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT RUN — 7 finding(s) |
| j-dawgs-jenkins-pipeline-safety-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO RUN — 1 finding(s) |
| j-dawgs-jitsi-meet-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 1 finding(s) |
| j-dawgs-joomla-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT PARSED — 1 finding(s) |
| j-dawgs-joplin-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 13 finding(s) |
| j-dawgs-joplin-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-json-damage-receipt | analyze | clean-example: `CLEAN_EXAMPLE` | PASS — done |
| j-dawgs-jsonpath-selector-pre-flight-auditor | evaluate | example-probe: `EXAMPLE_JSON` | PASS — done |
| j-dawgs-kamailio-sip-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 2 finding(s) |
| j-dawgs-karakeep-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-kavita-server-config-safety-auditortm | analyze | risky-example: `EXAMPLE_RISKY` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-kavita-server-config-safety-auditortm | analyze | clean-example: `EXAMPLE_HARDENED` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-kea-dhcp-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done — 1 finding(s) |
| j-dawgs-keycloak-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-keycloak-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-keycloak-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-kibana-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-kibana-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-knot-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-knot-resolver-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 3 finding(s) |
| j-dawgs-kong-gateway-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-kubeconfig-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT USE OR SHARE — 8 finding(s) |
| j-dawgs-kubeconfig-safety-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO USE — 0 finding(s) |
| j-dawgs-landscaping-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — PAY WITH CORRECTIONS — 0 finding(s) |
| j-dawgs-landscaping-quote-work-order-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 1 finding(s) |
| j-dawgs-librechat-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 5 finding(s) |
| j-dawgs-lidarr-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-link-list-pre-flight-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-linkding-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 5 finding(s) |
| j-dawgs-linkwarden-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-linkwarden-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 7 finding(s) |
| j-dawgs-listmonk-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-listmonk-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-livekit-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-log-flood-first-failure-triage | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-logrotate-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-logstash-pipeline-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-loki-log-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 5 finding(s) |
| j-dawgs-lychee-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-lychee-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-makefile-safety-silent-no-op-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT RUN — 1 finding(s) |
| j-dawgs-maradns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — SERVE WITH FIXES — 10 finding(s) |
| j-dawgs-mariadb-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 17 finding(s) |
| j-dawgs-markdown-anchor-link-auditor | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-mastodon-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-mastodon-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-mastodon-server-config-safety-auditortm-3 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-mattermost-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT PARSED — 1 finding(s) |
| j-dawgs-mautic-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-mcp-permission-auditor | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-mealie-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 5 finding(s) |
| j-dawgs-medusa-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-medusa-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 2 finding(s) |
| j-dawgs-meilisearch-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-meilisearch-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-memcached-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 10 finding(s) |
| j-dawgs-memcached-server-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-memos-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-menu-price-consistency-auditortm | audit | example-probe: `EXAMPLE_1` | PASS — DO NOT PUBLISH |
| j-dawgs-metabase-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-miniflux-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-miniflux-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-minio-object-storage-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-minio-object-storage-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-minio-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-mongodb-connection-string-safety-auditor | audit | generic-probe: `generic-probe` | PASS — COULD NOT PARSE — 1 finding(s) |
| j-dawgs-mongodb-server-config-safety-auditortm | auditConfig | risky-example: `EXAMPLE_RISKY` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-mongodb-server-config-safety-auditortm | auditConfig | clean-example: `EXAMPLE_HARDENED` | PASS — SAFE TO DEPLOY — 9 finding(s) |
| j-dawgs-mosquitto-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-mosquitto-mqtt-broker-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 11 finding(s) |
| j-dawgs-moving-service-estimate-work-record-final-invoice-consistency-auditortm | audit | risky-example: `EXAMPLE_BAD_ESTIMATE` | PASS — DO NOT PAY YET — 1 finding(s) |
| j-dawgs-moving-service-estimate-work-record-final-invoice-consistency-auditortm | audit | clean-example: `EXAMPLE_CLEAN_ESTIMATE` | PASS — DO NOT PAY YET — 1 finding(s) |
| j-dawgs-mysql-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-mysql-server-config-safety-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY — 7 finding(s) |
| j-dawgs-nats-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 7 finding(s) |
| j-dawgs-navidrome-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-neo4j-server-config-safety-auditortm | audit | risky-example: `EXAMPLE_RISKY` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-neo4j-server-config-safety-auditortm | audit | clean-example: `EXAMPLE_HARDENED` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-nextcloud-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-nextcloud-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 12 finding(s) |
| j-dawgs-nfs-exports-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — SHARE WITH FIXES — 4 finding(s) |
| j-dawgs-nginx-config-pre-flight-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-nginx-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-nifi-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 3 finding(s) |
| j-dawgs-nifi-server-config-safety-auditortm-2 | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-nifi-server-config-safety-auditortm-2 | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-nocobase-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-nocobase-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-nocodb-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 5 finding(s) |
| j-dawgs-nomad-agent-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-nomad-agent-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-npm-package-publish-pre-flight-auditor | audit | generic-probe: `generic-probe` | PASS — COULD NOT AUDIT — 1 finding(s) |
| j-dawgs-nsd-authoritative-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — SERVE WITH FIXES — 7 finding(s) |
| j-dawgs-ntfy-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-oauth-authorize-url-auditor | audit | risky-example: `BAD_SAMPLE` | PASS — DO NOT OPEN — 8 finding(s) |
| j-dawgs-oauth-authorize-url-safety-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-ollama-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-open-loop-abandoned-thread-detector | analyze | example-probe: `EXAMPLE` | PASS — done |
| j-dawgs-open-webui-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-openbao-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-opendkim-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — done — 0 finding(s) |
| j-dawgs-openldap-directory-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — notaudited — 0 finding(s) |
| j-dawgs-openldap-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-openldap-server-config-safety-auditortm-2 | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-openproject-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-openproject-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-openresty-server-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 13 finding(s) |
| j-dawgs-openresty-server-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 13 finding(s) |
| j-dawgs-opensearch-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-opensearch-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 2 finding(s) |
| j-dawgs-opensmtpd-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 6 finding(s) |
| j-dawgs-openssh-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 26 finding(s) |
| j-dawgs-opentelemetry-collector-config-auditor | auditConfig | clean-example: `CLEAN_EXAMPLE` | PASS — READY TO DEPLOY — 0 finding(s) |
| j-dawgs-opentelemetry-collector-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-outbound-reply-promise-commitment-auditor | analyze | example-probe: `EXAMPLE_FACTS` | PASS — done |
| j-dawgs-outline-server-config-safety-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-overseerr-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 14 finding(s) |
| j-dawgs-overseerr-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-package-hallucination-checker | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-painting-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-paperless-ngx-server-config-safety-auditor | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-parse-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 16 finding(s) |
| j-dawgs-parse-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 15 finding(s) |
| j-dawgs-passbolt-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-payload-cms-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-peertube-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-penpot-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-pgbouncer-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-pgbouncer-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 8 finding(s) |
| j-dawgs-photoprism-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-photoprism-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-pi-hole-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-pii-redaction-consistency-checker | analyze | generic-probe: `generic-probe` | PASS — SAFE TO SHARE — 0 finding(s) |
| j-dawgs-pinot-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-piwigo-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-piwigo-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 10 finding(s) |
| j-dawgs-placeholder-and-leftover-draft-leakage-auditor | scan | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-plane-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-plane-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-plausible-analytics-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-plausible-analytics-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-postfix-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 8 finding(s) |
| j-dawgs-posthog-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-posthog-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-powerdns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 10 finding(s) |
| j-dawgs-proftpd-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 14 finding(s) |
| j-dawgs-prometheus-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — SAFE TO DEPLOY — 5 finding(s) |
| j-dawgs-prosody-xmpp-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 3 finding(s) |
| j-dawgs-prowlarr-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-prowlarr-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 8 finding(s) |
| j-dawgs-proxysql-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-publish-accessibility-pre-flight-auditor | audit | generic-probe: `generic-probe` | PASS — done — 0 finding(s) |
| j-dawgs-pulsar-broker-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 1 finding(s) |
| j-dawgs-pulsar-broker-config-safety-auditor-2 | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-purchase-request-sanity-auditor | audit | generic-probe: `generic-probe` | PASS — BUY WITH FIXES — 5 finding(s) |
| j-dawgs-pure-ftpd-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT RUN — 14 finding(s) |
| j-dawgs-python-project-config-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — READY TO PUBLISH — 4 finding(s) |
| j-dawgs-qdrant-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-qdrant-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 7 finding(s) |
| j-dawgs-qr-payload-safety-auditor | analyze | clean-example: `CLEAN_EXAMPLE` | PASS — done — 1 finding(s) |
| j-dawgs-questdb-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-quote-estimate-consistency-auditor | audit | risky-example: `BROKEN_EXAMPLE` | PASS — DO NOT SEND — 8 finding(s) |
| j-dawgs-quote-estimate-consistency-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO SEND — 8 finding(s) |
| j-dawgs-rabbitmq-server-config-safety-auditor | auditConfig | risky-example: `EXAMPLE_RISKY` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-rabbitmq-server-config-safety-auditor | auditConfig | clean-example: `EXAMPLE_HARDENED` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-radarr-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-radon-mitigation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-readeck-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-readeck-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-recipient-list-domain-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SEND WITH FIXES — 4 finding(s) |
| j-dawgs-redirect-chain-canonical-auditor | audit | generic-probe: `generic-probe` | PASS — FIX BEFORE LAUNCH |
| j-dawgs-redis-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — EXPOSED — 7 finding(s) |
| j-dawgs-rocket-chat-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-romm-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-romm-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — DEPLOY WITH FIXES — 4 finding(s) |
| j-dawgs-rspamd-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-rspamd-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 9 finding(s) |
| j-dawgs-rsync-daemon-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-rsync-daemon-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 1 finding(s) |
| j-dawgs-rsyslog-logging-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-rsyslog-logging-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-run-cost-auditor | analyze | example-probe: `RUNAWAY_SAMPLE` | PASS — WITHIN BUDGET |
| j-dawgs-runbook-readiness-rollback-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT RUN BLIND — 9 finding(s) |
| j-dawgs-ryot-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-s3-bucket-policy-auditor | audit | generic-probe: `generic-probe` | PASS — NOT PARSED — 1 finding(s) |
| j-dawgs-saleor-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-saleor-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-samba-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-samba-config-safety-auditortm | auditConfig | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY — 6 finding(s) |
| j-dawgs-saml-response-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT TRUST — 11 finding(s) |
| j-dawgs-screenshot-share-leakage-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT SHARE — 2 finding(s) |
| j-dawgs-scylladb-cluster-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-searxng-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-seaweedfs-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-septic-system-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT PAY YET — 2 finding(s) |
| j-dawgs-service-decommission-dependency-shutdown-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO SHUT DOWN |
| j-dawgs-shaarli-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-shell-script-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT RUN — 10 finding(s) |
| j-dawgs-shell-script-safety-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO RUN — 0 finding(s) |
| j-dawgs-shlink-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-siding-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-siyuan-server-config-safety-auditor | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-siyuan-server-config-safety-auditor | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-sla-credit-claim-auditortm-2 | audit | generic-probe: `generic-probe` | PASS — NOT SETTLED |
| j-dawgs-smartdns-server-config-safety-auditor | auditConfig | generic-probe: `generic-probe` | PASS — SERVE WITH FIXES — 8 finding(s) |
| j-dawgs-snmp-agent-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 3 finding(s) |
| j-dawgs-solr-search-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-solr-search-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 4 finding(s) |
| j-dawgs-sonarqube-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-sonarr-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 7 finding(s) |
| j-dawgs-sonarr-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 2 finding(s) |
| j-dawgs-speaker-rescue | analyze | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-sql-migration-safety-auditor | audit | generic-probe: `generic-probe` | PASS — SAFE TO APPLY — 2 finding(s) |
| j-dawgs-squid-proxy-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 5 finding(s) |
| j-dawgs-ssh-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT EXPOSE — 10 finding(s) |
| j-dawgs-ssh-server-config-safety-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO EXPOSE — 6 finding(s) |
| j-dawgs-stack-trace-triage-bench | analyze | clean-example: `CLEAN_EXAMPLE` | PASS — done |
| j-dawgs-stale-evidence-freshness-checkertm | analyze | generic-probe: `generic-probe` | PASS — SAFE TO SEND AS CURRENT |
| j-dawgs-stalwart-mail-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 4 finding(s) |
| j-dawgs-stirling-pdf-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-strapi-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-stunnel-tls-proxy-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 5 finding(s) |
| j-dawgs-sudoers-privilege-safety-auditor | audit | example-probe: `EXAMPLE_A` | PASS — DO NOT INSTALL — 3 finding(s) |
| j-dawgs-supabase-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 17 finding(s) |
| j-dawgs-supabase-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-superset-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-synapse-server-config-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 17 finding(s) |
| j-dawgs-synapse-server-config-safety-auditor | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 13 finding(s) |
| j-dawgs-syncthing-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-sysctl-kernel-parameter-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — APPLY WITH FIXES — 4 finding(s) |
| j-dawgs-syslog-ng-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-systemd-unit-safety-auditor | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT RUN YET — 11 finding(s) |
| j-dawgs-systemd-unit-safety-auditor | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO RUN — 0 finding(s) |
| j-dawgs-task-ambiguity-pre-flight-checker | analyze | clean-example: `CLEAN_EXAMPLE` | PASS — READY TO START — 0 finding(s) |
| j-dawgs-tautulli-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 1 finding(s) |
| j-dawgs-technitium-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 1 finding(s) |
| j-dawgs-telegraf-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 2 finding(s) |
| j-dawgs-tempo-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-terraform-plan-risk-auditor | audit | clean-example: `SAMPLE_CLEAN` | PASS — SAFE TO APPLY |
| j-dawgs-thanos-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 4 finding(s) |
| j-dawgs-tile-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 1 finding(s) |
| j-dawgs-tomcat-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — NOT PARSED — 1 finding(s) |
| j-dawgs-tool-output-sanity-checker | analyze | generic-probe: `generic-probe` | PASS — SUSPECT |
| j-dawgs-tooljet-server-config-safety-auditortm | auditConfig | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-traefik-static-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 5 finding(s) |
| j-dawgs-tree-removal-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 0 finding(s) |
| j-dawgs-trilium-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-twenty-crm-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-twenty-crm-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-umami-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 11 finding(s) |
| j-dawgs-unbound-dns-resolver-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — OPEN RESOLVER RISK — 11 finding(s) |
| j-dawgs-unbound-dns-resolver-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 14 finding(s) |
| j-dawgs-unbound-dns-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 25 finding(s) |
| j-dawgs-uncertainty-and-hedge-auditor | audit | risky-example: `SAMPLE_BAD` | PASS — DO NOT SHIP AS FACT |
| j-dawgs-uncertainty-and-hedge-auditor | audit | clean-example: `SAMPLE_GOOD` | PASS — CALIBRATED |
| j-dawgs-untrusted-content-injection-surface-scanner | scan | clean-example: `SAMPLE_CLEAN` | PASS — done |
| j-dawgs-uptime-kuma-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |
| j-dawgs-valkey-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO GRADE — 0 finding(s) |
| j-dawgs-varnish-vcl-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 10 finding(s) |
| j-dawgs-varnish-vcl-safety-auditortm | audit | clean-example: `CLEAN_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-vault-server-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-vendor-contract-renewal-notice-window-auditortm | audit | generic-probe: `generic-probe` | PASS — NOTHING SETTLED |
| j-dawgs-vikunja-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 9 finding(s) |
| j-dawgs-vikunja-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-vsftpd-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 11 finding(s) |
| j-dawgs-vsftpd-ftp-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 14 finding(s) |
| j-dawgs-wallabag-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 12 finding(s) |
| j-dawgs-wallabag-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-warp-drive | analyze | example-probe: `EXAMPLE_PRIO` | PASS — done |
| j-dawgs-warranty-return-window-auditor | audit | generic-probe: `generic-probe` | PASS — done |
| j-dawgs-water-heater-installation-estimate-work-record-final-invoice-consistency-auditortm | analyze | generic-probe: `generic-probe` | PASS — SAFE TO PAY — 10 finding(s) |
| j-dawgs-websocket-session-trace-auditor | audit | example-probe: `DYING_SAMPLE` | PASS — DEAD OR DYING SESSION — 4 finding(s) |
| j-dawgs-websocket-transcript-auditor | audit | example-probe: `EXAMPLE` | PASS — BROKEN SESSION — 5 finding(s) |
| j-dawgs-wedding-vendor-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — PAY WITH FIXES — 11 finding(s) |
| j-dawgs-well-pump-installation-proposal-work-record-final-invoice-consistency-auditor | audit | generic-probe: `generic-probe` | PASS — NOT ENOUGH TO COMPARE — 5 finding(s) |
| j-dawgs-wger-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 8 finding(s) |
| j-dawgs-wger-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-wiki-js-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 6 finding(s) |
| j-dawgs-wiki-js-server-config-safety-auditortm-2 | auditConfig | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 3 finding(s) |
| j-dawgs-windmill-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DEPLOY WITH FIXES — 3 finding(s) |
| j-dawgs-window-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | generic-probe: `generic-probe` | PASS — SAFE TO PAY — 0 finding(s) |
| j-dawgs-wireguard-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT USE — 6 finding(s) |
| j-dawgs-wireguard-vpn-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 2 finding(s) |
| j-dawgs-wordpress-config-safety-auditor | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 17 finding(s) |
| j-dawgs-yadifa-authoritative-dns-server-config-safety-auditortm | auditConfig | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT SERVE — 10 finding(s) |
| j-dawgs-yadifa-authoritative-dns-server-config-safety-auditortm | auditConfig | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO SERVE — 0 finding(s) |
| j-dawgs-zabbix-server-config-safety-auditortm | audit | risky-example: `RISKY_EXAMPLE` | PASS — DO NOT DEPLOY — 13 finding(s) |
| j-dawgs-zabbix-server-config-safety-auditortm | audit | clean-example: `HARDENED_EXAMPLE` | PASS — SAFE TO DEPLOY — 0 finding(s) |
| j-dawgs-zitadel-server-config-safety-auditortm | audit | generic-probe: `generic-probe` | PASS — DO NOT DEPLOY — 6 finding(s) |

## Extracted but failed — reclassified OPEN-ONLY (88)

| Tool | Entry | Failure |
|---|---|---|
| j-dawgs-action-item-accountability-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-age-check-pro | evaluate | FAIL — Run failed: Cannot read properties of undefined (reading 'y') |
| j-dawgs-agent-loop-detective | analyze | FAIL — Extracted core has no analyze function. |
| j-dawgs-agent-trace-secret-sweeper | scan | FAIL — Run failed: entry returned nothing |
| j-dawgs-apache-nifi-server-config-safety-auditortm | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-asphalt-paving-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: t.split is not a function |
| j-dawgs-auto-detailing-service-package-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-auto-repair-estimate-invoice-consistency-auditor | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'present') |
| j-dawgs-basement-waterproofing-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'drain') |
| j-dawgs-capability-gap-mapper | analyze | FAIL — Run failed: Cannot read properties of undefined (reading 'toLowerCase') |
| j-dawgs-change-window-freeze-period-collision-auditortm | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-clamav-daemon-config-safety-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'forEach'); Run failed: Cannot read properties of undefined (reading 'forEach') |
| j-dawgs-codeowners-coverage-auditor | audit | FAIL — Extracted core has no audit function. |
| j-dawgs-commitment-date-sla-promise-auditor | audit | FAIL — Extracted core has no audit function. |
| j-dawgs-correction-quality-auditor | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-countertop-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-data-retention-deletion-proof-checker | analyze | FAIL — Run failed: entry returned nothing |
| j-dawgs-deliverable-acceptance-sign-off-auditor | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-dependency-lockfile-conflict-auditor | audit | FAIL — Run failed: parseManifest is not defined |
| j-dawgs-diff-intent-risk-auditortm | analyze | FAIL — Run failed: Cannot create property 'path' on string 'd' |
| j-dawgs-dns-zone-pre-flight-auditor | audit | FAIL — Run failed: records.forEach is not a function |
| j-dawgs-editorconfig-consistency-auditor | audit | FAIL — Run failed: filesText.split is not a function |
| j-dawgs-electrical-estimate-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: d.text.trim is not a function |
| j-dawgs-email-header-delivery-auth-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-environment-parity-auditor | analyze | FAIL — Run failed: Cannot read properties of undefined (reading 'forEach') |
| j-dawgs-error-message-translator-fix-router | analyze | FAIL — Extracted core has no analyze function. |
| j-dawgs-event-registration-terms-consistency-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'trim') |
| j-dawgs-file-operation-sandbox-path-guardtm | analyze | FAIL — Run failed: opsRaw.split is not a function |
| j-dawgs-firebase-security-rules-auditor | audit | FAIL — Run failed: sensitiveText.split is not a function; Run failed: sensitiveText.split is not a function |
| j-dawgs-firewall-ruleset-safety-auditor | audit | FAIL — Run failed: intendedPorts.forEach is not a function |
| j-dawgs-freelance-contract-milestone-invoice-consistency-auditortm | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-garage-door-proposal-work-record-final-invoice-consistency-auditortm-2 | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-garage-door-repair-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: work.trim is not a function |
| j-dawgs-ghost-config-safety-auditor | auditConfig | FAIL — harness: Command failed: node /home/hatch/workspace/botdawg-package/tool-library-pack/work/test_one.js /home/hatch/workspace/botdawg-package/tool-library-pack/tools/j-dawgs-ghost-config-safety-auditor.js
 |
| j-dawgs-goal-drift-termination-checker | analyze | FAIL — Run failed: Cannot read properties of undefined (reading 'map') |
| j-dawgs-gutter-installation-proposal-work-record-final-invoice-consistency-auditortm-3 | scan | FAIL — Extracted core has no scan function. |
| j-dawgs-gutter-installation-proposal-work-record-final-invoice-consistency-auditortm-4 | check | FAIL — Extracted core has no check function. |
| j-dawgs-har-performance-exposure-auditortm | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-home-services-quote-invoice-consistency-auditor | audit | FAIL — Run failed: render is not defined |
| j-dawgs-hot-tub-spa-installation-proposal-work-record-final-invoice-consistency-auditor | audit | FAIL — Run failed: text.match is not a function |
| j-dawgs-house-cleaning-service-agreement-visit-log-final-invoice-consistency-auditortm-2 | audit | FAIL — Run failed: logText.trim is not a function |
| j-dawgs-http-cache-freshness-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-hvac-proposal-invoice-consistency-auditor | audit | FAIL — Run failed: t.trim is not a function |
| j-dawgs-invoice-payment-term-consistency-auditortm | audit | FAIL — Run failed: parseDocument is not defined |
| j-dawgs-jwt-safety-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-kafka-server-config-safety-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'length') |
| j-dawgs-keepalived-config-safety-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'length') |
| j-dawgs-kitchen-remodel-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.trim is not a function |
| j-dawgs-komga-server-config-safety-auditor | auditConfig | FAIL — Run failed: parseConfig is not defined |
| j-dawgs-listing-claims-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-memory-staleness-auditor | analyze | FAIL — Run failed: todayStart is not defined |
| j-dawgs-n8n-server-config-safety-auditor | audit | FAIL — Run failed: Cannot convert undefined or null to object; Run failed: Cannot convert undefined or null to object |
| j-dawgs-on-call-roster-coverage-gap-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'slice') |
| j-dawgs-openvpn-config-safety-auditor | auditConfig | FAIL — Run failed: Cannot read properties of undefined (reading 'filter') |
| j-dawgs-plan-dependency-checker | analyze | FAIL — Run failed: steps.map is not a function |
| j-dawgs-plumbing-estimate-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'present') |
| j-dawgs-postgresql-server-config-safety-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'listen_addresses') |
| j-dawgs-pre-commit-hook-safety-auditor | audit | FAIL — Run failed: filesText.split is not a function |
| j-dawgs-prompt-compression-loss-receipt | scan | FAIL — Extracted core has no scan function. |
| j-dawgs-proof-photo-reuse-metadata-checker | analyze | FAIL — Run failed: rows.forEach is not a function |
| j-dawgs-rag-chunk-auditor | analyze | FAIL — Run failed: render is not defined |
| j-dawgs-rate-limit-header-burn-rate-auditor | audit | FAIL — Run failed: document.createTextNode is not a function |
| j-dawgs-regex-tester | scan | FAIL — Extracted core has no scan function. |
| j-dawgs-renovate-config-coverage-safety-auditor | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-roofing-proposal-work-record-final-invoice-consistency-auditortm-2 | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-roofing-proposal-work-record-final-invoice-consistency-auditortm-3 | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'depositCredited') |
| j-dawgs-schema-inference-forge | analyze | FAIL — Run failed: Cannot read properties of undefined (reading 'forEach') |
| j-dawgs-semver-range-pinning-auditortm | audit | FAIL — Run failed: render is not defined |
| j-dawgs-septic-system-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-sewer-line-replacement-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'itemOrder') |
| j-dawgs-slo-error-budget-auditortm | audit | FAIL — Run failed: entry returned nothing |
| j-dawgs-snow-removal-service-agreement-visit-log-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.trim is not a function |
| j-dawgs-social-card-open-graph-pre-flight-auditor | audit | FAIL — Run failed: renderFindings is not defined |
| j-dawgs-solar-panel-installation-proposal-work-record-final-invoice-consistency-auditortm | audit | FAIL — Run failed: text.trim is not a function |
| j-dawgs-sql-query-plan-risk-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'forEach') |
| j-dawgs-subagent-brief-stress-tester | analyze | FAIL — Run failed: entry returned nothing |
| j-dawgs-support-macro-policy-consistency-auditortm | audit | FAIL — Run failed: text.split is not a function |
| j-dawgs-suricata-ids-config-safety-auditortm | auditConfig | FAIL — Run failed: Cannot read properties of undefined (reading 'length') |
| j-dawgs-terraform-plan-safety-auditor | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'length') |
| j-dawgs-tool-result-truncation-checker | analyze | FAIL — Run failed: entry returned nothing |
| j-dawgs-travel-itinerary-booking-confirmation-consistency-auditor | audit | FAIL — Run failed: pastes.map is not a function |
| j-dawgs-typesense-server-config-safety-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'forEach') |
| j-dawgs-vector-pipeline-config-safety-auditor | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'length') |
| j-dawgs-victoriametrics-server-config-safety-auditortm | audit | FAIL — Run failed: parseInput is not defined |
| j-dawgs-warranty-and-return-window-deadline-auditor | evaluate | FAIL — Run failed: Cannot read properties of undefined (reading 'y') |
| j-dawgs-warranty-guarantee-terms-consistency-auditor | audit | FAIL — Run failed: texts.map is not a function |
| j-dawgs-wedding-vendor-contract-quote-final-invoice-consistency-auditortm | audit | FAIL — Run failed: Cannot read properties of undefined (reading 'present') |
| j-dawgs-whole-request-token-estimator | analyze | FAIL — Run failed: entry returned nothing |
