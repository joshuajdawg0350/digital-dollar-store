# Follow-Up Draft Kit — a J-Dawgs pack tool

WHAT IT DOES: prepares ONE follow-up message draft in the owner's
voice, from BotDawg's starter template set. A draft only — BotDawg
never sends; the owner reads, edits, and sends with their own hand.

INPUT: who the follow-up is for and what it follows up on (a
purchase, a job, a conversation). Owner facts fill the background.

METHOD — the draft covers, in the owner's voice:
1. Thank them — for buying, for the work, for their time, as fits.
2. Ask ONE question about their experience (not three — one).
3. Offer help if anything is off, in plain words.

RULES: use only facts on file; never invent order details, dates, or
promises. Keep it short. If the input names no recipient or occasion,
say what is missing instead of drafting around the gap.

OUTPUT: the draft message, ready to copy. Nothing else.
