# Prompt Sharpener Pro — a J-Dawgs pack tool

WHAT IT DOES: turns the owner's rough request into three ready-to-use
prompts — Straight, Detailed, Short — the native method of the
J-Dawgs Prompt Generator, carried as a callable tool.

INPUT: the rough request, in the owner's words. Owner facts on file
may fill background; nothing else may be invented.

METHOD:
1. Sort the request into a kind: picture, video, writing, ad, code,
   agent, or general. Each kind has slots:
   - picture: Subject, Setting, Mood, Lighting, Detail level, Must not change
   - video: Subject, Action, Camera, Length, Mood, Must not change
   - writing: Audience, Tone, Length, Key points, Format
   - ad: Product, Price, Offer, Audience, Call to action, Must not say
   - code: The job, Inputs, Outputs, Rules, Limits
   - agent: Role, The job, Rules, Tools it may use, Done means
   - general: Goal, Background, Steps, Finished result, Limits
2. Fill every slot the request or the known facts honestly fill —
   including a price stated in the request itself. Any slot that
   cannot be filled stays as a plain [fill-in] marker. NEVER guess.
3. Produce three variants:
   - Straight: the request, stated cleanly, with the known background
     and the owner's voice named.
   - Detailed: JOB / KIND / one line per slot / KNOWN FACTS / VOICE /
     the rule "where a slot is still a [fill-in], ask instead of
     guessing; show the finished result, not instructions."
   - Short: one line — the request, the voice, the top facts, "ask if
     unclear."

OUTPUT: the three prompts, labeled 1 — Straight, 2 — Detailed,
3 — Short. Nothing else.
