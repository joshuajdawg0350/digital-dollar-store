# Door Proof Checklist — a J-Dawgs pack tool

WHAT IT DOES: checks a product page (a "door" — where something is
sold or handed over) against the seller's OWN stated facts, the
standard of BotDawg's Proof Run skill, applied to page text.

INPUT: the page text (fetch it first with fetch_page if needed) plus
the seller's stated facts: product name, one-line description,
claims, stated price, buy link.

METHOD — one line per check, each PASS, FAIL, or UNCHECKED, with the
evidence quoted from the page:
1. The door answers: page text was actually read (if not, every line
   below is UNCHECKED and the tool says why).
2. Says what the seller says: the product name and description on the
   page match the stated ones.
3. Claims check: each stated claim is present on the page — present
   (PASS, quote it), contradicted (FAIL, quote both), or absent
   (UNCHECKED — absence is not a contradiction).
4. Price match: the price on the page equals the stated price.
5. Buy link: a buy/order link is present in the page text.

RULES: never buy, never log in, never fill in a form. Never judge
whether the product is good — only whether the door matches what the
seller says. Anything that cannot be checked from the text is
UNCHECKED, never a guessed pass. Hits and misses both, always.

OUTPUT: the checklist lines, then a one-line verdict count
(PASS n · FAIL n · UNCHECKED n).
