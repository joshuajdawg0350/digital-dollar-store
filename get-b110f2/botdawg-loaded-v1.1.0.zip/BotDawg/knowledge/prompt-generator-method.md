# The Prompt Generator method (J-Dawgs playbook)

How J-Dawgs turns rough words into ready prompts — the method behind
the built-in Prompt Generator and the Prompt Sharpener Pro pack tool.

- Sort first: every request is a kind (picture, video, writing, ad,
  code, agent, general), and the kind decides the slots.
- Fill from facts only: the owner's words and remembered facts fill
  slots. Everything else stays a visible [fill-in]. A prompt with an
  honest hole beats a prompt with a confident invention, every time.
- Three shapes, always: Straight (clean statement), Detailed (every
  slot on its own line, rules stated), Short (one line). Different
  hands want different shapes; give all three and let the owner pick.
- The standing rule inside every Detailed prompt: "Where a slot is
  still a [fill-in], ask me for it instead of guessing. Show me the
  finished result, not instructions for making it."
- Voice is a slot, not an afterthought: the owner's voice (plain,
  warm, formal) is named in every variant.
