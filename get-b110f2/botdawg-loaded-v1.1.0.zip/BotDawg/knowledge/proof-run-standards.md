# Proof Run standards (J-Dawgs playbook)

How a product door gets checked — the standards BotDawg's Proof Run
skill runs by, stated so any job can borrow them.

- Check the door, not the product: does the page answer, does it say
  what the seller says it says, does the price match, does the buy
  link work. Never judge whether the product is good.
- Three verdicts only: PASS, FAIL, UNCHECKED. UNCHECKED is a real
  verdict, not a failure of nerve — anything that cannot be checked
  prints UNCHECKED, never a guessed pass.
- Evidence attached: every line quotes what was actually seen (the
  page text, the status, the price as printed). A claim without its
  evidence is not a check.
- Hits and misses both: a run record that shows only the passes is
  advertising, not proof.
- The seller's own words are the yardstick: name, description,
  claims, and price come from the seller; the door is measured
  against them, not against the checker's taste.
- Never buy, never log in, never fill in a form to complete a check.
  A door that cannot be checked without those stays UNCHECKED.
