/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ chat — the chat box on the console screen. The owner types
 * in plain words; BotDawg answers in the conversation. This is a
 * LOCAL chat on the owner's own console (127.0.0.1) — not a chat-app
 * channel: no texting, no messaging apps, nothing leaves the folder.
 *
 * Chat runs through the SAME brain as everything else: questions are
 * answered from the charter, the memory file, and (if the owner
 * connected one) the owner's own model; jobs go through the planner
 * and the run loop, so the pre-run estimate, the live meter, the
 * owner's caps, the charter permissions, and the audit log all apply
 * exactly as they do for the work boxes. The by-design nevers hold in
 * chat too: BotDawg never sends, posts, buys, pays, deletes, or logs
 * in as the owner — asked in chat, it says so plainly and prepares a
 * draft instead where a draft makes sense.
 *
 * The conversation is kept in chat-history.json in this folder —
 * plain file, owner's to read or delete. It is context for replies,
 * never sent anywhere.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const lib = require('./lib');
const brain = require('./brain');

const HISTORY_PATH = path.join(__dirname, 'chat-history.json');
const MAX_TURNS = 60;

function loadHistory() {
  try { const h = JSON.parse(fs.readFileSync(HISTORY_PATH, 'utf8')); return Array.isArray(h) ? h : []; }
  catch { return []; }
}

function saveHistory(h) {
  try { fs.writeFileSync(HISTORY_PATH, JSON.stringify(h.slice(-MAX_TURNS), null, 2) + '\n'); } catch { /* chat still works */ }
}

/* ---------------- the nevers, in chat ----------------
 * A chat request to send / post / buy / pay / delete / log in gets a
 * plain refusal in the owner's chosen voice, and — for send/post,
 * where a draft is the useful thing — a real draft prepared through
 * the normal run loop (estimate, caps, audit, usage all apply).
 */

function neverHit(text) {
  const t = String(text || '');
  const low = ' ' + t.toLowerCase().replace(/\s+/g, ' ') + ' ';
  if (/\b(log|sign)\s?(in|into|on)\b/.test(low) || /\blogin\b/.test(low)) return { act: 'log in', draft: null };
  if (/\b(delete|erase|wipe)\b/.test(low) || /\bget rid of\b/.test(low) || /\bremove\b[^.?!]{0,40}\b(file|folder|files|everything|all)\b/.test(low)) return { act: 'delete', draft: null };
  if (/\b(buy|purchase)\b/.test(low) || /\bplace (an? )?order\b/.test(low) || /\bcheck ?out\b/.test(low)) return { act: 'buy', draft: null };
  if (/\b(pay|charge|bill)\b[^.?!]{0,50}\b(invoice|bill|card|them|him|her|it|this|that|\$|\d)/.test(low) || /\bsend (a )?payment\b/.test(low)) return { act: 'pay', draft: null };
  if (/\bput\b[^.?!]{0,40}\bonline\b/.test(low) || /\bhost\b[^.?!]{0,40}\b(website|web ?site|web ?page|landing page|site|page|this|it)\b/.test(low)) return { act: 'post', draft: 'post' };
  if (/\b(post|publish|upload)\b[^.?!]{0,40}\b(this|that|it|to|on|onto)\b/.test(low)) return { act: 'post', draft: 'post' };
  if (/\bsend\b(?!\s+(me|us)\b)/.test(low) || /\be-?mail (it|this|that|them|him|her)\b/.test(low) || /\btext (him|her|them|it)\b/.test(low)) return { act: 'send', draft: 'email' };
  return null;
}

function neverReply(hit, charter, draftFile) {
  const name = charter.agentName;
  const formal = charter.voice === 'formal';
  const gerund = { 'send': 'sending', 'post': 'posting', 'buy': 'buying', 'pay': 'paying', 'delete': 'deleting', 'log in': 'signing in' }[hit.act] || hit.act;
  const head = formal
    ? `I do not ${hit.act}, ${charter.ownerName || 'and I am not able to do so on your behalf'}. That is by design, and it is not a setting: consequences stay with the owner.`
    : `I never ${hit.act} — that's by design, not a setting. ${name} prepares the work; the ${gerund} is always your hand.`;
  if (hit.draft && draftFile) {
    return `${head}\n\nWhat I did instead: I prepared a draft for you — ${draftFile}. Read it, change anything, and ${hit.act} it yourself when it says what you mean.`;
  }
  if (hit.draft) {
    return `${head}\n\nSay "write a draft" and tell me what it should say, and I will prepare one you can ${hit.act} yourself.`;
  }
  const instead = {
    'log in': 'What I can do: read any public page you point me at, and keep your facts and drafts ready so signing in is the only step left to you.',
    'delete': 'What I can do: organize a folder into a full catalog with an exact-duplicate report, so you can see exactly what is there and delete with your own hand.',
    'buy': 'What I can do: research the options from sources you name and draft the order details, so placing the order is the only step left to you.',
    'pay': 'What I can do: draft the payment details and a checklist from your facts, so making the payment is the only step left to you.',
  }[hit.act] || '';
  return `${head}\n\n${instead}`;
}

/* ---------------- small talk + plain questions ---------------- */

function knownFacts(charter, query) {
  const pool = [
    ...(charter.facts || []).map(text => ({ text })),
    ...lib.loadMemory().facts,
  ];
  if (!query) return pool;
  const q = String(query).toLowerCase();
  return pool.filter(f => f.text.toLowerCase().includes(q) || q.split(/\s+/).some(w => w.length > 3 && f.text.toLowerCase().includes(w)));
}

function capabilities(charter, engine) {
  const list = Object.values(engine.SKILLS).map(s => `- ${s.name}: ${s.outWords}`).join('\n');
  const brainLine = brain.brainOn(charter)
    ? `\n- The Brain (your model is connected): any other job in plain words — your model plans it, and I run it step by step with my local tools (write a file, read a file, draft, sharpen, remember, fetch a public page, list a folder, apply a loaded pack tool), checking each step as I go.`
    : `\n- The Brain (not connected): connect your own model on this screen and any job in plain words becomes possible — your model plans it, I run it locally step by step. Until then, jobs outside the skills above get a plain UNABLE.`;
  return `Here is what I can do, ${charter.ownerName || 'in plain words'}:\n\n${list}${brainLine}\n\nAnd what I never do, by design: send, post, buy, pay, delete, or log in as you. I prepare drafts and finished files in the out/ folder — the last step is always your hand.\n\nHand me a job right here in chat ("watch this page…", "write a draft about…", "remember that…"), or ask me a question.`;
}

function voiceLine(charter, plain, warm, formal) {
  if (charter.voice === 'warm' && warm) return warm;
  if (charter.voice === 'formal' && formal) return formal;
  return plain;
}

/* ---------------- one chat turn ----------------
 * text in → BotDawg's reply out. engine is the same object the
 * console already uses: { runTask, planFromWords, estimateSteps,
 * brief, SKILLS }.
 */

async function chatTurn(text, charter, engine) {
  charter = charter || lib.loadCharter();
  const words = String(text || '').trim();
  const history = loadHistory();
  const done = (reply, kind, extra = {}) => {
    history.push({ role: 'owner', text: words, at: new Date().toISOString() });
    history.push({ role: 'agent', text: reply, at: new Date().toISOString() });
    saveHistory(history);
    lib.audit('chat-turn', { kind, summary: reply.slice(0, 140) });
    return { reply, kind, ...extra };
  };
  if (!words) return { reply: `Say it in plain words — a question, or a job. I am listening.`, kind: 'empty' };
  lib.audit('chat-owner', { summary: words.slice(0, 140) });
  const low = words.toLowerCase();

  /* 0 — the website skill's own limit, stated plainly (before the
   * nevers, so "checkout" in a site ask is answered with the site
   * limit, not the buying refusal): one page, no store, no checkout. */
  if (/\b(build|make|create|want|need)\b[^.?!]{0,60}\b(website|web ?site|web ?page|landing page|site|store|shop)\b/.test(low)
    && /\b(online store|e-?commerce|checkout|shopping cart|\d+\s*-?\s*pages?|multiple pages|multi-?page|take payments online|sell (things|stuff|products) online)\b/.test(low)) {
    return done(`Plainly: in built-in mode I build ONE self-contained website page from the facts I know — no online store, no checkout, no extra pages — and I never host or post it. Say "build me a website" and I will build that one page for you. Nothing was charged.`, 'site-limit');
  }

  /* 1 — the nevers */
  const hit = neverHit(words);
  if (hit) {
    let draftFile = null;
    if (hit.draft) {
      const r = await engine.runTask(
        { title: 'Chat: draft instead of ' + hit.act, steps: [{ skill: 'write', kind: hit.draft, topic: words }] },
        { charter });
      const stepResult = r.state.results && r.state.results[0];
      if (stepResult && stepResult.files && stepResult.files[0]) draftFile = stepResult.files[0].split('/').pop() + ' in the out/ folder';
    }
    return done(neverReply(hit, charter, draftFile), 'never');
  }

  /* 2 — greetings, identity, capabilities, usage, brief */
  if (/^(hi|hello|hey|good (morning|afternoon|evening)|howdy)\b/.test(low) && words.length < 60) {
    return done(voiceLine(charter,
      `Hello${charter.ownerName ? ', ' + charter.ownerName : ''}. I am ${charter.agentName}${charter.ownerBusiness ? ', working for ' + charter.ownerBusiness : ''}. Ask me a question, or hand me a job in plain words.`,
      `Well hello${charter.ownerName ? ', ' + charter.ownerName : ''}! ${charter.agentName} here${charter.ownerBusiness ? ', on duty for ' + charter.ownerBusiness : ''}. Ask me anything, or hand me a job — plain words are all I need.`,
      `Good day${charter.ownerName ? ', ' + charter.ownerName : ''}. I am ${charter.agentName}${charter.ownerBusiness ? ', in service to ' + charter.ownerBusiness : ''}. State a question or a job, and I will attend to it.`), 'greeting');
  }
  if (/\b(your name|who are you)\b/.test(low)) {
    return done(`I am ${charter.agentName} — your BotDawg${charter.ownerBusiness ? ', set up for ' + charter.ownerBusiness : ''}. I live in this folder on your computer, I remember what you teach me, and I never send, post, buy, pay, delete, or log in as you.`, 'identity');
  }
  if (/\bwhat can you do\b|\byour skills\b|\bwhat do you do\b/.test(low) || low === 'help') {
    return done(capabilities(charter, engine), 'capabilities');
  }
  if (/\b(usage|how much have (i|you) (used|spent)|what have i used|units (have|did))\b/.test(low)) {
    return done(`Today you have used ${lib.unitsToday()} of your ${charter.caps.perDayUnits} units (your cap is ${charter.caps.perTaskUnits} per task). Failed or stopped tasks were charged 0. The full ledger is in usage.json.`, 'usage');
  }
  if (/\b(brief|briefing|morning report)\b/.test(low) && words.length < 60) {
    return done(engine.brief(charter).replace(/^# /, ''), 'brief');
  }

  /* 3 — questions its memory can answer */
  const isQuestion = /\?\s*$/.test(words) || /^(what|when|where|who|how|do|does|did|is|are|tell me)\b/.test(low);
  if (isQuestion) {
    const q = low.replace(/^(do|does|did) you (remember|know)\s+/, '').replace(/\?+\s*$/, '').trim();
    const hits = knownFacts(charter, q);
    if (hits.length) {
      return done(`From what I know:\n${hits.slice(0, 6).map(f => `- ${f.text}`).join('\n')}`, 'memory-answer');
    }
  }

  /* 4 — a job in plain words: the planner + run loop, same as the work boxes.
   * planJob gives built-in skills first claim; a job no skill matches
   * goes to the Brain when the owner's model is connected. */
  const plan = engine.planJob ? await engine.planJob(words, charter) : engine.planFromWords(words, charter);
  if (plan.brainPlan) {
    const bp = plan.brainPlan;
    const r = await engine.runJob({ title: 'Chat: ' + words.slice(0, 54), job: words, brainPlan: bp }, { charter });
    let reply = `Brain plan (your model planned this job): ${bp.steps.map(s => brain.stepLabel(s)).join(' → ')}\n\n${r.message}`;
    if (bp.refused.length) reply += `\n\nRefused in the plan: ${bp.refused.map(x => x.reason).join(' ')}`;
    reply += `\n\n(Estimated ${bp.estimate} unit(s) before it ran; charged ${r.charged}. The meter above and the activity log have the full record.)`;
    return done(reply, 'brain-task', { taskId: r.state.id, charged: r.charged });
  }
  if (plan.steps.length) {
    const est = engine.estimateSteps(plan.steps);
    const r = await engine.runTask({ title: 'Chat: ' + words.slice(0, 54), steps: plan.steps }, { charter });
    const parts = plan.steps.map((s, i) => {
      const res = r.state.results && r.state.results[i];
      return res ? res.summary : '';
    }).filter(Boolean);
    // On a stopped task the finish message already carries the failing
    // step's summary — do not say it twice.
    let reply = r.state.status === 'done' && parts.length ? `${r.message}\n\n${parts.join('\n')}` : r.message;
    reply += `\n\n(Estimated ${est} unit(s) before it ran; charged ${r.charged}. The meter above and the activity log have the full record.)`;
    if (plan.missing.length) reply += `\n\nOne more thing I still need from you:\n${plan.missing.map(m => `- ${m}`).join('\n')}`;
    return done(reply, 'task', { taskId: r.state.id, charged: r.charged });
  }
  if (plan.missing.length && !plan.sharpenOnly) {
    return done(`I want to get that right, and first I need:\n${plan.missing.map(m => `- ${m}`).join('\n')}`, 'needs-info');
  }

  /* 5 — open conversation: the owner's model if connected, else honest built-in */
  const recent = history.slice(-8).map(h => ({ role: h.role === 'owner' ? 'user' : 'assistant', content: h.text }));
  const facts = knownFacts(charter).map(f => f.text);
  const m = await lib.modelChat(charter, [
    { role: 'system', content: `You are ${charter.agentName}, a local agent owned by ${charter.ownerName || 'the owner'}${charter.ownerBusiness ? ' of ' + charter.ownerBusiness : ''}. Voice: ${charter.voice}. Answer in that voice, plainly and briefly. Facts you know: ${facts.join('; ') || '(none on file)'}. You never send, post, buy, pay, delete, or log in as the owner, and you never invent facts, prices, or results. If a job is outside your skills, say so plainly.` },
    ...recent,
    { role: 'user', content: words },
  ], { strong: true });
  if (m.ok && m.text) {
    const units = Math.max(1, Math.ceil((m.tokens || 0) / 1000));
    if (lib.unitsToday() + units > charter.caps.perDayUnits) {
      return done(`That answer would take us past your daily cap (${charter.caps.perDayUnits} units), so I stopped before charging anything. Raise the cap on this screen, or ask again tomorrow.`, 'capped');
    }
    lib.recordUsage({ task: 'chat', title: 'Chat reply (your model)', status: 'done', unitsUsed: units, charged: units, at: new Date().toISOString() });
    lib.audit('chat-model', { units, tokens: m.tokens || 0 });
    return done(m.text, 'model', { charged: units });
  }
  const sharp = await engine.SKILLS.sharpen.run({ goal: words }, { charter });
  const brainNote = plan.brainError ? `\n\nI did try the Brain on it: ${plan.brainError}` : '';
  return done(`In built-in mode I answer from what I remember and the skills I have — and that one is not in either yet, so I will not fake an answer. Here are your words sharpened by my built-in Prompt Generator, in case they become a job:\n\n${sharp.detail.variants.straight}${brainNote}\n\nConnect your own model on this screen and I can talk through questions like that with it. Meanwhile I can remember facts, watch pages, research sources you name, write drafts, build a one-page website, organize folders, proof-run product pages${charter.allowHumanCheck ? ', and click a "Verify you are human" checkbox on a page you send me to' : ''}.`, 'builtin-fallback');
}

module.exports = { chatTurn, loadHistory, neverHit };
