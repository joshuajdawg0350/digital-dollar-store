#!/bin/sh
# BotDawg one-click launcher (Linux). Double-click this file (or run
# it): the chat opens in your browser. No terminal, no typed commands.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "BotDawg needs Node.js, which is free - the download page is opening now; install the LTS version, then double-click START BOTDAWG again."
  xdg-open https://nodejs.org >/dev/null 2>&1
  printf "Press Enter to close this window."
  read -r _
  exit 1
fi
node launch.js
