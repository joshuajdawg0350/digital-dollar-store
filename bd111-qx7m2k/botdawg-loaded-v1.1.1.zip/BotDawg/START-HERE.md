# START HERE — BotDawg™ in three steps

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

Welcome. BotDawg is a general-purpose agent that lives in this one
folder, on your computer. It never phones home, it never needs
J-Dawgs for anything, and everything it knows and makes stays in
plain files right here. Getting from the zip file to talking with
him takes three steps and no terminal:

## Step 1 — Unzip

Unzip the package anywhere you like — your Documents folder is
fine. You will get one folder named **BotDawg**. Everything happens
inside that folder. Don't move files out of it; BotDawg finds its
parts by looking next to itself.

## Step 2 — Double-click START BOTDAWG

In the BotDawg folder, double-click the launcher for your system:

- **Windows:** `START BOTDAWG.bat`
- **Mac:** `START BOTDAWG.command`
- **Linux:** `START BOTDAWG.sh`

That's the whole front door. The launcher:

- checks that **Node.js** is on the computer. Node is free; if it
  isn't there, the launcher says so in one plain line and opens the
  download page (https://nodejs.org — take the "LTS" version).
  Install it like any other program, then double-click again.
- runs setup **by itself** the first time — nothing to type.
- starts BotDawg and **opens the chat screen in your browser by
  itself**. No address to type, nothing to browse to.

Double-click it again any time. If BotDawg is already running, it
just opens the chat — no duplicate, no error.

## Step 3 — Make him yours, right in the chat screen

The screen that opens is the whole app — setup, work, memory, and
the chat box with BotDawg's head on it, all on the one screen, on
your computer only (it serves 127.0.0.1 — your machine, nobody
else's). Tell him his **name**, **your business**, his **voice**,
your **brand color**, and any facts he should never forget. Hand
him a job in the chat box in plain words and he plans it, shows
the estimate and the cap, and runs it by the same rules as
everything else.

**Connecting your own model (optional).** Out of the box BotDawg
runs in built-in mode — every built-in skill works. Connect a
model account of your own and his **Brain** opens up: jobs in
plain words that no built-in skill covers get planned by your
model and run step by step. The key is read from an environment
variable on your computer — the screen tells you its name and
exactly where it goes. BotDawg never asks you to paste the key
into the screen and never writes it into any file.

**Files first.** Before every job, BotDawg checks his own files —
his memory, his playbooks, his loaded tools — for anything related
to the job, and plans from what he finds. If a saved note of yours
clashes with a job, he stops and asks which stands, in plain
words, instead of quietly overriding you. Every check is written
to the activity log. **HONEST-LIMITS.md** in this folder states
exactly what he does and does not do.

## The phone version — no steps at all

This package also carries BotDawg for your phone: one single file,
`botdawg-phone.html`. Put that file on your phone and open it in
the phone's browser — or open it from a link — and BotDawg is
right there: chat, drafts, prepared messages, prompt sharpening,
memory, and personalization. No install, no computer needed. It
does not do everything the computer version does;
**PHONE-HONEST-LIMITS.md** (also in this folder) states plainly
what it leaves out.

The two versions do not sync with each other: each one keeps its
own memory on its own device. Facts you teach the one on your
computer are not on your phone, and the other way around.

## The manual way (for technical owners)

Everything the launcher does can also be done from a terminal in
this folder: `node botdawg.js setup` once, then
`node botdawg.js console`, and browse to http://127.0.0.1:7900.
The launcher is the front door; this is the same house through
the side entrance.
