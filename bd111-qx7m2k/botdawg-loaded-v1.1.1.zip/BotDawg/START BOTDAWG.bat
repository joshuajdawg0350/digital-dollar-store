@echo off
rem BotDawg one-click launcher (Windows). Double-click this file:
rem the chat opens in your browser. No terminal, no typed commands.
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo BotDawg needs Node.js, which is free - the download page is opening now; install the LTS version, then double-click START BOTDAWG again.
  start https://nodejs.org
  pause
  exit /b 1
)
node launch.js
