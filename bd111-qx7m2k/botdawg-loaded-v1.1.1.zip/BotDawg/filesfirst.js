/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ files-first — before ANY job is planned, BotDawg checks
 * its own files for anything related to the job and plans from what
 * it finds. This is a standing discipline, not a search box:
 *
 *   1. Memory — the owner's saved facts (memory.json) and the facts
 *      given at setup (charter), scored against the job's words.
 *   2. Knowledge — the playbooks in knowledge/, matched on title and
 *      full text (Loaded edition; the Clean starter pack alike).
 *   3. Tools — the loaded tool manifest (tools/manifest.json),
 *      searched the same way the Brain searches it.
 *
 * What the pass does with what it finds:
 *   - Matching facts, knowledge files, and tools ride into the job
 *     brief the planner works from (Brain prompt, and the built-in
 *     skills' fact pool), so a job is answered from the owner's own
 *     record — not from a blank slate.
 *   - A saved fact that CONTRADICTS the job as asked stops the job
 *     before it runs. The owner gets the clash in plain words —
 *     "Your saved notes say X — this job says Y. Which stands?" —
 *     and nothing runs until they answer. A saved fact is never
 *     silently overridden.
 *   - Every pass is written to the audit log with its counts, so
 *     the owner can see it happened: event "files-first".
 *
 * The search is local file work. It needs no model and runs exactly
 * the same in built-in (no-model) mode — that is the point: the
 * discipline does not depend on a model being connected.
 *
 * Contradiction detection is deliberately narrow and explainable —
 * two shapes only, each quoted back to the owner verbatim:
 *   (a) a saved standing order ("never …", "don't …", "do not …",
 *       "must not …", "no longer …") whose subject the job asks for
 *       without the negation;
 *   (b) a saved fact and the job stating different $ amounts for
 *       the same shared subject.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const lib = require('./lib');
const pack = require('./pack');

const STOP = new Set(['the', 'and', 'for', 'with', 'about', 'please', 'make', 'write', 'build', 'plan', 'run', 'use', 'using', 'get', 'set', 'new', 'our', 'your', 'you', 'that', 'this', 'from', 'into', 'onto', 'should', 'would', 'could', 'want', 'need', 'like', 'just', 'give', 'show', 'tell', 'them', 'then', 'than', 'over', 'under', 'when', 'what', 'all', 'any', 'one', 'two', 'per']);

function jobWords(text) {
  return [...new Set(String(text || '').toLowerCase().split(/[^a-z0-9$%.]+/).filter(w => w.length > 2 && !STOP.has(w)))];
}

function wordScore(words, text) {
  const t = ' ' + String(text || '').toLowerCase() + ' ';
  let s = 0;
  for (const w of words) if (t.includes(w)) s++;
  return s;
}

/* Light stemming for word matching: "discounts" in a saved note
 * must match "discount" in a job, "offer" must match "offering".
 * Deliberately crude — it only widens a substring check. */
function stem(w) {
  return w.length > 4 ? w.replace(/(ingly|edly|ing|es|s)$/, '') : w;
}
function textHasWord(text, w) {
  return text.includes(w) || text.includes(stem(w));
}

function amounts(text) {
  return [...new Set((String(text || '').match(/\$\s?\d[\d,]*(?:\.\d{2})?/g) || []).map(a => a.replace(/\s/g, '')))];
}

const NEGATIONS = [
  /\bnever\b/i, /\bdon'?t\b/i, /\bdo not\b/i, /\bmust not\b/i, /\bno longer\b/i, /\bnot ever\b/i, /\brefuse[sd]?\b/i,
];

function findContradictions(job, words, pool) {
  const out = [];
  const jobLow = ' ' + job.toLowerCase() + ' ';
  const jobAmounts = amounts(job);
  for (const fact of pool) {
    const text = String(fact.text || '');
    const low = text.toLowerCase();
    // (a) standing-order negation whose subject the job asks for
    for (const neg of NEGATIONS) {
      const m = low.match(neg);
      if (!m) continue;
      const span = low.slice(m.index + m[0].length).replace(/^[\s:,-]+/, '').split(/[.;!?\n,—–]/)[0].trim();
      const spanWords = [...new Set(span.split(/[^a-z0-9$%.]+/).filter(w => w.length > 2 && !STOP.has(w)))];
      if (!spanWords.length) continue;
      const shared = spanWords.filter(w => textHasWord(jobLow, w));
      const need = spanWords.length < 3 ? 1 : 2;
      // the job carrying the same negation is agreement, not a clash
      if (shared.length >= need && !NEGATIONS.some(n => n.test(job))) {
        out.push({ fact: text, kind: 'standing-order', span, shared });
      }
      break; // one negation read per fact is enough
    }
    // (b) different $ amounts for a shared subject
    const factAmounts = amounts(text);
    if (factAmounts.length && jobAmounts.length && !factAmounts.some(a => jobAmounts.includes(a))) {
      const shared = words.filter(w => (' ' + low + ' ').includes(w));
      if (shared.length >= 2) {
        out.push({ fact: text, kind: 'amount', factAmounts, jobAmounts, shared });
      }
    }
  }
  return out;
}

/* The pass itself. Returns the hits, the contradictions, and the
 * counts; writes the audit line as a side effect (every job, no
 * exceptions — the audit line is how the owner sees it happened). */
function filesFirstPass(jobText, charter) {
  charter = charter || lib.loadCharter();
  const job = String(jobText || '');
  const words = jobWords(job);

  const mem = lib.loadMemory();
  const pool = [
    ...(charter.facts || []).map(t => ({ text: String(t), source: 'setup facts' })),
    ...(mem.facts || []).map(f => ({ text: f.text, source: 'memory', id: f.id, project: f.project })),
  ];
  const memoryHits = pool
    .map(f => ({ ...f, score: wordScore(words, f.text) }))
    .filter(f => f.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);

  const knowledgeHits = [];
  const index = pack.knowledgeIndex();
  for (const k of index) {
    let content = '';
    try { content = fs.readFileSync(path.join(pack.KNOW_DIR, k.file), 'utf8'); } catch { /* unreadable: title still counts */ }
    const s = wordScore(words, `${k.title} ${k.file}`) * 2 + wordScore(words, content);
    if (s >= 2) knowledgeHits.push({ file: k.file, title: k.title, score: s });
  }
  knowledgeHits.sort((a, b) => b.score - a.score);

  const toolHits = pack.searchPack(job, 8).map(t => ({ id: t.id, name: t.name, kind: t.kind || 'method' }));

  const contradictions = findContradictions(job, words, pool);

  const pass = {
    job: job.slice(0, 120),
    memoryHits, knowledgeHits, toolHits, contradictions,
    counts: {
      memory: memoryHits.length, knowledge: knowledgeHits.length, tools: toolHits.length,
      contradictions: contradictions.length,
      memoryTotal: pool.length, knowledgeTotal: index.length, toolsTotal: pack.loadManifest().tools.length,
    },
  };
  lib.audit('files-first', {
    job: pass.job,
    memory: pass.counts.memory, knowledge: pass.counts.knowledge, tools: pass.counts.tools,
    contradictions: pass.counts.contradictions,
    memoryFound: memoryHits.map(h => h.text.slice(0, 80)),
    knowledgeFiles: knowledgeHits.map(h => h.file),
    toolIds: toolHits.map(h => h.id),
  });
  return pass;
}

/* The plain-words flag shown to the owner when a saved fact clashes
 * with the job. The job does NOT run behind this message. */
function flagText(pass) {
  const lines = ['Before I run that, I checked my files first — and a saved note clashes with this job:'];
  for (const c of pass.contradictions) {
    if (c.kind === 'amount') {
      lines.push(`- Your saved notes say: "${c.fact}" (${c.factAmounts.join(', ')}) — this job says ${c.jobAmounts.join(', ')}. Which stands?`);
    } else {
      lines.push(`- Your saved notes say: "${c.fact}" — this job asks for the thing that note rules out. Which stands?`);
    }
  }
  lines.push('Nothing was run and nothing was charged. Tell me which stands — the saved note or this job — and I will go with your word.');
  return lines.join('\n');
}

/* The section that rides into the Brain's planning prompt, so the
 * model plans from the owner's own record. */
function briefSection(pass) {
  const lines = ['FILES FIRST — before planning, I checked the owner\'s own files for anything related to this job. Plan from what they say:'];
  lines.push(pass.memoryHits.length
    ? `Saved facts that match: ${pass.memoryHits.map(h => `"${h.text}"`).join('; ')}`
    : 'Saved facts that match: (none)');
  if (pass.counts.knowledgeTotal) {
    lines.push(pass.knowledgeHits.length
      ? `Knowledge/playbook files that match: ${pass.knowledgeHits.map(h => `${h.file} — ${h.title}`).join('; ')} (read one whole with read_file when the job needs it)`
      : 'Knowledge/playbook files that match: (none)');
  }
  if (pass.counts.toolsTotal) {
    lines.push(pass.toolHits.length
      ? `Loaded tools that match: ${pass.toolHits.map(h => `${h.id} — ${h.name}`).join('; ')} (apply one with a pack_tool step)`
      : 'Loaded tools that match: (none)');
  }
  return lines.join('\n');
}

/* One short line for the CLI / chat surface, so the owner sees the
 * pass happened without opening the log. */
function summaryLine(pass) {
  const c = pass.counts;
  return `Files first: checked my memory (${c.memoryTotal} fact(s)), knowledge (${c.knowledgeTotal} file(s)) and tools (${c.toolsTotal} loaded) — found ${c.memory} fact(s), ${c.knowledge} file(s) and ${c.tools} tool(s) related to this job.`;
}

module.exports = { filesFirstPass, flagText, briefSection, summaryLine, findContradictions, jobWords };
