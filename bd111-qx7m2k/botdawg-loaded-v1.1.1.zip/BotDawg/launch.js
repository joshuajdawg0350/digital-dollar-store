/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ one-click launcher — what START BOTDAWG runs.
 *
 * Double-clicking the launcher is the whole front door:
 *   1. First run only: if there is no charter.json yet, setup runs
 *      by itself, right here — no terminal, no typed commands.
 *   2. If BotDawg is already running, the chat just opens.
 *   3. Otherwise BotDawg starts in the background and the chat
 *      screen opens in the owner's default browser by itself.
 *
 * The Node.js check lives in the START BOTDAWG shell files (this
 * script cannot run without Node to check for it). Nothing here
 * leaves the computer: the console serves 127.0.0.1 only.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn, spawnSync } = require('child_process');

const ROOT = __dirname;
const PORT = 7900;
const URL = `http://127.0.0.1:${PORT}/`;

function openBrowser(url) {
  try {
    const opts = { detached: true, stdio: 'ignore' };
    if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], opts).unref();
    else if (process.platform === 'darwin') spawn('open', [url], opts).unref();
    else spawn('xdg-open', [url], opts).unref();
  } catch { /* opening is a courtesy — the address is printed below too */ }
}

function probe() {
  return new Promise((resolve) => {
    const req = http.get(URL, (r) => { r.resume(); resolve(r.statusCode === 200); });
    req.on('error', () => resolve(false));
    req.setTimeout(1500, () => { req.destroy(); resolve(false); });
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  if (!fs.existsSync(path.join(ROOT, 'charter.json'))) {
    console.log('First run — setting BotDawg up in this folder…');
    spawnSync(process.execPath, [path.join(ROOT, 'botdawg.js'), 'setup'], { stdio: 'inherit' });
  }
  if (await probe()) {
    console.log('BotDawg is already running — opening the chat.');
    openBrowser(URL);
    return;
  }
  console.log('Starting BotDawg…');
  const child = spawn(process.execPath, [path.join(ROOT, 'botdawg.js'), 'console'], {
    cwd: ROOT, detached: true, stdio: 'ignore',
  });
  child.unref();
  for (let i = 0; i < 40; i++) {
    if (await probe()) {
      openBrowser(URL);
      console.log(`BotDawg is up — the chat opened in your browser. (${URL})`);
      return;
    }
    await sleep(500);
  }
  console.log(`BotDawg is still starting — open ${URL} in your browser in a few seconds.`);
})().catch((e) => {
  console.log(`BotDawg could not start (${e.message}). Open ${URL} after starting it the manual way — see START-HERE.md.`);
  process.exit(1);
});
