# Top 25 Templates Pack — Digital Dollar Store

**25 real, working templates + 5 bonus novelty joke certificates. One download.**

Every spreadsheet has live formulas (they calculate in Excel and Google Sheets — nothing is a picture of a spreadsheet). Every document is editable. Every planner prints cleanly on US Letter. Items marked EXAMPLE inside are filled with sample data so you can see how they work — delete the samples and type your own.

## How to open things

- **.xlsx** — Microsoft Excel, or upload to Google Drive and open with Google Sheets (free). Formulas work in both.
- **.docx** — Microsoft Word, or Google Docs (upload to Drive). Every folder's documents also include a **.pdf** twin showing the finished look.
- **.pptx** — PowerPoint, Google Slides, or import into Canva.
- **.pdf** — any PDF reader. Print at 100% scale on US Letter unless a piece states its own size (wedding suite pieces are true-size print-shop files).

Each numbered folder has a **HOW-TO.txt** explaining that item in plain words.

## What's inside

| # | Item | Format |
|---|---|---|
| 01 | Paycheck & Annual Budget Spreadsheet — dashboard, monthly + paycheck budgets, bills calendar, expense tracker (budget actuals fill themselves), debt & savings, annual summary with chart | XLSX |
| 02 | Digital Life Planner — hyperlinked for GoodNotes/Notability (index links + bookmarks) and printable; undated: year-at-a-glance 2027, goals, 12 monthly, weekly & daily pages, habit trackers, money & meal pages, to-dos, notes, stickers | PDF (36 pp) |
| 03 | ATS Resume + Cover Letter + References Bundle — ATS-safe resume, designed resume, optional page 2, cover letter, references, resume guide with action verbs | DOCX + PDF |
| 04 | Wedding Invitation Suite (Garden Blue) — invitation, save-the-date, RSVP, details, menu, place cards, table numbers, welcome sign, thank-you, seating chart — true print sizes + all text editable | PDF + DOCX |
| 05 | Instagram Post Pack — 30 square posts + 5 highlight covers (small-business edition), captions & content pillars guide | PPTX + PDF |
| 06 | Small-Business Bookkeeping Spreadsheet — income/expense/sales logs, pricing calculator, tax set-aside estimator (not tax advice), annual summary that fills itself by month | XLSX |
| 07 | Debt Payoff Tracker — snowball + avalanche plans with real payoff math (NPER), combined schedule with chart | XLSX |
| 08 | Invoice + Quote/Estimate + Receipt Pack — matching set + invoice tracker (outstanding totals itself) | DOCX + PDF + XLSX |
| 09 | Wedding Planner — budget, guest list & RSVP headcounts, vendors & balances, checklist, day-of timeline + printable binder pages | XLSX + PDF |
| 10 | Meal Planner + Grocery List + Recipe Cards — weekly & monthly plans, aisle-by-aisle grocery lists, pantry/freezer inventories, recipe cards, meal-prep page | PDF |
| 11 | Social Media Content Calendar — month grids, post tracker, ideas bank, hashtag bank, analytics, repurposing checklist | XLSX |
| 12 | Home Management Binder — daily tidy, weekly/monthly cleaning, deep-clean lists, chore chart, maintenance log, emergency contacts | PDF |
| 13 | Freelance Contract + Proposal + Onboarding Pack — proposal, general services agreement (general template — **not legal advice**), onboarding questionnaire, welcome packet, email scripts | DOCX + PDF |
| 14 | Pitch Deck — 18 widescreen slides incl. an editable financials chart and speaker notes on every slide (built on a fictional example company — replace with your real numbers) | PPTX |
| 15 | Teacher Lesson Planner + Classroom Pack — lesson grids, roster, seating chart, substitute sheet, certificates + grade/attendance tracker with automatic averages | PDF + XLSX |
| 16 | Wellness Journal + Habit Tracker — habit grid, mood & sleep logs, gratitude pages, self-care menu, 30 days of prompts, weekly reset (a journaling tool — no medical claims) | PDF |
| 17 | Party Kit — Dinosaur Birthday (original artwork, no licensed characters): invitation, welcome sign, bingo, word search + answer key, scavenger hunt, favour tags, thank-you | PDF |
| 18 | Job Application Tracker + Interview Planner — applications, pipeline counts, weighted offer comparison, networking log + printable interview prep & follow-up emails | XLSX + PDF |
| 19 | Life OS Dashboard — tasks, goals, habits, finance-lite as a ready spreadsheet + a step-by-step guide to rebuilding the same system free in Notion + printable dashboard pages (a live Notion link can't be zipped into a file — this is the honest equivalent) | XLSX + PDF |
| 20 | Brand Kit + Media Kit + Rate Card — brand board, business card, 3-page media kit, rate card | PDF + DOCX |
| 21 | ADHD Daily Planner — brain dumps, 3-box today pages, time blocks, focus sessions, reward menu, forgiving weekly reset, streak-free habit dots (a planning aid — no medical claims) | PDF |
| 22 | Seller/Maker Inventory + Pricing Calculator + Order Tracker — reorder flags, materials costing, price calculator, channel totals + printable bench pages | XLSX + PDF |
| 23 | 2027 Calendar + Monthly Planner — year at a glance, all 12 months with real 2027 dates, US holidays (computed), birthdays page, undated month | PDF |
| 24 | Client Tracker / Simple CRM — clients, projects, payments; follow-ups due and money owed total themselves | XLSX |
| 25 | One-Page Business Plan + Planner Pages — one-page plan, full plan, launch checklist + 12-month forecast spreadsheet | DOCX + PDF + XLSX |

## BONUS — Novelty Jokes folder

5 gag certificates (a Smart-Ass University "Doctorate of Balderdash", coworker superlative awards, a Licence to Chill retirement certificate, a fantasy gamer diploma, and family awards). Every one is stamped **NOVELTY** in giant letters across its face with joke institutions and cartoon seals — obvious gags for parties and office pranks, in their own folder so they're never confused with the real templates.

## Honest notes

- Sample data is marked EXAMPLE wherever it appears. Spreadsheets calculate for real; documents with sample wording (resume, pitch deck, wedding suite) must be replaced with your own before use — the HOW-TO in each folder says exactly what to change.
- The freelance agreement is a general template, **not legal advice**. The tax set-aside sheet is a planning estimate, **not tax advice**. The wellness and ADHD planners are journaling/planning aids, **not medical products**.
- Print planners at 100% — don't use "fit to page", or the margins shrink.

*Digital Dollar Store — questions or a file that won't open? Tell us the item number and we'll make it right.*
