# HONEST LIMITS — what BotDawg v1.0.5 does and does not do

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

We would rather tell you plainly than sell you a surprise. This is
the whole list, and it matches how the product actually behaves —
when BotDawg hits one of these limits it says so on the output
(UNABLE, UNCHECKED, or "built-in mode") instead of faking it.

## The human check (new in v1.0.1) — exactly what it does

- It is a **permission**, not a default. The human-check skill is
  **off** unless you switch it on (console tick, setup flag, or
  `"allowHumanCheck": true` in `charter.json`). With it off,
  BotDawg refuses the job in plain words and does not even open
  the page.
- With it on, BotDawg clicks **the checkbox only** — the "Verify
  you are human" box on a page you send it to — and then verifies
  the check actually cleared before it reports success. Three
  tries at most; after that it reports FAILED with the exact
  state it saw.
- It does **not** solve image puzzles, audio challenges, or any
  other test beyond that one checkbox. It does **not** pretend to
  be a person: it clicks the box the page offers, under your
  permission, in BotDawg's own browser.
- **Some sites may still refuse it.** A site's systems can often
  tell the click came from an automated browser, and the check
  may reset instead of clearing. When that happens BotDawg says
  FAILED and tells you what it saw — it will not smooth that
  over.
- **Real-site behavior is untested, and we say so.** The skill
  was proven against a locally built mock of the widget — one
  variant that clears, one that resets forever — and it behaved
  correctly on both (cleared the first, failed the second
  honestly after 3 attempts). It has **not** been run against a
  real site's live challenge, and no claim is made that it will
  clear any particular site.
- Every use is written to the audit log (`audit.jsonl`) with the
  page, the time, and the result.

## The chat box (new in v1.0.2) — exactly what it is

- The console screen carries a **chat box with BotDawg's head on
  it**. You type in plain words; BotDawg answers in the
  conversation, under the name and in the voice you gave it.
- It is a **local chat on your own console** (127.0.0.1, your
  computer only). It is **not** a chat-app channel: no texting, no
  messaging apps, no social accounts, and nothing about the
  conversation leaves this folder.
- Chat is not a side door around the rules. Questions are answered
  from your charter facts and memory (and, if you connected one,
  your own model — the buyer-model path is still the untested one
  described below). Jobs handed over in chat go through the same
  planner and run loop as the work boxes: **estimate first, live
  meter, your caps, your permissions, every run in the audit log.**
- The nevers hold in chat too. Ask it in chat to send, post, buy,
  pay, delete, or log in, and it refuses in plain words — and,
  where a draft is the useful thing, prepares the draft instead.
- The conversation is kept in `chat-history.json` in this folder
  so BotDawg can follow the thread. It is a plain file: read it,
  or delete it and the conversation starts fresh. It is never sent
  anywhere.
- In built-in mode (no model connected), chat answers questions
  from what BotDawg remembers and what its skills can do. A
  question outside both gets an honest "not in either yet" plus
  your words sharpened by the built-in Prompt Generator — never a
  made-up answer.

## Building a website (new in v1.0.5) — exactly what it does

- BotDawg can build you a website — one page of it. Say "build me a
  website" and it produces **one complete, self-contained HTML
  file**: header with your business name and tagline, About,
  Services, Contact, footer. Open it in any browser; hand it to
  any host.
- The page is built **only from what BotDawg knows about your
  business** — your setup facts and the facts you taught it.
  Anything it does not know stays marked **[fill-in]** in the
  page, and its reply lists exactly which facts were missing. It
  never invents services, prices, hours, or claims to fill a page.
- **One-page site only in built-in mode.** No extra pages, no
  menus of sub-pages. Ask for more and it says so plainly instead
  of faking a bigger build.
- **No online store, no checkout.** The built page cannot take
  orders or payments. It shows what you offer and how to reach
  you — selling through it is not in this skill.
- **No hosting.** BotDawg makes the file; it does not host, post,
  or upload it, ever. Putting the page online — your host, your
  account, your hand — is your step, the same as sending a draft.
- The page makes **no external requests**: styling is inline, no
  web fonts, no outside images, nothing loaded from anywhere else.

## How v1 was proven

- Every proof run published for BotDawg v1 ran in **built-in
  fallback mode** — no buyer's real model account was connected
  during testing. The skills, planner, memory, meter, and run loop
  were all exercised for real; writing and research synthesis were
  the built-in template/extract versions, not a live model's.
- **No buyer model account has been tested yet.** Connecting your
  own OpenAI-compatible endpoint is supported and documented, but
  we have not run v1 against a real buyer's account end to end.
  If your endpoint misbehaves, BotDawg reports the endpoint's
  answer and falls back to built-in mode rather than failing
  silently.

## What is NOT in v1

- **No voice.** BotDawg does not speak or listen.
- **No phone calls.**
- **No chat-app channels** — no texting, no messaging apps, no
  social accounts. The chat box (v1.0.5) lives on the console
  screen, on your computer only — it talks to you, on that screen,
  and to no one else. One screen (the console), one folder, the
  terminal.
- **No third-party integrations** — it does not log into your
  other services, pull your email, or sync with outside apps.

## What it will never do, by design

- It does **not** send, post, buy, pay, delete, or log in as you.
  It prepares drafts and messages; sending is always your hand.
- It does **not** invent search results, facts, or prices. Jobs
  outside its skills print UNABLE. Sources it could not open are
  listed as COULD NOT VERIFY.
- It does **not** click a "Verify you are human" checkbox unless
  you have switched that permission on — and even then it clicks
  the checkbox only, never a puzzle (see the human-check section
  above).
- It never asks for or stores your passwords or your model key —
  the key is read from an environment variable, never written to
  its files.

## Working limits to know

- **Built-in mode:** without your own model connected, writing and
  research run on templates and extracts and are labeled as such.
  Everything else — planning, watching, organizing, proof-runs,
  memory, the Prompt Generator — works the same either way.
- **Browser check:** the proof-run's real-browser check needs a
  browser engine. Run `npm install playwright` once inside this
  folder (or point the `BOTDAWG_PLAYWRIGHT` environment variable
  at an existing install). Without one, that single check prints
  UNCHECKED — never a guessed pass. Every other proof check runs
  without it. The human-check skill needs the same engine; without
  one it prints UNCHECKED and clicks nothing.
- **Schedules run only while BotDawg is running.** Standing
  watches and inbox jobs are checked while `node botdawg.js serve`
  (or the console) is up on your computer. Nothing runs while your
  computer is off, and BotDawg says so.
- **Web access:** watching, research, and proof-runs read public
  pages you point at. Pages that block readers or need a login may
  come back as COULD NOT VERIFY.
- **One computer, one folder.** BotDawg v1 is a local agent. It
  does not sync between computers; copying the folder copies the
  agent, memory and all.
