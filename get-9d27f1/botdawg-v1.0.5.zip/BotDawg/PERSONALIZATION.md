# MAKE IT YOURS — the personalization guide

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

BotDawg becomes *your* agent on one screen. No code, no config
files to hand-edit (unless you want to). Everything below is done
in the console:

```
node botdawg.js console
```

then open **http://127.0.0.1:7900** in your browser, fill in the
screen, and Save. Changes take effect immediately, and everything
BotDawg produces from then on — reports, drafts, briefs — comes out
in your name, your voice, your color.

## The fields, one by one

**Its name** (`agentName`)
Call it whatever you like — "Scout", "Front Desk", your shop dog's
name. The name shows up in its brief, its reports, and its drafts —
and it labels the chat box on the console screen. Naming it is
the whole rebrand: there is no J-Dawgs name anywhere in what it
produces for you.

**Your name** (`ownerName`) and **your business** (`ownerBusiness`)
Who it works for. Drafts sign off and reports head themselves with
your business, not ours.

**Its voice** (`voice`)
Pick one: **plain** (straight facts, no dressing), **warm**
(friendly, a little personality), or **formal** (business-letter
proper). The voice shapes every draft and note it writes — and its
chat replies: greetings, refusals, and (when your model is
connected) its open answers all speak in the voice you picked.

**Your brand color** (`brandColor`)
One hex color, like `#0096FF`. Its reports and pages use it for
headings and accents, so what it makes looks like it came from
your shop.

**Facts it should always know** (`facts`)
One fact per line: your hours, your town, your prices, how you
like things done, what you never say. These ride along in every
job — the Prompt Generator fills its slots from them, drafts write
from them, research briefs respect them. Anything you don't tell
it stays a plain [fill-in] in its output — it never guesses.

You can also teach it facts as you go, in the terminal:

```
node botdawg.js remember "We deliver free within 10 miles"
node botdawg.js recall deliver
node botdawg.js memory
node botdawg.js forget "We deliver free within 10 miles"
```

Its memory is the plain file `memory.json` — open it, read it,
edit it, delete lines. You can also ban whole topics from its
memory on the console screen; after that it refuses to save
anything touching them and tells you why.

**Job focus** (`focus`)
What it leans into: **general** (a bit of everything),
**full-audit**, **launch-check**, or **price-watch** (these three
tune its proof-run specialty — checking product pages against what
the seller claims). Change it any time; it is a leaning, not a
lock.

**Your model** (optional)
Endpoint address plus two model names — see START-HERE.md step 5.
Your key lives in the `BOTDAWG_MODEL_KEY` environment variable,
never in BotDawg's files.

**Human check permission** (`allowHumanCheck`) — new in v1.0.1
Some pages stop visitors with a **"Verify you are human"** checkbox
(the Cloudflare Turnstile box). BotDawg has a skill for exactly
that box — and it is **off by default**. It will not click anything
until you say so. Three ways to switch it on (they are the same
setting):

1. **Console:** tick *"Let BotDawg click 'Verify you are human'
   checkboxes for me"* on the setup screen, then Save.
2. **Setup:** run `node botdawg.js setup --allow-human-check`.
3. **By hand:** set `"allowHumanCheck": true` in `charter.json`.

With it on, when you send BotDawg to a page that is holding that
checkbox (in plain words: *"click verify you are human on
https://…"*, or with the Human check template), it opens the page,
clicks the one checkbox the way a person would, and then **waits
and watches until the check is really cleared** — the widget's
answer filled in, its success state showing, or the real page in
its place. Only then does it say CLEARED. If the check has not
cleared after **3 tries**, it stops and reports FAILED with the
exact state it saw. It never loops forever and never claims a
pass it did not see.

What it does **not** do, even with permission on: it clicks the
checkbox only. It does not solve picture puzzles or any other
challenge, and it does not pretend to be a person — some sites
may still refuse it, and then it tells you so plainly. Every use
— allowed, refused, cleared, or failed — is written to the
activity log (`audit.jsonl`, and the console's log panel) with
the page, the time, and the result, so you can always see exactly
when it ran. Turn it off the same way you turned it on; off is
where it starts, and off is a perfectly good place to leave it.

**The chat box** (new in v1.0.2)
The console screen carries a chat box with BotDawg's head on it.
It speaks as the agent you set up here — your name for it, your
voice — because it reads the same charter as everything else.
Ask it questions and it answers from the facts above and its
memory; hand it a job in plain words and it runs through the same
planner, estimate, caps, and audit log as the work box. Ask it to
do one of the things it never does (send, post, buy, pay, delete,
log in) and it will tell you no in your chosen voice and offer a
draft instead. The conversation is stored in `chat-history.json`
in the BotDawg folder — delete that file any time to start the
conversation fresh.

**Usage caps** (`caps`)
Two numbers: the most units one task may use, and the most units
per day. BotDawg stops at the cap and says so, in plain words.
Failed and stopped tasks are charged 0. Start with the defaults
(60 per task, 300 per day) and adjust once you see your rhythm in
`node botdawg.js usage`.

## Doing it by hand (optional)

Every setting lives in `charter.json`, a plain text file in this
folder. If you'd rather edit it with a text editor than use the
screen, you can — keep the punctuation exactly as it is, save,
and restart the console. The screen and the file are the same
settings; use whichever you like.

## Starter templates

The `templates/` folder holds ready-made jobs shaped by what
buyers ask for most: proof-run a product page, watch a price page,
a research brief, follow-up drafts. Open one, change the details
to yours, and run it from the console or with:

```
node botdawg.js do templates/watch-a-price-page.json
```

And once BotDawg does a routine the same way twice, teach it:
save the steps as a small file and run
`node botdawg.js teach my-routine steps.json` — it becomes one of
its personal skills. (The console explains the step format.)
