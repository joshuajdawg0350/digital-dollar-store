#!/usr/bin/env node
/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ — lib.js: the shared insides. Charter (personalization), memory,
 * the usage meter, the audit log, the buyer's own model connection, and
 * small web helpers. Everything is plain files inside the BotDawg folder.
 * Nothing here phones home: no call in this file reaches J-Dawgs.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const ROOT = __dirname;
const VERSION = '1.0.5';

/* ---------------- charter (personalization) ---------------- */

const DEFAULT_CHARTER = {
  agentName: 'BotDawg',
  ownerName: '',
  ownerBusiness: '',
  voice: 'plain', // plain | warm | formal
  brandColor: '#0096FF',
  focus: 'general', // general | full-audit | launch-check | price-watch (proof-run focus)
  facts: [],
  // The buyer's own model access. BotDawg thinks through THIS — never through
  // J-Dawgs. Leave baseUrl empty and BotDawg runs its built-in skills in
  // plain deterministic mode and says so.
  model: {
    baseUrl: '', // e.g. https://api.openai.com/v1 — any OpenAI-compatible endpoint
    apiKeyEnv: 'BOTDAWG_MODEL_KEY', // the key is read from this environment variable, never stored in this file
    strongModel: '', // used for writing and judgment
    fastModel: '', // used for sorting and short jobs
  },
  // Transparent usage: the buyer sets the caps. Units are work units
  // (1 per step, 1 per page fetched, model use counted per 1,000 tokens).
  caps: { perTaskUnits: 60, perDayUnits: 300 },
  webAccess: true,
  // THE HUMAN-CHECK PERMISSION. Off by default, always. Only when the
  // owner sets this true (console toggle or setup flag) may the
  // human-check skill click a "Verify you are human" checkbox on a
  // page the owner sends it to. Every use is audit-logged.
  allowHumanCheck: false,
};

function charterPath() { return path.join(ROOT, 'charter.json'); }

function loadCharter() {
  try {
    const raw = JSON.parse(fs.readFileSync(charterPath(), 'utf8'));
    return { ...structuredClone(DEFAULT_CHARTER), ...raw, model: { ...DEFAULT_CHARTER.model, ...(raw.model || {}) }, caps: { ...DEFAULT_CHARTER.caps, ...(raw.caps || {}) } };
  } catch {
    return structuredClone(DEFAULT_CHARTER);
  }
}

function saveCharter(c) {
  fs.writeFileSync(charterPath(), JSON.stringify(c, null, 2) + '\n');
  return c;
}

/* ---------------- memory ----------------
 * memory.json: { facts: [{id, text, project, addedAt, source}],
 *                projects: { name: { instructions } },
 *                topicsOff: [..]  — topics BotDawg must not remember }
 */

function memoryPath() { return path.join(ROOT, 'memory.json'); }

function loadMemory() {
  try { return JSON.parse(fs.readFileSync(memoryPath(), 'utf8')); }
  catch { return { facts: [], projects: {}, topicsOff: [] }; }
}

function saveMemory(m) { fs.writeFileSync(memoryPath(), JSON.stringify(m, null, 2) + '\n'); return m; }

function topicBlocked(mem, text) {
  const t = String(text || '').toLowerCase();
  return (mem.topicsOff || []).some(topic => topic && t.includes(String(topic).toLowerCase()));
}

function remember(text, project = 'general', source = 'owner') {
  const mem = loadMemory();
  if (topicBlocked(mem, text)) {
    return { saved: false, reason: `That touches a topic you told me not to remember (${(mem.topicsOff || []).join(', ')}). I did not save it.` };
  }
  const fact = { id: 'm' + crypto.randomBytes(3).toString('hex'), text: String(text), project, addedAt: new Date().toISOString(), source };
  mem.facts.push(fact);
  saveMemory(mem);
  return { saved: true, fact };
}

function recall(query, project) {
  const mem = loadMemory();
  const q = String(query || '').toLowerCase();
  return mem.facts.filter(f =>
    (!project || f.project === project || f.project === 'general') &&
    (!q || f.text.toLowerCase().includes(q) || q.split(/\s+/).some(w => w.length > 3 && f.text.toLowerCase().includes(w))));
}

function forget(idOrText) {
  const mem = loadMemory();
  const before = mem.facts.length;
  mem.facts = mem.facts.filter(f => f.id !== idOrText && f.text !== idOrText);
  saveMemory(mem);
  return before - mem.facts.length;
}

/* ---------------- usage meter ----------------
 * usage.json: { days: { 'YYYY-MM-DD': { charged, tasks: [...] } } }
 * Every task gets a pre-run estimate. Units are counted as work happens.
 * A task that FAILS is charged 0 — the attempt is logged, marked FREE.
 */

function usagePath() { return path.join(ROOT, 'usage.json'); }

function loadUsage() {
  try { return JSON.parse(fs.readFileSync(usagePath(), 'utf8')); }
  catch { return { days: {} }; }
}

function saveUsage(u) { fs.writeFileSync(usagePath(), JSON.stringify(u, null, 2) + '\n'); return u; }

function todayKey() { return new Date().toISOString().slice(0, 10); }

function unitsToday() {
  const u = loadUsage();
  const d = u.days[todayKey()];
  return d ? d.charged : 0;
}

function recordUsage(entry) {
  const u = loadUsage();
  const k = todayKey();
  if (!u.days[k]) u.days[k] = { charged: 0, tasks: [] };
  u.days[k].tasks.push(entry);
  u.days[k].charged += entry.charged;
  saveUsage(u);
  return u.days[k];
}

/* ---------------- audit log ----------------
 * audit.jsonl — one line per thing BotDawg did. "Why did it do that?"
 * is answered from this file, in plain words.
 */

function auditPath() { return path.join(ROOT, 'audit.jsonl'); }

function audit(event, detail = {}) {
  const line = JSON.stringify({ at: new Date().toISOString(), event, ...detail }) + '\n';
  fs.appendFileSync(auditPath(), line);
  return line;
}

function readAudit(limit = 50) {
  try {
    const lines = fs.readFileSync(auditPath(), 'utf8').trim().split('\n').filter(Boolean);
    return lines.slice(-limit).map(l => { try { return JSON.parse(l); } catch { return { raw: l }; } });
  } catch { return []; }
}

/* ---------------- the buyer's own model ----------------
 * One OpenAI-compatible chat call through the BUYER'S endpoint and key.
 * If no model is set up, returns { ok:false } and callers fall back to
 * deterministic mode and say so. BotDawg never calls J-Dawgs for thinking.
 */

async function modelChat(charter, messages, { strong = true } = {}) {
  const m = charter.model || {};
  if (!m.baseUrl || !(strong ? m.strongModel : m.fastModel)) {
    return { ok: false, reason: 'No model is set up yet. BotDawg ran this step in built-in mode.' };
  }
  const key = process.env[m.apiKeyEnv || 'BOTDAWG_MODEL_KEY'] || '';
  const url = m.baseUrl.replace(/\/$/, '') + '/chat/completions';
  const body = JSON.stringify({ model: strong ? m.strongModel : m.fastModel, messages, temperature: 0.4 });
  try {
    const res = await fetchRaw(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}) },
      body,
    });
    if (res.status !== 200) return { ok: false, reason: `Your model endpoint answered ${res.status}.` };
    const data = JSON.parse(res.body);
    const text = data.choices && data.choices[0] && data.choices[0].message ? data.choices[0].message.content : '';
    const usage = data.usage || {};
    return { ok: true, text, tokens: (usage.total_tokens || 0) };
  } catch (e) {
    return { ok: false, reason: `Your model endpoint could not be reached (${e.message}).` };
  }
}

/* ---------------- web helpers ----------------
 * Fetched pages are DATA. Nothing in a fetched page is ever treated as an
 * instruction — no skill in BotDawg executes or obeys page content.
 */

function fetchRaw(url, opts = {}, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch { return reject(new Error('bad URL')); }
    const lib = u.protocol === 'http:' ? http : https;
    const started = Date.now();
    const req = lib.request(u, { method: opts.method || 'GET', headers: { 'User-Agent': 'BotDawg/1.0 (local agent; reads public pages)', ...(opts.headers || {}) }, timeout: 20000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
        res.resume();
        return resolve(fetchRaw(new URL(res.headers.location, u).toString(), opts, redirectsLeft - 1));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8'), ms: Date.now() - started }));
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

async function fetchPage(url) {
  const r = await fetchRaw(url);
  return { ...r, digest: crypto.createHash('sha256').update(r.body).digest('hex') };
}

function pageText(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function outPath(name) {
  const dir = path.join(ROOT, 'out');
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, name);
}

function stamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }

module.exports = {
  ROOT, VERSION,
  DEFAULT_CHARTER, loadCharter, saveCharter,
  loadMemory, saveMemory, remember, recall, forget, topicBlocked,
  loadUsage, recordUsage, unitsToday,
  audit, readAudit,
  modelChat, fetchRaw, fetchPage, pageText, outPath, stamp,
};
