/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Human Check skill: clicks a "Verify you are human"
 * checkbox (a Cloudflare Turnstile-style widget) on a page YOU send
 * it to — and only when you have switched the permission on.
 *
 * THE PERMISSION GATE IS THE POINT. This skill is OFF by default.
 * Unless charter.json says allowHumanCheck: true (set on the console
 * screen or at setup), the skill refuses in plain words and does
 * nothing at all — it does not even open the page. Every use, allowed
 * or refused, is written to the audit log with the page, the time,
 * and the result.
 *
 * What it does: opens the page in BotDawg's real browser, finds the
 * human-check widget, moves to the checkbox the way a person would
 * (travel, hover, click), then WAITS and watches until the check is
 * actually cleared — the widget's answer token filled, its success
 * state showing, or the challenge gone and the real page in its
 * place. Only then does it report success.
 *
 * What it does NOT do: it does not solve image puzzles or any other
 * challenge beyond the single checkbox. It does not pretend to be a
 * person — it clicks the box the page offers, under your permission,
 * and some sites may still refuse it; when they do, it says so. If
 * the check has not cleared after 3 attempts it stops and reports
 * FAILED with the exact state it saw — it never loops forever and
 * never claims a pass it did not see.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');
const lib = require('../lib');

const MAX_ATTEMPTS = 3;
const CLEAR_WAIT_MS = 15000; // per attempt: how long to watch for the clear
const POLL_MS = 500;

function loadPlaywright() {
  const candidates = [
    process.env.BOTDAWG_PLAYWRIGHT,
    path.join(lib.ROOT, 'node_modules', 'playwright'),
    'playwright',
  ].filter(Boolean);
  for (const c of candidates) {
    try {
      const req = createRequire(path.join(__dirname, 'human-check.js'));
      return req(c);
    } catch (e) { /* try next */ }
  }
  return null;
}

function findChromiumExecutable() {
  for (const cache of [path.join(lib.ROOT, 'browsers'), path.join(process.env.HOME || '', '.cache/ms-playwright')]) {
    try {
      const shells = fs.readdirSync(cache)
        .filter((d) => d.startsWith('chromium_headless_shell-'))
        .sort()
        .reverse();
      for (const s of shells) {
        const p = path.join(cache, s, 'chrome-headless-shell-linux64', 'chrome-headless-shell');
        if (fs.existsSync(p)) return p;
      }
      const full = fs.readdirSync(cache).filter((d) => d.startsWith('chromium-')).sort().reverse();
      for (const s of full) {
        const p = path.join(cache, s, 'chrome-linux', 'chrome');
        if (fs.existsSync(p)) return p;
      }
    } catch (e) { /* try the next location */ }
  }
  return null;
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

/* Find the human-check widget on the page. Returns a description of
 * what was found: a challenge frame (Turnstile renders in an iframe),
 * an in-page widget, or just the answer field. */
async function findWidget(page) {
  for (const frame of page.frames()) {
    const u = frame.url() || '';
    if (/challenges\.cloudflare\.com|turnstile/i.test(u)) return { kind: 'frame', frame };
  }
  const inPage = await page.evaluate(() => {
    const widget = document.querySelector('.cf-turnstile, [data-sitekey], [id*="turnstile" i], [class*="turnstile" i]');
    const answer = document.querySelector('input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]');
    const bodyText = (document.body && document.body.innerText) || '';
    return {
      widget: !!widget,
      answer: !!answer,
      saysVerify: /verify you are human/i.test(bodyText),
    };
  }).catch(() => ({ widget: false, answer: false, saysVerify: false }));
  if (inPage.widget || inPage.answer || inPage.saysVerify) return { kind: 'page', ...inPage };
  return null;
}

/* Is the check cleared RIGHT NOW? Reads only state the page itself
 * exposes: the answer token the widget fills in, a success state in
 * the challenge frame, or the challenge gone with real content in
 * its place. */
async function checkCleared(page) {
  const token = await page.evaluate(() => {
    const a = document.querySelector('input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]');
    return a && a.value ? a.value : '';
  }).catch(() => '');
  if (token) return { cleared: true, how: 'the widget filled in its answer token' };

  for (const frame of page.frames()) {
    const u = frame.url() || '';
    if (/challenges\.cloudflare\.com|turnstile/i.test(u)) {
      const state = await frame.evaluate(() => {
        const cb = document.querySelector('input[type="checkbox"]');
        const text = (document.body && document.body.innerText) || '';
        return { checked: !!(cb && cb.checked), success: /success/i.test(text) };
      }).catch(() => ({ checked: false, success: false }));
      if (state.success || state.checked) return { cleared: true, how: 'the widget shows its success state' };
      return { cleared: false, how: 'the challenge widget is still on the page, unchecked' };
    }
  }

  const pageState = await page.evaluate(() => {
    const bodyText = (document.body && document.body.innerText) || '';
    const widget = document.querySelector('.cf-turnstile, [data-sitekey], [id*="turnstile" i], [class*="turnstile" i]');
    return {
      widgetGone: !widget,
      stillVerifying: /performing security verification|verify you are human/i.test(bodyText),
    };
  }).catch(() => ({ widgetGone: false, stillVerifying: true }));
  if (pageState.widgetGone && !pageState.stillVerifying) {
    return { cleared: true, how: 'the challenge is gone and the page itself has loaded' };
  }
  return { cleared: false, how: 'the page still shows the human check' };
}

/* Click the checkbox the way a person would: travel to it in steps,
 * hover a moment, then click. Works on a checkbox inside the
 * challenge frame, an in-page checkbox, or — when the widget hides
 * its input — the left end of the widget box, where the box sits. */
async function clickCheckbox(page, found) {
  let target = null;
  if (found.kind === 'frame') {
    const cb = found.frame.locator('input[type="checkbox"]').first();
    if (await cb.count().catch(() => 0)) target = cb;
    else {
      const el = await page.locator('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile" i]').first().elementHandle().catch(() => null);
      if (el) {
        const box = await el.boundingBox();
        if (box) {
          await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 12 });
          await page.mouse.move(box.x + 22, box.y + box.height / 2, { steps: 6 });
          await sleep(450);
          await page.mouse.down();
          await sleep(90);
          await page.mouse.up();
          return true;
        }
      }
      return false;
    }
  } else {
    const cb = page.locator('.cf-turnstile input[type="checkbox"], [data-sitekey] input[type="checkbox"], input[type="checkbox"]').first();
    if (await cb.count().catch(() => 0)) target = cb;
    else {
      const el = await page.locator('.cf-turnstile, [data-sitekey]').first().elementHandle().catch(() => null);
      if (!el) return false;
      const box = await el.boundingBox();
      if (!box) return false;
      await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 12 });
      await page.mouse.move(box.x + 22, box.y + box.height / 2, { steps: 6 });
      await sleep(450);
      await page.mouse.down();
      await sleep(90);
      await page.mouse.up();
      return true;
    }
  }
  const handle = await target.elementHandle();
  if (!handle) return false;
  const box = await handle.boundingBox().catch(() => null);
  if (box) {
    await page.mouse.move(box.x - 40, box.y + 30, { steps: 4 });
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 10 });
  } else {
    await handle.hover().catch(() => {});
  }
  await sleep(450);
  await handle.click().catch(async () => {
    if (box) { await page.mouse.down(); await sleep(90); await page.mouse.up(); }
  });
  return true;
}

async function run(step, ctx) {
  const url = step.url;
  if (!url) return { ok: false, units: 0, summary: 'A human check needs the page address (URL) to go to.' };

  /* ---- THE PERMISSION GATE — checked before anything else. ---- */
  if (!ctx.charter.allowHumanCheck) {
    lib.audit('human-check-refused', { url, result: 'refused — owner has not allowed human checks' });
    return {
      ok: false, units: 0,
      summary: 'I am not allowed to click "Verify you are human" checkboxes — you have not switched that permission on. It is off by default. To allow it: open the console and tick "Let BotDawg click \'Verify you are human\' checkboxes for me", or add "allowHumanCheck": true to charter.json. I did nothing — I did not even open the page.',
      detail: { state: 'refused' },
    };
  }
  if (!ctx.charter.webAccess) {
    lib.audit('human-check-refused', { url, result: 'refused — web access is off' });
    return { ok: false, units: 0, summary: 'Web access is turned off in your settings, so I cannot open that page at all.', detail: { state: 'refused' } };
  }

  const pw = loadPlaywright();
  if (!pw) {
    lib.audit('human-check', { url, result: 'UNCHECKED — no browser engine installed' });
    return {
      ok: false, units: 0,
      summary: 'UNCHECKED: no browser engine is installed on this computer, so the human check did not run. Run "npm install playwright" once inside this folder (or point BOTDAWG_PLAYWRIGHT at an existing install) and ask again. I will not claim a click I could not make.',
      detail: { state: 'unchecked-no-browser' },
    };
  }

  let browser;
  const statesSeen = [];
  try {
    const executablePath = findChromiumExecutable();
    browser = await pw.chromium.launch(executablePath ? { executablePath } : {});
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});

    const foundFirst = await findWidget(page);
    if (!foundFirst) {
      lib.audit('human-check', { url, result: 'no check on the page — nothing to click', attempts: 0 });
      return { ok: true, units: 1, summary: `No human check on ${url} — the page is open and there was nothing to click.`, detail: { state: 'no-check' } };
    }
    const already = await checkCleared(page);
    if (already.cleared) {
      lib.audit('human-check', { url, result: `already cleared before any click — ${already.how}`, attempts: 0 });
      return { ok: true, units: 1, summary: `The human check on ${url} was already cleared (${already.how}) — nothing to click.`, detail: { state: 'already-cleared' } };
    }

    let lastState = 'the widget never appeared';
    let attemptsMade = 0;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      attemptsMade = attempt;
      const found = await findWidget(page);
      if (!found) {
        const now = await checkCleared(page);
        if (now.cleared) {
          const shot = lib.outPath(`human-check-${lib.stamp()}.png`);
          await page.screenshot({ path: shot }).catch(() => {});
          lib.audit('human-check', { url, result: `cleared — ${now.how}`, attempts: attempt - 1 });
          return {
            ok: true, units: 3, files: [shot],
            summary: `Human check CLEARED on ${url} (${now.how}). Screenshot saved: ${shot.split('/').pop()}.`,
            detail: { state: 'cleared', attempts: attempt - 1 },
          };
        }
        lastState = 'the widget disappeared without the check clearing';
        break;
      }
      const clicked = await clickCheckbox(page, found);
      if (!clicked) { lastState = 'the checkbox was visible but could not be clicked'; continue; }

      // Watch for the clear. The widget typically shows "Verifying…"
      // for a moment, then either settles cleared or resets.
      const deadline = Date.now() + CLEAR_WAIT_MS;
      let clearedHow = null;
      while (Date.now() < deadline) {
        await sleep(POLL_MS);
        const s = await checkCleared(page);
        if (s.cleared) { clearedHow = s.how; break; }
        lastState = s.how;
      }
      statesSeen.push(`attempt ${attempt}: ${clearedHow || lastState}`);
      if (clearedHow) {
        const shot = lib.outPath(`human-check-${lib.stamp()}.png`);
        await page.screenshot({ path: shot }).catch(() => {});
        lib.audit('human-check', { url, result: `cleared on attempt ${attempt} — ${clearedHow}`, attempts: attempt });
        return {
          ok: true, units: 3, files: [shot],
          summary: `Human check CLEARED on ${url} (attempt ${attempt} of ${MAX_ATTEMPTS}: ${clearedHow}). Screenshot saved: ${shot.split('/').pop()}.`,
          detail: { state: 'cleared', attempts: attempt },
        };
      }
      if (attempt < MAX_ATTEMPTS) await sleep(1500);
    }

    const shot = lib.outPath(`human-check-${lib.stamp()}.png`);
    await page.screenshot({ path: shot }).catch(() => {});
    lib.audit('human-check', { url, result: `FAILED — did not clear after ${attemptsMade} attempt(s) (${lastState})`, attempts: attemptsMade });
    return {
      ok: false, units: 0, files: [shot],
      summary: `FAILED: the human check on ${url} did not clear after ${attemptsMade} attempt(s). Last state seen: ${lastState}. The site may be refusing automated browsers, or it may want a challenge beyond the checkbox (an image puzzle), which I do not solve. Nothing was submitted or logged in. Screenshot saved: ${shot.split('/').pop()}.`,
      detail: { state: 'not-cleared', attempts: attemptsMade, statesSeen },
    };
  } catch (e) {
    lib.audit('human-check', { url, result: `FAILED — browser error: ${e.message}` });
    return { ok: false, units: 0, summary: `FAILED: the browser hit an error on ${url} (${e.message}). The check was not cleared and I will not claim otherwise.`, detail: { state: 'error' } };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = {
  id: 'human-check',
  name: 'Human check — click a "Verify you are human" checkbox when you allow it',
  inWords: 'The address of a page that is stopping you with a "Verify you are human" checkbox — plus your permission, switched on in Settings (off by default).',
  outWords: 'CLEARED once the check is really gone, or FAILED with the exact state seen after 3 tries. Every use is written to the activity log.',
  estimate: () => 3,
  run,
};
