/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Watch skill: keeps an eye on a page for you. First run saves
 * what the page says (the baseline). Later runs compare and report
 * CHANGED — with the lines that moved — or SAME. Standing watches are
 * BotDawg's persistent assigned work: they live in watches.json and run
 * on schedule. It only reads public pages; it never logs in.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const lib = require('../lib');

function watchesFile() { return path.join(lib.ROOT, 'watches.json'); }
function loadWatches() { try { return JSON.parse(fs.readFileSync(watchesFile(), 'utf8')); } catch { return {}; } }
function saveWatches(w) { fs.writeFileSync(watchesFile(), JSON.stringify(w, null, 2) + '\n'); }

async function run(step, ctx) {
  const url = step.url;
  if (!url) return { ok: false, summary: 'A watch needs the page address (URL).' };
  if (!ctx.charter.webAccess) return { ok: false, summary: 'Web access is turned off in your settings, so I cannot check that page.' };
  let page;
  try { page = await lib.fetchPage(url); }
  catch (e) { return { ok: false, summary: `The page did not answer (${e.message}). Nothing was compared.` }; }
  if (page.status !== 200) return { ok: false, summary: `The page answered ${page.status}, not 200. Nothing was compared.` };
  const text = lib.pageText(page.body);
  const watches = loadWatches();
  // A watch is keyed by its page address, never by the label: the same
  // page watched once with a name and once without is ONE watch, so a
  // later check always compares against the first baseline.
  const key = url;
  const before = watches[key];
  // A label that is just the address again (the plain-words planner
  // sets that) counts as no label, so a human-given name is kept.
  const name = (step.label && step.label !== url ? step.label : null) || (before && before.label) || url;
  watches[key] = { url, label: name, digest: page.digest, text: text.slice(0, 20000), checkedAt: new Date().toISOString() };
  saveWatches(watches);
  if (!before) {
    return { ok: true, units: 2, summary: `Baseline saved for ${name}. Next check will tell you if anything changes.`, detail: { state: 'baseline' } };
  }
  if (before.digest === page.digest) {
    return { ok: true, units: 2, summary: `${name}: no change since ${before.checkedAt}.`, detail: { state: 'same' } };
  }
  const a = String(before.text || '').split(/(?<=[.!?])\s+/);
  const b = text.split(/(?<=[.!?])\s+/);
  const added = b.filter(s => s.length > 25 && !a.includes(s)).slice(0, 5);
  const removed = a.filter(s => s.length > 25 && !b.includes(s)).slice(0, 5);
  const file = lib.outPath(`watch-${lib.stamp()}.md`);
  fs.writeFileSync(file, `# Watch: ${name}\n${url}\nChanged since ${before.checkedAt}.\n\n## New on the page\n${added.map(s => '- ' + s).join('\n') || '- (wording changed in small ways)'}\n\n## Gone from the page\n${removed.map(s => '- ' + s).join('\n') || '- (nothing removed)'}\n`);
  return { ok: true, units: 2, files: [file], summary: `${name}: CHANGED. ${added.length} new line(s), ${removed.length} removed. Details in ${file.split('/').pop()}.`, detail: { state: 'changed', added, removed } };
}

module.exports = { id: 'watch', name: 'Watch a page', inWords: 'A page address (URL) and a name for it.', outWords: 'Baseline the first time; after that, CHANGED with the lines that moved, or SAME.', estimate: () => 2, run };
