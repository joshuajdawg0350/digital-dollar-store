/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ built-in Prompt Generator — a native edition of the J-Dawgs
 * Prompt Generator, living inside BotDawg. Same job as the standalone
 * product: you say what you want in your own words, it hands you back
 * three ready-to-use prompts — Straight, Detailed, and Short — filled
 * with what BotDawg remembers about your business. One screen, plain
 * words, no jargon. Anything it doesn't know stays as a plain
 * [fill-in] slot instead of a guess.
 */
'use strict';

const fs = require('fs');
const lib = require('../lib');

const KINDS = {
  picture: { label: 'Picture', slots: ['Subject', 'Setting', 'Mood', 'Lighting', 'Detail level', 'Must not change'] },
  video: { label: 'Video', slots: ['Subject', 'Action', 'Camera', 'Length', 'Mood', 'Must not change'] },
  writing: { label: 'Writing', slots: ['Audience', 'Tone', 'Length', 'Key points', 'Format'] },
  ad: { label: 'Ad or Post', slots: ['Product', 'Price', 'Offer', 'Audience', 'Call to action', 'Must not say'] },
  code: { label: 'Code', slots: ['The job', 'Inputs', 'Outputs', 'Rules', 'Limits'] },
  agent: { label: 'Agent Prompt', slots: ['Role', 'The job', 'Rules', 'Tools it may use', 'Done means'] },
  general: { label: 'Anything', slots: ['Goal', 'Background', 'Steps', 'Finished result', 'Limits'] },
};

function guessKind(goal) {
  const g = String(goal || '').toLowerCase();
  if (/\b(photo|picture|image|drawing|logo|thumbnail)\b/.test(g)) return 'picture';
  if (/\b(video|clip|reel|short)\b/.test(g)) return 'video';
  if (/\b(ad|advert|post|promo|sale)\b/.test(g)) return 'ad';
  if (/\b(code|app|script|program|function|bug)\b/.test(g)) return 'code';
  if (/\b(agent|bot|assistant)\b/.test(g)) return 'agent';
  if (/\b(write|email|letter|article|essay|story|caption)\b/.test(g)) return 'writing';
  return 'general';
}

function run(step, ctx) {
  const goal = String(step.goal || '').trim();
  if (!goal) return { ok: false, summary: 'The generator needs one thing: say what you want to make, in your own words.' };
  const kind = KINDS[step.kind] ? step.kind : guessKind(goal);
  const spec = KINDS[kind];
  const charter = ctx.charter;

  // What BotDawg already knows fills the background — never invented.
  const known = [
    ...(charter.facts || []),
    ...lib.recall(goal).map(f => f.text),
  ].filter((v, i, a) => a.indexOf(v) === i).slice(0, 6);

  const priceMatch = goal.match(/\$\s?\d+(?:\.\d{2})?/);
  const slotFill = {};
  for (const s of spec.slots) slotFill[s] = `[your ${s.toLowerCase()}]`;
  if (kind === 'ad' && priceMatch) slotFill.Price = priceMatch[0].replace(/\s/g, '');
  if (kind === 'picture') slotFill.Subject = goal;
  if (kind === 'general') slotFill.Goal = goal;

  const bg = known.length ? `\nBackground it should use (from what ${charter.agentName} remembers): ${known.join('; ')}.` : '';
  const straight = `${goal}.${bg} Make it ${spec.label === 'Anything' ? 'well' : `as a finished ${spec.label.toLowerCase()}`}, in a ${charter.voice} voice${charter.ownerBusiness ? ` for ${charter.ownerBusiness}` : ''}. If anything is unclear, ask before starting.`;
  const detailed = [
    `JOB: ${goal}`,
    `KIND: ${spec.label}`,
    ...spec.slots.map(s => `${s.toUpperCase()}: ${slotFill[s]}`),
    ...(known.length ? [`KNOWN FACTS: ${known.join('; ')}`] : []),
    `VOICE: ${charter.voice}.`,
    'RULES: Use only the facts above. Where a slot is still a [fill-in], ask me for it instead of guessing. Show me the finished result, not instructions for making it.',
  ].join('\n');
  const short = `${goal} — ${charter.voice} voice${known.length ? `; use these facts: ${known.slice(0, 3).join('; ')}` : ''}. Ask if unclear.`;

  const file = lib.outPath(`prompt-${lib.stamp()}.md`);
  fs.writeFileSync(file, `# Your prompts — ${spec.label}\n\nMade by ${charter.agentName} from your words: "${goal}"\n\n## 1 — Straight\n${straight}\n\n## 2 — Detailed\n${detailed}\n\n## 3 — Short\n${short}\n`);
  return {
    ok: true,
    units: 1,
    files: [file],
    summary: `Three ready prompts (${spec.label}) written to ${file.split('/').pop()}. Slots BotDawg could not fill from memory are marked [fill-in] — it never guesses.`,
    detail: { kind, variants: { straight, detailed, short } },
  };
}

module.exports = { id: 'sharpen', name: 'Sharpen a request (built-in Prompt Generator)', inWords: 'What you want to make, in your own words.', outWords: 'Three ready-to-use prompts: Straight, Detailed, Short.', estimate: () => 1, run };
