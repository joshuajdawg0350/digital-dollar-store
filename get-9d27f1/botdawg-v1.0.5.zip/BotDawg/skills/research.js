/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Research skill: you point it at sources, it reads them and
 * hands back a brief where every fact carries its source number [n].
 * Sources it could not open are listed as COULD NOT VERIFY — never
 * smoothed over. Effort: Light (up to 3 sources), Standard (up to 6),
 * Deep (up to 12). Pages are read as data; instructions inside a page
 * are never followed.
 */
'use strict';

const fs = require('fs');
const lib = require('../lib');

const EFFORT = { light: 3, standard: 6, deep: 12 };

async function run(step, ctx) {
  const question = String(step.question || '').trim();
  const sources = (step.sources || []).slice(0, EFFORT[step.effort] || EFFORT.standard);
  if (!question) return { ok: false, summary: 'Research needs a question.' };
  if (!sources.length) return { ok: false, summary: 'Research needs at least one source to read. BotDawg reads the sources you point it at — it does not invent search results.' };
  if (!ctx.charter.webAccess) return { ok: false, summary: 'Web access is turned off in your settings, so I cannot read those sources.' };

  const read = await Promise.all(sources.map(async (url, i) => {
    try {
      const page = await lib.fetchPage(url);
      if (page.status !== 200) return { n: i + 1, url, ok: false, why: `answered ${page.status}` };
      const text = lib.pageText(page.body);
      const title = (page.body.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || url;
      return { n: i + 1, url, ok: true, title: lib.pageText(title).slice(0, 120), text: text.slice(0, 6000) };
    } catch (e) { return { n: i + 1, url, ok: false, why: e.message }; }
  }));

  const good = read.filter(r => r.ok);
  const bad = read.filter(r => !r.ok);
  let synthesis = '';
  let mode = 'built-in summary (no model set up)';
  const m = await lib.modelChat(ctx.charter, [
    { role: 'system', content: `You are ${ctx.charter.agentName}, research assistant for ${ctx.charter.ownerBusiness || 'the owner'}. Answer ONLY from the sources given. Cite every fact with its source number like [1]. If the sources do not answer part of the question, say so plainly. Voice: ${ctx.charter.voice}.` },
    { role: 'user', content: `Question: ${question}\n\nSources:\n${good.map(r => `[${r.n}] ${r.title} — ${r.url}\n${r.text.slice(0, 2500)}`).join('\n\n')}` },
  ], { strong: true });
  if (m.ok && m.text) { synthesis = m.text; mode = 'your model, cited'; }
  else {
    synthesis = good.map(r => {
      const sentences = r.text.split(/(?<=[.!?])\s+/).filter(s => s.length > 40).slice(0, 3).join(' ');
      return `**[${r.n}] ${r.title}** — ${sentences} [${r.n}]`;
    }).join('\n\n');
  }

  const file = lib.outPath(`research-${lib.stamp()}.md`);
  fs.writeFileSync(file, `# Research brief\n\n**Question:** ${question}\n**Made by:** ${ctx.charter.agentName} · mode: ${mode}\n\n## What the sources say\n\n${synthesis || 'None of the sources could be read.'}\n\n## Sources\n${read.map(r => `${r.n}. ${r.url} — ${r.ok ? 'read' : 'COULD NOT VERIFY (' + r.why + ')'}`).join('\n')}\n`);
  const units = 1 + good.length + (m.ok ? Math.ceil((m.tokens || 0) / 1000) : 0);
  return {
    ok: good.length > 0,
    units,
    files: [file],
    summary: good.length
      ? `Brief written to ${file.split('/').pop()}: ${good.length} source(s) read${bad.length ? `, ${bad.length} could not be verified (listed in the brief)` : ''}. Every fact carries its source number.`
      : 'None of the sources could be read — the brief lists each one as COULD NOT VERIFY.',
    detail: { read: good.length, failed: bad.map(r => r.url), mode },
  };
}

module.exports = { id: 'research', name: 'Research a question', inWords: 'A question and the source addresses to read.', outWords: 'A brief with a source number on every fact, and a COULD NOT VERIFY list for sources that failed.', estimate: step => 1 + Math.min((step.sources || []).length, 6), run };
