/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Build-a-website skill (new in v1.0.5): builds ONE complete,
 * self-contained website page — a single HTML file the owner can open
 * in any browser and hand to any host — from the facts BotDawg knows
 * about the business: its name, its offerings, its contact facts, its
 * brand color, its voice. Facts it does not have stay marked
 * [fill-in]; it never invents services, prices, or claims.
 *
 * Built-in mode builds one page only: no online store, no checkout,
 * no extra pages. And BotDawg never hosts, posts, or uploads the
 * page — putting it online is the owner's step, with the owner's hand.
 */
'use strict';

const fs = require('fs');
const lib = require('../lib');

const COST = 4;

const LIMIT = 'That is more than this skill does in built-in mode: I build ONE self-contained website page — no online store, no checkout, no extra pages — and I never host or post it. Say "build me a website" and I will build the one page from the facts I know.';

const FILL = {
  business: '[fill-in: your business name]',
  tagline: '[fill-in: your tagline — one line that says what you do]',
  about: '[fill-in: a few lines about your business — teach me the facts and I will write this from them]',
  service: '[fill-in: a service or offering]',
  contact: '[fill-in: how customers reach you — phone, email, address, hours]',
};

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* Sort the facts BotDawg knows into the parts of a page. Each fact
 * lands in exactly one bucket; a fact it cannot place honestly is an
 * offering line — never rewritten, never embellished. */
function classify(facts) {
  const out = { services: [], about: [], phone: [], email: [], address: [], hours: [], tagline: '' };
  for (const raw of facts) {
    const f = String(raw || '').trim();
    if (!f) continue;
    const tag = f.match(/tagline[:\s]+(.+)/i) || f.match(/motto[:\s]+(.+)/i) || f.match(/slogan[:\s]+(.+)/i);
    if (tag && !out.tagline) { out.tagline = tag[1].trim(); continue; }
    if (/[\w.+-]+@[\w-]+\.[\w.]+/.test(f)) { out.email.push(f); continue; }
    if (/\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}/.test(f)) { out.phone.push(f); continue; }
    if (/\b\d{1,6}\s+[A-Z][\w.]*\s+(Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Court|Ct|Highway|Hwy)\b/.test(f) || /\b(located at|find us at|our address|visit us)\b/i.test(f)) { out.address.push(f); continue; }
    if (/\b(open|opens|opened|closed|closes|hours)\b/i.test(f) || /\b\d{1,2}\s?(AM|PM)\b/i.test(f) || /\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b/.test(f)) { out.hours.push(f); continue; }
    if (/\b(since|founded|family[- ]owned|locally owned|we are|our story|years of|started in)\b/i.test(f)) { out.about.push(f); continue; }
    out.services.push(f);
  }
  return out;
}

function knownFacts(charter) {
  const pool = [
    ...(charter.facts || []),
    ...lib.loadMemory().facts.map(f => f.text),
  ].map(s => String(s || '').trim()).filter(Boolean);
  return pool.filter((v, i, a) => a.indexOf(v) === i);
}

function siteHtml({ business, tagline, aboutParas, parts, brand, agentName, missing }) {
  const contactLines = [
    ...parts.phone.map(f => `<p>${esc(f)}</p>`),
    ...parts.email.map(f => `<p>${esc(f)}</p>`),
    ...parts.address.map(f => `<p>${esc(f)}</p>`),
    ...parts.hours.map(f => `<p>${esc(f)}</p>`),
  ];
  const services = parts.services.length
    ? parts.services.map(s => `<div class="svc"><h3>${esc(s)}</h3></div>`).join('\n      ')
    : `<div class="svc"><h3>${FILL.service}</h3></div>\n      <div class="svc"><h3>${FILL.service}</h3></div>\n      <div class="svc"><h3>${FILL.service}</h3></div>`;
  const contact = contactLines.length ? contactLines.join('\n      ') : `<p>${FILL.contact}</p>`;
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(business)}</title>
<style>
  :root{--brand:${brand}}
  *{box-sizing:border-box}
  html,body{margin:0;padding:0}
  body{font-family:system-ui,Arial,sans-serif;color:#1c2530;background:#fbfcfd;line-height:1.55;-webkit-text-size-adjust:100%}
  header{background:var(--brand);color:#fff;padding:44px 20px 36px;text-align:center}
  header h1{margin:0;font-size:clamp(28px,6vw,44px);line-height:1.15}
  header p{margin:10px auto 0;font-size:clamp(16px,3.5vw,20px);max-width:640px;opacity:.95}
  main{max-width:880px;margin:0 auto;padding:8px 20px 40px}
  section{margin-top:36px}
  h2{font-size:24px;border-bottom:3px solid var(--brand);padding-bottom:6px;margin:0 0 14px}
  .svc{border:1px solid #dde4ec;border-left:5px solid var(--brand);border-radius:8px;padding:12px 16px;margin:10px 0;background:#fff}
  .svc h3{margin:0;font-size:17px;font-weight:600}
  .contact p{margin:6px 0;font-size:17px}
  footer{background:#141a23;color:#c8d4e2;text-align:center;padding:22px 20px;margin-top:44px;font-size:14px}
  footer .biz{color:#fff;font-size:16px}
</style></head><body>
<header>
  <h1>${esc(business)}</h1>
  <p>${esc(tagline)}</p>
</header>
<main>
  <section>
    <h2>About</h2>
    ${aboutParas.map(p => `<p>${esc(p)}</p>`).join('\n    ')}
  </section>
  <section>
    <h2>Services</h2>
      ${services}
  </section>
  <section class="contact">
    <h2>Contact</h2>
      ${contact}
  </section>
</main>
<footer>
  <div class="biz">© ${new Date().getFullYear()} ${esc(business)}</div>
  <div>Built by ${esc(agentName)} from the facts it knows${missing.length ? ' — gaps marked [fill-in] are yours to finish' : ''}.</div>
</footer>
</body></html>
`;
}

async function run(step, ctx) {
  const words = String(step.words || step.topic || '');
  const lower = words.toLowerCase();
  if (/\b(online store|e-?commerce|checkout|shopping cart|\d+\s*-?\s*pages?|multiple pages|multi-?page|take payments online|sell (things|stuff|products) online)\b/.test(lower)) {
    return { ok: false, units: 0, summary: LIMIT };
  }
  const charter = ctx.charter;
  const facts = knownFacts(charter);
  const parts = classify(facts);

  const missing = [];
  const business = charter.ownerBusiness || '';
  if (!business) missing.push('your business name');
  const tagline = parts.tagline || '';
  if (!tagline) missing.push('a tagline');
  if (!parts.services.length) missing.push('your services or offerings');
  if (!parts.phone.length) missing.push('a phone number');
  if (!parts.email.length) missing.push('an email address');
  if (!parts.address.length) missing.push('an address');
  if (!parts.hours.length) missing.push('your hours');

  /* About copy: the owner's model if connected (facts only), else the
   * built-in template — the same pattern as the Write skill. */
  let mode = 'built-in template (no model set up)';
  let aboutParas = null;
  const m = await lib.modelChat(charter, [
    { role: 'system', content: `You are ${charter.agentName}, writing the About section of a one-page website for ${business || 'a small business'}. Voice: ${charter.voice}. Use ONLY the facts provided; never invent services, prices, dates, or promises. Two or three short sentences.` },
    { role: 'user', content: `Facts you may use: ${facts.join('; ') || '(none on file)'}` },
  ], { strong: true });
  if (m.ok && m.text) {
    aboutParas = [m.text.trim()];
    mode = 'your model, in your voice';
  } else {
    aboutParas = [
      business ? `Welcome to ${business}.` : `Welcome to ${FILL.business}.`,
      ...(parts.about.length ? parts.about : []),
      ...(parts.services.length ? [`What we do: ${parts.services.join(' · ')}.`] : []),
      ...(!parts.about.length && !parts.services.length ? [FILL.about] : []),
    ];
  }

  const html = siteHtml({
    business: business || FILL.business,
    tagline: tagline || FILL.tagline,
    aboutParas,
    parts,
    brand: /^#[0-9a-fA-F]{6}$/.test(charter.brandColor || '') ? charter.brandColor : '#0096FF',
    agentName: charter.agentName,
    missing,
  });

  const file = lib.outPath(`website-${lib.stamp()}.html`);
  fs.writeFileSync(file, html);
  const units = COST + (m.ok ? Math.ceil((m.tokens || 0) / 1000) : 0);
  return {
    ok: true,
    units,
    files: [file],
    summary: `Website built and saved to ${file.split('/').pop()} (${mode}). One complete, self-contained page — open it in any browser, or hand the file to any host. I do not host, post, or upload it.${missing.length ? ` For a fuller site, teach me: ${missing.join('; ')} — those spots are marked [fill-in] in the page, never invented.` : ' It uses every fact I have on file.'}`,
    detail: { mode, missing },
  };
}

module.exports = { id: 'build-site', name: 'Build a website', inWords: 'The kind of site, in your own words — "a website for my bakery", "a landing page for my lawn service". It is built from the facts BotDawg knows about your business.', outWords: 'One complete website page as a single HTML file in out/ — open it in any browser, hand it to any host. Gaps stay marked [fill-in], never invented. BotDawg does not host or post it.', estimate: () => COST, run };
