/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Proof skill (wrapper): runs the Proof Run engine
 * (skills/proof-run.js) on a product door and returns its sealed verdict
 * counts. This is BotDawg's starter specialty — the job the demand
 * evidence asked for loudest: proof a buyer can audit before paying.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const lib = require('../lib');

function run(step, ctx) {
  return new Promise((resolve) => {
    const job = {
      productName: step.name, descriptionLine: step.description, doorUrl: step.door,
      claims: step.claims || [], priceStated: step.price, buyUrl: step.buyUrl,
      seller: ctx.charter.ownerBusiness || '',
    };
    if (!job.doorUrl || !job.productName) return resolve({ ok: false, summary: 'A proof run needs the product name and the door (page address).' });
    const jobFile = lib.outPath(`proof-job-${lib.stamp()}.json`);
    fs.writeFileSync(jobFile, JSON.stringify(job, null, 2));
    execFile(process.execPath, [path.join(__dirname, 'proof-run.js'), 'run', jobFile], { cwd: lib.ROOT, timeout: 120000 }, (err, stdout) => {
      if (err) return resolve({ ok: false, summary: `The proof run itself failed to complete (${err.message}). Charged 0 units.` });
      try {
        const r = JSON.parse(stdout);
        resolve({
          ok: true, units: 6,
          files: [path.join(lib.ROOT, r.report)],
          summary: `Proof run ${r.tag}: ${r.counts.pass} PASS / ${r.counts.fail} FAIL / ${r.counts.unchecked} UNCHECKED of ${r.counts.total}. Sealed report: ${r.report}.`,
          detail: r,
        });
      } catch { resolve({ ok: false, summary: 'The proof run finished but its record could not be read. Charged 0 units.' }); }
    });
  });
}

module.exports = { id: 'proof', name: 'Proof-run a product door', inWords: 'The product name, its one-line description, its claims, its price, the page address, and the buy link.', outWords: 'A sealed run record: every check PASS / FAIL / UNCHECKED with the evidence attached.', estimate: () => 6, run };
