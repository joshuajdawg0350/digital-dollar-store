#!/usr/bin/env node
/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ — a general-purpose agent by J-Dawgs Industries.
 * This file is BotDawg's Proof Run skill: a delivery-audit agent.
 *
 * What it does: takes a product door (a public web page where something is
 * sold or handed over) plus the seller's own stated facts (product name,
 * one-line description, claims, price, buy link), runs the door for real,
 * and writes a sealed run record: every check PASS / FAIL / UNCHECKED,
 * hits and misses both, with the evidence attached.
 *
 * What it does NOT do: it does not buy anything, log in anywhere, fill in
 * forms, or judge whether a product is good. It checks whether the door
 * answers, whether the page says what the seller says it says, whether the
 * price on the page matches the price the seller states, and whether the
 * page loads in a real browser without errors. Anything it cannot check
 * prints UNCHECKED, never a guessed pass.
 *
 * Personalization: the buyer makes it theirs in charter.json — the agent's
 * name, their business name and brand color, the voice its reports speak
 * in, the facts it knows about their business, and its job focus. No code.
 *
 * Usage:
 *   node skills/proof-run.js run <job.json> [--charter charter.json]
 *   node skills/proof-run.js settings [--charter charter.json] [--port 7799]
 *   node skills/proof-run.js version
 */
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { createRequire } = require('module');

const VERSION = '1.0.0';
const ROOT = path.join(__dirname, '..'); // the BotDawg folder — everything lives inside it
const RUNS_DIR = path.join(ROOT, 'out', 'proof-runs');

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function nowIso() {
  return new Date().toISOString();
}

function loadJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function visibleText(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fetchUrl(url, timeoutMs = 20000) {
  return new Promise((resolve) => {
    const started = Date.now();
    let lib;
    try {
      lib = url.startsWith('https:') ? https : http;
    } catch (e) {
      return resolve({ ok: false, error: 'bad url: ' + e.message });
    }
    const req = lib.get(
      url,
      { headers: { 'User-Agent': 'BotDawg/' + VERSION, Accept: '*/*' } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const body = Buffer.concat(chunks);
          resolve({
            ok: true,
            status: res.statusCode,
            bytes: body.length,
            ms: Date.now() - started,
            body,
            digest: sha256(body),
            finalUrl: url,
          });
        });
      }
    );
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error('timeout after ' + timeoutMs + 'ms'));
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message, ms: Date.now() - started }));
  });
}

/* ---------------- charter (the personalization layer) ---------------- */

function loadCharter(charterPath) {
  const file = charterPath || path.join(ROOT, 'charter.json');
  const fallback = {
    agentName: 'BotDawg',
    ownerBusiness: '',
    voice: 'plain',
    brandColor: '#0096FF',
    focus: 'full-audit',
    facts: [],
  };
  if (!fs.existsSync(file)) return { charter: fallback, charterFile: file, charterFound: false };
  const raw = loadJson(file);
  return { charter: Object.assign({}, fallback, raw), charterFile: file, charterFound: true };
}

const FOCUS_CHECKS = {
  'full-audit': ['door-answers', 'determinism', 'name-on-page', 'description-on-page', 'claims-on-page', 'price-consistency', 'buy-door', 'browser-load'],
  'launch-check': ['door-answers', 'name-on-page', 'description-on-page', 'claims-on-page', 'buy-door', 'browser-load'],
  'price-watch': ['door-answers', 'determinism', 'price-consistency'],
};

const VOICES = {
  plain: {
    allPass: (p, n) => `${p}: ${n} of ${n} checks passed. The record below is the whole story.`,
    someFail: (p, pass, fail, un, n) => `${p}: ${pass} passed, ${fail} failed, ${un} unchecked, of ${n} checks. The failures are printed at the same size as the passes.`,
  },
  warm: {
    allPass: (p, n) => `Good news — ${p} passed every one of its ${n} checks. The full record is below, and it is a pleasure to show it.`,
    someFail: (p, pass, fail, un, n) => `${p} came through its run with ${pass} passes and ${fail} failures out of ${n} checks (${un} unchecked). Every miss is printed right beside the hits, so the fix is easy to find.`,
  },
  formal: {
    allPass: (p, n) => `Audit result for ${p}: all ${n} checks passed. The complete record follows.`,
    someFail: (p, pass, fail, un, n) => `Audit result for ${p}: ${pass} of ${n} checks passed; ${fail} failed; ${un} unchecked. Failures are recorded at equal prominence, per protocol.`,
  },
};

/* ---------------- the checks ---------------- */

async function checkDoorAnswers(job) {
  const r = await fetchUrl(job.doorUrl);
  if (!r.ok) {
    return { verdict: 'FAIL', evidence: { error: r.error, ms: r.ms }, note: 'The door did not answer at all.' };
  }
  return {
    verdict: r.status === 200 ? 'PASS' : 'FAIL',
    evidence: { status: r.status, bytes: r.bytes, ms: r.ms, digest: r.digest },
    note: r.status === 200 ? 'The door answered with its page.' : `The door answered with status ${r.status}, not 200.`,
    // Only a 200 page is handed to the content checks. Reading claims off an
    // error page would fail them all for the door's one fault — double-counting.
    _body: r.status === 200 ? r.body : null,
  };
}

async function checkDeterminism(job) {
  const a = await fetchUrl(job.doorUrl);
  const b = await fetchUrl(job.doorUrl);
  if (!a.ok || !b.ok) {
    return { verdict: 'UNCHECKED', evidence: { errorA: a.error || null, errorB: b.error || null }, note: 'Could not fetch the door twice, so determinism is unmeasured this run.' };
  }
  const same = a.digest === b.digest;
  return {
    verdict: same ? 'PASS' : 'FAIL',
    evidence: { digestA: a.digest, digestB: b.digest, bytesA: a.bytes, bytesB: b.bytes },
    note: same
      ? 'Two fetches returned identical bytes — the covered content is deterministic.'
      : 'Two fetches of the same door returned different bytes. A digest that differs on a double-run from identical inputs is a finding, not a rounding error.',
  };
}

function checkNameOnPage(job, text, html) {
  const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '';
  const h1 = (html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '';
  const inTitle = visibleText(title).toLowerCase().includes(job.productName.toLowerCase());
  const inH1 = visibleText(h1).toLowerCase().includes(job.productName.toLowerCase());
  const inText = text.toLowerCase().includes(job.productName.toLowerCase());
  return {
    verdict: inTitle || inH1 ? 'PASS' : 'FAIL',
    evidence: { inTitle, inH1, inBodyText: inText, title: visibleText(title).slice(0, 120) },
    note: inTitle || inH1 ? 'The product name is on the door where a buyer looks first.' : 'The product name appears in neither the page title nor its first heading.',
  };
}

function checkDescriptionOnPage(job, text) {
  if (!job.descriptionLine) {
    return { verdict: 'UNCHECKED', evidence: {}, note: 'The seller stated no one-line description, so there is nothing to check the page against.' };
  }
  const found = text.toLowerCase().includes(job.descriptionLine.toLowerCase());
  return {
    verdict: found ? 'PASS' : 'FAIL',
    evidence: { descriptionLine: job.descriptionLine, found },
    note: found ? 'A cold reader can tell what this is from the page itself.' : 'The seller\'s own one-line description of the product does not appear on the door.',
  };
}

function checkClaims(job, text) {
  const claims = Array.isArray(job.claims) ? job.claims : [];
  if (!claims.length) {
    return [{ id: 'claims-on-page', name: 'Seller claims appear on the page', verdict: 'UNCHECKED', evidence: {}, note: 'The seller stated no claims for this run.' }];
  }
  return claims.map((claim, i) => {
    const found = text.toLowerCase().includes(String(claim).toLowerCase());
    return {
      id: 'claim-' + (i + 1),
      name: 'Claim on page: "' + String(claim).slice(0, 60) + '"',
      verdict: found ? 'PASS' : 'FAIL',
      evidence: { claim: String(claim), found },
      note: found ? 'The page says it, in the seller\'s own words.' : 'The seller states this claim, but the door does not say it.',
    };
  });
}

function checkPriceConsistency(job, text) {
  if (!job.priceStated) {
    return { verdict: 'UNCHECKED', evidence: {}, note: 'The seller stated no price, so price consistency is unmeasured this run.' };
  }
  const found = text.includes(job.priceStated);
  const pricesOnPage = Array.from(new Set(text.match(/\$\d[\d,]*(\.\d{2})?/g) || [])).slice(0, 12);
  return {
    verdict: found ? 'PASS' : 'FAIL',
    evidence: { priceStated: job.priceStated, foundOnPage: found, pricesOnPage },
    note: found
      ? 'The price on the page is the price the seller states.'
      : `The seller states ${job.priceStated}, but that price does not appear on the door. Prices found on the page: ${pricesOnPage.join(', ') || 'none'}.`,
  };
}

async function checkBuyDoor(job) {
  if (!job.buyUrl) {
    return { verdict: 'UNCHECKED', evidence: {}, note: 'The seller named no buy link, so there is no buy door to test.' };
  }
  const r = await fetchUrl(job.buyUrl);
  if (!r.ok) {
    return { verdict: 'FAIL', evidence: { buyUrl: job.buyUrl, error: r.error }, note: 'The buy link did not answer at all.' };
  }
  return {
    verdict: r.status === 200 ? 'PASS' : 'FAIL',
    evidence: { buyUrl: job.buyUrl, status: r.status, bytes: r.bytes, ms: r.ms },
    note: r.status === 200 ? 'The buy door answers.' : `The buy door answered with status ${r.status}, not 200 — a buyer hits a wall here.`,
  };
}

function loadPlaywright() {
  const candidates = [
    process.env.BOTDAWG_PLAYWRIGHT,
    path.join(ROOT, 'node_modules', 'playwright'),
    'playwright',
  ].filter(Boolean);
  for (const c of candidates) {
    try {
      const req = createRequire(path.join(__dirname, 'proof-run.js'));
      return req(c);
    } catch (e) { /* try next */ }
  }
  return null;
}

function findChromiumExecutable() {
  for (const cache of [path.join(ROOT, 'browsers'), path.join(process.env.HOME || '', '.cache/ms-playwright')]) {
  try {
    const shells = fs.readdirSync(cache)
      .filter((d) => d.startsWith('chromium_headless_shell-'))
      .sort()
      .reverse();
    for (const s of shells) {
      const p = path.join(cache, s, 'chrome-headless-shell-linux64', 'chrome-headless-shell');
      if (fs.existsSync(p)) return p;
    }
    const full = fs.readdirSync(cache).filter((d) => d.startsWith('chromium-')).sort().reverse();
    for (const s of full) {
      const p = path.join(cache, s, 'chrome-linux', 'chrome');
      if (fs.existsSync(p)) return p;
    }
  } catch (e) { /* try the next location */ }
  }
  return null;
}

async function checkBrowserLoad(job, runDir) {
  const pw = loadPlaywright();
  if (!pw) {
    return { verdict: 'UNCHECKED', evidence: {}, note: 'No browser engine is installed on this machine, so the browser-load check did not run. It prints UNCHECKED, never a guessed pass.' };
  }
  let browser;
  try {
    const executablePath = findChromiumExecutable();
    browser = await pw.chromium.launch(executablePath ? { executablePath } : {});
    const page = await browser.newPage();
    const pageErrors = [];
    const consoleErrors = [];
    page.on('pageerror', (e) => pageErrors.push(String(e).slice(0, 300)));
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)); });
    const resp = await page.goto(job.doorUrl, { waitUntil: 'load', timeout: 30000 });
    await page.waitForTimeout(750);
    const shotPath = path.join(runDir, 'screenshot.png');
    await page.screenshot({ path: shotPath });
    const shotDigest = sha256(fs.readFileSync(shotPath));
    const status = resp ? resp.status() : null;
    const failed = pageErrors.length > 0 || (status !== null && status >= 400);
    return {
      verdict: failed ? 'FAIL' : 'PASS',
      evidence: { status, pageErrors, consoleErrors: consoleErrors.slice(0, 5), screenshot: 'screenshot.png', screenshotSha256: shotDigest },
      note: pageErrors.length
        ? 'The page throws errors in a real browser: ' + pageErrors[0]
        : 'The page loaded in a real browser (Chromium) with no page errors. A screenshot is attached to the run record as evidence.',
    };
  } catch (e) {
    const msg = String(e);
    // An instrument failure (our browser could not start) is not the door's
    // failure. It prints UNCHECKED; only a page that loads and misbehaves,
    // or refuses to load, earns a FAIL.
    if (/Executable doesn't exist|Failed to launch|launch: /.test(msg) || /ERR_TUNNEL|ERR_PROXY|ERR_NAME_NOT_RESOLVED|ERR_DNS/.test(msg)) {
      return { verdict: 'UNCHECKED', evidence: { error: msg.slice(0, 300) }, note: 'Our browser could not reach the door from this machine (browser instrument / network path), so the browser-load check is unmeasured this run — that is our miss, not the door\'s.' };
    }
    return { verdict: 'FAIL', evidence: { error: msg.slice(0, 300) }, note: 'The browser could not load the door: ' + msg.slice(0, 160) };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

/* ---------------- the run ---------------- */

async function runJob(jobFile, charterPath) {
  const job = loadJson(jobFile);
  const { charter, charterFile, charterFound } = loadCharter(charterPath);
  const focus = job.focus || charter.focus || 'full-audit';
  const selected = FOCUS_CHECKS[focus] || FOCUS_CHECKS['full-audit'];
  const runId = 'run-' + new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomBytes(3).toString('hex');
  const runDir = path.join(RUNS_DIR, runId);
  fs.mkdirSync(runDir, { recursive: true });
  const startedAt = nowIso();

  const checks = [];
  let doorBody = null;
  let doorText = '';
  let doorHtml = '';

  for (const id of selected) {
    if (id === 'door-answers') {
      const r = await checkDoorAnswers(job);
      doorBody = r._body || null;
      delete r._body;
      checks.push(Object.assign({ id, name: 'The door answers' }, r));
      if (doorBody) {
        doorHtml = doorBody.toString('utf8');
        doorText = visibleText(doorHtml);
      }
    } else if (id === 'determinism') {
      checks.push(Object.assign({ id, name: 'Same door, same bytes, twice (determinism)' }, await checkDeterminism(job)));
    } else if (id === 'name-on-page') {
      checks.push(Object.assign({ id, name: 'Product name where a buyer looks first' },
        doorBody ? checkNameOnPage(job, doorText, doorHtml) : { verdict: 'UNCHECKED', evidence: {}, note: 'The door never answered, so this check had nothing to read.' }));
    } else if (id === 'description-on-page') {
      checks.push(Object.assign({ id, name: 'A cold reader can tell what it is' },
        doorBody ? checkDescriptionOnPage(job, doorText) : { verdict: 'UNCHECKED', evidence: {}, note: 'The door never answered, so this check had nothing to read.' }));
    } else if (id === 'claims-on-page') {
      const rows = doorBody ? checkClaims(job, doorText) : [{ id: 'claims-on-page', name: 'Seller claims appear on the page', verdict: 'UNCHECKED', evidence: {}, note: 'The door never answered, so claims could not be read.' }];
      checks.push(...rows);
    } else if (id === 'price-consistency') {
      checks.push(Object.assign({ id, name: 'The price on the page is the price stated' },
        doorBody ? checkPriceConsistency(job, doorText) : { verdict: 'UNCHECKED', evidence: {}, note: 'The door never answered, so no price could be read.' }));
    } else if (id === 'buy-door') {
      checks.push(Object.assign({ id, name: 'The buy door answers' }, await checkBuyDoor(job)));
    } else if (id === 'browser-load') {
      checks.push(Object.assign({ id, name: 'Loads in a real browser without errors' }, await checkBrowserLoad(job, runDir)));
    }
  }

  const counts = {
    total: checks.length,
    pass: checks.filter((c) => c.verdict === 'PASS').length,
    fail: checks.filter((c) => c.verdict === 'FAIL').length,
    unchecked: checks.filter((c) => c.verdict === 'UNCHECKED').length,
  };

  const record = {
    product: 'BotDawg™ — Proof Run skill',
    agentVersion: VERSION,
    runId,
    startedAt,
    finishedAt: nowIso(),
    runBy: {
      agentName: charter.agentName,
      ownerBusiness: charter.ownerBusiness,
      voice: charter.voice,
      focus,
      charterFile: path.basename(charterFile),
      charterFound,
      charterFactsKnown: Array.isArray(charter.facts) ? charter.facts.length : 0,
    },
    job: {
      productName: job.productName,
      seller: job.seller || null,
      doorUrl: job.doorUrl,
      priceStated: job.priceStated || null,
      buyUrl: job.buyUrl || null,
      claimsStated: Array.isArray(job.claims) ? job.claims.length : 0,
    },
    checks,
    counts,
  };
  // The seal: a hash over the canonical record. Anyone holding this record
  // can re-compute it; if a row is edited after the run, the seal breaks.
  const canonical = JSON.stringify(record);
  record.seal = sha256(Buffer.from(canonical, 'utf8'));
  record.tag = 'botdawg-proofrun-v' + VERSION + '+' + record.seal.slice(0, 12);

  fs.writeFileSync(path.join(runDir, 'run-record.json'), JSON.stringify(record, null, 2));
  fs.writeFileSync(path.join(runDir, 'report.html'), renderReport(record, charter));
  return record;
}

function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function renderReport(record, charter) {
  const voice = VOICES[charter.voice] || VOICES.plain;
  const c = record.counts;
  const summary = c.fail === 0 && c.unchecked === 0
    ? voice.allPass(record.job.productName, c.total)
    : voice.someFail(record.job.productName, c.pass, c.fail, c.unchecked, c.total);
  const rows = record.checks.map((ch) => {
    const color = ch.verdict === 'PASS' ? '#1d9e57' : ch.verdict === 'FAIL' ? '#d33' : '#b8860b';
    return `<tr><td style="color:${color};font-weight:700">${ch.verdict}</td><td>${esc(ch.name)}</td><td>${esc(ch.note)}</td></tr>`;
  }).join('\n');
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Proof Run — ${esc(record.job.productName)} — by ${esc(charter.agentName)}</title></head>
<body style="font-family:system-ui,sans-serif;background:#0b0e13;color:#e8ecf1;margin:0;padding:24px">
<div style="max-width:820px;margin:0 auto">
<p style="color:${esc(charter.brandColor)};font-weight:700;letter-spacing:.08em">${esc(charter.ownerBusiness).toUpperCase()}</p>
<h1>Proof Run — ${esc(record.job.productName)}</h1>
<p>Run by <strong>${esc(charter.agentName)}</strong> (BotDawg™ v${VERSION}, Proof Run skill) for ${esc(charter.ownerBusiness)}.</p>
<p>${esc(summary)}</p>
<p>Run ID: ${record.runId}<br>Tag: ${record.tag}<br>Seal (SHA-256 of this record): ${record.seal}<br>
Door run: <a style="color:${esc(charter.brandColor)}" href="${esc(record.job.doorUrl)}">${esc(record.job.doorUrl)}</a><br>
Counts: ${c.pass} passed / ${c.fail} failed / ${c.unchecked} unchecked, of ${c.total} checks. The denominator is printed beside every rate, always.</p>
<table style="width:100%;border-collapse:collapse" border="1" cellpadding="8">
<tr><th>Verdict</th><th>Check</th><th>What the runner saw</th></tr>
${rows}
</table>
<p style="color:#9aa4b0">Hits and misses both, at the same size. An UNCHECKED row means the runner could not measure it this run — it is never smoothed into a pass.
<br>© 2026 ${esc(charter.ownerBusiness) || esc(charter.agentName)}. BotDawg™.</p>
</div></body></html>`;
}

/* ---------------- the settings surface (no code, just a form) ---------------- */

function serveSettings(charterPath, port) {
  const file = charterPath || path.join(ROOT, 'charter.json');
  const server = http.createServer((req, res) => {
    if (req.method === 'GET') {
      const { charter } = loadCharter(file);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Make BotDawg yours</title></head>
<body style="font-family:system-ui,sans-serif;max-width:640px;margin:24px auto;padding:0 16px">
<h1>Make this agent yours</h1>
<p>No code. Fill this in, save, and every run and report carries your name, your business, your voice, your focus.</p>
<form method="POST">
<label>Your agent's name<br><input name="agentName" value="${esc(charter.agentName)}" style="width:100%"></label><br><br>
<label>Your business<br><input name="ownerBusiness" value="${esc(charter.ownerBusiness)}" style="width:100%"></label><br><br>
<label>Voice<br><select name="voice">
<option ${charter.voice === 'plain' ? 'selected' : ''}>plain</option>
<option ${charter.voice === 'warm' ? 'selected' : ''}>warm</option>
<option ${charter.voice === 'formal' ? 'selected' : ''}>formal</option></select></label><br><br>
<label>Brand color<br><input name="brandColor" value="${esc(charter.brandColor)}"></label><br><br>
<label>Job focus<br><select name="focus">
<option ${charter.focus === 'full-audit' ? 'selected' : ''}>full-audit</option>
<option ${charter.focus === 'launch-check' ? 'selected' : ''}>launch-check</option>
<option ${charter.focus === 'price-watch' ? 'selected' : ''}>price-watch</option></select></label><br><br>
<label>What it knows about your business (one fact per line)<br>
<textarea name="facts" rows="6" style="width:100%">${esc((charter.facts || []).join('\n'))}</textarea></label><br><br>
<button type="submit">Save — make it mine</button>
</form></body></html>`);
    } else if (req.method === 'POST') {
      let body = '';
      req.on('data', (d) => (body += d));
      req.on('end', () => {
        const p = new URLSearchParams(body);
        const charter = {
          agentName: p.get('agentName') || 'Proof Runner',
          ownerBusiness: p.get('ownerBusiness') || '',
          voice: ['plain', 'warm', 'formal'].includes(p.get('voice')) ? p.get('voice') : 'plain',
          brandColor: p.get('brandColor') || '#0096FF',
          focus: FOCUS_CHECKS[p.get('focus')] ? p.get('focus') : 'full-audit',
          facts: (p.get('facts') || '').split('\n').map((s) => s.trim()).filter(Boolean),
        };
        fs.writeFileSync(file, JSON.stringify(charter, null, 2));
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`<!DOCTYPE html><html><body style="font-family:system-ui,sans-serif;max-width:640px;margin:24px auto"><h1>Saved.</h1><p>This agent is now <strong>${esc(charter.agentName)}</strong>, working for ${esc(charter.ownerBusiness)}, speaking in a ${esc(charter.voice)} voice, focused on ${esc(charter.focus)}. It knows ${charter.facts.length} facts about the business.</p></body></html>`);
      });
    }
  });
  server.listen(port, '127.0.0.1', () => {
    console.log('Settings surface live at http://127.0.0.1:' + port + ' (editing ' + file + ')');
  });
}

/* ---------------- main ---------------- */

(async () => {
  const args = process.argv.slice(2);
  const cmd = args[0];
  const getOpt = (name) => {
    const i = args.indexOf(name);
    return i >= 0 ? args[i + 1] : null;
  };
  if (cmd === 'version') {
    console.log('BotDawg™ (Proof Run skill) v' + VERSION);
  } else if (cmd === 'run') {
    const jobFile = args[1];
    if (!jobFile) { console.error('usage: proof-runner.js run <job.json> [--charter charter.json]'); process.exit(2); }
    const record = await runJob(jobFile, getOpt('--charter'));
    console.log(JSON.stringify({ runId: record.runId, tag: record.tag, counts: record.counts, report: 'out/proof-runs/' + record.runId + '/report.html' }, null, 2));
  } else if (cmd === 'settings') {
    serveSettings(getOpt('--charter'), parseInt(getOpt('--port') || '7799', 10));
  } else {
    console.log('BotDawg™ (Proof Run skill) v' + VERSION);
    console.log('usage: node skills/proof-run.js run <job.json> [--charter charter.json]');
    console.log('       node skills/proof-run.js settings [--charter charter.json] [--port 7799]');
  }
})().catch((e) => { console.error('proof-runner failed:', e); process.exit(1); });
