/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Write skill: drafts in the owner's voice — an email, a post,
 * a page, a note — from the facts BotDawg remembers. Output is always a
 * DRAFT file for the owner to read and use. BotDawg does not send or
 * publish anything, ever.
 */
'use strict';

const fs = require('fs');
const lib = require('../lib');

const VOICE_TONE = {
  plain: 'Plain words. Short sentences. Say what it is, what it costs, where to get it.',
  warm: 'Warm and friendly, like talking to a neighbor. Still plain — no hype.',
  formal: 'Formal and measured. Full sentences, no slang, no contractions.',
};

async function run(step, ctx) {
  const topic = String(step.topic || '').trim();
  if (!topic) return { ok: false, summary: 'Writing needs a topic — what is this piece about?' };
  const kind = step.kind || 'note';
  const charter = ctx.charter;
  const facts = [...(charter.facts || []), ...lib.recall(topic).map(f => f.text)].filter((v, i, a) => a.indexOf(v) === i).slice(0, 8);
  const points = step.points || [];

  let draft = '';
  let mode = 'built-in template (no model set up)';
  const m = await lib.modelChat(charter, [
    { role: 'system', content: `You are ${charter.agentName}, writing for ${charter.ownerBusiness || 'the owner'}. Voice: ${charter.voice} — ${VOICE_TONE[charter.voice] || VOICE_TONE.plain} Use ONLY the facts provided; never invent prices, dates, or promises.` },
    { role: 'user', content: `Write a ${kind} about: ${topic}\nPoints to cover: ${points.join('; ') || '(none given)'}\nFacts you may use: ${facts.join('; ') || '(none on file)'}\nAudience: ${step.audience || 'customers'}` },
  ], { strong: true });
  if (m.ok && m.text) { draft = m.text; mode = 'your model, in your voice'; }
  else {
    draft = [
      `${topic}`,
      '',
      ...(points.length ? points.map(p => `- ${p}`) : ['[Say the main point here, in one line.]']),
      '',
      ...(facts.length ? ['What we know:', ...facts.map(f => `- ${f}`)] : ['[Add the facts this piece needs — BotDawg has none on file for this topic yet.]']),
      '',
      charter.ownerBusiness ? `— ${charter.ownerBusiness}` : '',
    ].join('\n');
  }

  const file = lib.outPath(`draft-${kind}-${lib.stamp()}.md`);
  fs.writeFileSync(file, `# DRAFT — ${kind}: ${topic}\n\nWritten by ${charter.agentName} in a ${charter.voice} voice (${mode}). This is a draft — nothing has been sent or posted.\n\n---\n\n${draft}\n`);
  const units = 2 + (m.ok ? Math.ceil((m.tokens || 0) / 1000) : 0);
  return { ok: true, units, files: [file], summary: `Draft ${kind} written to ${file.split('/').pop()} (${mode}). It is a draft — BotDawg never sends or posts.`, detail: { mode } };
}

module.exports = { id: 'write', name: 'Write a draft', inWords: 'The kind (email, post, page, note), the topic, and the points to cover.', outWords: 'A finished draft file in your voice. Never sent, never posted.', estimate: () => 2, run };
