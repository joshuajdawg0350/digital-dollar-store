/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Organize skill: catalogs a folder — every file, its size,
 * and a fingerprint — and reports exact duplicates. It NEVER moves,
 * renames, or deletes anything. Tidying is advice; your files stay put
 * until you move them.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const lib = require('../lib');

function walk(dir, depth, acc) {
  if (depth > 6) return acc;
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return acc; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, depth + 1, acc);
    else if (e.isFile()) {
      const st = fs.statSync(p);
      let hash = null;
      if (st.size <= 5 * 1024 * 1024) hash = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
      acc.push({ path: p, name: e.name, ext: path.extname(e.name).toLowerCase() || '(none)', bytes: st.size, hash });
    }
  }
  return acc;
}

function run(step, ctx) {
  const dir = step.dir;
  if (!dir || !fs.existsSync(dir)) return { ok: false, summary: `That folder does not exist here: ${dir || '(none given)'}` };
  const files = walk(dir, 0, []);
  const byHash = {};
  for (const f of files) if (f.hash) (byHash[f.hash] = byHash[f.hash] || []).push(f);
  const dupes = Object.values(byHash).filter(g => g.length > 1);
  const byExt = {};
  for (const f of files) byExt[f.ext] = (byExt[f.ext] || 0) + 1;
  const totalBytes = files.reduce((a, f) => a + f.bytes, 0);
  const wasted = dupes.reduce((a, g) => a + g[0].bytes * (g.length - 1), 0);

  const catalogFile = lib.outPath(`catalog-${lib.stamp()}.json`);
  fs.writeFileSync(catalogFile, JSON.stringify({ dir, madeAt: new Date().toISOString(), files }, null, 2));
  const summaryFile = lib.outPath(`organize-${lib.stamp()}.md`);
  fs.writeFileSync(summaryFile, `# Folder catalog — ${dir}\n\nMade by ${ctx.charter.agentName}. Nothing was moved, renamed, or deleted.\n\n- Files: ${files.length}\n- Total size: ${(totalBytes / 1024).toFixed(1)} KB\n- Kinds: ${Object.entries(byExt).map(([k, v]) => `${k} ×${v}`).join(', ') || 'none'}\n- Exact duplicate sets: ${dupes.length} (${(wasted / 1024).toFixed(1)} KB in extra copies)\n\n## Duplicates\n${dupes.map(g => g.map(f => '- ' + f.path).join('\n')).join('\n\n') || 'None found.'}\n\nFull catalog: ${catalogFile}\n`);
  const units = 1 + Math.ceil(files.length / 50);
  return { ok: true, units, files: [summaryFile, catalogFile], summary: `${files.length} files cataloged, ${dupes.length} exact duplicate set(s) found. Nothing moved or deleted. Report: ${summaryFile.split('/').pop()}.`, detail: { files: files.length, dupes: dupes.length } };
}

module.exports = { id: 'organize', name: 'Organize a folder', inWords: 'A folder on this computer.', outWords: 'A catalog of every file plus a duplicate report. Nothing is moved or deleted.', estimate: () => 2, run };
