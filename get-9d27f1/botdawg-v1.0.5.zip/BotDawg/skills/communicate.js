/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ Communicate skill: prepares a message for the owner to send
 * — a follow-up, a thank-you, a reply — with a before-you-send checklist.
 * It NEVER sends. Sending is a consequence, and consequences stay with
 * the owner. (Approval before consequences is a design rule, not a
 * setting you can switch off.)
 */
'use strict';

const fs = require('fs');
const lib = require('../lib');

async function run(step, ctx) {
  const to = String(step.to || '').trim();
  const purpose = String(step.purpose || '').trim();
  if (!to || !purpose) return { ok: false, summary: 'A message needs who it is for and what it is for.' };
  const inner = await require('./write').run({ kind: 'email', topic: purpose, points: step.points || [], audience: to }, ctx);
  if (!inner.ok) return inner;
  const file = lib.outPath(`message-${lib.stamp()}.md`);
  const draftBody = fs.readFileSync(inner.files[0], 'utf8');
  fs.writeFileSync(file, `# Message for ${to} — NOT SENT\n\nPrepared by ${ctx.charter.agentName}. BotDawg never sends messages. Read it, change anything, then send it yourself.\n\nBefore you send:\n- [ ] The name and address are right\n- [ ] Every fact in it is true\n- [ ] The price / date / promise (if any) is the one you mean\n\n${draftBody}\n`);
  return { ok: true, units: inner.units, files: [file], summary: `Message for ${to} prepared at ${file.split('/').pop()} — NOT SENT. BotDawg never sends; you read it and send it yourself.`, detail: { sent: false } };
}

module.exports = { id: 'communicate', name: 'Prepare a message', inWords: 'Who it is for, what it is for, and the points to cover.', outWords: 'A ready message with a before-you-send checklist. Never sent by BotDawg.', estimate: () => 2, run };
