# START HERE — BotDawg™ setup, step by step

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

Welcome. BotDawg is a general-purpose agent that lives in this one
folder, on your computer. It never phones home, it never needs
J-Dawgs for anything, and everything it knows and makes stays in
plain files right here. This page gets you from the zip file to a
working agent in a few minutes. No coding. No account with us.

## Two versions in this package — computer and phone

This package carries BotDawg twice, and you can use either one, or
both:

- **The computer version** is this folder, set up by the steps
  below. It is the full BotDawg — every job, every skill.
- **The phone version** is one single file in this folder:
  `botdawg-phone.html`. Put that file on your phone and open it in
  the phone's browser — or open it from a link — and BotDawg is
  right there: chat, drafts, prepared messages, prompt sharpening,
  memory, and personalization. No install, no computer needed. It
  does not do everything the computer version does;
  **PHONE-HONEST-LIMITS.md** (also in this folder) states plainly
  what it leaves out.

The two versions do not sync with each other: each one keeps its
own memory on its own device. Facts you teach the one on your
computer are not on your phone, and the other way around.

The steps below are for the computer version. The phone version
needs no steps at all — just open the file.

## What you need

- A computer (Windows, Mac, or Linux) with **Node.js** installed.
  Node is free. If you don't have it: go to https://nodejs.org,
  download the "LTS" version, install it like any other program.
  (To check: open a terminal and type `node --version`. Any version
  18 or newer is fine.)
- That's all. BotDawg works out of the box in built-in mode. A model
  account of your own is optional — step 5 explains.

## Step 1 — Unzip

Unzip the package anywhere you like — your Documents folder is fine.
You will get one folder named **BotDawg**. Everything happens inside
that folder. Don't move files out of it; BotDawg finds its parts by
looking next to itself.

## Step 2 — Open a terminal in the folder

- **Windows:** open the BotDawg folder in File Explorer, click the
  address bar, type `powershell`, press Enter.
- **Mac:** right-click the BotDawg folder in Finder →
  Services → New Terminal at Folder (or open Terminal and `cd`
  into the folder).
- **Linux:** right-click in the folder → Open Terminal Here.

Every command below is typed in that terminal, then Enter.

## Step 3 — Set it up

```
node botdawg.js setup
```

You should see a message saying BotDawg is set up in this folder.
That created your settings file (`charter.json`). Nothing was sent
anywhere — setup is entirely local.

## Step 4 — Make it yours (one screen)

```
node botdawg.js console
```

Then open this address in your browser:

```
http://127.0.0.1:7900
```

One screen does everything: tell it its **name**, **your business**,
its **voice**, your **brand color**, the **facts** it should always
know, and its **job focus** — then Save. Full details are in
**PERSONALIZATION.md**. Until you do this step it answers to
"BotDawg" and knows nothing about you; that's normal.

That same screen carries the **chat box** — BotDawg's head is on
it. Type a question, or a whole job, in plain words and it answers
in the conversation. Jobs handed over in chat follow the same
rules as the work box: the estimate and the meter apply, your caps
and permissions hold, and everything lands in the activity log.
The chat is local to this screen — it is not a texting or
messaging channel.

One switch on that screen is a permission, and it starts **off**:
letting BotDawg click "Verify you are human" checkboxes for you.
Leave it off unless a page is stopping you with that checkbox —
**PERSONALIZATION.md** explains exactly what it does and doesn't
do, and **HONEST-LIMITS.md** states its limits plainly.

Leave the console running while you work, or close it — your
settings are saved in the folder either way. Press Ctrl+C in the
terminal to stop it.

## Step 5 — Optional: connect your own model

Out of the box, BotDawg runs in **built-in mode**: every skill works,
and writing/research use templates and extracts, and say so on the
output. If you have your own model account (any OpenAI-compatible
service), you can connect it on the same console screen: the
endpoint address, and the names of the two models to use (a strong
one for writing, a fast one for short jobs). Your key itself is
never typed into BotDawg: set it as an environment variable named
`BOTDAWG_MODEL_KEY` before starting the console, and BotDawg reads
it from there. BotDawg thinks through YOUR model account — never
ours — and with no model set up it still works; it just says
"built-in mode" where that matters.

## Step 6 — Give it a first job

In the terminal:

```
node botdawg.js ask "make me a prompt for an ad for my shop"
```

BotDawg sharpens your words with its built-in Prompt Generator,
shows you the plan and the estimated cost **before** it runs, then
does the work and tells you what it made and where the file is
(everything it makes lands in the `out/` folder).

More ways to work:

```
node botdawg.js brief                 your morning brief
node botdawg.js remember "My shop is closed on Sundays"
node botdawg.js recall sunday         what it remembers
node botdawg.js usage                 today's work meter
node botdawg.js log                   everything it has done
```

Or just use the console screen for all of it — including the chat
box: type the same words there and BotDawg answers in the
conversation, then runs the job by the same rules.

## Step 7 — Leave it on (optional)

```
node botdawg.js serve
```

While that runs, BotDawg checks its schedules and its `inbox/`
folder every minute (drop a task file in `inbox/` and it runs it).
It only works while it's running — it does not run while your
computer is off, and it will tell you so.

**New in v1.0.5 — it builds websites.** Ask BotDawg to "build me a
website" (in chat, or in the job box) and it makes one complete
website page from what it knows about your business — a single HTML
file in the `out/` folder that opens in any browser and can be
handed to any host. Facts it doesn't have stay marked [fill-in] —
it never invents services, prices, or claims — and its reply lists
exactly what to teach it for a fuller site. Built-in mode builds
one page only: no online store, no checkout. And BotDawg does not
host or post the page; putting it online is your step.

## What things cost

Nothing is hidden. Work is counted in plain **units**, and what a
step costs depends on the job: sharpening a request is 1 unit;
writing a draft or preparing a message is 2; building a website is
4; watching a page is 2;
organizing a folder is 1 plus 1 per 50 files (or part of 50);
research is 1 plus 1 per source actually read; a proof run is 6; a
human check is 3 when it clicks and clears, 1 when the page has no
check to clear (or it is already cleared), and 0 when it is not
allowed. When your own model does the writing or the thinking, its
use adds 1 unit per 1,000 tokens. Every task shows an
estimate first, a live meter while it runs, and **you** set the caps
(per task and per day) on the console screen. A task that fails or
is stopped is charged **0 units**. The full ledger is in
`usage.json`; everything it ever did is in `audit.jsonl` — both
plain files you can open.

## Your data

`charter.json` = who it is. `memory.json` = what it knows.
`usage.json` = what work cost. `audit.jsonl` = everything it did.
`chat-history.json` = the chat box conversation. `out/` =
everything it made. Back up = copy the folder. Delete = delete
the folder. Nothing is ever sent to J-Dawgs.

## If something doesn't work

- **"node is not recognized / command not found"** — Node.js isn't
  installed or the terminal needs reopening after install. See
  "What you need" above.
- **The console page won't open** — make sure the
  `node botdawg.js console` command is still running in the
  terminal, and the address is exactly `http://127.0.0.1:7900`.
- **A job prints UNABLE or UNCHECKED** — that's BotDawg being
  honest, not broken: it means the job is outside its skills, or a
  check it could not really perform. Read **HONEST-LIMITS.md** for
  exactly what it can and can't do in this version.
