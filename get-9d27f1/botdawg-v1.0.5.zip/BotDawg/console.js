/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ console — ONE screen. Setup, work, memory, chat, and the
 * usage meter all live here. Every box says what goes in and what
 * comes out. No code, no jargon. It runs on your computer only
 * (127.0.0.1). The chat box (new in v1.0.2) is a local conversation
 * on this screen — BotDawg's head is on it — and runs through the
 * same planner, run loop, caps, permissions, and audit log as the
 * work boxes. It is not a chat-app channel; nothing leaves the
 * folder.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const lib = require('./lib');
const chat = require('./chat');

function page(charter, skills) {
  const skillCards = Object.values(skills).map(s => `
    <div class="card">
      <h3>${s.name}</h3>
      <p><b>Goes in:</b> ${s.inWords}</p>
      <p><b>Comes out:</b> ${s.outWords}</p>
    </div>`).join('');
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${charter.agentName} — BotDawg™</title>
<style>
  body{font-family:system-ui,Arial,sans-serif;background:#0b0e13;color:#eef2f7;margin:0;padding:20px;max-width:860px;margin:0 auto}
  h1{font-size:26px} h2{margin-top:34px;border-bottom:2px solid ${charter.brandColor};padding-bottom:6px}
  .sub{color:#9fb2c8} .card{background:#141a23;border:1px solid #26303f;border-radius:10px;padding:14px;margin:10px 0}
  label{display:block;margin:10px 0 4px;color:#c8d4e2} input,select,textarea{width:100%;padding:10px;border-radius:8px;border:1px solid #33404f;background:#0e1319;color:#fff;box-sizing:border-box}
  button{background:${charter.brandColor};color:#fff;border:0;padding:11px 18px;border-radius:8px;font-size:16px;cursor:pointer;margin-top:10px}
  button.ghost{background:#26303f} .meter{height:14px;background:#26303f;border-radius:7px;overflow:hidden}
  .meter>div{height:100%;background:${charter.brandColor}} .small{font-size:14px;color:#9fb2c8}
  pre{white-space:pre-wrap;background:#0e1319;padding:10px;border-radius:8px;overflow:auto}
  .chathead{display:flex;gap:12px;align-items:center;margin-bottom:10px}
  .avatar{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid ${charter.brandColor};flex:none;background:#0e1319}
  .avatar.big{width:58px;height:58px}
  .chatlog{height:340px;overflow-y:auto;background:#0e1319;border:1px solid #26303f;border-radius:8px;padding:12px}
  .msg{display:flex;gap:10px;margin:10px 0;align-items:flex-start}
  .msg .bubble{background:#141a23;border:1px solid #26303f;border-radius:10px;padding:10px 12px;white-space:pre-wrap;word-break:break-word;max-width:85%}
  .msg.owner{justify-content:flex-end}
  .msg.owner .bubble{background:#1b2a3d;border-color:${charter.brandColor}}
  .chatrow{display:flex;gap:10px;margin-top:10px}
  .chatrow input{flex:1}
  .chatrow button{margin-top:0}
</style></head><body>
<h1>${charter.agentName} <span class="sub">· BotDawg™ by J-Dawgs Industries</span></h1>
<p class="sub">Your agent. It runs on this computer, out of its own folder. It never phones home, never sends or posts anything, and shows you its plan and its cost before it works.</p>

<h2>Today</h2>
<div class="card"><div id="brief">Loading…</div>
<p class="small" style="margin-top:12px">Usage meter — what today has cost so far, against the daily cap YOU set. Failed or stopped tasks are charged 0.</p>
<div class="meter"><div id="meterFill" style="width:0%"></div></div><p class="small" id="meterText"></p></div>

<h2>Talk to ${charter.agentName}</h2>
<div class="card">
<div class="chathead"><img class="avatar big" src="/assets/botdawg-head.webp" alt="${charter.agentName}">
<div><b>${charter.agentName}</b><div class="small">Chat — right here on this screen, on your computer only. Ask a question, or hand it a job in plain words. Jobs given in chat run by the same rules as the work box below: plan, estimate, your caps, your permissions, everything in the activity log. It still never sends, posts, buys, pays, deletes, or logs in — ask, and it will tell you so and offer a draft instead.</div></div></div>
<div id="chatlog" class="chatlog"></div>
<div class="chatrow"><input id="chatin" placeholder="Type to ${charter.agentName}…" autocomplete="off"><button id="chatbtn" onclick="sendChat()">Send</button></div>
</div>

<h2>Give ${charter.agentName} a job</h2>
<div class="card">
<label for="ask">Say the job in your own words. Goes in: plain words (a page link helps for watch/research jobs). Comes out: a plan, an estimated cost, and — after you say go — the finished work as files.</label>
<textarea id="ask" rows="3" placeholder="e.g. Watch https://example.com/prices for changes · or: Write a post about our Saturday sale"></textarea>
<button onclick="ask()">Show me the plan</button>
<div id="plan"></div>
</div>
<div class="card">
<h3>Or pick a job</h3>
${skillCards}
<p class="small">Describe any of these jobs in the box above. ${charter.agentName} shows its plan and the estimated cost first — nothing runs without your go. A proof run needs the product's name, description, claims, and price; if any are missing, the plan says exactly which, in plain words.</p>
</div>

<h2>Make ${charter.agentName} yours</h2>
<div class="card">
<p class="small">This is the whole setup — one screen. What you type here is what ${charter.agentName} becomes: its name, its voice, your facts, your caps. Nothing here needs code.</p>
<label>Its name</label><input id="c_agentName" value="${charter.agentName}">
<label>Your name</label><input id="c_ownerName" value="${charter.ownerName || ''}">
<label>Your business</label><input id="c_ownerBusiness" value="${charter.ownerBusiness || ''}">
<label>Its voice</label><select id="c_voice">
  <option value="plain" ${charter.voice === 'plain' ? 'selected' : ''}>Plain — short sentences, no fluff</option>
  <option value="warm" ${charter.voice === 'warm' ? 'selected' : ''}>Warm — friendly, like a neighbor</option>
  <option value="formal" ${charter.voice === 'formal' ? 'selected' : ''}>Formal — measured, no slang</option></select>
<label>Brand color</label><input id="c_brandColor" type="color" value="${charter.brandColor}">
<label>Facts it should always know (one per line)</label><textarea id="c_facts" rows="3">${(charter.facts || []).join('\n')}</textarea>
<label>Your model (optional) — BotDawg thinks through YOUR model account, never ours. Base address (e.g. https://api.openai.com/v1)</label><input id="c_baseUrl" value="${charter.model.baseUrl || ''}" placeholder="Leave empty to run in built-in mode">
<label>Strong model name (writing, judgment)</label><input id="c_strongModel" value="${charter.model.strongModel || ''}">
<label>Fast model name (sorting, short jobs)</label><input id="c_fastModel" value="${charter.model.fastModel || ''}">
<p class="small">Your key is read from the environment variable <b>${charter.model.apiKeyEnv}</b> on this computer — it is never written into BotDawg's files.</p>
<label>Cap per task (work units)</label><input id="c_perTask" type="number" value="${charter.caps.perTaskUnits}">
<label>Cap per day (work units)</label><input id="c_perDay" type="number" value="${charter.caps.perDayUnits}">
<label><input type="checkbox" id="c_web" ${charter.webAccess ? 'checked' : ''} style="width:auto"> Web access (watch, research, and proof runs read public pages)</label>
<label><input type="checkbox" id="c_humancheck" ${charter.allowHumanCheck ? 'checked' : ''} style="width:auto"> Let BotDawg click 'Verify you are human' checkboxes for me</label>
<p class="small">Off unless you switch it on. With it on, when a page stops BotDawg with a "Verify you are human" checkbox, it may click that one checkbox and wait for the page to open. It clicks the checkbox only — it does not solve picture puzzles, and some sites may still refuse it; then it tells you plainly. Every use is written to the activity log below, with the page and the result.</p>
<button onclick="saveCharter()">Save — make it mine</button> <span id="saved" class="small"></span>
</div>

<h2>What ${charter.agentName} remembers</h2>
<div class="card">
<p class="small">Everything it knows, in plain sight. Add a fact, delete a fact — it is your memory, stored in this folder. Topics you ban here are never remembered.</p>
<div id="memory">Loading…</div>
<label>Teach it a fact</label><input id="newFact" placeholder="e.g. We close at 6 PM on Sundays">
<button onclick="teach()">Remember it</button>
<label>Topics it must never remember (comma separated)</label><input id="topicsOff" placeholder="e.g. health, finances">
<button class="ghost" onclick="saveTopics()">Save banned topics</button>
</div>

<h2>What it has done</h2>
<div class="card"><p class="small">The full activity log — every action, in plain words. This is the answer to "why did it do that?"</p><pre id="log">Loading…</pre></div>

<script>
async function j(u, o){ const r = await fetch(u, o); return r.json(); }
async function refresh(){
  const s = await j('/api/state');
  document.getElementById('brief').innerHTML = s.brief.replace(/\\n/g,'<br>');
  const pct = Math.min(100, s.capDay ? (s.usedToday / s.capDay) * 100 : 0);
  document.getElementById('meterFill').style.width = pct + '%';
  document.getElementById('meterText').textContent = s.usedToday + ' of ' + s.capDay + ' units used today';
  document.getElementById('memory').innerHTML = s.memory.length ? s.memory.map(f => '<p>• ' + f.text + ' <button class="ghost" onclick="forget(\\'' + f.id + '\\')">Forget</button></p>').join('') : '<p class="small">Nothing yet.</p>';
  document.getElementById('topicsOff').value = s.topicsOff.join(', ');
  document.getElementById('log').textContent = s.audit.map(e => e.at + '  ' + e.event + (e.summary ? ' — ' + e.summary : '')).join('\\n') || 'Nothing yet.';
}
async function ask(){
  const words = document.getElementById('ask').value;
  const p = await j('/api/ask', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ words }) });
  let html = '<p><b>Your words, sharpened:</b> ' + p.sharpened + '</p>';
  if (p.missing.length) html += '<p><b>Before it can run:</b></p>' + p.missing.map(m => '<p>– ' + m + '</p>').join('');
  if (p.steps.length) html += '<p><b>Plan:</b> ' + p.steps.join(' → ') + ' · <b>Estimated:</b> ' + p.estimate + ' unit(s)</p><button onclick="runPlan()">Run it</button> <span id="runOut"></span>';
  window._plan = p;
  document.getElementById('plan').innerHTML = html;
}
async function runPlan(){
  const r = await j('/api/run', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ title: document.getElementById('ask').value.slice(0,60), steps: window._plan.stepObjects }) });
  document.getElementById('runOut').textContent = 'Running…';
  const timer = setInterval(async () => {
    const t = await j('/api/task/' + r.id);
    document.getElementById('runOut').textContent = t.status + ' · ' + t.unitsUsed + ' unit(s) so far';
    if (['done','failed','capped','paused'].includes(t.status)) { clearInterval(timer); refresh(); }
  }, 800);
}
async function saveCharter(){
  const body = { agentName: v('c_agentName'), ownerName: v('c_ownerName'), ownerBusiness: v('c_ownerBusiness'), voice: v('c_voice'), brandColor: v('c_brandColor'),
    facts: v('c_facts').split('\\n').map(s => s.trim()).filter(Boolean),
    model: { baseUrl: v('c_baseUrl'), strongModel: v('c_strongModel'), fastModel: v('c_fastModel') },
    caps: { perTaskUnits: Number(v('c_perTask')), perDayUnits: Number(v('c_perDay')) }, webAccess: document.getElementById('c_web').checked, allowHumanCheck: document.getElementById('c_humancheck').checked };
  await j('/api/charter', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  document.getElementById('saved').textContent = 'Saved. Reload the page to see it in its new name and color.';
}
function v(id){ return document.getElementById(id).value; }
async function teach(){ await j('/api/remember', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text: v('newFact') }) }); document.getElementById('newFact').value=''; refresh(); }
async function forget(id){ await j('/api/forget', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) }); refresh(); }
async function saveTopics(){ await j('/api/topics', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ topics: v('topicsOff').split(',').map(s => s.trim()).filter(Boolean) }) }); refresh(); }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function addMsg(role, text){
  const log = document.getElementById('chatlog');
  const row = document.createElement('div');
  if (role === 'owner') { row.className = 'msg owner'; row.innerHTML = '<div class="bubble">' + esc(text) + '</div>'; }
  else { row.className = 'msg agent'; row.innerHTML = '<img class="avatar" src="/assets/botdawg-head.webp" alt="">' + '<div class="bubble">' + esc(text) + '</div>'; }
  log.appendChild(row);
  log.scrollTop = log.scrollHeight;
  return row;
}
async function loadChat(){
  const h = await j('/api/chat/history');
  const log = document.getElementById('chatlog');
  log.innerHTML = '';
  if (!h.turns.length) addMsg('agent', 'This is my chat box — my head is on it, and I am on the other side of it. Ask me a question, or hand me a job in plain words.');
  else h.turns.forEach(t => addMsg(t.role, t.text));
}
async function sendChat(){
  const input = document.getElementById('chatin');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  addMsg('owner', text);
  const btn = document.getElementById('chatbtn');
  btn.disabled = true;
  const thinking = addMsg('agent', '…');
  try {
    const r = await j('/api/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text }) });
    thinking.querySelector('.bubble').textContent = r.reply;
  } catch(e) { thinking.querySelector('.bubble').textContent = 'The chat hit a snag on this computer — nothing was charged. Try again.'; }
  btn.disabled = false;
  document.getElementById('chatlog').scrollTop = document.getElementById('chatlog').scrollHeight;
  refresh();
}
document.getElementById('chatin').addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });
refresh();
loadChat();
</script>
</body></html>`;
}

function serve(args, engine) {
  const port = Number((args.find(a => a.startsWith('--port=')) || '').split('=')[1]) || 7900;
  const server = http.createServer((req, res) => {
    const charter = lib.loadCharter();
    const send = (code, body, type = 'application/json') => { res.writeHead(code, { 'Content-Type': type }); res.end(typeof body === 'string' ? body : JSON.stringify(body)); };
    const body = () => new Promise(r => { const c = []; req.on('data', x => c.push(x)); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString() || '{}')); } catch { r({}); } }); });

    if (req.url === '/' && req.method === 'GET') return send(200, page(charter, engine.SKILLS), 'text/html');
    if (req.url === '/assets/botdawg-head.webp' && req.method === 'GET') {
      try { const img = fs.readFileSync(path.join(__dirname, 'assets', 'botdawg-head.webp')); res.writeHead(200, { 'Content-Type': 'image/webp', 'Content-Length': img.length }); return res.end(img); }
      catch { return send(404, { error: 'no head image' }); }
    }
    if (req.url === '/api/chat/history' && req.method === 'GET') return send(200, { turns: chat.loadHistory() });
    if (req.url === '/api/chat' && req.method === 'POST') return body().then(async b => {
      try { send(200, await chat.chatTurn(b.text, lib.loadCharter(), engine)); }
      catch (e) { lib.audit('chat-error', { summary: e.message }); send(200, { reply: 'The chat hit a snag inside my own folder — nothing was charged. The activity log has the detail.', kind: 'error' }); }
    });
    if (req.url === '/api/state') {
      const mem = lib.loadMemory();
      return send(200, { brief: engine.brief(charter), usedToday: lib.unitsToday(), capDay: charter.caps.perDayUnits, memory: mem.facts, topicsOff: mem.topicsOff || [], audit: lib.readAudit(40) });
    }
    if (req.url === '/api/charter' && req.method === 'POST') return body().then(b => { const c = lib.loadCharter(); Object.assign(c, b, { model: { ...c.model, ...(b.model || {}) }, caps: { ...c.caps, ...(b.caps || {}) } }); lib.saveCharter(c); lib.audit('charter-saved', { agentName: c.agentName }); send(200, { ok: true }); });
    if (req.url === '/api/remember' && req.method === 'POST') return body().then(b => send(200, lib.remember(b.text, b.project || 'general', 'owner')));
    if (req.url === '/api/forget' && req.method === 'POST') return body().then(b => send(200, { removed: lib.forget(b.id) }));
    if (req.url === '/api/topics' && req.method === 'POST') return body().then(b => { const m = lib.loadMemory(); m.topicsOff = b.topics; lib.saveMemory(m); send(200, { ok: true }); });
    if (req.url === '/api/ask' && req.method === 'POST') return body().then(async b => {
      const plan = engine.planFromWords(b.words, charter);
      const sharp = await engine.SKILLS.sharpen.run({ goal: b.words }, { charter });
      send(200, { sharpened: sharp.detail.variants.straight, missing: plan.missing, steps: plan.steps.map(s => s.skill), stepObjects: plan.steps, estimate: engine.estimateSteps(plan.steps) });
    });
    if (req.url === '/api/run' && req.method === 'POST') return body().then(b => {
      const id = 'task-' + lib.stamp();
      engine.runTask({ id, title: b.title || 'Console task', steps: b.steps }, { charter }).catch(() => {});
      send(200, { id });
    });
    const tm = req.url.match(/^\/api\/task\/(.+)$/);
    if (tm) {
      try { return send(200, JSON.parse(fs.readFileSync(path.join(__dirname, 'tasks', tm[1] + '.json'), 'utf8'))); }
      catch { return send(404, { error: 'no such task' }); }
    }
    send(404, { error: 'not found' });
  });
  server.listen(port, '127.0.0.1', () => console.log(`BotDawg console: http://127.0.0.1:${port} — one screen: setup, work, memory, usage. Ctrl+C stops it.`));
}

module.exports = { serve };
