# BotDawg™ — a general-purpose agent that is YOURS

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

**Big dreams for a small world.**

BotDawg is a general-purpose agent you own outright. It runs entirely on
your computer, out of this one folder. Unbox it, make it yours on one
screen, and it works — it never comes back to J-Dawgs for anything. Its
memory is a file in this folder. Its planning loop is in this folder. Its
built-in Prompt Generator is in this folder. And when you give it a model
(your own account, your own key), it thinks through YOUR model — never
ours. No J-Dawgs server, account, or permission is needed for BotDawg to
work, ever.

## What it does

- **Plans and runs multi-step work.** Say the job in plain words; BotDawg
  shows its plan and the estimated cost first, then runs it step by step,
  checking its own work as it goes. Pause it and it picks up exactly
  where it stopped — no work is lost.
- **Proof-runs product pages** (its starter specialty): give it a product
  page and the seller's own stated facts, and it checks the door for
  real — answers, says what the seller says, price matches, buy link
  works, loads in a real browser — and writes a sealed record: PASS /
  FAIL / UNCHECKED, hits and misses both.
- **Watches pages** and tells you what changed, line by line.
- **Researches questions** from sources you point it at. Every fact in
  the brief carries its source number; sources it could not open are
  listed as COULD NOT VERIFY.
- **Writes drafts in your voice** — emails, posts, pages, notes — from
  the facts it remembers. Drafts only.
- **Organizes folders**: a full catalog and an exact-duplicate report.
  It never moves or deletes anything.
- **Prepares messages** with a before-you-send checklist. It never sends.
- **Remembers your facts** across sessions — in a plain file you can
  open, edit, or delete. You can ban whole topics from its memory.
- **Sharpens rough requests** with its built-in J-Dawgs Prompt
  Generator: your words in, three ready prompts out (Straight, Detailed,
  Short), filled with what it remembers about your business. Slots it
  cannot fill stay marked [fill-in] — it never guesses.
- **Teaches itself your routines**: show it the steps once, save them as
  a personal skill, run them any time.
- **Talks with you in a chat box** (new in v1.0.2): the console
  carries a chat panel with BotDawg's head on it. Ask a question in
  plain words, or hand it a job the same way — chat runs through the
  same planner, run loop, estimate, caps, permissions, and audit log
  as the work boxes, and its answers speak in the name and voice you
  gave it. It is a local chat on your own screen, not a messaging
  channel: nothing is texted, posted, or sent anywhere.
- **Clicks a "Verify you are human" checkbox — only with your
  permission** (new in v1.0.1). The human-check skill is OFF by
  default. Switch it on (one tick on the console screen) and BotDawg
  may click that one checkbox on a page you send it to, then confirm
  the check really cleared before it reports success. It solves no
  puzzles, it does not pretend to be a person, some sites may still
  refuse it — and every use is in the activity log.
- **Runs on schedule** while it is on: standing watches and jobs in
  `schedules.json`, plus any task file dropped in `inbox/`.

## What it costs you in work — always in the open

Every task shows a **cost estimate before it runs**, in plain work
units. What a step costs depends on the job: sharpening a request is
1 unit; writing a draft or preparing a message is 2; watching a page
is 2; organizing a folder is 1 plus 1 per 50 files (or part of 50);
research is 1 plus 1 per source actually read; a proof run is 6; a
human check is 3 when it clicks and clears, 1 when the page has no
check to clear (or it is already cleared), and 0 when it is not
allowed. When your own model does the writing or the thinking, its
use adds 1 unit per 1,000 tokens. A **live meter** counts units as
work happens. **You set hard caps** per
task and per day; BotDawg stops at the cap and says so. **A task that
fails or is stopped is charged 0 units** — the attempt is logged and
marked free. The full ledger is in `usage.json`, and every action ever
taken is in `audit.jsonl`, in plain words. No opaque credits, ever.

## What it does NOT do — honest limits

- It does **not** send, post, buy, pay, delete, or log in as you.
  Consequences stay with the owner. It never asks for your passwords.
- It does **not** invent search results, facts, or prices. Jobs outside
  its skills print UNABLE in plain words instead of a fake success.
- Without a model set up, writing and research run in built-in mode
  (templates and extracts) and say so on every output. Connect your own
  model on the setup screen for full drafting and synthesis.
- Its browser check needs a browser engine: run `npm install playwright`
  in this folder once (or point `BOTDAWG_PLAYWRIGHT` at an install).
  Without one, that one check prints UNCHECKED — never a guessed pass.
- Scheduled work runs while BotDawg is running on your computer
  (`node botdawg.js serve`). It does not run while your computer is off,
  and it says so.
- No voice, no phone calls, no chat-app channels in v1. The chat box
  (v1.0.3) sits on the console screen, on your computer only — it is
  not a texting or messaging-app channel, and it reaches no one but
  you. One screen, one folder, plain files.

## Quick start

```
node botdawg.js setup        # creates your settings file
node botdawg.js console      # the one screen: setup + work + memory + meter
node botdawg.js ask "Watch https://example.com/prices for changes"
node botdawg.js brief        # your morning brief
```

## Make it yours (no code)

Open the console and fill in one screen: its **name**, **your business**,
its **voice** (plain / warm / formal), your **brand color**, the **facts**
it should always know, its **job focus**, your **model** (optional), and
your **usage caps**. Everything BotDawg produces — reports, drafts,
briefs — comes out in your name, your voice, your color.

Starter templates live in `templates/`, shaped by the jobs buyers ask
for most: proof-run a product door, watch a price page, a research
brief, follow-up drafts.

## Your data

Everything is plain files in this folder: `charter.json` (who it is),
`memory.json` (what it knows), `usage.json` (what work cost),
`audit.jsonl` (everything it did), `chat-history.json` (what you and
it said in the chat box), `out/` (everything it made).
Export = copy the folder. Delete = delete the folder. Your data is
never used to train anything, and none of it ever leaves your computer
except the public pages you tell it to read and your own model endpoint,
if you set one up.
