#!/usr/bin/env node
/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ — a general-purpose agent that is YOURS.
 *
 * BotDawg runs entirely on your computer, out of this one folder. It does
 * not phone home, it does not need J-Dawgs for anything, and it never
 * comes back to us to think: its memory is a file here, its planning loop
 * is here, its built-in Prompt Generator is here, and when you give it a
 * model (your own key, set up on one screen) it thinks through YOUR
 * model account — never ours.
 *
 * What it does: plans multi-step work and runs it — proof-runs product
 * pages, watches pages for changes, researches questions from sources
 * you point it at, writes drafts in your voice, organizes folders,
 * prepares messages (never sends), remembers your facts across sessions,
 * sharpens rough requests with its built-in Prompt Generator, and —
 * ONLY when you switch the permission on — clicks a "Verify you are
 * human" checkbox on a page you send it to (the human-check skill;
 * off by default, every use written to the audit log). New in v1.0.2:
 * a chat box on the console screen, with BotDawg's head on it — ask
 * questions or hand it jobs in plain words, through this same planner
 * and run loop. Local only; not a chat-app channel.
 *
 * What it does NOT do: it does not send, post, buy, delete, or log in as
 * you. It does not solve image puzzles or pretend to be a person. It
 * does not invent search results or facts. Jobs outside its
 * skills print UNABLE in plain words instead of a fake success.
 *
 *   node botdawg.js console          the one-screen app (setup + work)
 *   node botdawg.js ask "your words" describe a job in plain words
 *   node botdawg.js do task.json     run a task file (steps listed inside)
 *   node botdawg.js remember "..."   teach it a fact
 *   node botdawg.js recall <words>   ask its memory
 *   node botdawg.js brief            your morning brief
 *   node botdawg.js usage            today's usage meter and ledger
 *   node botdawg.js log              what it has done, in plain words
 *   node botdawg.js serve            stay on: schedules + inbox pickup
 */
'use strict';

const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const SKILLS = {};
for (const f of fs.readdirSync(path.join(__dirname, 'skills'))) {
  if (f.endsWith('.js') && f !== 'proof-run.js') {
    const s = require(path.join(__dirname, 'skills', f));
    SKILLS[s.id] = s;
  }
}

/* ---------------- planning ----------------
 * Plain words in → a plan (list of steps) or a plain statement of what
 * is missing. BotDawg asks instead of guessing.
 */

function planFromWords(words, charter) {
  const w = String(words || '').trim();
  const urls = w.match(/https?:\/\/[^\s)]+/g) || [];
  const lower = w.toLowerCase();
  const steps = [];
  const missing = [];

  if (/^remember\b/i.test(w)) {
    const fact = w.replace(/^remember( that)?\s+/i, '');
    return { steps: [{ skill: 'remember', text: fact }], missing: [] };
  }
  if (/\bwatch\b/.test(lower) && urls.length) steps.push({ skill: 'watch', url: urls[0], label: urls[0] });
  if (/verify you are human|human check|turnstile|i am (not a robot|human)|not a robot|prove you are human/.test(lower)) {
    if (!urls.length) missing.push('a human check needs the page address — paste the link of the page that is stopping you');
    else steps.push({ skill: 'human-check', url: urls[0] });
  }
  if (/\bresearch\b|\blook into\b|\bcompare\b/.test(lower)) {
    if (!urls.length) missing.push('research needs the source addresses to read — paste the links and I will read exactly those');
    else steps.push({ skill: 'research', question: w, sources: urls, effort: /\bdeep\b/.test(lower) ? 'deep' : 'standard' });
  }
  if (/\bproof|audit|check (my|the) (page|site|door|listing)\b/.test(lower)) {
    if (!urls.length) missing.push('a proof run needs the page address');
    else missing.push('a proof run needs the product name, its one-line description, its claims and its price — easiest from the console, where the form asks for each one');
  }
  if (/\borganize|catalog|tidy|duplicate\b/.test(lower)) {
    const dirMatch = w.match(/(\/[^\s]+|~\/[^\s]+)/);
    if (dirMatch) steps.push({ skill: 'organize', dir: dirMatch[1].replace(/^~\//, process.env.HOME + '/') });
    else missing.push('organize needs the folder path');
  }
  if (/\bwrite|draft\b/.test(lower)) steps.push({ skill: 'write', kind: /email/.test(lower) ? 'email' : /post/.test(lower) ? 'post' : 'note', topic: w });
  if (/\bprompt for|sharpen|make (me )?a prompt\b/.test(lower)) steps.push({ skill: 'sharpen', goal: w });
  if (!steps.length && !missing.length) {
    // General fallback: sharpen the request so the owner sees it stated
    // cleanly, and say plainly that no skill matched — never fake a run.
    return { steps: [], missing: [`No skill I have matches that job yet. I sharpened your words below so you can see them stated cleanly — and I can remember facts, watch pages, research sources you name, write drafts, organize folders, proof-run product pages, and — only with your permission switched on — click a "Verify you are human" checkbox on a page you send me to.`], sharpenOnly: true };
  }
  return { steps, missing };
}

function estimateSteps(steps) {
  return steps.reduce((a, s) => a + (SKILLS[s.skill] ? SKILLS[s.skill].estimate(s) : 1), 0);
}

/* ---------------- the run loop ----------------
 * Plan → estimate → caps checked → steps run one by one (independent
 * research/watch steps in a plan run in parallel) → each step's output
 * is verified by the skill itself → checkpoint after every step →
 * audit line for everything. A failed or capped task is charged 0.
 */

const tasksDir = path.join(__dirname, 'tasks');
fs.mkdirSync(tasksDir, { recursive: true });

async function runTask(task, { charter, onStep } = {}) {
  charter = charter || lib.loadCharter();
  const id = task.id || 'task-' + lib.stamp();
  const stateFile = path.join(tasksDir, id + '.json');
  const state = { id, title: task.title || 'Task', steps: task.steps, done: task.done || [], status: 'running', unitsUsed: 0, results: task.results || {}, startedAt: task.startedAt || new Date().toISOString() };
  const save = () => fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
  save();
  lib.audit('task-start', { id, title: state.title, steps: state.steps.length, estimate: estimateSteps(state.steps) });

  const ctx = { charter };
  for (let i = 0; i < state.steps.length; i++) {
    if (state.done.includes(i)) continue;
    if (fs.existsSync(path.join(tasksDir, id + '.pause'))) {
      state.status = 'paused';
      save();
      lib.audit('task-paused', { id, atStep: i });
      return finish(state, 0, `Paused before step ${i + 1}. Run "resume" and I will pick up right there — no work is lost.`);
    }
    const step = state.steps[i];
    const projected = lib.unitsToday() + state.unitsUsed + (SKILLS[step.skill] ? SKILLS[step.skill].estimate(step) : 1);
    if (projected > charter.caps.perDayUnits) {
      state.status = 'capped';
      save();
      lib.audit('task-capped', { id, atStep: i, cap: charter.caps.perDayUnits });
      return finish(state, 0, `Stopped by your daily cap (${charter.caps.perDayUnits} units). Nothing was charged for this task. Raise the cap in Settings or run it tomorrow.`);
    }
    if (state.unitsUsed + (SKILLS[step.skill] ? SKILLS[step.skill].estimate(step) : 1) > charter.caps.perTaskUnits) {
      state.status = 'capped';
      save();
      lib.audit('task-capped', { id, atStep: i, cap: charter.caps.perTaskUnits });
      return finish(state, 0, `Stopped by your per-task cap (${charter.caps.perTaskUnits} units). Nothing was charged for this task.`);
    }
    let result;
    if (step.skill === 'remember') {
      const r = lib.remember(step.text, step.project || 'general', 'task');
      result = { ok: r.saved, units: 0, summary: r.saved ? `Remembered: "${step.text}"` : r.reason };
    } else if (SKILLS[step.skill]) {
      try { result = await SKILLS[step.skill].run(step, ctx); }
      catch (e) { result = { ok: false, units: 0, summary: `Step failed inside the ${step.skill} skill (${e.message}).` }; }
    } else {
      result = { ok: false, units: 0, summary: `UNABLE: I do not have a "${step.skill}" skill. I will not fake it.` };
    }
    state.unitsUsed += result.units || 0;
    state.results[i] = result;
    if (onStep) onStep(i, step, result, state.unitsUsed);
    lib.audit('step', { id, step: i, skill: step.skill, ok: result.ok, units: result.units || 0, summary: result.summary });
    if (!result.ok) {
      state.status = 'failed';
      save();
      return finish(state, 0, `Stopped at step ${i + 1} (${step.skill}): ${result.summary} A failed task is charged 0 units.`);
    }
    state.done.push(i);
    save(); // checkpoint — a crash or pause loses nothing past this line
  }
  state.status = 'done';
  save();
  return finish(state, state.unitsUsed, `Done. ${state.steps.length} step(s), ${state.unitsUsed} unit(s) used.`);
}

function finish(state, charged, message) {
  lib.recordUsage({ task: state.id, title: state.title, status: state.status, unitsUsed: state.unitsUsed, charged, at: new Date().toISOString() });
  lib.audit('task-finish', { id: state.id, status: state.status, charged });
  return { state, charged, message };
}

/* ---------------- brief ---------------- */

function brief(charter) {
  const mem = lib.loadMemory();
  // Count everything the agent actually remembers and uses: the facts
  // saved in setup (charter) plus the facts taught into memory,
  // deduplicated by text so a fact living in both counts once.
  const factSet = new Set();
  for (const t of (charter.facts || [])) { const s = String(t).trim().toLowerCase(); if (s) factSet.add(s); }
  for (const f of (mem.facts || [])) { const s = String(f.text || '').trim().toLowerCase(); if (s) factSet.add(s); }
  const factCount = factSet.size;
  let watches = {};
  try { watches = JSON.parse(fs.readFileSync(path.join(__dirname, 'watches.json'), 'utf8')); } catch { /* none */ }
  const usage = lib.loadUsage();
  const today = usage.days[new Date().toISOString().slice(0, 10)] || { charged: 0, tasks: [] };
  const lines = [
    `# ${charter.agentName} — your brief`,
    '',
    `For ${charter.ownerBusiness || 'you'} · ${new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}`,
    '',
    `- Usage today: ${today.charged} unit(s) charged across ${today.tasks.length} task(s). Your caps: ${charter.caps.perTaskUnits}/task, ${charter.caps.perDayUnits}/day.`,
    `- I remember ${factCount} fact(s) for you${(mem.topicsOff || []).length ? `; topics I must not remember: ${mem.topicsOff.join(', ')}` : ''}.`,
    `- Standing watches: ${Object.keys(watches).length ? Object.entries(watches).map(([k, w]) => `${w.label || k} (last checked ${String(w.checkedAt).slice(0, 10)})`).join('; ') : 'none yet — tell me a page to watch'}.`,
    `- Model: ${charter.model.baseUrl ? 'your model is set up' : 'not set up — I am running in built-in mode (skills work; writing and research synthesis use templates and extracts)'}.`,
  ];
  return lines.join('\n');
}

/* ---------------- CLI ---------------- */

async function main() {
  const [cmd, ...rest] = process.argv.slice(2);
  const charter = lib.loadCharter();

  if (cmd === 'setup' || (!cmd && !fs.existsSync(path.join(__dirname, 'charter.json')))) {
    if (!fs.existsSync(path.join(__dirname, 'charter.json'))) lib.saveCharter(charter);
    if (rest.includes('--allow-human-check') && !charter.allowHumanCheck) {
      charter.allowHumanCheck = true;
      lib.saveCharter(charter);
      lib.audit('human-check-permission', { allowed: true, via: 'setup flag' });
      console.log('Human-check permission: ON. BotDawg may click "Verify you are human" checkboxes on pages you send it to. Every use is written to the activity log. Turn it off any time on the console screen.');
    }
    console.log(`${charter.agentName} is set up in this folder. Open the console to make it yours:\n  node botdawg.js console   →   http://127.0.0.1:7900`);
    if (!charter.allowHumanCheck) console.log('Human-check permission is OFF (the default): BotDawg will not click "Verify you are human" checkboxes unless you switch it on — on the console screen, or by running: node botdawg.js setup --allow-human-check');
    return;
  }
  if (cmd === 'console') return serveConsole(rest);
  if (cmd === 'ask') {
    const words = rest.join(' ');
    const plan = planFromWords(words, charter);
    const sharp = await SKILLS.sharpen.run({ goal: words }, { charter });
    console.log(`Your words, sharpened (built-in Prompt Generator):\n  ${sharp.detail.variants.straight}\n`);
    if (plan.missing.length) console.log('Before I can run that:\n' + plan.missing.map(m => '  - ' + m).join('\n'));
    if (!plan.steps.length) { if (sharp.files) console.log(`Full prompt set: ${sharp.files[0]}`); return; }
    const est = estimateSteps(plan.steps);
    console.log(`Plan: ${plan.steps.map(s => s.skill).join(' → ')} · estimated ${est} unit(s) · caps ${charter.caps.perTaskUnits}/task, ${charter.caps.perDayUnits}/day.`);
    if (!rest.includes('--yes') && process.argv.includes('--dry')) { console.log('Dry run — nothing was run.'); return; }
    const { state, charged, message } = await runTask({ title: words.slice(0, 60), steps: plan.steps }, { charter, onStep: (i, s, r) => console.log(`  step ${i + 1} ${s.skill}: ${r.summary}`) });
    console.log(`${message} Charged: ${charged} unit(s).`);
    return;
  }
  if (cmd === 'do') {
    const file = rest[0];
    const task = JSON.parse(fs.readFileSync(file, 'utf8'));
    console.log(`Plan: ${task.steps.map(s => s.skill).join(' → ')} · estimated ${estimateSteps(task.steps)} unit(s).`);
    const { charged, message } = await runTask(task, { charter, onStep: (i, s, r) => console.log(`  step ${i + 1} ${s.skill}: ${r.summary}`) });
    console.log(`${message} Charged: ${charged} unit(s).`);
    return;
  }
  if (cmd === 'resume') {
    const id = rest[0];
    const state = JSON.parse(fs.readFileSync(path.join(tasksDir, id + '.json'), 'utf8'));
    fs.rmSync(path.join(tasksDir, id + '.pause'), { force: true });
    const { charged, message } = await runTask(state, { charter, onStep: (i, s, r) => console.log(`  step ${i + 1} ${s.skill}: ${r.summary}`) });
    console.log(`${message} Charged: ${charged} unit(s).`);
    return;
  }
  if (cmd === 'remember') {
    const r = lib.remember(rest.join(' '), 'general', 'owner');
    console.log(r.saved ? `Remembered. I will still know that next time you open me.` : r.reason);
    return;
  }
  if (cmd === 'recall') {
    const hits = lib.recall(rest.join(' '));
    console.log(hits.length ? hits.map(h => `- [${h.id}] ${h.text}`).join('\n') : 'I do not know that yet. Tell me with: node botdawg.js remember "..."');
    return;
  }
  if (cmd === 'forget') {
    const n = lib.forget(rest.join(' '));
    console.log(n ? `Forgotten (${n}).` : 'Nothing matched that.');
    return;
  }
  if (cmd === 'memory') {
    const mem = lib.loadMemory();
    console.log(mem.facts.length ? mem.facts.map(f => `- [${f.id}] (${f.project}) ${f.text}`).join('\n') : 'My memory is empty so far.');
    return;
  }
  if (cmd === 'teach') {
    const [name, stepsFile] = rest;
    const steps = JSON.parse(fs.readFileSync(stepsFile, 'utf8'));
    fs.writeFileSync(path.join(__dirname, 'templates', name + '.json'), JSON.stringify({ name, steps }, null, 2));
    lib.audit('teach', { name, steps: steps.length });
    console.log(`Saved "${name}" as one of your personal skills. Run it any time: node botdawg.js do templates/${name}.json`);
    return;
  }
  if (cmd === 'brief') { console.log(brief(charter)); return; }
  if (cmd === 'usage') {
    const u = lib.loadUsage();
    const today = u.days[new Date().toISOString().slice(0, 10)] || { charged: 0, tasks: [] };
    console.log(`Today: ${today.charged} unit(s) charged. Caps: ${charter.caps.perTaskUnits}/task, ${charter.caps.perDayUnits}/day.`);
    for (const t of today.tasks) console.log(`  - ${t.title} — ${t.status} — used ${t.unitsUsed}, charged ${t.charged}${t.charged === 0 && t.status !== 'done' ? ' (failed or stopped runs are free)' : ''}`);
    return;
  }
  if (cmd === 'log') {
    for (const e of lib.readAudit(Number(rest[0]) || 30)) console.log(`${e.at}  ${e.event}${e.skill ? ' ' + e.skill : ''}${e.summary ? ' — ' + e.summary : ''}`);
    return;
  }
  if (cmd === 'serve') return serveLoop(charter);
  if (cmd === 'run-due') { await runDue(charter); console.log('Due schedules and inbox checked.'); return; }
  console.log('BotDawg commands: console · ask "words" · do task.json · resume <id> · remember · recall · forget · memory · teach · brief · usage · log · serve · run-due');
}

/* ---------------- schedules + inbox (always-on, while BotDawg runs) ---------------- */

async function runDue(charter) {
  let schedules = [];
  try { schedules = JSON.parse(fs.readFileSync(path.join(__dirname, 'schedules.json'), 'utf8')); } catch { /* none */ }
  const now = Date.now();
  for (const s of schedules) {
    if (!s.lastRun || now - new Date(s.lastRun).getTime() >= (s.everyMinutes || 1440) * 60000) {
      await runTask({ title: s.title || 'Scheduled job', steps: s.steps }, { charter });
      s.lastRun = new Date().toISOString();
    }
  }
  fs.writeFileSync(path.join(__dirname, 'schedules.json'), JSON.stringify(schedules, null, 2));
  const inbox = path.join(__dirname, 'inbox');
  for (const f of fs.readdirSync(inbox)) {
    if (!f.endsWith('.json')) continue;
    const task = JSON.parse(fs.readFileSync(path.join(inbox, f), 'utf8'));
    await runTask(task, { charter });
    fs.renameSync(path.join(inbox, f), path.join(inbox, 'done-' + f));
    lib.audit('inbox-task', { file: f });
  }
}

async function serveLoop(charter) {
  console.log(`${charter.agentName} is on. Schedules and the inbox folder are checked every minute, on this computer. Ctrl+C stops me — nothing runs while I am off, and I say so.`);
  for (;;) { await runDue(charter); await new Promise(r => setTimeout(r, 60000)); }
}

/* ---------------- console (defined in console.js) ---------------- */

function serveConsole(args) {
  require('./console').serve(args, { runTask, planFromWords, estimateSteps, brief, SKILLS });
}

if (require.main === module) main().catch(e => { console.error('BotDawg stopped with an error:', e.message); process.exit(1); });

module.exports = { runTask, planFromWords, estimateSteps, brief, SKILLS };
